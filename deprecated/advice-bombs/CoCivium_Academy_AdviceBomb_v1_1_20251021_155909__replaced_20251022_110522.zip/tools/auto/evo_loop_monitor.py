
#!/usr/bin/env python3
# Minimal drift monitor: lists PAIR nodes missing review_date or with 'TBD' and prints suggestions.
import json, pathlib, datetime
PAIR = pathlib.Path('academy/PAIR')
now = datetime.datetime.utcnow().date()
issues = []
if PAIR.exists():
    for manifest in PAIR.rglob("manifest.json"):
        data = json.loads(manifest.read_text())
        rd = data.get('review_date','TBD')
        if rd == 'TBD':
            issues.append({"path":str(manifest),"issue":"missing review_date"})
        else:
            try:
                d = datetime.date.fromisoformat(rd.split('T')[0])
                if d <= now:
                    issues.append({"path":str(manifest),"issue":"review overdue","due":rd})
            except Exception:
                issues.append({"path":str(manifest),"issue":"invalid review_date","value":rd})
print(json.dumps({"issues":issues}, indent=2))
