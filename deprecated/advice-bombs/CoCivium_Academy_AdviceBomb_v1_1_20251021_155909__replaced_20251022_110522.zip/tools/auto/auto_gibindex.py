
#!/usr/bin/env python3
# Harvest @@Term@@ patterns and append to GIBindex TERMS.md/TERMS.json (no overwrite, idempotent-ish).
import re, json, pathlib, datetime
ROOT = pathlib.Path('.')
terms_json = ROOT/'docs'/'gibindex'/'TERMS.json'
db = {"version":"1.0","generated":datetime.datetime.utcnow().isoformat()+"Z","terms":[]}
if terms_json.exists():
    db = json.loads(terms_json.read_text())
seen = {t['term'].lower() for t in db.get('terms',[])}
pattern = re.compile(r'@@([A-Z][A-Za-z0-9\-]+)@@')
for p in ROOT.rglob("*.*"):
    if any(seg in p.parts for seg in ['node_modules','.git','.github']): continue
    try:
        text = p.read_text(encoding='utf-8', errors='ignore')
    except: 
        continue
    for m in pattern.findall(text):
        if m.lower() not in seen:
            db['terms'].append({"term":m,"expansion":None,"definition":"TBD","see_also":[]})
            seen.add(m.lower())
terms_json.write_text(json.dumps(db, indent=2))
print("auto_gibindex: harvested terms; wrote TERMS.json")
