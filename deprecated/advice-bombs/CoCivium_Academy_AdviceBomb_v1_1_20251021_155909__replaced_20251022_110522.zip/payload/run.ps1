
param(
  [Parameter(Mandatory=$true)][string]$RepoRoot,
  [switch]$Force
)
$ErrorActionPreference="Stop"; Set-StrictMode -Version Latest
function Copy-Tree($src, $dst, $force) {
  $files = Get-ChildItem -Path $src -Recurse -File
  foreach ($f in $files) {
    $rel = $f.FullName.Substring($src.Length).TrimStart('\','/')
    $target = Join-Path $dst $rel
    $dir = Split-Path $target -Parent
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    if ((-not (Test-Path $target)) -or $force) {
      Copy-Item -Path $f.FullName -Destination $target -Force
    } else {
      Write-Host "[SKIP] $target exists (use -Force to overwrite)" -ForegroundColor Yellow
    }
  }
}
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root = Split-Path -Parent $Here
Copy-Tree (Join-Path $Root "docs")   (Join-Path $RepoRoot "docs")   $Force
Copy-Tree (Join-Path $Root "academy")(Join-Path $RepoRoot "academy")$Force
Copy-Tree (Join-Path $Root "tools")  (Join-Path $RepoRoot "tools")  $Force
Copy-Tree (Join-Path $Root "site")   (Join-Path $RepoRoot "site")   $Force
Copy-Tree (Join-Path $Root "payload")(Join-Path $RepoRoot "payload")$Force
Copy-Tree (Join-Path $Root "_hp.manifest.json") (Join-Path $RepoRoot "_hp.manifest.json") $Force
Write-Host "[DONE] Staged AdviceBomb v1.1 into $RepoRoot" -ForegroundColor Green
