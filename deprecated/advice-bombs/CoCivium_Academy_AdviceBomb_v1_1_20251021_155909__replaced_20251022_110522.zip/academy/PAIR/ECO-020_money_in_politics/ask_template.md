
# ASK — Money in Politics
- What would falsify the claim that caps+disclosure reduce capture?
- Competing hypotheses: disclosure theater vs real deterrence.
- Evidence: capture indices pre/post reform; donation concentration; policy skew measures.
- Failure modes: evasion via PACs/shells; jurisdiction arbitrage.
- Pilot: 12‑month cap+real‑time disclosure with random audits; thresholds defined.
