
# Money in Politics — Current Synthesis (v0.1)
**Direction:** Caps + real‑time disclosure + conflict enforcement are likely to reduce capture pressure where enforcement is credible and evasion channels are closed by design (beneficial ownership checks; cross‑jurisdiction attestation).  
**Caveats:** Without independent audit and penalties proportionate to hidden risk, reforms decay into disclosure theater.
