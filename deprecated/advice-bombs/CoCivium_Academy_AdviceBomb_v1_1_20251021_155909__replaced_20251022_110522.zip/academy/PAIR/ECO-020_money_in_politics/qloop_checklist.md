
- [x] Intent & uncertainty registered
- [x] Competing explanations listed
- [ ] Evidence bound with provenance
- [ ] Pilot thresholds defined
- [ ] Synthesis published; review date set
