
async function loadGIB(){
  const res = await fetch('/docs/gibindex/TERMS.json');
  return await res.json();
}
function expandTerms(root=document){
  loadGIB().then(db=>{
    const map = new Map(db.terms.map(t=>[t.term.toLowerCase(), t]));
    root.querySelectorAll('[data-term]').forEach(el=>{
      const key = el.getAttribute('data-term').toLowerCase();
      if(map.has(key)){
        const t = map.get(key);
        el.classList.add('gib-term');
        el.setAttribute('title', (t.expansion? (t.term+' — '+t.expansion+': '): (t.term+': ')) + t.definition);
      }
    });
  });
}
document.addEventListener('DOMContentLoaded', ()=>expandTerms());
