
# CoNeura v1 — L0 Domain Registry (16 + 2 overlays)
Stable three-letter codes aligning CoCore, Academy (PAIR), and CoAudit.

- L0 domains are stable; growth happens via subdomains (L1/L2).
- Overlays (EVO, LEG) are cross-cutting reviews/metrics.

Use `docs/domains/RFC_TEMPLATE.md` for changes.
