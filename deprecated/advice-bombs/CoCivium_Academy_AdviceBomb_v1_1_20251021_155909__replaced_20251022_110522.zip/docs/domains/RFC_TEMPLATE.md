
# Domain RFC Template
- Proposal: add/modify domain code
- Rationale & scope
- Backward compatibility / migration
- Impacted assets (CoCore/Academy/CoAudit/site)
- Sunset / review date
