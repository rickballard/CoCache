
# Ambiguity Log
Record ambiguous terms, conflicts, and decisions to minimize misinterpretation.
