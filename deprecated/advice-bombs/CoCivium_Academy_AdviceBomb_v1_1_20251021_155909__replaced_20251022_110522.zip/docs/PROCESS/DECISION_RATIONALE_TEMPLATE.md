
# Decision Rationale
- Context
- Alternatives considered
- Evidence & trade-offs
- Decision & caveats
- Review date
