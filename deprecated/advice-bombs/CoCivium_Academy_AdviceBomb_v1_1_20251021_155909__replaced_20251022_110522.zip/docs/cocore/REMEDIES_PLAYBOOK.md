
# Remedies Playbook (Draft)
Describe canonical remedies for frequent failure modes, with pilots, thresholds, and rollback criteria.
