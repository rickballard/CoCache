
# Best vs Worst Remedies — Mapping Template
| domain_code | problem_statement | best_practice_ref | best_remedy_summary | worst_anti_pattern | evidence_links | notes |
|---|---|---|---|---|---|---|
