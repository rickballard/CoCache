
# GIBindex — Terms Catalogue (seed)

| Term | Expansion | Definition | See Also |
|---|---|---|---|
| PAIR | Partnered AI Reasoning | Human–AI dialogue unit replacing static FAQs. | ASK; Q-Loop |
| ASK | Adaptive Socratic Kernel | Prompt engine driving a PAIR. | PAIR |
| Q-Loop | Question–Evidence–Synthesis–Audit loop | Method cycle for reasoning quality. | PAIR; ASK |
| Halo | — | Dynamic, auditable credential showing wisdom growth. | RepTag |
| RepTag | Reputation Tag | Public pseudonymous identity trail for contributions. | Halo |
| CoCivia | — | CoCivium-aligned AI collective for certification & audit; non-sovereign. | CoCivium |
| CoNeura | — | Taxonomy of societal domains (L0 registry). | domains |
| CoCacheGlobal | — | Distributed attestation mesh and heartbeat hub. | CoCivia |
| GIBindex | Gibberlink Index | Global catalogue of invented terms and definitions. | lexicon |
| AdviceBomb | — | Bundled deliverable with strategy, docs, DO-blocks. | package |
