# Bootstrap EEL into orphaned repos
Write-Output 'Injecting evolution scaffolding...'