# 30‑minute Demo Agenda (onsite or virtual)

**0–5 min** — Context: Business Transformation challenges, “vibe‑coding” concept, guardrails
**5–15 min** — Live micro‑workflow build (e.g., compile bullets from 3 docs → 1‑page brief; CSV → chart → PPT slide)
**15–25 min** — Practitioner drives: repeat run, make a change, capture the runbook
**25–30 min** — Pilot proposal, success metrics, Q&A
