# smoke.ps1 — local smoke test

pwsh -v
pwsh -File scripts/Discover-Metrics.ps1 -Owner rickballard -ShallowClone
$today = Get-Date -Format 'yyyy-MM-dd'
$target = Join-Path "reports" $today
New-Item -ItemType Directory -Force -Path $target | Out-Null
Add-Content (Join-Path $target "_SMOKE_OK.txt") ("CoAudit finished on {0} UTC" -f (Get-Date -AsUTC))
Write-Host "Smoke OK. See reports/$today"
