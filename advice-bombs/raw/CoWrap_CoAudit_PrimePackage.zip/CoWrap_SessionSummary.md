# CoWrap: CoAudit × CoCache (InSeed kickoff) — 2025-10-20

## What we delivered (verifiable)
- **ZIPs landed in default branches**:
  - CoAudit → `advice-bombs/uploads/CoAudit_AdviceBomb_20251019_185428_v3.zip`
  - CoAudit → `advice-bombs/uploads/InSeed_Flagship_ServiceLine_Pkg.zip`
  - CoCache → `advice-bombs/uploads/InSeed_Flagship_ServiceLine_Pkg.zip` (**duplicate**, intentional)
- **Context README** files placed alongside uploads to explain purpose and duplication.
- **CI fixed for CoAudit**: replaced broken `powershell/powershell@v1` usage; job runs with runner `pwsh` and uploads `coaudit-reports` artifact.
- **Smoke evidence**:
  - Local: `reports/YYYY-MM-DD/metrics.discovery.json`, `metrics.registry.json`, and `reports/stream/metrics.YYYYMMDD.ndjson` created by `scripts/Discover-Metrics.ps1`.
  - CI: run logs show “Discovery complete. See: …” and artifact `coaudit-reports` finalized.

## Why it matters
- **CoAudit** = read-only discovery probe. It inventories metrics definitions, manifests, and workflow emissions across repos without mutating them.
- **CoCache** = append-only memory/archives, ideal target for periodic ingestion of CoAudit’s NDJSON stream and JSON registries.
- This separation enforces safety and repeatability for **InSeed.com’s flagship service line**: *discover → artifact → ingest*, never guessing or modifying source of truth.

## Philosophy (operational)
- **Trust & Verify**: publish artifacts, not opinions; every claim has a path + SHA + artifact.
- **Composable**: CoAudit feeds CoCache; CoCache powers eyes/dashboards (e.g., CoCivium) without tight coupling.
- **Small, safe steps**: ship minimal discovery; iterate on validation and schemas.

## What still needs doing
1. **Secret** — ensure `secrets.COAUDIT_RO_TOKEN` (read-only) exists in CoAudit.
2. **Automated ingestion (CoCache)** — schedule fetching of `coaudit-reports` artifact and append NDJSON to `reports/stream/` (see `workflows/cocache_ingest_artifact.yml`).
3. **Schema hardening** — add lightweight validation for `*.metrics.(yml|yaml|json)` and table formats in `METRICS_INDEX.md`.
4. **Duplication label** — optionally rename duplicate InSeed ZIP in CoCache to include `dup-of-CoAudit` for machine detection.
5. **Docs** — add short explainer in `CoAudit/reports/` describing artifact fields and intended consumer.

## Proof points to show the prime/lead
- GitHub API/`gh api` listings show the binaries present.
- CI logs: checkout @ main → `pwsh -v` → discovery SHAs echoed → “Discovery complete” → upload-artifact success with size + digest.
- Local `reports/` files exist and open.

---

### Hand-off
This package is the session’s canonical wrap: **assets verified, CI green, artifacts produced**.  
Prime/lead can wire ingestion + dashboards next.
