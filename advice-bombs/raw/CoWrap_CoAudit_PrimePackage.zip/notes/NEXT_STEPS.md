# NEXT_STEPS.md

1) Secrets: add `COAUDIT_RO_TOKEN` (CoAudit) and `COCACHE_GH_TOKEN` (CoCache) with minimal scopes.
2) Enable `workflows/cocache_ingest_artifact.yml` in CoCache to pull CoAudit artifacts nightly.
3) Add JSON schema checks for `*.metrics.*` and table parsing for `METRICS_INDEX.md`.
4) Add a tiny CoCivium view that reads `metrics.ingested.ndjson` from CoCache and renders a table.
