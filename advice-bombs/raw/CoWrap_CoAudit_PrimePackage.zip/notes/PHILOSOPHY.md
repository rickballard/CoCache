# PHILOSOPHY.md

- **Read-only audit, append-only cache.** Keep discovery and persistence concerns decoupled.
- **Evidence over assumptions.** Emit JSON/NDJSON with file paths and SHAs; humans and machines can reason over it.
- **Composable pipelines.** Let CoCivium subscribe to CoCache streams without reaching back into source repos.
- **Iterate safely.** Small PRs, observable artifacts, reversible moves.
