# VERIFY_CHECKLIST.md

Use this list to confirm the state quickly and unambiguously.

## Files present
- [ ] CoAudit contains:
  - [ ] `advice-bombs/uploads/CoAudit_AdviceBomb_20251019_185428_v3.zip`
  - [ ] `advice-bombs/uploads/InSeed_Flagship_ServiceLine_Pkg.zip`
- [ ] CoCache contains:
  - [ ] `advice-bombs/uploads/InSeed_Flagship_ServiceLine_Pkg.zip` (duplicate by design)

## CI status
- [ ] `CoAudit (read-only discovery)` workflow exists as `audit.yml`.
- [ ] Manual dispatch succeeds.
- [ ] Logs show “Discovery complete. See:” and 3 file paths under `reports/`.
- [ ] Artifact `coaudit-reports` is finalized and downloadable.

## Local smoke (optional)
- [ ] Run `scripts/Discover-Metrics.ps1 -Owner rickballard -ShallowClone` locally.
- [ ] Confirm `reports/YYYY-MM-DD/*.json` and `reports/stream/*.ndjson` exist.
- [ ] (Optional) create `_SMOKE_OK.txt` in today’s `reports/` folder.
