# gh_commands.ps1 — repeatable smoke & verification

# Show CoAudit uploads
gh api repos/rickballard/CoAudit/contents/advice-bombs/uploads --jq '.[].name'
gh api repos/rickballard/CoAudit/contents/advice-bombs/uploads/InSeed_Flagship_ServiceLine_Pkg.zip --jq '.size'
gh api repos/rickballard/CoAudit/contents/advice-bombs/uploads/CoAudit_AdviceBomb_20251019_185428_v3.zip --jq '.size'

# Show CoCache duplicate
gh api repos/rickballard/CoCache/contents/advice-bombs/uploads --jq '.[].name'
gh api repos/rickballard/CoCache/contents/advice-bombs/uploads/InSeed_Flagship_ServiceLine_Pkg.zip --jq '.size'

# Trigger CoAudit audit.yml and stream logs
gh workflow run audit.yml --repo rickballard/CoAudit --ref main
$run = gh run list --repo rickballard/CoAudit --limit 1 --json databaseId -q '.[0].databaseId'
gh run view $run --repo rickballard/CoAudit --log

# Download artifact (if present)
gh run download --repo rickballard/CoAudit --name coaudit-reports
