
# HOWTO: CoPong receipts (triple‑click mode)

- Receipts can be printed as **single-line** comments (triple-click to copy).
- Only emit **one receipt per cycle**. For watchers that print internally, set `emit=external` in the ping.
- Prefer violet theme for visibility; use `-OneLine` to reduce copy errors.
