
# CoSuite Bundle 001 — scripts + workflows

This bundle installs/updates:
- **CoCache**: watcher, emitter, indexer, guard/indexer workflows, HOWTO, `.gitattributes`
- **CoAgent**: emitter, consumer, handshake workflows, guard, intent README, `.gitattributes`

## Install (one small CoPing)

1) Download this zip to your machine.
2) Extract to a temp folder, then run in **PowerShell 7**:

```powershell
$Root = "$HOME\Documents\GitHub"   # adjust if different
$Zip   = "$HOME\Downloads\CoSuite_Bundle_001.zip"
$Tmp   = "$HOME\Downloads\CoSuite_Bundle_001"
Expand-Archive -Force -Path $Zip -DestinationPath $Tmp

# Copy into repos (preserve structure)
Copy-Item -Recurse -Force (Join-Path $Tmp 'CoCache/*')  (Join-Path $Root 'CoCache')
Copy-Item -Recurse -Force (Join-Path $Tmp 'CoAgent/*')  (Join-Path $Root 'CoAgent')

# Commit/push CoCache (main is open)
git -C (Join-Path $Root 'CoCache') add -- .
git -C (Join-Path $Root 'CoCache') commit -m "bundle001: scripts+workflows+howto+attrs" ; git -C (Join-Path $Root 'CoCache') push

# Commit CoAgent on a feature branch (main protected)
$ts = Get-Date -Format "yyyyMMdd-HHmmss"
$CoAgent = (Join-Path $Root 'CoAgent')
git -C $CoAgent switch -c "feat/bundle001-$ts"
git -C $CoAgent add -- .
git -C $CoAgent commit -m "bundle001: emitter+consumer+handshake workflows+guard+attrs" ; git -C $CoAgent push -u origin HEAD

# Emit single-line receipts (triple-click)
$EmitCoCache = Join-Path $Root 'CoCache/scripts/Emit-CoPongReceipt.ps1'
pwsh -NoProfile -File $EmitCoCache `
  -SessionId "coagent-2025w42-sLead" -CycleId "bundle001-CoCache" -Attempt 1 -Status ready `
  -RepoName "CoCache" -Branch "main" -Prev "-" -NewSha (git -C (Join-Path $Root 'CoCache') rev-parse --short HEAD) `
  -LinesUp "bundle: installed scripts+workflows+howto+attrs" -LinesDown "next: verify CI" -Theme violet -OneLine

$EmitCoAgent = Join-Path $Root 'CoAgent/scripts/Emit-CoPongReceipt.ps1'
$branch = (git -C $CoAgent rev-parse --abbrev-ref HEAD)
$compareUrl = "https://github.com/rickballard/CoAgent/compare/main...$branch"
pwsh -NoProfile -File $EmitCoAgent `
  -SessionId "coagent-2025w42-sLead" -CycleId "bundle001-CoAgent" -Attempt 1 -Status "needs-PR" `
  -RepoName "CoAgent" -Branch $branch -Prev "-" -NewSha (git -C $CoAgent rev-parse --short HEAD) `
  -LinesUp "bundle: installed emitter+consumer+workflows+guard+attrs" -LinesDown "next: open PR → $compareUrl" -Theme violet -OneLine
```

3) Paste the two **single-line receipts** back here.
