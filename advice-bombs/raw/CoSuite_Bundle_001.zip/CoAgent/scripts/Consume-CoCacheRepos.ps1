
param(
  [string]$CoCacheRepos = "$HOME\Documents\GitHub\CoCache\docs\intent\repos.json",
  [string]$OutHandshake = "$HOME\Documents\GitHub\CoAgent\docs\HANDOFFS\HANDSHAKE.md"
)
$ErrorActionPreference='Stop'; Set-StrictMode -Version Latest
if(!(Test-Path $CoCacheRepos)){ throw "Missing $CoCacheRepos" }
$j = Get-Content $CoCacheRepos -Raw | ConvertFrom-Json
$stamp = Get-Date -Format o
New-Item -Force -ItemType Directory (Split-Path $OutHandshake) | Out-Null

$rows = foreach($r in $j.repos){
  "| !{0} | {1} | {2} |" -f $r.name, ($r.role ?? 'unknown'), ($r.path ?? '?')
}

$md = @"
# CoAgent ⇄ CoCache Handshake
Updated: $stamp

Source: CoCache/docs/intent/repos.json

| !Repo | Role | Local Path |
|------:|------|------------|
$([string]::Join("`n", $rows))
"@
$md | Set-Content -Encoding UTF8 $OutHandshake
