
# CoAgent Intent

- Consumes AllRepos from CoCache: `../CoCache/docs/intent/repos.json`
- Handshake doc: `docs/HANDOFFS/HANDSHAKE.md`
