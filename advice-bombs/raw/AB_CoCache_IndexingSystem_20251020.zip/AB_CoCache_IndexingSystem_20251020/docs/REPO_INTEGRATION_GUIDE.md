
## Integration Guide for CoCache Repo

- Recommended location: `CoCache/index/`
- Maintain `units/`, `schemas/`, `MANIFEST.json`, `README.md`
- Index becomes the cognitive substrate for AI-augmented session orchestration.
- Include `CoCacheGlobal` references for future distributed cognition sync.
