
## Assembly Considerations

- Atomic unit should be clearly defined: ConceptIntentUnit (CIU).
- Include rich metadata: UUID, canonical label, aliases, embedding[], lineage[], links[], AI tips.
- Place in `/index/units/` with append-only versioning.
- Sidecar index must be usable by CoAgent and embeddable in CoWraps and AdviceBombs.
- Questions to ask before adding: Is this duplicative? How does it evolve prior units?
