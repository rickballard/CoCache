# Troubleshooting

## Hard reloads
- Keep DevTools open → Network → check **Disable cache** → Ctrl+R / Ctrl+Shift+R.

## Console nudges (paste in DevTools Console; NOT PowerShell)
```js
// Ensure one group visible & draw
window.vis = window.vis || {};
if (!(vis.countries||vis.parties||vis.modes)) vis.modes = true;
encodeState && encodeState();
draw && draw();

// Equalize if available
if (typeof total==='function' && typeof equalize==='function') {
  const t = total(); if (!t || t===0) equalize();
  encodeState && encodeState();
  draw && draw();
}

// Show explain for first visible
if (Array.isArray(ENTITIES) && typeof showExplainFor==='function') {
  const e = ENTITIES.find(e =>
    (e.group==='mode' && vis.modes) ||
    (e.group==='party' && vis.parties) ||
    (e.group==='country' && vis.countries)
  ) || ENTITIES[0];
  e && showExplainFor(e);
}
```

## If buttons don’t respond
- Try hotkeys (E/1/2/3). If these work, button text matching may have failed—add fixed `id`s in HTML.
- Ensure `plane-explain.js` and `plane-model.js` are included after `plane.js` with `defer`.
