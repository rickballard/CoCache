# NAV_FIX — Add top nav link to /plane-app/
param(
  [string]$RepoRoot = "."
)
$ErrorActionPreference='Stop'
Set-Location $RepoRoot
$candidates = @('index.html','site\index.html','docs\index.html','public\index.html','www\index.html')
$landing = $candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $landing) { throw "Couldn't find a landing index.html in: $($candidates -join ', ')" }
$html = Get-Content $landing -Raw
if ($html -notmatch '(?is)<nav[^>]*>') {
  $html = $html -replace '(?is)<body([^>]*)>', '<body$1><nav style="padding:10px 0;border-bottom:1px solid #223044;margin-bottom:18px"></nav>'
}
if ($html -notmatch '/plane-app/') {
  $html = $html -replace '(?is)(<nav[^>]*>)', '$1<a href="/plane-app/" style="margin:0 12px; text-decoration:none; color:#2b72ff;">Perspective Plane</a>'
}
Set-Content -NoNewline $landing -Value $html
git add $landing; git commit -m "nav: add Perspective Plane link to top navigation"; git push
"✅ NAV_FIX done"
