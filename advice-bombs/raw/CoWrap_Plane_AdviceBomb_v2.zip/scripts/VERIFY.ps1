# VERIFY — Quick checks for Perspective Plane
param(
  [string]$Url = "https://copolitic.org/plane-app/"
)
Write-Host "Open Chrome DevTools → Network → check 'Disable cache' and load $Url"
Write-Host "Expect: blue dots, hotkeys E/1/2/3 working, click dot updates Notes/Sources."
