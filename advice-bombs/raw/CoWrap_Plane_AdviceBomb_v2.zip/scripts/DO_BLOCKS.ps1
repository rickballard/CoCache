# DO_BLOCKS — Perspective Plane hardening & scaffolding (idempotent)
param(
  [string]$RepoRoot = "."
)
$ErrorActionPreference='Stop'
Set-Location $RepoRoot

# 01 — Cache-bust plane.js (defer) and clean prior helper scripts
$idx = 'plane-app\index.html'
$js  = 'plane-app\plane.js'
if (-not (Test-Path $idx) -or -not (Test-Path $js)) { throw "Missing plane-app files." }
$html = Get-Content $idx -Raw
$ts = [string](Get-Date -UFormat %s)
$planeTag = "<script src=""plane.js?v=$ts"" defer></script>"
$html = $html -replace '(?is)<script\s+src="plane\.js(?:\?v=[^""]*)?"[^>]*></script>', $planeTag
$removeIds = @('wire-plane-buttons','plane-boot-ensure','plane-rescue','plane-boot-guard')
foreach ($id in $removeIds) { $html = $html -replace "(?is)<script\s+id=""$id""[^>]*>.*?</script>","" }
Set-Content -NoNewline $idx -Value $html

# 02 — Window exports (append to plane.js if absent)
$src = Get-Content $js -Raw
if ($src -notmatch 'WINDOW_EXPORTS') {
  $exports = @"
/* WINDOW_EXPORTS (idempotent) */
;(() => { try {
  const g = (typeof window==='object') ? window : null; if (!g) return;
  g.PLANE = Object.assign(g.PLANE||{}, {
    vis:(typeof vis!=='undefined')?vis:undefined,
    draw:(typeof draw==='function')?draw:undefined,
    total:(typeof total==='function')?total:undefined,
    equalize:(typeof equalize==='function')?equalize:undefined,
    encodeState:(typeof encodeState==='function')?encodeState:undefined,
    showExplainFor:(typeof showExplainFor==='function')?showExplainFor:undefined,
    ENTITIES:(typeof ENTITIES!=='undefined')?ENTITIES:undefined,
    REGISTRY:(typeof REGISTRY!=='undefined')?REGISTRY:undefined
  });
} catch {} })();
/* END WINDOW_EXPORTS */
"@
  ($src + "`r`n" + $exports) | Set-Content -NoNewline $js
}

git add $idx $js; git commit -m "plane: cache-bust + WINDOW_EXPORTS"; git push
"✅ DO_BLOCKS applied"
