# CoWrap: Perspective Plane — Advice Bomb
Generated: 2025-10-20 05:36:41

This bundle captures the current state, the intent, and the concrete steps to keep
`/plane-app/` working and evolving on **CoPolitic.org**.

## TL;DR
- Plane page lives at `/plane-app/` and renders a 2D chart with blue points.
- We added **boot guards**, **window exports**, **button wiring**, **notes/sources scaffold**,
  and a **transparent scoring model** scaffold.
- Common blockers are **caching / service workers**, **load order**, and **stale HTML**.
- Use the DO BLOCKS in `scripts/DO_BLOCKS.ps1` from the repo root to reapply fixes idempotently.
- If homepage menu is missing, run `scripts/NAV_FIX.ps1` to inject a top-nav link pointing to `/plane-app/`.

## Files
- `Status.md` — checklist of what’s shipped and what to verify next
- `BPOE-Lessons.md` — the reproducible failure modes and best practices
- `Troubleshooting.md` — copy/paste console nudges + chrome cache nukes
- `Data-Schema.json` — entity schema (scores + sources)
- `Example-entities.v1.json` — demo data
- `CHANGELOG-snippet.md` — what changed this session
- `scripts/DO_BLOCKS.ps1` — hardening + scaffold steps
- `scripts/NAV_FIX.ps1` — adds a top nav link to /plane-app/
- `scripts/VERIFY.ps1` — quick verifications for dots, buttons, panel

## Placement on CoCache
- Add this folder into `CoCache/CoWraps/` (or `CoCache/Packages/Plane/`).
- Create a short note in the prime/lead session pointing at this bundle and run `scripts/VERIFY.ps1` post-deploy.
