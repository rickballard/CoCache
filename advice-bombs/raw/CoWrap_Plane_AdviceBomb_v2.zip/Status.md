# Status & Verification

## Shipped
- `/plane-app/`:
  - Boot guard to ensure at least one group visible and force draw
  - Window exports: `window.PLANE` exposes {vis, draw, total, equalize, encodeState, showExplainFor, ENTITIES, REGISTRY}
  - Button wiring (Equalize, Reset, Toggles) + hotkeys (E, 1,2,3)
  - Notes/Sources panel container + showExplainFor wrapper (`plane-explain.js`)
  - Versioned data scaffold: `plane-app/data/entities.v1.json`
  - Transparent model: `plane-app/plane-model.js` (maps scores→(x,y), freshness decay)
  - Hint strip under controls

## To Verify (manual)
- Open Chrome DevTools → Network → **Disable cache** (keep open).
- Visit `/plane-app/`:
  - Blue dots visible
  - Hotkeys work: E equalize; 1/2/3 toggle groups
  - Clicking a dot updates Notes & Sources panel
- Homepage `/` has a visible **Perspective Plane** link; if not, run NAV_FIX.ps1

## Next
- Replace placeholder sources in `entities.v1.json` with real citations.
- Expand `PLANE_META` entries in `plane-explain.js` for robust explain text + links.
- Decide hosting model for homepage (which file actually serves `/`).
