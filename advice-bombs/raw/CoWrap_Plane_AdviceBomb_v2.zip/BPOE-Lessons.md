# BPOE: Lessons from Perspective Plane

## 1) Cache / SW
- Use DevTools → Network → **Disable cache** for all reloads while validating changes.
- If a service worker exists, unregister: `navigator.serviceWorker.getRegistrations().then(rs=>rs.forEach(r=>r.unregister()))`.
- Clear `caches` API: `caches.keys().then(keys=>Promise.all(keys.map(k=>caches.delete(k))))`.

## 2) Load Order
- Add `defer` to local `<script src="...">` where possible.
- Add a "boot guard" that runs on `DOMContentLoaded` and `load` with a small timeout.

## 3) Button Wiring
- Prefer wiring by stable `id` rather than text content to avoid localization or copy tweaks.
- Add keyboard shortcuts as a resilient fallback.

## 4) Data + Provenance
- Store versioned datasets under `plane-app/data/` (`entities.vN.json`).
- Keep sources array alongside scores; compute (x,y) via a transparent model.
- Show citations under the chart; expose last-updated stamp.

## 5) Diagnostics
- Expose `window.PLANE` bag for quick inspection:
  - `PLAN E.vis`, `PLANE.draw()`, `PLANE.total()`, etc.
- Keep `_planeError/_planeWireError/_planeModelErr` hooks for quick error surfacing.
