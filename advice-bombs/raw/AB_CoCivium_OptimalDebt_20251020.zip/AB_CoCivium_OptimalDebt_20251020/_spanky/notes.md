# AdviceBomb Handler Notes — Optimal Debt & Fiscal Balance

**Package date:** 2025-10-20

This package encodes both **philosophical** and **operational** understandings of public debt for CoCivium’s hybrid economic ecosystem.

## What the lead/prime session should do (quick checklist)
1. Create an `insights/Insight_OptimalDebt` pair using the two `.md` files:
   - `Insight_OptimalDebt_Philosophy.md`
   - `Insight_OptimalDebt_Practice.md`
2. Update FinFlow’s model documentation to incorporate fiscal-balance heuristics.
3. Register a new *CoAudit Congruence Test* to check fiscal stance against real-capacity metrics.
4. Add educational mapping for CoPolitic’s outreach: “Fiscal Myths and Realities.”
5. Propagate the philosophical section to CoCore’s “Principles of Economic Governance.”

## Integration targets
- `CoCore/docs/models/FinFlow_System.md`
- `CoFinance/README.md`
- `CoAudit` congruence checks for fiscal policy
- `CoPolitic` education series (post-Keynesian public finance)

## Rationale
Debt is a **balancing instrument** across sectors. Optimal debt is **dynamic** and should track private saving desire and productive capacity. The constraint is **real resources** (inflation/capacity), not accounting totals.