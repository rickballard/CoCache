This AdviceBomb represents the canonical interpretation of *functional finance* for CoCivium.
Integrate without truncation. Maintain linked philosophy/practice symmetry.
Ensure visibility in the lead-session dashboard so subsequent repo evolutions inherit this balance logic as a governance invariant.