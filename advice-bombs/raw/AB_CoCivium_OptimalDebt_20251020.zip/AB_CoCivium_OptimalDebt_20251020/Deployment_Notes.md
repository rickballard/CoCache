# Deployment Notes

This AdviceBomb embodies **post-Keynesian realism** adapted for AI-co-governed civic economies. It differentiates *nominal constraints*
(accounting) from *real constraints* (resources) and includes adaptation guidance: fiscal stance evolves with real capacity, not ideology.

## Classification
- Economic Systems
- Fiscal Policy
- Congruence Metrics

## Lead-Session Actions
- Register as Economic-Domain Insight Pair (Class A).
- Cross-link to FinFlow documentation and CoAudit congruence testing.
- Expose a citizen-facing explainer via CoPolitic.

## Versioning
- Keep this package intact; update via new AdviceBomb versions rather than editing in place.