# Implementing Functional Fiscal Balance in CoCivium’s Economic Model

## 1) Canonical Identity
**Sectoral balances:** (Government) + (Private) + (Foreign) = 0.  
Government deficits offset private saving desires and external deficits.

## 2) Dynamic Targeting
- Aim for **debt growth ≈ nominal GDP growth** over the cycle.
- Use inflation/capacity as constraints; avoid arbitrary debt/GDP caps.
- Permit temporary surpluses when the economy overheats; avoid chronic surpluses.

## 3) Sustainability Heuristics
- Debt in domestic currency; domestic ownership dominant.
- **Debt service ≤ productivity growth**; **interest ≤ ~3% of GDP** (heuristic).
- Real capacity utilization < ~95% → safe to run deficits for investment.

## 4) Policy Levers
- **Maturity mix + policy rate** to steer liquidity/interest income distribution.
- **Taxes** manage demand/inequality; they don’t “fund” spending for a sovereign.
- Borrow where **public investment yield > real funding cost**.

## 5) Data Integration (FinFlow Dashboard)
Monitor:
- Sectoral balances (G/P/F)
- Debt composition & maturity
- Capacity utilization, inflation, unemployment
- Interest income distribution (inequality signal)

## 6) AI Oversight
- **CoAudit**: congruence tests for fiscal stance vs. resource capacity.
- **CoCacheGlobal**: index policy decisions and metric drift.
- **CoPolitic**: public explainer series “Fiscal Myths and Realities.”