# AdviceBomb: CoCivium Optimal Debt Insight Deployment

**Purpose:** Provide the philosophical and operational framework for understanding and applying “optimal debt” logic within CoCivium’s economic and governance model.

**How to use:**
- Install the Insight Pair into `CoCivium/insights` (see `scripts/Install-InsightPair.ps1`).
- Link to FinFlow (`CoCore/docs/models/FinFlow_System.md`) and CoFinance docs.
- Register a CoAudit congruence test for fiscal stance vs. capacity metrics.
- Publish a CoPolitic explainer based on `Insight_OptimalDebt_Philosophy.md`.

**Contents:**
- `_spanky/manifest.json`, `_spanky/notes.md`, `_spanky/readme.txt`
- `Insight_OptimalDebt_Philosophy.md`, `Insight_OptimalDebt_Practice.md`
- `Deployment_Notes.md`, `_copayload.meta.json`, `out.txt`
- `scripts/Install-InsightPair.ps1`, `scripts/Verify-AdviceBomb.ps1`

**Date:** 2025-10-20