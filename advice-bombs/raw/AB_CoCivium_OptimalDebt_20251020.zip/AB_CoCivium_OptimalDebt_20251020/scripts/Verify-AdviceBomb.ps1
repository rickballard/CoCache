<# 
DO BLOCK: Verify-AdviceBomb.ps1
Purpose: Validate the AdviceBomb contents and mandatory files.
#>

param(
  [Parameter(Mandatory=$true)][string]$PackageRoot
)

$ErrorActionPreference = 'Stop'

$required = @(
  "_spanky/manifest.json",
  "_spanky/notes.md",
  "Insight_OptimalDebt_Philosophy.md",
  "Insight_OptimalDebt_Practice.md",
  "Deployment_Notes.md",
  "_copayload.meta.json",
  "out.txt"
)

$missing = @()
foreach($rel in $required){
  $p = Join-Path $PackageRoot $rel
  if (-not (Test-Path $p)) { $missing += $rel }
}

if ($missing.Count -gt 0){
  Write-Error "Missing required files:`n - " + ($missing -join "`n - ")
  exit 1
}

Write-Host "AdviceBomb looks valid."