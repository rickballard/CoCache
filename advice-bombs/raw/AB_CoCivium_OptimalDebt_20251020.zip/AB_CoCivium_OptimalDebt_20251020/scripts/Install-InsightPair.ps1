<# 
DO BLOCK: Install-InsightPair.ps1
Purpose: Install the Optimal Debt Insight Pair into a target repo and open a PR.
BPOE: -Requires PowerShell 7+, gh CLI logged in, git configured.
Safety: Dry-run by default. Use -Apply to modify files.
#>

param(
  [Parameter(Mandatory=$true)][string]$TargetRepoPath,
  [switch]$Apply,
  [string]$BranchName = "docs/insight-optimal-debt-$(Get-Date -Format 'yyMMdd-HHmm')"
)

$ErrorActionPreference = 'Stop'

function Write-Step($msg){ Write-Host "[STEP] $msg" }
function Write-Note($msg){ Write-Host "  - $msg" }

Write-Step "Validating paths"
if (-not (Test-Path $TargetRepoPath)) { throw "Target repo path not found: $TargetRepoPath" }

$insights = Join-Path $TargetRepoPath "insights"
if (-not (Test-Path $insights)) { 
  Write-Note "Creating insights folder (dry-run unless -Apply)"
  if ($Apply){ New-Item -ItemType Directory -Force -Path $insights | Out-Null }
}

$files = @(
  "Insight_OptimalDebt_Philosophy.md",
  "Insight_OptimalDebt_Practice.md",
  "Deployment_Notes.md"
)

$src = $PSScriptRoot | Split-Path -Parent
Write-Step "Preparing file copy (dry-run unless -Apply)"
foreach($f in $files){
  $from = Join-Path $src $f
  $to = Join-Path $insights $f
  if (-not (Test-Path $from)) { throw "Missing source file: $from" }
  Write-Note "Copy $f -> $to"
  if ($Apply){ Copy-Item $from $to -Force }
}

Write-Step "Git branch/commit (dry-run unless -Apply)"
Push-Location $TargetRepoPath
try {
  if ($Apply){
    git checkout -b $BranchName
    git add insights/Insight_OptimalDebt_Philosophy.md insights/Insight_OptimalDebt_Practice.md insights/Deployment_Notes.md
    git commit -m "Add Insight Pair: Optimal Debt & Fiscal Balance"
    try { gh pr create --fill } catch { Write-Warning "gh pr create failed: $_" }
  } else {
    Write-Note "Would create branch: $BranchName"
    Write-Note "Would add and commit insight files, then open PR"
  }
} finally {
  Pop-Location
}

Write-Step "Done"