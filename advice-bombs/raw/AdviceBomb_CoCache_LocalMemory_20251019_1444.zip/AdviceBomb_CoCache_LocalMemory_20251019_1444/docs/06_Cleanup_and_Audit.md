# 06 — Cleanup, Audit & Decision Log

## Cleanup playbook (human‑readable)
1. Open the session folder (or list sessions via your helper command).
2. Ensure deliverables are committed to repos.
3. Run cleanup: purge STAGING and old CACHE; send originals to Trash.
4. Verify `OEHeartbeat` shows success; optionally keep `SESSION.txt` while active.

## Audit questions
- Can we reconstruct which inputs produced which outputs (within TTL)?
- Did any executable run from INBOX? (should be **no**)
- Are any long‑lived files outside `CoTemp`? (should be **no**)

## Decision Log
- **Layout default**: Per‑session subfolders.  
- **Flat mode** allowed for one‑offs with strict filenames.  
- **Final residue**: Trash only (no active work in Trash).
- **Future**: If needed, add an index CSV or receipts; not required on day‑1.
