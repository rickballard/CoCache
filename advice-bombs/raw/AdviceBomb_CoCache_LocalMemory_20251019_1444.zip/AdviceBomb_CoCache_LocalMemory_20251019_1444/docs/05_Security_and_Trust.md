# 05 — Security & Trust Considerations

- **MOTW/quarantine:** Respect OS protections; remove only after verification.
- **Principle of least footprint:** No installers; no global state changes; no hidden services.
- **User expectations:** Downloads area is acceptable; Trash as terminal state is acceptable.
- **Transparency:** Keep `SESSION.txt` succinct; avoid noisy prompts; document when auto‑cleanup ran.
- **Recovery:** Crash‑safe by isolating STAGING per run; on restart, resume or purge aged runs.
