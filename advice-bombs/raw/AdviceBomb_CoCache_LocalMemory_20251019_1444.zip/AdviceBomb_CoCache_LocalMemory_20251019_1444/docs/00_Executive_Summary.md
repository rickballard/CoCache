# 00 — Executive Summary

**Objective:** Provide a planning‑first, cross‑platform approach for **local memory usage** that
lets **CoAgent** operate with a *“zero footprint”* user perception in its **temp install** mode,
while giving CoSuite predictable staging and cleanup semantics.

**Key Positions**  
- **Source of truth is on repo.** Local workspaces are disposable.  
- **One CoTemp root under Downloads.** Users expect Downloads to be messy; keep our mess *managed*.  
- **Two viable staging patterns:** flat dump *(strict filenames+TTL)* **or** per‑session subfolders.  
- **User‑friendly traces only:** optional `.url` to the chat, `SESSION.txt` as a human note.  
- **Zero‑footprint temp installs:** After success, run thorough cleanup; any remaining residue lives
  in the **Trash/Recycle Bin** only (user‑perceived “not installed”).  
- **Security posture:** verify → *then* unblock (Windows MOTW / macOS quarantine); never execute from INBOX.

**What this is not:** An implementation spec. We give *templates* only; lead/prime session decides tooling.
