# 01 — Local Footprint Strategy (CoAgent & CoSuite)

## Goals
- **Temporary by default**: local staging is ephemeral; durable artifacts always land in repos.
- **Simple UX**: users can identify “which folder goes with which chat” without memorizing anything.
- **Operator trust**: no hidden installs; explicit, readable notes in staging.
- **Zero‑footprint temp installs**: post‑run cleanup removes all traces except optional items in Trash.

## Recommended Layout (Per‑Session, preferred)
```
~/Downloads/CoTemp/
  CoTemp-SES_YYYYMMDD_HHMM_R1[_Tag]/
    INBOX/     # landing zone (never execute here)
    STAGING/   # unzip + run area (short‑lived)
    CACHE/     # ephemeral artifacts (TTL/size‑cap)
    ARCHIVE/   # optional keepers (rotated)
    _logs/
    SESSION.txt       # human note: alias, chat URL, created
    SESSION.url/webloc# optional: double‑click returns to chat
```
- **Why preferred:** isolation, easier cleanup, better handoffs, minimal extra effort.

## Alternative Layout (Flat Dump, acceptable for short work)
- Single `CoTemp` folder; **strict filename schema**:  
  `YYYYMMDD-HHMM__SID8__ROLE__slug[--vNN]__hHASH8.ext`
- **Must** enforce TTL and size caps, plus small `.meta.json` receipts for OUT artifacts.

## Retention & Cleanup
- STAGING: purge ≤ 48–72h after success or abandonment.
- CACHE: TTL 7–30 days, **size cap** (2–5 GB), oldest‑first trim.
- ARCHIVE: optional; rotate by time or count.
- OUT (deliverables): keep ≤ 7 days; should be committed/released in repos by then.
- **Final residue:** send originals and old runs to **Trash/Recycle Bin**; no active workspace in Trash.

## User‑Facing Signals
- `SESSION.txt` is the one file a human needs to read.
- Optional `SESSION.url` (Windows) / `SESSION.webloc` (macOS) to jump back to the chat.
- Optional root `INDEX.tsv` (flat mode) or simple `Get-CoTempSessions` script to list sessions.

## Why not use Trash as workspace?
- OS semantics differ; users (and cleaners) empty it; security systems treat it specially.
- Keep Trash as the **end‑state** for deleted items only.
