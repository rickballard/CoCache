# 07 — Cross‑Platform Notes

- **Windows**: `%USERPROFILE%\Downloads\CoTemp\...`; use `Unblock-File`; avoid deep paths.
- **macOS**: `~/Downloads/CoTemp/...`; respect `com.apple.quarantine`; provide `.webloc` shortcut.
- **Linux**: `~/Downloads/CoTemp/...`; follow XDG if migrating to app data later.
- **iOS/iPadOS**: No global Downloads/Trash workflow; temp usage must be inside app sandbox `tmp/` or `Library/Caches/`.

**Trash/Recycle Bin is not a workspace**; it’s a terminal state for cleanup.
