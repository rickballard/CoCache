# 03 — CoTemp Design Options (Trade‑offs)

| Factor | Flat Dump | Per‑Session |
|---|---|---|
| Setup effort | Minimal | Low |
| Traceability | Weak | **Strong** |
| Cleanup precision | Low | **High (per‑session)** |
| Long‑running work | Poor | **Good** |
| Human handoff | OK (disciplined) | **Clear** |
| Collision risk | **Higher** | Low |
| Scalability | Poor | **Good** |

**Default:** Per‑Session for anything > 1 day or > 2 artifacts.  
**Allow Flat:** One‑off, low‑stakes tasks with strict filenames + TTL.
