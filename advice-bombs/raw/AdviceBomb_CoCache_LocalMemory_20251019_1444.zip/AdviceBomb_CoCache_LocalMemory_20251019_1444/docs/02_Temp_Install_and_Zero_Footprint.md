# 02 — Temp Install & “Zero‑Footprint” Perception

**Problem:** CoAgent wants to “install temporarily,” run, and leave users with the impression that
nothing remains resident.

**Answer:** Treat install as *staging*, not system‑wide installation.

1. **Download → INBOX** (CoTemp): verify checksum/signature.
2. **Move → STAGING**: unblock (Windows) / remove quarantine (macOS) **after** verification.
3. **Execute** from STAGING (e.g., `run.ps1`) with flags that put any caches under `CACHE/`.
4. **Commit outputs to repos** (or send to target system). Nothing durable remains locally.
5. **Cleanup on success**:
   - Delete STAGING and CACHE contents not deliberately kept.
   - Send originals and logs to **Trash/Recycle Bin** (or hard delete in CI).
   - Leave only `SESSION.txt` (optional) for transparency during long sessions.
6. **Uninstall semantics**:
   - No registry writes, no global PATH edits, no system services.  
   - If a helper (watcher) was used, it must be self‑terminating and remove its own files.

**Outcome:** Users perceive “zero footprint.” The only visible residue (if any) sits in Trash.
