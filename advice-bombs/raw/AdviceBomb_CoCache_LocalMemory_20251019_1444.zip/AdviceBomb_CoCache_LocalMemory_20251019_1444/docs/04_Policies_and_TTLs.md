# 04 — Policies, TTLs, and Caps (Draft)

- **INBOX**: never execute; move within minutes after size stabilizes (>1.2s quiet).
- **STAGING**: purge ≤ 72h; one subfolder per run (`run_YYYYMMDD_HHMM_pidNNNN`).
- **CACHE**: TTL 14–30 days; **3 GB** cap default; oldest‑first trim.
- **ARCHIVE**: optional; 30–90 days or 10 most recent runs.
- **OUT**: keep ≤ 7 days locally; must be committed/released to repos.
- **Logs**: keep session `_logs/run.log` ≤ 21 days unless escalated.

**Security gates**
- Validate name/signature/hash before execution.
- Unblock/strip quarantine only after validation.
- Deny path traversal on unzip; reject paths > 240 chars on Windows.
- Never rely on Trash as a security boundary.

**Observability (lightweight)**
- One‑line heartbeat appended to `CoAgent/OEHeartbeat.txt` after each cleanup:
  `UTC, sess_id, ingested=N, purged=M, bytes_freed=K`
