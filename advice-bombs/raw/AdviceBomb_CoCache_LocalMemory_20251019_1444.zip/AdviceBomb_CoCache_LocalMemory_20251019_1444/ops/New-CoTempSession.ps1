# New-CoTempSession.ps1 — create a per-session staging folder (planning template)
param([string]$Tag = "")
$Root = Join-Path $HOME 'Downloads\CoTemp'
$null = New-Item -ItemType Directory -Force -Path $Root | Out-Null
$ts   = Get-Date -Format 'yyyyMMdd_HHmm'
$sess = "SES_{0}_R1" -f $ts
$path = Join-Path $Root ("CoTemp-{0}" -f $sess)
$null = New-Item -ItemType Directory -Force -Path $path,(Join-Path $path 'INBOX'),(Join-Path $path 'STAGING'),(Join-Path $path '_logs') | Out-Null
@"
Session: CoTemp-$sess
Created: $(Get-Date)
Tag:     $Tag
Chat:    (paste URL here if desired)
"@ | Out-File (Join-Path $path 'SESSION.txt') -Encoding UTF8
Write-Host $path
