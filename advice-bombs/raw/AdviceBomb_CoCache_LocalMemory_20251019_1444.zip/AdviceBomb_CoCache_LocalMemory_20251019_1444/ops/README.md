# ops/ — Optional Templates (Minimal)

These are *examples* only. Lead/prime session decides whether to adopt, adapt, or replace.

- `New-CoTempSession.ps1` — creates a per‑session folder and drops a simple `SESSION.txt`.
- `List-CoTempSessions.ps1` — lists session folders with their notes.
- `Cleanup-CoTemp.ps1` — TTL + size‑cap cleanup (safe defaults).

Each script is designed to be short and readable, not production‑final.
