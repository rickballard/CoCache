# Cleanup-CoTemp.ps1 — TTL + size cap purger (safe defaults)
$ErrorActionPreference = 'Stop'
$Root = Join-Path $HOME 'Downloads\CoTemp'
if (-not (Test-Path $Root)) { exit 0 }
$TTL_StagingHours = 72
$TTL_LogsDays     = 21
$CapGB            = 3

# Purge old STAGING contents
Get-ChildItem -LiteralPath $Root -Directory -Filter 'CoTemp-*' | ForEach-Object {
  $stg = Join-Path $_.FullName 'STAGING'
  if (Test-Path $stg) {
    Get-ChildItem -LiteralPath $stg -Force | Where-Object { $_.LastWriteTime -lt (Get-Date).AddHours(-$TTL_StagingHours) } |
      ForEach-Object { try { Remove-Item -LiteralPath $_.FullName -Recurse -Force } catch {} }
  }
  $logs = Join-Path $_.FullName '_logs'
  if (Test-Path $logs) {
    Get-ChildItem -LiteralPath $logs -File | Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-$TTL_LogsDays) } |
      ForEach-Object { try { Remove-Item -LiteralPath $_.FullName -Force } catch {} }
  }
}

# Size cap across entire CoTemp
$capB = [math]::Round($CapGB * 1GB)
$files = Get-ChildItem -LiteralPath $Root -Recurse -File | Sort-Object LastWriteTime
$sum = ($files | Measure-Object Length -Sum).Sum
foreach ($f in $files) {
  if ($sum -le $capB) { break }
  try { $sum -= $f.Length; Remove-Item -LiteralPath $f.FullName -Force } catch {}
}
