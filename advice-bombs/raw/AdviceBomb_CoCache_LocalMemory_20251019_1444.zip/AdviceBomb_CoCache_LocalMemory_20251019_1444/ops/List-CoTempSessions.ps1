# List-CoTempSessions.ps1 — list sessions by reading SESSION.txt
$Root = Join-Path $HOME 'Downloads\CoTemp'
if (-not (Test-Path $Root)) { Write-Error "No CoTemp found at $Root"; exit 1 }
Get-ChildItem -LiteralPath $Root -Directory -Filter 'CoTemp-*' |
  Sort-Object LastWriteTime -Descending | ForEach-Object {
    $note = Join-Path $_.FullName 'SESSION.txt'
    $tag  = ""
    $url  = ""
    if (Test-Path $note) {
      $t = Get-Content $note -Raw
      if ($t -match '^Tag:\s*(.*)$'  ) { $tag = $Matches[1].Trim() }
      if ($t -match '^Chat:\s*(.*)$' ) { $url = $Matches[1].Trim() }
    }
    [pscustomobject]@{ Name=$_.Name; Tag=$tag; ChatURL=$url; Path=$_.FullName; Modified=$_.LastWriteTime }
  } | Format-Table -Auto
