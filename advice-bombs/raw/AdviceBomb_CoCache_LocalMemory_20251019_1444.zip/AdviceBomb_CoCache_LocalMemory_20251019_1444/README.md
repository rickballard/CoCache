# CoCache Advice Bomb — Local Memory & Zero‑Footprint Plan
**Package**: AdviceBomb_CoCache_LocalMemory_20251019_1444  
**Date**: 2025-10-19

This package is **planning‑first** guidance for how CoSuite (esp. **CoAgent**) should manage
local working files, temporary installs, and cleanup to **appear zero‑footprint** to end users,
while still preserving reliability, auditability, and user trust.

> TL;DR: Use a branded, disposable **CoTemp** workspace under the user's Downloads, keep
> session continuity via simple notes (or per‑session subfolders), commit all durable records
> to repos, and leave only the **Trash/Recycle Bin** as the final, optional residue when
> doing temp installs with auto‑uninstall.

### How to use this Advice Bomb
1. Place this folder (or its contents) into the `CoCache` repo under  
   `advice-bombs/local-memory/` (or similar).
2. Ask the lead/prime session to read: `docs/00_Executive_Summary.md` then
   `docs/01_Local_Footprint_Strategy.md`.
3. Optionally adapt the minimal operational templates under `ops/`.
4. Track open decisions in `docs/06_Cleanup_and_Audit.md` → “Decision Log”.

### Contents
- `docs/` — Strategy, policies, and planning (minimal implementation).
- `ops/` — Optional, lightweight templates (PowerShell) the lead session may adapt.
- `artifacts/` — Example note/receipt templates (for consistent staging UX).
- `pastebins/` — Ready‑to‑paste one‑pager for PRs/issues and a Slack/Chat handoff blurb.
- `manifest.json` — Metadata describing this Advice Bomb.
- `status/out.txt` — One‑line status heartbeat for ingest tooling.
