# CoCache: Local Memory & Zero‑Footprint Policies (Advice Bomb)

This PR adds planning-first guidance + minimal templates for managing local staging (CoTemp),
temp installs for CoAgent, and cleanup policies that achieve "zero‑footprint" user perception.

- Read `docs/00_Executive_Summary.md` then `docs/01_Local_Footprint_Strategy.md`.
- Decide default workspace pattern: **Per‑Session** (recommended) or **Flat** (short one‑offs).
- Optionally adapt the tiny ops templates under `ops/`.

Final residue after successful runs should be **Trash/Recycle Bin** only. Durable records live on repos.
