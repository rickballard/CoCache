# CiEvolve
InSeed.com's transformation retreat and executive re-alignment platform.

## Purpose
CiEvolve helps executive teams recalibrate for hybrid governance and CoCivium-aligned leadership.

## Structure
- `docs/retreat/`: Retreat planning guides and training modules.
- `docs/intro.md`: Vision and methodology.

## Positioning
Bridges legacy leadership with emergent civic paradigms. Designed to co-evolve with both human and AI agents.