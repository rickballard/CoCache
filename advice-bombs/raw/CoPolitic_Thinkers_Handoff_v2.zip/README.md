# CoPolitic ↔ CoCore — Thinkers Page Handoff

**Date:** 2025-10-16T21:19:48.795387Z

This pack documents what we did, why, and how another session (or operator) can pick up the work quickly.

---

## Summary (what we did)

1. **Added a Thinkers page** to the CoPolitic site:
   - Page file: `docs/thinkers/index.html` (client-rendered)
   - Data file (local preview): `docs/assets/thinkers/thinkers.json`
   - Branch: `feature/thinkers-page-20251016-1633` (PR was opened from your machine)

2. **Fixed local preview issues**:
   - Serve `docs/` with a local HTTP server (Python/Node).
   - Corrected dataset path to use relative `../assets/thinkers/thinkers.json` and added a fallback loader.

3. **Added a simple nav link** to `docs/index.html` so `/thinkers/` is reachable on the live site.

4. **Proposed final architecture**:
   - **System of record is CoCore** (best-practices database).
   - CoPolitic only **renders** and **fetches JSON** from CoCore (CDN URL).
   - Each thinker has a **generated summary sheet**, hosted from `CoCore/docs/thinkers/sheets/*.html`.

---

## Why this architecture?

- Single source of truth (CoCore) → easier maintenance and reuse across Co* sites.
- GitHub Pages + jsDelivr CDN **CORS-friendly** and cacheable.
- CoPolitic stays a thin client with **no data duplication**.

---

## What the next operator should do

### A) Generate per-thinker sheets in CoCore and add `sheet_url` to the JSON

1. Ensure CoCore exists locally and has (or create) these paths:
   - `CoCore/best-practices/thinkers/thinkers.json` (canonical dataset)
   - `CoCore/docs/thinkers/sheets/` (output HTML sheets)

2. Run `Generate-ThinkersSheets.ps1` with the path to your CoCore clone.
   - This will create/overwrite `docs/thinkers/sheets/*.html` and inject `sheet_url` into the JSON.

3. Commit & push CoCore.

### B) Point CoPolitic at CoCore (CDN) & make card titles link to sheets

1. Run `Patch-CoPoliticPage.ps1` with the path to your CoPolitic clone.
   - It swaps the JSON fetch to a **jsDelivr** URL for CoCore and makes card titles clickable to `sheet_url`.

2. Commit & push CoPolitic, merge PR to `main`.
   - Live site: `https://copolitic.org/thinkers/`.

### C) Local preview commands

- Python:
  ```powershell
  cd <CoPolitic>\docs
  python -m http.server 8080
  # http://127.0.0.1:8080/thinkers/
  ```

- Node:
  ```powershell
  cd <CoPolitic>\docs
  http-server -p 8080 -c-1
  # http://127.0.0.1:8080/thinkers/
  ```

---

## Troubleshooting notes (from this session)

- If you see `Could not load thinkers.json`, confirm the server is running and the fetch path is correct.
- If the server prints `EADDRINUSE`, pick another port or kill the process on that port.
- When editing from inside `docs`, remember `git add docs/index.html` expects you are at repo root.
- PowerShell `-replace` uses regex; prefer `.Replace()` for literal string swaps.

---

## Files in this pack

- `Generate-ThinkersSheets.ps1` — generate CoCore sheets + add `sheet_url` to JSON.
- `Patch-CoPoliticPage.ps1` — point CoPolitic to CoCore CDN and link cards to sheets.
- `Handoff.manifest.json` — machine-readable summary of decisions and pointers.
- `README.md` — this file.
