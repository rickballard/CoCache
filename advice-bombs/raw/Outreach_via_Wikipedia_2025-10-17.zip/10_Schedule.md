# Two‑Week Micro‑Plan

Day 0–1
- Publish /about and /press using provided stubs.
- Export Fact Sheet to PDF; link it on /press.
- Send N1 to 2 newsroom desks; T1 to 2 trade editors.
- Post CLRIM LinkedIn; Darren reshares.

Day 2–5
- Handle replies; book 15‑minute demo; provide PDF on request.
- Record activity in Target_Tracker.csv.

Day 6–10
- Expect first newsroom item; push for one trade article.
- When 2 items are live, draft Wikipedia sandbox.

Day 11–14
- Submit AfC; respond to reviewer notes.
