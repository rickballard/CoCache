# Communications Policy — Neutrality & COI

- Use neutral, verifiable statements only; avoid superlatives.
- Offer facts; let editors decide newsworthiness.
- For Wikipedia, cite only independent, staff‑written sources.
- Disclose conflict of interest if you write or submit anything yourself.
- One canonical link per post: https://cocivium.org/
