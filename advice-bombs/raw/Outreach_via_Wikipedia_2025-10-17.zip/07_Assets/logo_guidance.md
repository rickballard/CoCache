Logo guidance:
- Provide PNG (transparent) and SVG.
- Keep strokes simple; avoid gradients for clarity at small sizes.
- Provide monochrome version for dark/light backgrounds.
