# Flights & Halos Guide
Purpose: Define how PAIR completions update MeritHalo Spectrum.

## Key Terms
- **Flight:** a structured learning journey (3–5 linked PAIRs).
- **Nest:** local peer circle or physical meetup.
- **Halo Renewal:** positive reinforcement of new wisdom across domains.

Each completed Flight modifies Halo brightness by domain relevance × congruence alignment.
