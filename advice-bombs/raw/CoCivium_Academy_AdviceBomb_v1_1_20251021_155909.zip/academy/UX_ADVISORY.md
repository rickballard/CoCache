# UX & Pedagogical Advisory
Purpose: Make the Academy emotionally engaging, intellectually credible, and pedagogically transformative.

Highlights:
- **Duckling Line** hero (mentorship & emergence metaphor)
- Rollover term explanations for new lexicon (Quack, Halo, CME)
- Gamified progress → Wisdom Halo brightness
- Dual entry: “Explore by Domain” / “Explore by Question”
- Palette: Civium Blue #1A90FF; Halo Gold #F6B93B

Outcome shift: from **Certifiable Competence → Evolving Congruence**.
