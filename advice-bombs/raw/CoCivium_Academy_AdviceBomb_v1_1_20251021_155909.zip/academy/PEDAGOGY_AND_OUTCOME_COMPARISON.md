# Pedagogical & Outcome Comparison

| Aspect | Legacy | CoCivium |
|---|---|---|
| Motivation | Grades | Curiosity |
| Learning Mode | Consumption | Co-creation |
| Authority | Deference | Partnership |
| Output | Diploma | Living Halo |
| Outcome | Certifiable Competence | Evolving Congruence |

**Type of Human Produced**: Legacy = compliant, dependent; CoCivium = adaptive, ethical, self-correcting.
