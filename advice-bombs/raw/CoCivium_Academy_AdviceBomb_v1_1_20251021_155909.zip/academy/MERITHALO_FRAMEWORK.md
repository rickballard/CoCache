# MeritHalo Continuum
Purpose: Unify learning, employability, and civic fit through a visible, positive-only record of wisdom growth.

## Layers
- **MeritHalo** — dynamic certificate showing growth, trust, and contribution.
- **RepTag** — pseudonymous identity record.
- **MeritLedger** — quantitative backbone integrating CoAudit + CoCore.
- **Halo Spectrum** — visual brightness per CoNeura domain.
- **Renewal Cycle** — ongoing reinforcement of learning; unused knowledge fades.

Integration: Halo metrics feed Vital-Signs SEI; CoAudit validates sources.
