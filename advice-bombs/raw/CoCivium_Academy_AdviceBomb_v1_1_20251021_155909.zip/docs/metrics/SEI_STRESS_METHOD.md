# SEI / Stress Methodology
- Trend Direction: ↑=+1, ↓=-1, ~=0
- Impact Magnitude: High=3, Med=2, Low=1
- Momentum: 1.2 if accelerating decline, 0.8 if improving

Reversibility adjusts policy tractability weighting.
