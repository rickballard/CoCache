# Analytical Methods
Purpose: Compute SEI (Systemic Evolution Index) and Stress Index.

## Formulas
SEI = Σ (trend_direction × impact_magnitude × domain_weight)
Stress = declining_metrics / total × impact × momentum

Includes sensitivity table for Growth-first, Egalitarian, Climate-first weightings.
