# Response Map
Links each Vital Sign to Academy modules and Halo contributions.
| Metric | Domain | Academy Link | Adequacy | Proposed Upgrade |
|---|---|---|---|---|
| Wealth Gini | ECO | PAIR-ECO-020 | 2 | add distribution equity module |
