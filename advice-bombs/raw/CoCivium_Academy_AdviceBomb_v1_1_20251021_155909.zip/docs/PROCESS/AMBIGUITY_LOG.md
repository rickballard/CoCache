# Ambiguity Log
Purpose: Capture interpretive uncertainty before integration.
