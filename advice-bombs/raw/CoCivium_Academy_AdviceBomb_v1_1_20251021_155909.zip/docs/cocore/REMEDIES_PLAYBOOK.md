# Remedies Playbook
Purpose: canonical best practices per domain.
