# Website Hero Snippets (Ready-to-Paste)

## Hero (plain)
**Your governance. BYO-AI.**  
A vendor-neutral AI Trust Container. Keep your rules, your records, and your options—no matter which AI you use.

- Policy once, enforce everywhere  
- Repatriated data, only you control  
- Evidence-grade receipts

**CTA:** Get the container

## Coverage/compatibility block (public)
*Continuously evolving support; integrates with your existing processes, workflows, systems, and apps.*

**Footnote (legal-safe):** Works with supported providers and models; coverage expands over time.
