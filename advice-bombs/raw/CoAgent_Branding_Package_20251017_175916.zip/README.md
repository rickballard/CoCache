# CoAgent Branding & Messaging Package (v1.1)
Generated: 20251017_175916

This package contains a plain‑language messaging brief, taglines, a comparison checklist,
and a non‑technical case‑study story. It is intended for the lead/prime session that is
organizing repos to ingest and adapt into website content, decks, and READMEs.

## Contents
- `brand/MESSAGING_PLAIN.md` — Core brief (plain-language)
- `brand/COMPARE_CHECKLIST.md` — Scoring grid for other briefs
- `brand/CoAgent_Taglines.md` — Taglines and hero variants
- `docs/WEBSITE_HERO_SNIPPETS.md` — Ready-to-paste sections
- `stories/Maya_Homework_Club.md` — Narrative case study (non-technical)
- `brand/VISUAL_IDENTITY_NOTES.md` — Cues for designers and wordmark
- `scripts/Deploy-CoAgentBranding.ps1` — DO‑block for PS7 to stage into a repo
- `VERSION` / `CHANGELOG.md` — Versioning stubs
- `LICENSE` — CC BY 4.0 for the textual assets

## Quick Start (repo operator)
1. Unzip anywhere (safe zone).
2. Review `brand/MESSAGING_PLAIN.md` and `brand/CoAgent_Taglines.md`.
3. (Optional) Run `scripts/Deploy-CoAgentBranding.ps1` with parameters to copy the assets into a target repo (e.g., CoSteward or CoAgent).
4. Use `brand/COMPARE_CHECKLIST.md` to evaluate existing briefs in the repo and close gaps.
5. Paste snippets from `docs/WEBSITE_HERO_SNIPPETS.md` into landing pages or slides.

## Safe Wording Notes
- Use “Any model” / “model‑agnostic,” not “All models.”
- Coverage line: “Continuously evolving support; integrates with your existing processes, workflows, systems, and apps.”
- Legal footnote when listing vendors: “Works with supported providers and models; coverage expands over time.”
- Prefer “evidence‑grade receipts” over “tamper‑proof.”

