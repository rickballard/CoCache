# Changelog
## v1.1
- Plain-language brief with broader personas and repatriated-data line
- Coverage language updated: continuously evolving support; integrates with processes, workflows, systems, apps
- Added non-technical case study
- Added PS7 deploy script
