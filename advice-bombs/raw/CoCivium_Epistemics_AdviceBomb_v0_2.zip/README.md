# v0.2 Additions


## v0.2 Additions
- GitHub Action **provenance-lint** (enforce provenance in PRs)
- **semantic_drift_monitor.py** (offline cosine drift calculator)
- Tunable **METRICS/thresholds.json** for quarantine rules
- Stronger **ingest-gate-stub.ps1** (basic YAML-frontmatter checks)
