# InSeed Drop‑In Page — v1

This package contains:
- `pages/inseed-living-policy-framework.md` — main page (Markdown).  
- `pages/competitor-matrix.md` — optional comparison page.  
- `assets/css/inseed-dropin.css` — scoped CSS for dictionary box, matrix, and CTAs.  
- `preview/preview.html` — static preview without a site generator.

**Hero**: uses your existing repo image; update the `hero_image` frontmatter path if needed.

**Quotes**: anonymized excerpts from historic references; labels describe the person (role) without naming.  
If you want exact titles shown for any quote, tell us which ones and we will update the labels.

## Preview locally (no server)
Open `preview/preview.html` in a browser.

## Integration
See comments at top of each file. Add CSS to your theme or include it in your build (MkDocs/Docusaurus/Jekyll).