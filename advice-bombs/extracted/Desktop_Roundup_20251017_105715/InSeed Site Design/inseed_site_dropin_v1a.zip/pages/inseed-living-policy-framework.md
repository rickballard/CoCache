---
title: Living Policy Framework
hero_image: /assets/img/hero-inseed.png   # ← update to your repo path if different
layout: default
description: InSeed turns policy chaos into a living, trusted framework—clear, current, and pivot‑ready.
---

<div id="hero">
  <img src="{{ page.hero_image | default: '/assets/img/hero-inseed.png' }}" alt="Hero: frustrated professional with broken pencil; AI words from earbuds">
  <div class="overlay container">
    <div class="cta">
      <a href="/contact">Get Your Free CoAudit</a>
      <a href="#how-it-works" class="secondary">See How It Works</a>
    </div>
  </div>
</div>

<div class="container">
  <!-- SECTION: DICTIONARY -->
  <section id="dictionary" class="section" aria-labelledby="policy-def">
    <div class="term" id="policy-def">policy <span class="phon">(noun)</span></div>
    <div class="definition">
      <p><strong>1.</strong> A rule or principle adopted by an organization to guide decisions.</p>
      <p><strong>2.</strong> A course of action chosen to influence behavior.</p>
      <p><strong>3. [InSeed]</strong> A living framework of operational guidance — always current, integrated, justified, and trusted.</p>
    </div>
  </section>

  <!-- SECTION: PAIN -->
  <section id="pain" class="section">
    <h2>The problem (facts, not emotions)</h2>
    <ul>
      <li>Policies are outdated the moment they’re published.</li>
      <li>Overlaps and contradictions erode trust and invite workarounds.</li>
      <li>Staff already use AI informally; side‑channels are unavoidable.</li>
      <li>Regulators and partners demand clarity and proof of adoption.</li>
      <li>Leaders can’t measure effectiveness or audit change history.</li>
    </ul>
  </section>

  <!-- SECTION: NEED -->
  <section id="need" class="section">
    <h2>What you need</h2>
    <ul>
      <li>Policies that are always current and non‑contradictory.</li>
      <li>Clear “why” behind each rule (stakeholder‑visible rationale).</li>
      <li>Auto‑auditable adoption and effectiveness.</li>
      <li>All‑staff suggestions with governance approval — safe, not chaotic.</li>
      <li>Portability to your next‑gen business model; AI‑ready when you are.</li>
    </ul>
  </section>

  <!-- SECTION: SOLUTION -->
  <section id="how-it-works" class="section">
    <h2>The InSeed solution</h2>
    <h3>CoAudit — Free audit & RFP generation</h3>
    <p>Independent of vendors. 1‑week, semi‑automated map of systems, data flows, policy gaps, and prioritized risks. Output is a structured RFP you can send to any firm.</p>

    <h3>CoFlow — Workflow for living policies</h3>
    <p>Turns static rules into self‑governance workflows. Staff can propose improvements; leadership approves. Free for good causes.</p>

    <h3>CoMirror — Executive off‑site</h3>
    <p>One‑day, customized seminar for vision, role clarity, KPI rituals, and ethical congruence in hybrid (human+AI) teams.</p>
  </section>

  <!-- SECTION: MATRIX (optional separate page too) -->
  <section id="compare" class="section">
    <h2>Where else could you go?</h2>
    <p class="lede">We believe in ultra‑transparency. When you request a CoAudit, you’ll get an RFP you can share with any firm. Here’s how the market typically compares on the criteria that matter.</p>
    <table class="matrix">
      <thead>
        <tr><th>Firm (archetype)</th><th>Independence</th><th>Transparency</th><th>Open outputs</th><th>SME‑friendly cost</th><th>Future‑proof (AI‑aware)</th></tr>
      </thead>
      <tbody>
        <tr><td><strong>InSeed</strong></td><td class="ok">✓</td><td class="ok">✓</td><td class="ok">✓ (portable RFP)</td><td class="ok">✓</td><td class="ok">✓</td></tr>
        <tr><td>Global strategy major</td><td>—</td><td>—</td><td>—</td><td>—</td><td>✓</td></tr>
        <tr><td>Big audit/compliance</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td></tr>
        <tr><td>Boutique policy shop</td><td>✓</td><td>—</td><td>—</td><td>✓</td><td>—</td></tr>
        <tr><td>IT vendor‑aligned</td><td>—</td><td>—</td><td>—</td><td>✓</td><td>✓</td></tr>
      </tbody>
    </table>
  </section>

  <!-- SECTION: TESTIMONIALS (anonymized) -->
  <section id="credibility" class="section">
    <h2>What people say (selected excerpts)</h2>
    <div class="testimonials">
      <div class="quote">
        <p>“Critical to our rise from startup to a billion‑dollar valuation.”</p>
        <div class="who">— President & Board Chair (worked on the same team)</div>
      </div>
      <div class="quote">
        <p>“Inspires entrepreneurs while asking the tough questions that drive growth.”</p>
        <div class="who">— President / advisory board peer</div>
      </div>
      <div class="quote">
        <p>“Never at a loss for creative approaches to business development challenges.”</p>
        <div class="who">— Marketing lead who reported into the team’s BD function</div>
      </div>
      <div class="quote">
        <p>“Forward‑thinking manager with a rare blend of tech, process, and people sense.”</p>
        <div class="who">— Engineering/DevOps leader at a partner firm</div>
      </div>
      <div class="quote">
        <p>“Able to rapidly learn new markets and craft compelling value propositions.”</p>
        <div class="who">— Former cross‑functional colleague in telecom/IT</div>
      </div>
      <div class="quote">
        <p>“Human multithreading — breadth of insight and energy wrapped in a caring persona.”</p>
        <div class="who">— Co‑founder of a tech conference/acceleration firm</div>
      </div>
    </div>
    <p class="lede" style="margin-top:1rem;">(If you want specific titles shown for any quote, tell us and we’ll update the labels.)</p>
  </section>

  <!-- SECTION: CTA / CONTACT -->
  <section id="cta" class="section">
    <div class="cta-block">
      <div><strong>Ready to turn policy chaos into clarity?</strong><br/>Start with a free, independent CoAudit.</div>
      <a href="/contact">Get Your Free CoAudit</a>
    </div>
  </section>

  <!-- SECTION: RESOURCES -->
  <section id="resources" class="section">
    <h2>Resources</h2>
    <ul>
      <li>Founder Bio • LinkedIn • Substack</li>
      <li>Visionary context: CoCivium (optional reading)</li>
      <li>Address, phone, and map</li>
    </ul>
  </section>
</div>