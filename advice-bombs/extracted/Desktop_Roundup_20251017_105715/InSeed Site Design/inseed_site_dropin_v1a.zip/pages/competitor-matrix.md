---
title: Competitor Comparison (Archetypes)
layout: default
description: Transparent comparison of typical market archetypes on independence, transparency, open outputs, cost, and future‑proofing.
---

<div class="container">
  <h1>Competitor Comparison (Archetypes)</h1>
  <p class="lede">We respect these firms. This matrix simply shows how typical approaches compare on criteria that matter for living policies.</p>
  <table class="matrix">
    <thead>
      <tr><th>Firm (archetype)</th><th>Independence</th><th>Transparency</th><th>Open outputs</th><th>SME‑friendly cost</th><th>Future‑proof (AI‑aware)</th></tr>
    </thead>
    <tbody>
      <tr><td><strong>InSeed</strong></td><td class="ok">✓</td><td class="ok">✓</td><td class="ok">✓ (portable RFP)</td><td class="ok">✓</td><td class="ok">✓</td></tr>
      <tr><td>Global strategy major</td><td>—</td><td>—</td><td>—</td><td>—</td><td>✓</td></tr>
      <tr><td>Big audit/compliance</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td></tr>
      <tr><td>Boutique policy shop</td><td>✓</td><td>—</td><td>—</td><td>✓</td><td>—</td></tr>
      <tr><td>IT vendor‑aligned</td><td>—</td><td>—</td><td>—</td><td>✓</td><td>✓</td></tr>
    </tbody>
  </table>
</div>