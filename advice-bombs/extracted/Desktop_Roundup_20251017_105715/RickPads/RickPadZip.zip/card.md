---
title: Guardrails Badge (CoCivGuard)
persona: left
category: Ideas
status: approved
provenance: Off-platform ideation -> RickPad
---

**Lead.** A small badge near the README header points to a 300-word guardrails explainer in plain English. It signals consent and safety without false promises.

**Context.** We want newcomers to feel safe and seen before they read any code.

**Proposal.**
- Design a tiny badge and link to an explainer page.
- Document HumanGate and sensitive-connectivity approvals.
- Add one "no-go" bullet (what we will not do).

**Risks.**
- Security theater if the explainer is shallow; scope misreads.

**Dependencies.** People, Content, Infra, Policy, Security.

**Ask.** Early reactions by Friday; I will draft v1 explainer over the weekend.
