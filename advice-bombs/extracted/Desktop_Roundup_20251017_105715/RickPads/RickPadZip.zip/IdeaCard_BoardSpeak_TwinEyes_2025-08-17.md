# Idea Card — BoardSpeak & Twin‑Eyes (AI‑coached discussion norms)

**Lead.** Establish a dignified “BoardSpeak” discussion style, with personal AIs subtly coaching users toward respectful, evidence‑based dialogue.  Introduce a compact “Twin‑Eyes” habit (analysis eye + imagination eye) to replace “left‑brain vs right‑brain” and avoid Left/Right political conflation.  Minimize user effort; default the assistant to do the lifting.

**Context.** Builds on *Scribble — Two Mindedness By Default* and *AI‑First Contributor Guidance*.  Ships as a human‑readable Academy page plus an AI‑readable guide.  Target venues: GitHub Discussions, PR descriptions, and high‑heat threads.

**Proposal.**
- **AI guidance file** (`ops/ai-guides/boardspeak.yml`): behaviors, nudges, and boundaries the user’s AI should follow in CoCivium.  Non‑coercive; user‑overrideable.
- **Human Academy page** (`academy/boardspeak.md`): short explainer, quick‑start, and 6 paired micro‑examples: *Flame‑war → BoardSpeak*.
- **Evidence by default.** AIs suggest citations as users write: claim → source link → date → one‑line justification.  Teach minimal acceptable citation format.
- **Twin‑Eyes pattern.** For commits/PRs and proposals, assistants add a 2‑bullet “Twin‑Eyes Note”: *Analysis Eye* (risks, constraints) and *Imagination Eye* (opportunities, upside).  Clear that this is not Left/Right politics.
- **Tone & safety.** Nudge toward questions, steel‑manning, and respectful disagreement.  Auto‑red‑flag personal attacks; propose a re‑phrase.
- **Opt‑out & transparency.** A small “This assistant is coaching BoardSpeak” line with a one‑tap pause for 24h.

**Risks.**
- Perceived paternalism or culture‑policing.  Mitigate with visible opt‑out and “assistant did the work” ergonomics.
- Politicization via name confusion.  Fix with explicit “Twin‑Eyes ≠ Left/Right.”
- Privacy & telemetry creep.  Keep on‑device where possible; collect only aggregate opt‑in metrics.
- Assistant inconsistency across vendors.  Publish a thin, vendor‑neutral contract and tests.

**Dependencies.** People (editor/curator), Content (examples, citation style), Infra (repo paths noted above; CI link‑checker), Policy (HumanGate; delegation limits), Security (privacy note).

**Ask.**
1) Approve the terms **BoardSpeak** and **Twin‑Eyes** (or propose better).  
2) Pick 6 “Flame‑war → BoardSpeak” example pairs to seed v1.  
3) Set the **minimal citation rule** (e.g., link + date + claim).  
4) Choose a pilot venue (GitHub Discussions) and a review window (72h).  
5) Green‑light creation of `ops/ai-guides/boardspeak.yml` and `academy/boardspeak.md`.

**Provenance.** Voice session 2025‑08‑17; aligns with RickPad active ideas and *Scribble — Two Mindedness By Default*.

**Devils’ Advocates**
- **SecOpGuy —** What new attack surface or compliance risk?  Minimum guardrail?
- **ConflictPerspective —** Who loses voice or feels filtered?  Compensations?
- **Debunker —** Shakiest assumption?  One falsifiable test.
