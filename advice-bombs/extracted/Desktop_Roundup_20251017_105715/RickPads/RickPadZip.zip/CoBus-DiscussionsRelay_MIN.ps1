param(
  [string]$HS    = "https://matrix-client.matrix.org",
  [string]$User  = "@rick_ball:matrix.org",
  [string]$Room  = "!onAbUAZZGsiexyPpza:matrix.org",
  [string]$Owner = "rickballard",
  [string]$Repo  = "CoCivium",
  [switch]$DryRun,
  [switch]$Force
)
$ErrorActionPreference = "Stop"

function Get-MatrixToken {
  # Use cached token to avoid password prompts
  $cached = [Environment]::GetEnvironmentVariable('MATRIX_ACCESS_TOKEN','User')
  if([string]::IsNullOrWhiteSpace($cached)){ throw "No MATRIX_ACCESS_TOKEN found. Run the one-time mint step first." }
  return $cached
}

function Get-LatestCardMd {
  param([string]$Tok)
  $url = "$HS/_matrix/client/v3/rooms/$Room/messages?dir=b&limit=200&access_token=$Tok"
  $resp = Invoke-RestMethod -Uri $url -Method Get
  foreach($e in @($resp.chunk)){
    if($e.content.msgtype -ne 'm.text'){ continue }
    $t = [string]$e.content.body
    if($t -match '(?s)```card-md\s*(.+?)\s*```'){ return $Matches[1] }
  }
  throw "No ```card-md``` block found in last 200 messages."
}

function Parse-Card {
  param([string]$Block)
  $meta = @{}
  $body = $Block
  if($Block -match '(?s)^\s*---\s*(.+?)\s*---\s*(.*)$'){
    $fm,$rest = $Matches[1],$Matches[2]
    foreach($line in ($fm -split "`n")){
      if($line -match '^\s*([A-Za-z0-9_-]+)\s*:\s*(.+?)\s*$'){
        $k=$Matches[1].ToLower(); $v=$Matches[2].Trim('"')
        $meta[$k]=$v
      }
    }
    $body = $rest.Trim()
  }
  [pscustomobject]@{ Meta = $meta; Body = $body }
}

function Get-GHToken {
  if(-not (Get-Command gh -ErrorAction SilentlyContinue)){ throw "GitHub CLI (gh) not found." }
  gh auth status | Out-Null
  gh auth token
}

function Get-DiscussionCategoryId {
  param([string]$Tok, [string]$Owner, [string]$Repo, [string]$Name)
  $hdr = @{
    Authorization = "Bearer $Tok"
    Accept        = "application/vnd.github+json"
    "X-GitHub-Api-Version" = "2022-11-28"
    "User-Agent"  = "CoBus-Relay"
  }
  $cats = Invoke-RestMethod -Uri "https://api.github.com/repos/$Owner/$Repo/discussions/categories" -Headers $hdr -Method Get
  $hit = $cats | Where-Object { $_.name -ieq $Name } | Select-Object -First 1
  if(-not $hit){ throw "Discussion category '$Name' not found. Create it in repo Settings -> Discussions." }
  $hit.id
}

function Decorate-Body {
  param([string]$Body, [hashtable]$Meta)
  $persona = ""
  if($Meta.ContainsKey('persona') -and $Meta.persona){ $persona = ($Meta.persona).ToLower() }
  elseif($Meta.ContainsKey('attribution') -and $Meta.attribution){ $persona = ($Meta.attribution).ToLower() }

  $label = switch -Regex ($persona) {
    '^(rick-)?left|^lb$'             { 'Left Brain'; break }
    '^(rick-)?right|^rb$'            { 'Right Brain'; break }
    '^(rick-)?(whole|integrator)$'   { 'Whole Brain'; break }
    default { '' }
  }

  if([string]::IsNullOrWhiteSpace($label)){ return $Body }

  $prefix = "**Rick — $label.** "
  $footer = "`n`n_Meta: perspective tag for clarity; single author (Rick)._"
  return ($prefix + $Body + $footer)
}

function Post-Discussion {
  param([string]$Tok,[string]$Owner,[string]$Repo,[string]$Title,[string]$Body,[int]$CategoryId,[switch]$DryRun,[switch]$Force)
  $hdr = @{
    Authorization = "Bearer $Tok"
    Accept        = "application/vnd.github+json"
    "X-GitHub-Api-Version" = "2022-11-28"
    "User-Agent"  = "CoBus-Relay"
  }
  $payload = @{ title = $Title; body = $Body; category_id = $CategoryId } | ConvertTo-Json -Depth 5

  if(-not $Force){
    Write-Host ""
    Write-Host "About to post to $Owner/$Repo (category_id: $CategoryId)" -ForegroundColor Cyan
    Write-Host "Title: $Title" -ForegroundColor Cyan
    Write-Host "Proceed? (Y/N)" -NoNewline
    $resp = Read-Host
    if($resp -notin @('y','Y')){ throw "User declined." }
  }

  if($DryRun){
    "DRY RUN — would POST to https://api.github.com/repos/$Owner/$Repo/discussions"
    $payload
  } else {
    $res = Invoke-RestMethod -Uri "https://api.github.com/repos/$Owner/$Repo/discussions" -Headers $hdr -Method Post -Body $payload -ContentType 'application/json'
    "Posted discussion #$($res.number): $($res.title)"
    "URL: $($res.html_url)"
  }
}

# --- Main ---
$mxTok = Get-MatrixToken
$block = Get-LatestCardMd -Tok $mxTok
$card  = Parse-Card $block

$status = ($card.Meta.status ?? '').ToLower()
if($status -notin @('approved','ready-for-discussion','approved-for-discussion')){
  throw "Card status is '$status'. Set status: approved (or ready-for-discussion) to publish."
}

# Title/category (explicit assigns; avoids wrap bugs)
if ($card.Meta.title) { $title = $card.Meta.title } else { $title = "Untitled idea" }
if ($card.Meta.category) { $categoryName = $card.Meta.category } else { $categoryName = "Ideas" }
