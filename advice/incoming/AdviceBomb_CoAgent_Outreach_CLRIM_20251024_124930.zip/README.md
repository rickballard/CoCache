# AdviceBomb — CoAgent Outreach Pack (CLRIM‑personalized)
**Build:** 20251024_124930
**Target:** Campbell, Lee & Ross Investment Management Inc. (CLRIM), Oakville ON

This pack personalizes the Pizza Lunch Primer and outreach assets for **CLRIM** and **Darren Sissons**.
It mirrors CLRIM site language (“Invest intelligently. Grow your wealth.”; “Balance. Protection. Growth.”; “Disciplined. Tested. Proven.”) and references Darren’s public BNN presence.
