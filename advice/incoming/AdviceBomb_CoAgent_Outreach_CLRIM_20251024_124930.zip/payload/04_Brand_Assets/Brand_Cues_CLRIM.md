Use phrases seen on clrim.com:
- “Invest intelligently. Grow your wealth.”
- “Balance. Protection. Growth.”
- “Disciplined. Tested. Proven.”
BNN presence for partners is prominent; keep tone measured and professional.
