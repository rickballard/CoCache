Write-Host 'CLRIM Outreach Pack (echo-only). Open 02_Outreach next.'
