Pizza Lunch Primer — AI & Policy Volatility (CLRIM‑tailored)
