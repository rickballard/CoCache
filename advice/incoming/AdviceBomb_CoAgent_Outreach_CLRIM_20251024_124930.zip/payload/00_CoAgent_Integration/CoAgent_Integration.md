# CoAgent Integration (CLRIM)
- Path: CoAgent/advice/Outreach/PizzaLunch_AI_Shock/CLRIM_<build-id>/
- Left (Chat): open 02_Outreach/Email_Templates_CLRIM.md
- Middle (PS7): run payload/run.ps1 (echo-only)
- Right (Browser): clrim.com for quick references (firm, team, approach)
