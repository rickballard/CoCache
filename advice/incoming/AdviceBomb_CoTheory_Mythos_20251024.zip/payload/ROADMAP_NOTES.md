## Mythos Layer for CoTheory

- Develop narrative like: two halo'd children floating above a fungal-glow grove
- Visualize IdeaCards as bioluminescent leaves on logic trees
- Use interactions as co-decision dances — gestures instead of terms

## Tasks
- [ ] Locate earlier narrative scenes in Godspawn, CoFutures, insights folders
- [ ] Draft storyboard markdowns for mythic scenes
- [ ] Prepare journal pitch strategy memo