
# Article Shape — Repost Channel
1) Title
2) Context (2–3 sentences)
3) Highlights (6–10 bullets, badges float at end)
4) Short editorial note
5) Source & attribution (prominent)
6) Footer microprint: badge key + CoCivium link
