
# Cadence — Advisory Rhythm
- Repost: monthly candidate list; promote 1–2 pieces.
- Insights: 2–3 week heartbeat only if ideas warrant it.
- Carry forward near‑miss pieces; don’t force schedule.
