
# Badges — Suggested Key (Advisory)
- 🛡️ CoAudit — provenance, transparency, causal auditing
- 🧮 MeritRank — contestable scoring, measurable claims
- 🤝 CoAgent — sandboxed agents, audit trails
- 📚 CoCore — reproducible playbooks, data lineage
- 🧭 No‑Coercion — consent‑based governance, alignment
