
# Risks & Softeners
- Auto‑captions brittle → keep full transcript + paraphrase.
- Over‑badging → 0–3 per highlight.
- Voice drift → brief editorial stance note.
- Tool fragility → prefer simple, visible steps for now.
