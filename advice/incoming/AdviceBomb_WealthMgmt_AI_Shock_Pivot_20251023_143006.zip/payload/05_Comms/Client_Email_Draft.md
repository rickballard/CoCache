## Client Email Draft
Hi <Name>, ... — <Partner Name>