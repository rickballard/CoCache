# Liquidity Drill Checklist
- Cash ladders, custodian lines/gates, redemption timelines, stress, gaps & owners.
