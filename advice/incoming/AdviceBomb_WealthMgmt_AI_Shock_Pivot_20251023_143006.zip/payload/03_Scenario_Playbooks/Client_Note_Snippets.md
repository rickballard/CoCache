# Client Note Snippets
- Tariff Escalation: <100–150 words>
- Managed De-escalation: <...>
- Policy Shock: <...>
