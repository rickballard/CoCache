# Scenario Playbook Template
Scenario | Triggers | Implications | Pre-authorized tilts | Client snippet | Review cadence
