# Data Corpus Policy
- Whitelist approved docs; versioning; PII controls; retention.
