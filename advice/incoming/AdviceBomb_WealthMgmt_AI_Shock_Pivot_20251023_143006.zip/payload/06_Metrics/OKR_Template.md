# OKR Template (90 days)
- O1: Assisted adviser; O2: Playbooks; O3: Governed corpus
