# ROADMAP_NOTES
- Stage under CoCache/advice/wealth/AI_Shock_Pivot/<build-id>/
- Create pointer entry in docs/intent/manifest.json if used.
- Kick off weekly 30-min standup; update metrics CSV; commit deltas.
