Weights: Impact 0.35, Rights 0.25, Equity 0.20, Feasibility 0.15, Reversibility 0.05. Publish sub-scores + composite + confidence band from evidence grade.
