A: multi-site RCTs; B: single RCT/strong quasi-experiment; C: observational/pilot; D: expert theory only; U: unknown. Include one-paragraph justification + links.
