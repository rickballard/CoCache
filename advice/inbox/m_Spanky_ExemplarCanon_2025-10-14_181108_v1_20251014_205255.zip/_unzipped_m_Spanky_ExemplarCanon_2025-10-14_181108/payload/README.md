# CoCivium Exemplar Canon — Advice Bomb (v0.1)
Catalog policy exemplars (concept→scaled) without endorsing policy. Includes template + schema, lifecycle, evidence grades, HumanGate, lints, intake templates, and setup DO script.
Placement: CoCore/BestPractices/Exemplars/<domain>/<id>/ ; CoCache/ExemplarCanon for runs/dashboards.
