Triggers: bio/surveillance, minors/sensitive data, rights_burden_index ≥70, due-process <60, weak inference + high stakes. Outputs: mitigations, redactions, consent plan.
