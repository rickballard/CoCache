# Roles, Circles, Mandates

- **Stewards**: temporary custodians executing DAO-approved **Mandates**; no enrichment; COI disclosure; rotation required.
- **Contributors**: earn merit via accepted work; governance weight may be non-transferable.
- **Circles**: self-organising, topic-bound teams; form/disband as needed.
- **Mandates**: time-limited scopes approved by DAO/mesh; Stewards act only within active Mandates.
