# ASSUMPTIONS
- GitHub workflows available across repos.
- PowerShell 7 is available for DO blocks.
- Repos can add `.cocache.yml` and `coevo/*` without friction.
