Title: MANIFEST
Intent: Backfilled legacy advice
Owner: Backfill
Version: 2025-10-25T02-08-40
Status: settled
Guardrails:
  MaxSizeKB: 256
  MaxCadenceMins: 30
  MaxChangePct: 20
Change-Notes:
  - Backfilled from legacy content; preserved original timestamp

## Source Files
- docs\staging\CoTheoryAssets\CoAxa_20251025_020840\MANIFEST.json)
