# TL;DR
Multiple sessions were locking up. We produced a Spanky v2.2 archive with required structure, counts, and MISSING markers for unavailable materials.
