# Sources
- User-provided Spanky Request Pack v2.2 (instruction files).
- Recent in-session guidance and reports of lockups.
