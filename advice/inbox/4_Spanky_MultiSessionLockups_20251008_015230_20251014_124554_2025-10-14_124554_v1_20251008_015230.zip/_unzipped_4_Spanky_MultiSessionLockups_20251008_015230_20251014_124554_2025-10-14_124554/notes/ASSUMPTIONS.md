# Assumptions
- The attached pack (v2.2) defines the structure and minimal metadata expectations.
- Some sessions cannot be accessed by tools; placeholders are acceptable per rules.
