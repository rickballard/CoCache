# Decisions
- Proceed with archive creation despite missing raw transcripts by using MISSING_* markers and summaries.
- Use ShortName = MultiSessionLockups to reflect the symptom focus.
