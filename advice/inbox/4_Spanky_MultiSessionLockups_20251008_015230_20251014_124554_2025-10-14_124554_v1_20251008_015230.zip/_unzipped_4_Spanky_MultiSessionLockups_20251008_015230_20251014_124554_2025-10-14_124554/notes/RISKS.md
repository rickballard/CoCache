# Risks
- Partial capture may omit nuanced early intents.
- Misalignment on ShortName could require renaming later.
- If missing deliverables exist elsewhere, this archive will list them as MISSING_*.
