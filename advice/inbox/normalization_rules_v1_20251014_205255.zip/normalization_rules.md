# Normalization Rules
- Publish absolute Δ and relative %Δ; prefer DiD with CI.
- Cost-effectiveness: cost_per_unit_outcome for one primary KPI.
- Transforms: index=100 at baseline or log; declare in KPI.normalization.
- Denominators enforced centrally; unknown denominators fail lints.
