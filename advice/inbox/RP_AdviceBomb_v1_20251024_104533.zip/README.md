Title: RP_AdviceBomb
Intent: Backfilled legacy advice
Owner: Backfill
Version: 2025-10-24T10-45-33
Status: settled
Guardrails:
  MaxSizeKB: 256
  MaxCadenceMins: 30
  MaxChangePct: 20
Change-Notes:
  - Backfilled from legacy content; preserved original timestamp

## Source Files
- advice\incoming\RP_AdviceBomb_v1.zip)
