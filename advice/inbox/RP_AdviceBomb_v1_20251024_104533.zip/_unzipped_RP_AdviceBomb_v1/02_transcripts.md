
# Transcripts — From Capture to Insight
- Keep a full transcript (plain text) beside each draft.
- Prefer official transcripts; use auto-captions as fallback.
- Avoid timestamp shards; paraphrase 6–10 self-contained insights.
- If quoting, keep it short and include an approximate timestamp.
