
# Repo Alignment — Gentle Structure
RickPublic/
  sotw/<slug>/post.md
  sotw/<slug>/assets/transcript.txt
candidates/2025-10.md
templates/repost.md
