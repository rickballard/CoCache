# Inspiration Pointer
Seed corpus (Operating theses, Upgrade plan, PIU schema/examples, specs) lives in the prior Inspiration Pack zip.
