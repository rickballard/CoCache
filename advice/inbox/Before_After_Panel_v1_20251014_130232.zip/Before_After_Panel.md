# Before / After — Mudfling to Lightring

## Mudfling (what it feels like)
- Fast talk, thin thinking
- Slides as weapons, not lenses
- Interruptions > completed turns
- Energy drops as time rises
- Decisions drift after the room empties

## Lightring (what it feels like)
- Pause first, then speak
- Cards carry the voice, not volume
- Completed turns > interruptions
- Energy rises as clarity forms
- Decisions stick because links are visible

> From meeting to meaning.
