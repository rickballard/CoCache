# SOURCES
- Session outputs; article-specific data to be listed per Methods.
