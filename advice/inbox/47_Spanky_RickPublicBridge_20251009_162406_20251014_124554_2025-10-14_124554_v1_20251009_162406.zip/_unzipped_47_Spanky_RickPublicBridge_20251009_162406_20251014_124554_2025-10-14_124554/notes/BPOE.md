# BPOE Notes
- Spanky contract satisfied.
- Checksums provided for integrity.
- Between-article experimentation only.
