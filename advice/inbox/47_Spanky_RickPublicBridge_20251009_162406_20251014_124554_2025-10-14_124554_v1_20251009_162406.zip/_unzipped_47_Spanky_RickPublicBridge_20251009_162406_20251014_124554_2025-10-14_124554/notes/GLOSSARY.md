# GLOSSARY
- Baseline, Between-article experiment, Resonance Score.
