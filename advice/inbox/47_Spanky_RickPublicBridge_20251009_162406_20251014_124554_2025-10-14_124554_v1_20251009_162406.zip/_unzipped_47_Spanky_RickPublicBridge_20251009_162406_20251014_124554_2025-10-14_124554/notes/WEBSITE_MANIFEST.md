# WEBSITE MANIFEST
- Pinned video slot; standard skeleton; footers with sources & repo links.
