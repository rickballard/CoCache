# INTENTIONS
- Unify outputs across sessions via a standard advice‑bomb interface.
- Reduce planning fragmentation; increase ingest reliability.
- Embed congruence and transparency as default operating rules.
