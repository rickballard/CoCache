Title: CoPing_Guardrails
Intent: Backfilled legacy advice
Owner: Backfill
Version: 2025-10-25T13-42-10
Status: settled
Guardrails:
  MaxSizeKB: 256
  MaxCadenceMins: 30
  MaxChangePct: 20
Change-Notes:
  - Backfilled from legacy content; preserved original timestamp

## Source Files
- advice\CoPing_Guardrails.txt)
