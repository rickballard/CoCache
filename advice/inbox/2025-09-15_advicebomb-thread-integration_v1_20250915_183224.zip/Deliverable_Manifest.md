filename: 2025-09-15_advicebomb-thread-integration_v1_20250915_183224.zip
version: v1
timestamp: 20250915_183224
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
