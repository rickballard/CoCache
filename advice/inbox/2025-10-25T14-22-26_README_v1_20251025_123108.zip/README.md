Title: 2025-10-25T14-22-26_README
Intent: Backfilled legacy advice
Owner: Backfill
Version: 2025-10-25T12-31-08
Status: settled
Guardrails:
  MaxSizeKB: 256
  MaxCadenceMins: 30
  MaxChangePct: 20
Change-Notes:
  - Backfilled from legacy content; preserved original timestamp

## Source Files
- docs\intent\advice\processed\2025-10-25T14-22-26_README.md)
