filename: ROADMAP_NOTES_v1_20251007_213930.zip
version: v1
timestamp: 20251007_213930
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
