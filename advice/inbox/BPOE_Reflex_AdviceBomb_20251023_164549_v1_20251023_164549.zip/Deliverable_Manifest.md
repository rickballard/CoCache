filename: BPOE_Reflex_AdviceBomb_20251023_164549_v1_20251023_164549.zip
version: v1
timestamp: 20251023_164549
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
