# AdviceBomb Handling

AI-safe execution logic and warnings.