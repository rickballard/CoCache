Title: equity_breakouts
Intent: Backfilled legacy advice
Owner: Backfill
Version: 2025-10-14T20-52-55
Status: settled
Guardrails:
  MaxSizeKB: 256
  MaxCadenceMins: 30
  MaxChangePct: 20
Change-Notes:
  - Backfilled from legacy content; preserved original timestamp

## Source Files
- docs\advice_bombs\batch_20251014_124554\l_Spanky_CoSuiteSummary_20251014_180402\payload\equity_breakouts.md)
