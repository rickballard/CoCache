# Assumptions
- User will relaunch inside CoAgent once MVP+ is ready.
- Local paths as used in PowerShell blocks exist or will be created as needed.
