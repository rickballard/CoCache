# Dependencies
- CoAgent MVP+ (onboarding, session recall, sidecar, coevo hooks).
- Bitwarden for secrets; passworded zip handling.
- GitHub repos access and mirroring.
