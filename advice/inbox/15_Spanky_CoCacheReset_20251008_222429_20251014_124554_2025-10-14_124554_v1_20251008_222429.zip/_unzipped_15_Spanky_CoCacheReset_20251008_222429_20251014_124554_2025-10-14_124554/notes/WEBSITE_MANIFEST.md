# Website Manifest (targets)
- CoCivium.org: Human face + AI (alien aesthetic).
- InSeed.com: Consulting-grade credibility.
- CoPolitic.org: Association of sponsors/supporters.
- GroupBuild.org: Fallback staging if external repo stalls.
