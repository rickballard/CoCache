# Sources
- This conversation's session content and directives.
- User-provided PowerShell transcripts (in-session).
