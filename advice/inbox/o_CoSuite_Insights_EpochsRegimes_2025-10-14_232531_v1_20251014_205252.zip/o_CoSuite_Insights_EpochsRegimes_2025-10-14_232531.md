# Package: o_CoSuite_Insights_EpochsRegimes_20251014_232531.zip

* SHA256: FBAAEACD1D8413F67FDDC9F7F2AAC9ABFB9A214D2C18B23C621164580AE20E46
* Size:   7517 bytes
* Contents: 6x(noext)
* Hints:  unsure

## Tree (top)
- insights_ages_falsifiers_20251014_232531\_insight.meta.json
- insights_ages_falsifiers_20251014_232531\cocivium_hypotheses.csv
- insights_ages_falsifiers_20251014_232531\pragmatics.md
- insights_ages_falsifiers_20251014_232531\README.md
- insights_ages_falsifiers_20251014_232531\scorecard_template.csv
- insights_ages_falsifiers_20251014_232531\theory.md

