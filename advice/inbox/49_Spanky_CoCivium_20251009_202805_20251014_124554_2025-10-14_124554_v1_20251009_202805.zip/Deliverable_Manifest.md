filename: 49_Spanky_CoCivium_20251009_202805_20251014_124554_2025-10-14_124554_v1_20251009_202805.zip
version: v1
timestamp: 20251009_202805
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
