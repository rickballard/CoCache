# Assumptions
- Contributors can run PS7 locally; repos are public where possible.
