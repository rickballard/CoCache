# Deprecated
- Human-only poetic canon / gibberlink policy.
