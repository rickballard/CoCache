# Dependencies
- GitHub local clones; Git CLI.
