# Decisions
- Abandon AI-only-human-poetry governance in seed stage.
