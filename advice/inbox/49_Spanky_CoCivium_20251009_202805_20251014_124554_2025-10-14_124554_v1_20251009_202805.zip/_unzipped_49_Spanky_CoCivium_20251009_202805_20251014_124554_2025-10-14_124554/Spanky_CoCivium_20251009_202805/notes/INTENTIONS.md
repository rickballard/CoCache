# Intentions
- Establish CoCache as authoritative intersessional memory.

## Unfinished
- Draft and land four new insight docs.
