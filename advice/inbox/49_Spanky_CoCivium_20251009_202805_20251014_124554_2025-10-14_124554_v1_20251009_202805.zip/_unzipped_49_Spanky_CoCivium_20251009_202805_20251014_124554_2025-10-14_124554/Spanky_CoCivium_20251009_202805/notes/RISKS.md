# Risks
- Schema creep; staleness; over-surface area; trust optics.
