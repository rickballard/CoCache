# Roadmap Notes
1) Create four insight docs.
2) CI staleness checks + decision ledgers.
3) Keep ≤7 active initiatives.
4) Publish orientation artifacts and link to CoCache.
