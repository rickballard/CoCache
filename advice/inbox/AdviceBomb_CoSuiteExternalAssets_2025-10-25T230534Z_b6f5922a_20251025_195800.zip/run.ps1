#requires -Version 7.0
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

# --- CONFIG ---
# Default staging path (edit as needed). Suggest CoCache staging:
# e.g., C:\Users\Chris\Documents\GitHub\CoCache\docs\staging\CoSuiteAssets_Advisory_YYYYMMDD
$UserHome = [Environment]::GetFolderPath('UserProfile')
$DefaultTarget = Join-Path $UserHome 'Documents\GitHub\CoCache\docs\staging\CoSuiteAssets_Advisory_{0}' -f (Get-Date -Format 'yyyyMMdd_HHmmss')
$Target = $env:COCACHE_ADVISORY_TARGET
if ([string]::IsNullOrWhiteSpace($Target)) { $Target = $DefaultTarget }

# --- CREATE TARGET ---
New-Item -ItemType Directory -Path $Target -Force | Out-Null

# --- COPY DOCS ---
$srcDocs = Join-Path $PSScriptRoot 'docs'
Copy-Item -Path (Join-Path $srcDocs '*') -Destination $Target -Recurse -Force

# --- EMIT STATUS ---
$status = "OK: CoSuite External Assets Advisory staged to: {0}" -f $Target
Set-Content -Path (Join-Path $PSScriptRoot 'out.txt') -Value $status -Encoding UTF8

Write-Host $status
Write-Host "Next: review TLDR.md, then commit/push if desired."
