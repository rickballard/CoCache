# AdviceBomb — CoSuite External Assets (v0.1)
Date: 2025-10-25T230534Z (UTC)

This package consolidates *all* assets discussed in the session for CoSuite, plus additional vetted sources,
grouped by how to leverage, why needed, and urgency/priority. It includes a DO block (`run.ps1`) and manifests
compatible with the CoAgent/CoPayload runner.

## Contents
- `run.ps1` — DO block to stage this advice into a CoCache staging folder and emit `out.txt` status line.
- `_hp.manifest.json` — optional execution order manifest (single-step in this bundle).
- `_copayload.meta.json` — metadata for provenance and routing.
- `docs/` — human-readable advisory:
  - `TLDR.md` — one-screen summary.
  - `CoSuite_External_Assets_Advisory.md` — full advisory document.
  - `SOURCES.md` — links and brief notes (licensing/etiquette).
  - `CHECKSUMS.txt` — SHA256 of files in this bundle.

## What this does (non-destructive)
- Copies the advisory docs to a local *staging* path you select (default suggested path under your CoCache repo).
- Writes a single-line status file `out.txt` at the root of this bundle upon success.
- Does **not** install software, fetch external data, or modify repos.

## How to use
1. Unzip somewhere safe (e.g., `C:\Users\Chris\Downloads\HH\AdviceBombs\CoSuiteAssets_v0_1`).
2. Open **PowerShell 7** in that folder.
3. Run: `./run.ps1`
4. Inspect the target staging folder (printed at the end) and commit/push if desired.

## Priority quick glance (from full advisory)
- **P0 (Now):** Entity & provenance backbone (GLEIF, OpenCorporates, PROV-O/DCAT/SKOS), Evidence graph (OpenAlex, Crossref, DataCite), Regulatory sources (EDGAR, GovInfo/EUR-Lex/legislation.gov.uk/CanLII), Web provenance (Wayback CDX).
- **P1 (Next):** OA access (arXiv, Unpaywall, DOAJ, CORE), Indicators (World Bank/OECD/StatsCan/IMF/FRED/ECB), News & claims (GDELT, Fact Check Tools), Geo stack (OSM/ORS/MapLibre/Natural Earth), Data quality/security (GX, OSV, OpenRefine).
- **P2/P3:** Nice-to-haves and specialized enrichments (OCCRP Aleph, OpenParliament, Copernicus/NASA Earthdata, Openverse, Badges).

