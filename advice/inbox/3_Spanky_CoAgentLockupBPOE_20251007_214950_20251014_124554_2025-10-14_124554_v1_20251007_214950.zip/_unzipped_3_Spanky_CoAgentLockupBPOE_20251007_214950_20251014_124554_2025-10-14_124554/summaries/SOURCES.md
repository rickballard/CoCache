# Sources
- User reports and observed behavior in this session.
- Prior CoAgent HealthGate/Advice Bomb patterns in your repos.
- General browser triage practices (incognito, extension isolation, reboot, status checks).