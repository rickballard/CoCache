# Website Manifest
- No website assets changed in this incident.
- If CoAgent docs site exists, add a Troubleshooting page linking these advisories.