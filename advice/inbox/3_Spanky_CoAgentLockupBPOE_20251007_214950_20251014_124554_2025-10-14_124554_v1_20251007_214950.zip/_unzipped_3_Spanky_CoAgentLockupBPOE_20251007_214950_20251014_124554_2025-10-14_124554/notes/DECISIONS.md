# Decisions
- Treat lockups as recoverable faults; design for graceful continuity.
- Ship HealthGate preflight as a blocker if checks fail.
- Prefer CoWrap consolidation over proliferating idle sessions.