# Glossary
- **CoWrap/Spanky**: Portable bundle of session artifacts + instructions.
- **HealthGate**: Preflight gate blocking startup on failed checks.
- **Sidecar**: CoCache/log watchers and helpers outside the main UI.
- **Safe Mode**: Minimal UI with watchers disabled.