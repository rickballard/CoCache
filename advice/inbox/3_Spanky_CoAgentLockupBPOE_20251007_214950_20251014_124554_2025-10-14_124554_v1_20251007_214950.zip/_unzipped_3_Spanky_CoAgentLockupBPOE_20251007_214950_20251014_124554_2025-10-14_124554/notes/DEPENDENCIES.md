# Dependencies
- LLM provider status endpoint
- CoCache writable directory and quota
- Minimal JS telemetry for heap/CPU hints (privacy-safe)