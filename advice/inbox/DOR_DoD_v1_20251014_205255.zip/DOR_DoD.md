# DOR (Definition of Ready)
- Problem:
- Scope (in/out):
- Inputs & Interfaces:
- Owner:
- Deadline:
- Risks & mitigations:

# DoD (Definition of Done)
- Artifacts:
- Validation (script/checklist):
- CI proof:
- Docs updated:
- Demo link:
