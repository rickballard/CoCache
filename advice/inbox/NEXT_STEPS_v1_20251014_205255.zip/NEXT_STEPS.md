# Next Steps (7–14 days)
- Run DO scripts to scaffold folders, templates, `.github` intake.
- Enable CoAgent watcher: run lints; block on HumanGate triggers; label by domain/flags.
- Seed 10 concept exemplars with KPI plans (unknown allowed if accompanied by plan).
- Publish Denominator Dictionary v0 and enforce.
- Open placeholder dashboards and wire to congruence output.
- Recruit Stewards, Citizens’ Panel, Standards Liaison, Data/Infra.
