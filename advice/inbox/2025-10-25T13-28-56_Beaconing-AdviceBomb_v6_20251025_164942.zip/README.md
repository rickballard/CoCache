Title: 2025-10-25T13-28-56_Beaconing-AdviceBomb
Intent: Backfilled legacy advice
Owner: Backfill
Version: 2025-10-25T16-49-42
Status: settled
Guardrails:
  MaxSizeKB: 256
  MaxCadenceMins: 30
  MaxChangePct: 20
Change-Notes:
  - Backfilled from legacy content; preserved original timestamp

## Source Files
- docs\intent\advice\archive\2025-10-25T13-28-56_Beaconing-AdviceBomb_v6_20251025_164942.zip)
