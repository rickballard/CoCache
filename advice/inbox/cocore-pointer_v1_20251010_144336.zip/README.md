Title: cocore-pointer
Intent: Backfilled legacy advice
Owner: Backfill
Version: 2025-10-10T14-43-36
Status: settled
Guardrails:
  MaxSizeKB: 256
  MaxCadenceMins: 30
  MaxChangePct: 20
Change-Notes:
  - Backfilled from legacy content; preserved original timestamp

## Source Files
- docs\advicebombs\cocore-pointer.md)
