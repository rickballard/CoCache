filename: cocore-pointer_v1_20251010_144336.zip
version: v1
timestamp: 20251010_144336
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
