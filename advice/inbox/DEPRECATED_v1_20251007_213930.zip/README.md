Title: DEPRECATED
Intent: Backfilled legacy advice
Owner: Backfill
Version: 2025-10-07T21-39-30
Status: settled
Guardrails:
  MaxSizeKB: 256
  MaxCadenceMins: 30
  MaxChangePct: 20
Change-Notes:
  - Backfilled from legacy content; preserved original timestamp

## Source Files
- docs\advice_bombs\batch_20251014_124554\.18_Spanky_TypeK_Briefing_20251009_024352\notes\DEPRECATED.md
- docs\advice_bombs\batch_20251014_124554\.1_Spanky_examples_20251008_004552\Spanky_examples_20251008_004552\notes\DEPRECATED.md
- docs\advice_bombs\batch_20251014_124554\.1_Spanky_examples_20251008_004552\Spanky_examples_20251008_004552\payload\forms\notes\DEPRECATED.md
- docs\advice_bombs\batch_20251014_124554\.21_Spanky_CoCore_20251009_025331\notes\DEPRECATED.md
- docs\advice_bombs\batch_20251014_124554\.22_Spanky_GodspawnSessionRecovery_20251009_025454\notes\DEPRECATED.md
- docs\advice_bombs\batch_20251014_124554\.25_Spanky_MultiRepoGH_20251009_030819\notes\DEPRECATED.md
- docs\advice_bombs\batch_20251014_124554\.32_Spanky_Congruence_20251009_183041\notes\DEPRECATED.md
- docs\advice_bombs\batch_20251014_124554\.36_Spanky_RequestPack_20251009_185641\notes\DEPRECATED.md
- docs\advice_bombs\batch_20251014_124554\.36_Spanky_RequestPack_20251009_185641\payload\forms\notes\DEPRECATED.md
- docs\advice_bombs\batch_20251014_124554\.37_Spanky_HP_20251009_191434\notes\DEPRECATED.md
- docs\advice_bombs\batch_20251014_124554\.44c_Spanky_CoCivOutreach_20251009_201820\forms\notes\DEPRECATED.md)
