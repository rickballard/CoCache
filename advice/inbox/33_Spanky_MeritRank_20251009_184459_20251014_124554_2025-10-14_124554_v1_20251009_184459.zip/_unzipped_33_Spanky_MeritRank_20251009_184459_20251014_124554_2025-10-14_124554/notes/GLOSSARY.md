# Glossary
- badge: the job producing required status and artifacts.
- deploy: job that publishes to Pages on main.
- strict: branch-protection up-to-date requirement.
