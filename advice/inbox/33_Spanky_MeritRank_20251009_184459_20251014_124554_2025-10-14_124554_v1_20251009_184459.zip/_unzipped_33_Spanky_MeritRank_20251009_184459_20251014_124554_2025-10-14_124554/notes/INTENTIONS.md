# Intentions
- Maintain fast signal with `badge` as the only required check.
- Keep Pages deploy exclusive to `main`.
- Preserve scriptable flows (PowerShell + gh).

## Unfinished
- Investigate/deflake `smoke (windows-latest)` job.
- Expand details page beyond `badge.json`.
