# Deprecated
- Required context string "MeritRank Badge Publish / badge" (now just `badge`).
- Pages steps on PR events.
