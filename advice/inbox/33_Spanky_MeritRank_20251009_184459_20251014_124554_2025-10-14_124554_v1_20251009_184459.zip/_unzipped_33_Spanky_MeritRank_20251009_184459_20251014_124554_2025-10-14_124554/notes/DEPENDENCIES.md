# Dependencies
- GitHub CLI authenticated.
- GitHub Actions permissions: contents:read, pages:write, id-token:write.
- PowerShell 7+ for local helper scripts.
