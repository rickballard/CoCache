# Assumptions
- Repo: rickballard/MeritRank uses GitHub Pages.
- Job name `badge` remains stable.
