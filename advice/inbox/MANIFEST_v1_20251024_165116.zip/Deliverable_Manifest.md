filename: MANIFEST_v1_20251024_165116.zip
version: v1
timestamp: 20251024_165116
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
