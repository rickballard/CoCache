# Website Manifest (Draft)
- Public docs page: HealthGate overview, privacy stance (read-only), how-to run.
- Troubleshooting page: HID hygiene, stallouts, AV exclusions.
