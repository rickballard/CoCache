# Risks
- False positives if counters sampled during load spikes.
- Users may misinterpret HealthGate WARN as product defect.
- Over-collection concerns; mitigate by staying read-only.
