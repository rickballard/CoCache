# Decisions
- Use read-only checks only; no silent system mutation.
- Store HealthGate report artifacts (md/json) per run.
- Use PRs for protected branches with auto-merge.
