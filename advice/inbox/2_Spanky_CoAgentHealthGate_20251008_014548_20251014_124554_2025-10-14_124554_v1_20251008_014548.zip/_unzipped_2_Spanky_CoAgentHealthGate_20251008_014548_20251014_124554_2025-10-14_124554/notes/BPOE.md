# BPOE Notes
- HealthGate preflight is required before heavy workflows.
- Guard PowerShell profiles with Test-Path; avoid auto-launch.
- HID hygiene (clean/replace keyboard/mouse) can resolve phantom inputs.
- Defer deep diagnostics to trusted external tools on consent.
