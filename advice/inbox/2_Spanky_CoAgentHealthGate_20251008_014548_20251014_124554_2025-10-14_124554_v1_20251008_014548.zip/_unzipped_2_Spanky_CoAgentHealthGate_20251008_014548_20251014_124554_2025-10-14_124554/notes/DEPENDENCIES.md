# Dependencies
- PowerShell 7+
- Windows CIM/WMI availability
- Optional: Sysinternals, CrystalDiskInfo, HWiNFO (when user opts-in)
