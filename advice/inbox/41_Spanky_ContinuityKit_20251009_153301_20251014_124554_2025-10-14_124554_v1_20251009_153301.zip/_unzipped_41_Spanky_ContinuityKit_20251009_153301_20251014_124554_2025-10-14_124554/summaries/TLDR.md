# TL;DR
- Make portable, verified copies of every repo (local mirrors + ZIPs).
- Optionally add a small LAN Gitea host for nightly auto-mirroring.
- Harden domains (locks + DNSSEC) and keep a vendor-neutral continuity kit in CoCache.
