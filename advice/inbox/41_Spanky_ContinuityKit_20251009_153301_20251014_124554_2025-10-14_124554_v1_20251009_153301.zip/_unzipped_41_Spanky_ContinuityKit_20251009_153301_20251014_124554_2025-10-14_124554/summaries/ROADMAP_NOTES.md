# ROADMAP NOTES
1) Week N: Run mirror + zip packer, copy to Synology.
2) Week N+1: Add GH Action to 1–2 critical repos and confirm mirrors.
3) Month N+1: Procure small LAN box; deploy Gitea; shift nightly mirrors.
4) Quarter: Set up off-site object storage; test restore; print cheat sheets.
