# GLOSSARY (selected)
- **Bare mirror**: a `.git` directory containing all objects/refs, suitable for push/pull.
- **Bundle**: a single-file pack stream (`git bundle`) that can restore a repo without network.
- **Registry Lock**: registrar+registry controlled lock preventing unauthorized domain transfers.
