# WEBSITE_MANIFEST
- Continuity landing page (static HTML) that can be hosted on LAN or any VPS:
  - Announces new origin URLs if GitHub unavailable.
  - Lists mirrors and contact email for access.
