# ASSUMPTIONS
- Synology is reachable by you only; manual copy step is required.
- LAN mirror host (if added) will be reachable over Tailscale, not exposed publicly.
- GitHub org structure remains stable during the next week.
