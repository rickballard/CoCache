filename: 2025-10-25T13-28-56_AI_BEACON_STRATEGY_v6_20251025_133959.zip
version: v6
timestamp: 20251025_133959
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
