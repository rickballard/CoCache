# WEBSITE_MANIFEST
- Place Explainer in `docs/insights/` with badges and hover chips.
- Cross-link to Cognocarta Consenti and Governance Spec.
