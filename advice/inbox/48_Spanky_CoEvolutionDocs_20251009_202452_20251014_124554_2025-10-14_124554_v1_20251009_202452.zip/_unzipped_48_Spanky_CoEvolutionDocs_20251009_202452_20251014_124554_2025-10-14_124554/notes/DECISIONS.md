# DECISIONS
- Use tiered sensitivity model.
- Human-gate required for Established/Canonical semantic changes.
- Avoid rainbow color-coding; use badges/hover metadata instead.
