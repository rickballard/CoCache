# BPOE Notes
- Keep AI contributions rate-limited post-Launch to preserve human voice.
- Record decision provenance (`human|ai|hybrid`) in PR template.
- Schedule periodic canon audits; maintain immutable audit trails for Canonical edits.
