# ASSUMPTIONS
- Community size sufficient for quorum-based voting.
- Repos will adopt sidecar metadata pattern without breaking builds.
