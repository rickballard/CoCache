# DEPRECATED
- Earlier standalone CoGenetics drafts superseded by this Idea Card and forthcoming Governance Spec.
