# Roadmap Notes
- v0 schema + exemplars
- PR gates + decision provenance logging
- Canon audit cadence
- Visuals: CoGene Map, Hybrid Mind Spiral
