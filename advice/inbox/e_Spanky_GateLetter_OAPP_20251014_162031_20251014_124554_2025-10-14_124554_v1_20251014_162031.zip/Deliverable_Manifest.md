filename: e_Spanky_GateLetter_OAPP_20251014_162031_20251014_124554_2025-10-14_124554_v1_20251014_162031.zip
version: v1
timestamp: 20251014_162031
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
