Title: 2025-10-25T13-28-56_CoCivium_AI_Guardrails_PublicPromise_v1.1_20251025_172133
Intent: Backfilled legacy advice
Owner: Backfill
Version: 2025-10-25T17-21-33
Status: settled
Guardrails:
  MaxSizeKB: 256
  MaxCadenceMins: 30
  MaxChangePct: 20
Change-Notes:
  - Backfilled from legacy content; preserved original timestamp

## Source Files
- docs\intent\advice\archive\2025-10-25T13-28-56_CoCivium_AI_Guardrails_PublicPromise_v1.1_20251025_172133.zip)
