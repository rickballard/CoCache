Title: launch
Intent: Backfilled legacy advice
Owner: Backfill
Version: 2025-09-18T21-50-45
Status: settled
Guardrails:
  MaxSizeKB: 256
  MaxCadenceMins: 30
  MaxChangePct: 20
Change-Notes:
  - Backfilled from legacy content; preserved original timestamp

## Source Files
- docs\advice_bombs\batch_20251014_124554\.42_Spanky_RickGuard_20251009_194327\payload\ISSUE_TEMPLATE\launch.md)
