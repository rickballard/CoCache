filename: launch_v1_20250918_215045.zip
version: v1
timestamp: 20250918_215045
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
