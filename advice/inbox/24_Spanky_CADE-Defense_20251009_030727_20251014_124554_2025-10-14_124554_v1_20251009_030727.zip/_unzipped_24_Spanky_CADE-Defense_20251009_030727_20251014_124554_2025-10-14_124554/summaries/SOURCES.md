# SOURCES
- Attached: `Spanky_Request_Pack_v2_2_2025-10-08.zip` entries=5
  - 01_INSTRUCTION_BLOCK.md
  - 01_INSTRUCTION_BLOCK.txt
  - _examples/_copayload.meta.json
  - _examples/_wrap.manifest.json
  - forms/notes/DEPRECATED.md
