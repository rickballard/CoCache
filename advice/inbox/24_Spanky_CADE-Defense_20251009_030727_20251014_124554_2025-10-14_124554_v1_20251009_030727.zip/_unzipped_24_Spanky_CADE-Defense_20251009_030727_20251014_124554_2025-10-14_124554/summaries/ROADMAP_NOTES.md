# ROADMAP_NOTES
- Q1 mirrors/provenance/drills; Q2 model-routing & KPIs; Q3 external red-team.
