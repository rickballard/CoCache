# DECISIONS
- Prefer mirror+failover over single-platform reliance.
- Deepfake events treated as narrative drills with countersignals.
- Quarantine/deprecate over hard deletion (minimize coercion).
