# GLOSSARY (delta)
- **Tripwire:** Automatic trigger to restore or quarantine on anomaly.
- **Countersignal:** Transparent public response with provenance proofs.
