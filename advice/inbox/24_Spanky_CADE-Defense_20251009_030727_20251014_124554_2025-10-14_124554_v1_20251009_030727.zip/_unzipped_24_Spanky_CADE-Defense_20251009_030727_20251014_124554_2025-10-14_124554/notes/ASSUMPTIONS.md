# ASSUMPTIONS
- Primary AI provider may be intermittently unavailable.
- Some contributors have fragile browser caches.
- Congruence metrics can be gamed without monitoring.
