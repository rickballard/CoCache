# Civium Archived

The CoCivium™ repo is now **private + archived**.
- Final public tag: `final-public`
- Deprecation README merged (PR #402)
- Session plan & leftovers: see `docs/bpoe/SESSION_PLAN_GrandMigration.md` and `docs/migration/LEFTOVERS_Register.md`

Reason: migrated working docs/process into **CoCache**; Civium is no longer used.
