# Semantic Weaving — GIBindex Hotlinks

All human-facing docs auto-hotlink GIBindex terms; scripts remain unlinked.  
Phases: manual linking → CoAgent watcher injection → semantic tags (AI-parsable).
