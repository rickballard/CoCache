# Risks

- Scope creep leading to burnout and loss of traction.
- Repo collisions with concurrent sessions if edits happen prematurely.
- Misinterpretation without dual index (human + AI) clarity.
- Legal/licensing when ingesting external best practices.