# BPOE Notes (Safety & Process)

- Always warn Rick **before** any action that might trigger system guardrails.
- HumanGate ON by default; CoIntent protocol required for autonomous agent work.
- No repo-wide edits until Grand Migration declares final scroll published and stable.