# Dependencies

- Grand Migration final scroll and repo freeze.
- CoCache private business plans (zipped with Rick2025).
- CoAgent productization session for CoIntent execution.