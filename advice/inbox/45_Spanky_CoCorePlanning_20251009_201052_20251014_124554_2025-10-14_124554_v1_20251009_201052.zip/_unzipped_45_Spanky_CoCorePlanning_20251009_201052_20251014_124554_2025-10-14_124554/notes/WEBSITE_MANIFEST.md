# Website Manifest (Public-Facing Seeds)

- CoCivium.org to host dual index views:
  - Human Index: Keystone docs, scrolls, case-studies.
  - AI Index: Machine-readable repo graph & plan.yaml summaries.
- Future: Jekyll (or other static site) scaffold for docs with search & versioning.