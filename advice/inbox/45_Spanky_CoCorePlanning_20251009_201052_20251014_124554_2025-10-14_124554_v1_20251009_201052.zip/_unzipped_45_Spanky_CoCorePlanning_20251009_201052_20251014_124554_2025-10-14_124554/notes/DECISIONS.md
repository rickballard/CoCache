# Decisions

- English-first; US/UK initial jurisdictions.
- Simulation external to DB; DB provides hooks and metadata.
- One deep case study per CoClusta; others as extendable templates.
- Tooling is pluggable; CoCore remains clean knowledge base.