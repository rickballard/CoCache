# Deprecated / Out-of-Scope (For Now)

- Full multilingual support.
- Low-level per-employee workflow modeling at scale.
- Embedding simulation engines into CoCore.