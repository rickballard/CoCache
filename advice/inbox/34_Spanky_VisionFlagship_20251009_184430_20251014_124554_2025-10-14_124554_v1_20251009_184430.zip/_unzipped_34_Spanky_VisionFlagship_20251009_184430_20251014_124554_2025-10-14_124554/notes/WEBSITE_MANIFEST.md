# Website Manifest (draft)
- Title: Vision Flagship — Mudfling to Lightring
- Hero: grove scene with Lightring; 10-ft legibility
- Sections: Hook, Story, Analogue, EvoPath, Lifecycle, Hero, Ethics, Before/After, Mapping, Invitation
- AI sibling: expose JSON schema + GIBindex seeds
