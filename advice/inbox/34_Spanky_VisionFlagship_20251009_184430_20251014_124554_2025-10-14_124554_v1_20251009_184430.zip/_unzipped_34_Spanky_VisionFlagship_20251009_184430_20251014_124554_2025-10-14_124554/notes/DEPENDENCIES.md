# Dependencies
- HP / Hitchhiker Plan: packaging, CoWrap, site publishing.
- CoCivium repos: CoAgent, CoCache, GroupBuild, Best Practice DB, RepTag.
- Designer/AI image tool for hero image execution.
