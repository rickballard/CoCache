# Decisions
- Naming: Mudfling (bad meeting) to Lightring (good meeting).
- Session folder: Vision_Flagship (staged in Godspawn repo for now).
- Outline uses <details> blocks to keep surface skim, depth on demand.
- Repo keeps main branch clean; squash or commit directly to main.
