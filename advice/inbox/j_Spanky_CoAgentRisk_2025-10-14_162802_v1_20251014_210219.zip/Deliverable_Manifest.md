filename: j_Spanky_CoAgentRisk_2025-10-14_162802_v1_20251014_210219.zip
version: v1
timestamp: 20251014_210219
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
