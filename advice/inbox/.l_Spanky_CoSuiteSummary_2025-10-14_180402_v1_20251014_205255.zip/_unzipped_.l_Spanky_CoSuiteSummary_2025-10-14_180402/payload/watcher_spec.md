# CoAgent Watcher Spec
- On PR to Exemplars: run lints; check Metrics Core; verify denominators and equity breakouts; compute provisional congruence; label by domain and flags; block on HumanGate triggers.
