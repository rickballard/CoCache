# Congruence
Weights: Impact 35%, Rights 25%, Equity 20%, Feasibility 15%, Reversibility 5%.
Publish sub-scores + composite + confidence band.
