# Integration Guide
- CoCore: records/templates. CoCache: scoring runs/dashboards. CoAgent: lints, routing, labels. GIBINDEX codes in front matter.
