Cataloging ≠ endorsement. Dual-use/surveillance/bio content must be high-level; HumanGate review required; redact operational detail.
