filename: 35_Spanky_MeritRank_20251009_185743_20251014_124554_2025-10-14_124554_v1_20251009_185743.zip
version: v1
timestamp: 20251009_185743
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
