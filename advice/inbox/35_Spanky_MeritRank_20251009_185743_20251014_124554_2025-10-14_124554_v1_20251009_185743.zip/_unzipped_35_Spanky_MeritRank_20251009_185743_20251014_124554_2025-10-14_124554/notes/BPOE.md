# BPOE

- Keep `main` runnable: smoke locally and in CI.
- Externalize parameters (scoring constants).
- Rebase hygiene and artifact untracking.
- CI helpers for watch/triage/rerun.
- Branding & Trust/Safety positioning.