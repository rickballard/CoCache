filename: 1_Spanky_examples_20251008_004552_20251014_124554_2025-10-14_124554_v1_20251008_004552.zip
version: v1
timestamp: 20251008_004552
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
