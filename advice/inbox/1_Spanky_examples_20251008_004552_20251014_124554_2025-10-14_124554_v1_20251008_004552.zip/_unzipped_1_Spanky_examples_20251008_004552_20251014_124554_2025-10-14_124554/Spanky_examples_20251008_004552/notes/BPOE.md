# BPOE
- Idempotent asset generation via scripts; avoid manual edits.
- SVG sanitized; color variants via hex-swap; PNG fallbacks via ImageMagick.
- CI/CD to Substack gated by ethics thresholds.
