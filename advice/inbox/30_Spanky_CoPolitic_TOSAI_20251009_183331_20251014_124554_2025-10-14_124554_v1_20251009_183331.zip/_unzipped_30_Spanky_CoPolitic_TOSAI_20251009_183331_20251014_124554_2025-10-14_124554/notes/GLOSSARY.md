**TOS-AI** — Transition Office Steward (AI pivots): temporary executive steward guiding strategy, governance, operating-model shifts during AI transition.
**CoWrap/CoCache** — Local zip-able artifact capturing session outputs, scripts, and handoff instructions.
