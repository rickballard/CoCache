This pack was compiled from the active ChatGPT session artifacts and commands. No external downloads were embedded. Scripts are reconstructed from the session for convenience.
