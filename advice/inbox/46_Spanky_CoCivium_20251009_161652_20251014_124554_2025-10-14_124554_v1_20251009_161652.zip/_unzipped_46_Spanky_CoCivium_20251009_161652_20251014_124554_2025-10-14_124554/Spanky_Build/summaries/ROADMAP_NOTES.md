# ROADMAP NOTES
1. Upsweep repos; emit indexes (JSON/YAML + markdown).
2. Pilot two BPMN processes with CoAgent workers.
3. Publish Academy Folder 1 (Foundations) with translation track.
4. Downsweep: polish, link, and align indexes.
