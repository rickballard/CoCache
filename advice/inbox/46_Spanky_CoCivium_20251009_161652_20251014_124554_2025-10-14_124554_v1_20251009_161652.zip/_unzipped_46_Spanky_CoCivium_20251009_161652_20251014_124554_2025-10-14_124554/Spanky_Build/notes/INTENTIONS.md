# INTENTIONS
- Upsweep all repos; create machine- and human-readable indexes.
- Launch Academy folder series.
- Pilot two BPMN processes (Grant Lifecycle, Policy-Vote).
- (Unfinished) Define full Civic-BPMN stencil set and linting rules.
