# RISKS
- Drift between human and AI indexes.
- Over-complexity in orchestration models.
- Incomplete repo permissions blocking the upsweep.
