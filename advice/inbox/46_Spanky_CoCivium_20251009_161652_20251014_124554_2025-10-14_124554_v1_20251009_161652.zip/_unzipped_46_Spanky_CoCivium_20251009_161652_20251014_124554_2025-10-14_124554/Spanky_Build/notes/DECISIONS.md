# DECISIONS
- OSS-first orchestration, Camunda-inspired but not vendor-locked.
- BPMN/DMN as the lingua franca with Civic extensions.
