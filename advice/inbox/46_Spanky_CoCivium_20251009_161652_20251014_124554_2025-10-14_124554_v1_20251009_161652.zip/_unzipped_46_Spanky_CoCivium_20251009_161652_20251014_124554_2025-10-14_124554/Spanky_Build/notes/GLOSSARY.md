# GLOSSARY
- Civic-BPMN: BPMN extended with civic stencils (Assembly, Ballot, Grant Escrow, Reputation Check).
- Dual-layer Index: Human keystone doc list + AI graph metadata.
