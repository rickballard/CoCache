# DEPENDENCIES
- Access to all repos.
- GitHub API tokens (read-only for upsweep).
- Structured output directories for indexes.
