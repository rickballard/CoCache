# BPOE Notes
- Dual-layer indexing governance gate: human + AI layers must be updated together.
- Academy docs are living scaffolds; prioritize iteration over perfection.
- Treat recipient session as executor and learner.
