# Best Possible Operational Environment
- GitHub Pages static site
- Plausible analytics
- CF Worker enrichment optional
