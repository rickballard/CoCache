filename: seed-status_v1_20251010_150655.zip
version: v1
timestamp: 20251010_150655
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
