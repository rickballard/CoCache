# OUTREACH_CHECKLIST

- [ ] Send short intro email (or sector variant) with 2 links.
- [ ] Confirm the onboarding checklist page resolves.
- [ ] Offer a tiny docs PR task and shepherd if needed.
- [ ] If engaged, send long email variant (AdviceBomb invite).
- [ ] Log status in `outreach_targets.csv`.
- [ ] Leave a public trail (CoSync note with pointers).
