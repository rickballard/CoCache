# Roadmap Notes
- Canonical links; OG cards; follow-up posts.
