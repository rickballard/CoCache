# Website Manifest
- insights/global-village-buyback.md
- insights/images/hero_global_village_buyback.png
- insights/images/gvb_table.png
- insights/assets/js/soundtrack.js
- insights/assets/css/soundtrack.css
