# Intentions
- Clarify buyback effect; introduce CoCivium.
- Publish to Substack; keep repo canonical.
- Unfinished: OG/Twitter cards; UTM link; analytics.
