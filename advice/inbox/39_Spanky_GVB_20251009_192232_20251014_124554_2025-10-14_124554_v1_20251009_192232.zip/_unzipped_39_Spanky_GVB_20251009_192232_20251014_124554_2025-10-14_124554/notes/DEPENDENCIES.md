# Dependencies
- GitHub repo; Substack access; audio hosting.
