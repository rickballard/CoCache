# Glossary
- Buyback Effect; CoCivium; CME; Digital Halo.
