# Package: m_Spanky_ExemplarCanon_20251014_181108.zip

* SHA256: BF51EFA8BBD50F3044EFBA8A45D267C5AE5DB11C15A45F4F4ED38546D5E1C78F
* Size:   5401 bytes
* Contents: 14x(noext)
* Hints:  unsure

## Tree (top)
- payload\CoSuite_integration.md
- payload\disclaimer.md
- payload\DO_Setup_ExemplarCanon.ps1
- payload\evidence_grading.md
- payload\Exemplar_Scoring.md
- payload\EXEMPLAR_TEMPLATE.md
- payload\exemplar.schema.json
- payload\humangate.md
- payload\lifecycle.md
- payload\Lint-Exemplar.ps1
- payload\PULL_REQUEST_TEMPLATE.md
- payload\README.md
- payload\.github\ISSUE_TEMPLATE\exemplar_intake.md
- transcripts\session.md

