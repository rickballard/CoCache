# AdviceBomb — CoSuite External Assets (v0.2)
Date: 2025-10-26T000056Z (UTC)

See TLDR_v0_2.md for changes. Run fixup.ps1 then run.ps1.
