#requires -Version 7.0
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$UserHome = [Environment]::GetFolderPath('UserProfile')
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$Target = $env:COCACHE_ADVISORY_TARGET
if ([string]::IsNullOrWhiteSpace($Target)) {
  $Target = Join-Path $UserHome ("Documents\GitHub\CoCache\docs\staging\CoSuiteAssets_Advisory_{0}" -f $stamp)
}
New-Item -ItemType Directory -Path $Target -Force | Out-Null

$srcDocs = Join-Path $PSScriptRoot 'docs'
Copy-Item -Path (Join-Path $srcDocs '*') -Destination $Target -Recurse -Force

$status = "OK: CoSuite External Assets Advisory (v0.2) staged to: {0}" -f $Target
Set-Content -Path (Join-Path $PSScriptRoot 'out.txt') -Value $status -Encoding UTF8
Write-Host $status

Write-Host "CoEvo Checklist:" -ForegroundColor Cyan
@(
  "1) Prioritize P0 adapters: GLEIF, OpenCorporates, OpenAlex, Crossref, EDGAR, Wayback CDX.",
  "2) Confirm PROV-O/DCAT/SKOS schemas are in CoCore.",
  "3) Add owners in OWNERS.json and fill target SLAs in SLA.json.",
  "4) Run GX validations and OSV scans in CI for ingest jobs.",
  "5) File tickets for rate-limit backoff policies."
) | ForEach-Object { Write-Host " - $_" }
