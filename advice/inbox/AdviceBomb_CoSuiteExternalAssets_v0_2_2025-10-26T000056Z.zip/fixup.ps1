#requires -Version 7.0
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'
$CoCache = "$HOME\Documents\GitHub\CoCache"

$badRoot = Join-Path $CoCache 'docs\staging\CoSuiteAssets_Advisory_{0}\-f'
if(Test-Path $badRoot){
  $sub = Get-ChildItem -Path $badRoot -Directory | Select-Object -First 1
  if($sub){
    $stamp = $sub.Name
    $good = Join-Path $CoCache ("docs\staging\CoSuiteAssets_Advisory_{0}" -f $stamp)
    if(-not (Test-Path $good)){ New-Item -ItemType Directory -Path $good | Out-Null }
    Copy-Item -Path (Join-Path $sub.FullName '*') -Destination $good -Recurse -Force
    Write-Host ("Moved staged docs to: {0}" -f $good)
  } else {
    Write-Warning "Malformed path present but no dated subfolder found."
  }
} else {
  Write-Host "No malformed v0.1 path found; nothing to fix."
}
