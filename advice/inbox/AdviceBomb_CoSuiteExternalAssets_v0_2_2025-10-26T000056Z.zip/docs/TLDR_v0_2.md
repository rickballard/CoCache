# TL;DR v0.2
- Fixed staging path bug.
- Added CoEvo artifacts (OWNERS.json, SLA.json, adapters.json).
- Added fixup.ps1 to migrate malformed v0.1 staging.
- Same P0/P1 priorities; ready for owners + tickets.
