filename: f_Spanky_CoSuite-Summary_20251014_161916_20251014_124554_2025-10-14_124554_v1_20251014_161916.zip
version: v1
timestamp: 20251014_161916
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
