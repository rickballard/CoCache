# Mitigation Options (Seed)
- Kinetic impactor feasibility vs lead time
- Tugboat (continuous thrust) — decades lead
- Nuclear disruption — policy-gated, last-resort
