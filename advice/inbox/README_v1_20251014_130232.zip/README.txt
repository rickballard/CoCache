Session payload: PowerShell helpers and scaffolds reconstructed from the CoPolitic TOS-AI session.
