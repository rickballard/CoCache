This PR seeds **CoSteward (CoSteward)** — the Steward operating spine.

**What’s included**
- Human WIP cap (≤4) via `streams.yml` + CI
- `Co:` ideation intake and IdeaCards render
- Heartbeat script + CI presence check
- Templates for DOR/DoD and governance

**Acceptance**
- [ ] `streams.yml` reflects current 3–4 human streams
- [ ] First heartbeat file created
- [ ] Linked from CoCache global index

