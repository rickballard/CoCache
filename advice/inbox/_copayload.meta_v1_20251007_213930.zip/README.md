Title: _copayload.meta
Intent: Backfilled legacy advice
Owner: Backfill
Version: 2025-10-07T21-39-30
Status: settled
Guardrails:
  MaxSizeKB: 256
  MaxCadenceMins: 30
  MaxChangePct: 20
Change-Notes:
  - Backfilled from legacy content; preserved original timestamp

## Source Files
- docs\advice_bombs\batch_20251014_124554\.1_Spanky_examples_20251008_004552\Spanky_examples_20251008_004552\payload\_examples\_copayload.meta.json
- docs\advice_bombs\batch_20251014_124554\.1_Spanky_examples_20251008_004552\Spanky_examples_20251008_004552\_spanky\_copayload.meta.json
- docs\advice_bombs\batch_20251014_124554\.32_Spanky_Congruence_20251009_183041\_spanky\_copayload.meta.json
- docs\advice_bombs\batch_20251014_124554\.36_Spanky_RequestPack_20251009_185641\payload\_examples\_copayload.meta.json
- docs\advice_bombs\batch_20251014_124554\.36_Spanky_RequestPack_20251009_185641\_spanky\_copayload.meta.json
- docs\advice_bombs\batch_20251014_124554\.37_Spanky_HP_20251009_191434\_spanky\_copayload.meta.json
- docs\advice_bombs\batch_20251014_124554\.44c_Spanky_CoCivOutreach_20251009_201820\_examples\_copayload.meta.json
- docs\advice_bombs\batch_20251014_124554\.4_Spanky_MultiSessionLockups_20251008_015230\_spanky\_copayload.meta.json
- docs\advice_bombs\batch_20251014_124554\.50_Spanky_CoCiviumWP_20251009_204122\_spanky\_copayload.meta.json)
