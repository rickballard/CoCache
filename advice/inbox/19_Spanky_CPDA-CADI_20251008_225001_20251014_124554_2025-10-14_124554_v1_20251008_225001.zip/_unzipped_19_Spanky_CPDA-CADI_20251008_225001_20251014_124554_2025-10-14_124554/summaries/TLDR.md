# TL;DR
CPDA is a neutral, anti-capture umbrella that will evolve into **CoCivium**. CADI is the seed flagship. This pack contains repo scaffolds, microsite pages, governance skeletons, and headline graphics (quadrant/radar) ready to paste into GitHub.
