# Dependencies
- GitHub Pages for microsite.
- Open licenses (Apache-2.0, CC BY-SA/ODC-BY/ODbL).
- Future: Swiss/IoM legal shells; multi-sig wallets; mirror hosts.
