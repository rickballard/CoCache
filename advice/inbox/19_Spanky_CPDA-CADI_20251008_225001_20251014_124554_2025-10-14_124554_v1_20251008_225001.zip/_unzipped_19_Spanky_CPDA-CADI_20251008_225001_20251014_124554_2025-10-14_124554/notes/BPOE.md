# BPOE Notes (Session)
- Zip deliverable with deterministic structure.
- Metadata sidecar (`_spanky`) and transparency (manifest, checksums).
- No code to be run on user's machine; deliver drag-and-drop assets.
