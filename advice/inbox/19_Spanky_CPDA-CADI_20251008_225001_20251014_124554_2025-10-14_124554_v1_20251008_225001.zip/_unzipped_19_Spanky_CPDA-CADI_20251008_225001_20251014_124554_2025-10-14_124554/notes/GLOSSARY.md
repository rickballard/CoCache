# Glossary (Seed)
- **CPDA**: CoCivium Planetary Defence Alliance (temporary umbrella).
- **CoCivium**: Enduring community/commons Mindshare.
- **CADI**: CoCivium Asteroid Defence Initiative.
- **Steward/Contributor/Circle/Mandate**: Roles in no-kings governance mesh.
- **DAO/Mesh**: Rule-encoded, transparent governance layer.
