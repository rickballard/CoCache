Title: hp.manifest
Intent: Backfilled legacy advice
Owner: Backfill
Version: 2025-10-22T17-19-27
Status: settled
Guardrails:
  MaxSizeKB: 256
  MaxCadenceMins: 30
  MaxChangePct: 20
Change-Notes:
  - Backfilled from legacy content; preserved original timestamp

## Source Files
- docs\hp\hp.manifest.json)
