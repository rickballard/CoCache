Title: 2025-10-25T13-40-42_README
Intent: Backfilled legacy advice
Owner: Backfill
Version: 2025-10-25T13-39-48
Status: settled
Guardrails:
  MaxSizeKB: 256
  MaxCadenceMins: 30
  MaxChangePct: 20
Change-Notes:
  - Backfilled from legacy content; preserved original timestamp

## Source Files
- docs\intent\advice\archive\2025-10-25T13-40-42_README.md)
