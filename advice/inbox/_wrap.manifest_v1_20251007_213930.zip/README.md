Title: _wrap.manifest
Intent: Backfilled legacy advice
Owner: Backfill
Version: 2025-10-07T21-39-30
Status: settled
Guardrails:
  MaxSizeKB: 256
  MaxCadenceMins: 30
  MaxChangePct: 20
Change-Notes:
  - Backfilled from legacy content; preserved original timestamp

## Source Files
- docs\advice_bombs\batch_20251014_124554\.13_Spanky_CoAgency_20251009_022055\Spanky_CoAgency\_spanky\_wrap.manifest.json
- docs\advice_bombs\batch_20251014_124554\.1_Spanky_examples_20251008_004552\Spanky_examples_20251008_004552\payload\_examples\_wrap.manifest.json
- docs\advice_bombs\batch_20251014_124554\.1_Spanky_examples_20251008_004552\Spanky_examples_20251008_004552\_spanky\_wrap.manifest.json
- docs\advice_bombs\batch_20251014_124554\.32_Spanky_Congruence_20251009_183041\_spanky\_wrap.manifest.json
- docs\advice_bombs\batch_20251014_124554\.36_Spanky_RequestPack_20251009_185641\payload\_examples\_wrap.manifest.json
- docs\advice_bombs\batch_20251014_124554\.36_Spanky_RequestPack_20251009_185641\_spanky\_wrap.manifest.json
- docs\advice_bombs\batch_20251014_124554\.37_Spanky_HP_20251009_191434\_spanky\_wrap.manifest.json
- docs\advice_bombs\batch_20251014_124554\.40_Spanky_ScripTagger_20251009_193224\_spanky\_wrap.manifest.json
- docs\advice_bombs\batch_20251014_124554\.42_Spanky_RickGuard_20251009_194327\_spanky\_wrap.manifest.json
- docs\advice_bombs\batch_20251014_124554\.44c_Spanky_CoCivOutreach_20251009_201820\_examples\_wrap.manifest.json
- docs\advice_bombs\batch_20251014_124554\.4_Spanky_MultiSessionLockups_20251008_015230\_spanky\_wrap.manifest.json
- docs\advice_bombs\batch_20251014_124554\.50_Spanky_CoCiviumWP_20251009_204122\_spanky\_wrap.manifest.json
- docs\advice_bombs\batch_20251014_124554\.51_Spanky_CoCiviumDualSite_20251009_163123\_spanky\_wrap.manifest.json
- docs\advice_bombs\batch_20251014_124554\.6_Spanky_CoCiviumFaiths_20251008_015909\_spanky\_wrap.manifest.json)
