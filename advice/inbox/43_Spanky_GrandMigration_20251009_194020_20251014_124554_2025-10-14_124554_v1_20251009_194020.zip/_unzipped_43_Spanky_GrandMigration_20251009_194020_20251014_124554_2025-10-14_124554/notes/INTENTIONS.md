# Intentions (with status)

- Remove large blobs blocking pushes (**Done**).
- Establish CoTemp handoff pattern (**Done**).
- Produce session plan, templates, runbooks (**Done**).
- Deprecate Civium (private + archived) (**Done**).
- Wire OmniBar v2 KPIs to live metrics (**Unfinished**) → CoCache issue #26.
- Replace SMTP placeholders & validate digest Action (**Unfinished**) → CoCache issue #27.
