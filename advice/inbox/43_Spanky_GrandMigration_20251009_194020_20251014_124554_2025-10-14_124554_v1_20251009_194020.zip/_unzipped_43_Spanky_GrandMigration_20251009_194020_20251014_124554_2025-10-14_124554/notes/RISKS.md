# Risks
- Link rot after archival → mitigated by pointer docs and README notice.
- Hidden large objects resurfacing → mitigated by guard function and hook guidance.
