# Glossary
- **BPOE**: Best Practices / Operating Experience (IssueOps playbook).
- **CoTemp**: Local temp handoff directory convention for inter-session comms.
