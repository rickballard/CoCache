# Dual Approval Protocol (Human + AI)

All `main` merges require **Steward + ChatGPTsession** approval.  
Pre-merge checks: ontology closure, congruence lint, provenance, flood/spam heuristics, preview links for org/com renders.
