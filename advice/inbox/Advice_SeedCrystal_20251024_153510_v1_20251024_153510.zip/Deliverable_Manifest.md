filename: Advice_SeedCrystal_20251024_153510_v1_20251024_153510.zip
version: v1
timestamp: 20251024_153510
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
