# ROADMAP
1) Finalize SVG aesthetic
2) PNG fallback
3) Expand resources
