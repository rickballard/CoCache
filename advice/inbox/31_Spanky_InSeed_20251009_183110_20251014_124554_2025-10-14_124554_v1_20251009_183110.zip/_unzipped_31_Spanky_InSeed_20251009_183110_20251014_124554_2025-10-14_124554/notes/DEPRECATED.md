Old tails + duplicate signposts.
