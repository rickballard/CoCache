Clean one‑pager; credible copy; crisp SVG.
