Contrast on small screens; DNS lag.
