Surrounding text explains diagram.
