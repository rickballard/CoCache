## Decision Record

**Intent type:**  
**Lifecycle state:**  
**Congruence (before → after):**  
**Lens deltas (KPI/Reliability/Cost/Access/Sustainability):**  
**Evidence level (E0–E4):**  
**PE:**  
**DR (semantic/contract):**  
**Trust-radius Δ:**  
**Contracts impacted:**  
**Kill criteria & rollback ID:**  

> Why/Why not (auto): Top 3 contributors to PE; Top 3 risks.
