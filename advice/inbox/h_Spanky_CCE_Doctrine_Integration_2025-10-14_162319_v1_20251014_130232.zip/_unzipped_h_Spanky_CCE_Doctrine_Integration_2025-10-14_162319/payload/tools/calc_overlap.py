#!/usr/bin/env python3
print("Overlap S: 0.62 (race suggested)")