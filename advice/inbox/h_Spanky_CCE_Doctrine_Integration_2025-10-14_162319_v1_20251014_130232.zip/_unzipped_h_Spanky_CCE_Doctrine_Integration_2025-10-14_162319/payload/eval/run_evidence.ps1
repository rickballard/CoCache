Write-Host "Running offline evals (placeholder)"; Exit 0
