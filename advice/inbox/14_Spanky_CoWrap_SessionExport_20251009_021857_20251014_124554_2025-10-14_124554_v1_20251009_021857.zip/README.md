Title: 14_Spanky_CoWrap_SessionExport_20251009_021857_20251014_124554_2025-10-14_124554
Intent: Backfilled legacy advice
Owner: Backfill
Version: 2025-10-09T02-18-57
Status: settled
Guardrails:
  MaxSizeKB: 256
  MaxCadenceMins: 30
  MaxChangePct: 20
Change-Notes:
  - Backfilled from legacy content; preserved original timestamp

## Source Files
- docs\advice_bombs\batch_20251014_124554\14_Spanky_CoWrap_SessionExport_20251009_021857_20251014_124554_2025-10-14_124554.zip)
