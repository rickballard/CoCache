Title: 2025-10-25T13-57-19_Deliverable_Manifest
Intent: Backfilled legacy advice
Owner: Backfill
Version: 2025-10-25T13-57-23
Status: settled
Guardrails:
  MaxSizeKB: 256
  MaxCadenceMins: 30
  MaxChangePct: 20
Change-Notes:
  - Backfilled from legacy content; preserved original timestamp

## Source Files
- docs\intent\advice\processed\2025-10-25T13-57-19_Deliverable_Manifest.md)
