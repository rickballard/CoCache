# Steward Code (No Crowns)
- Steward is a high-utility IC with access, not authority.
- Public weekly commitments + public misses.
- Boundaries: no unilateral mission/brand changes; use governance PRs.
- Rotation-ready: handoff checklist in this folder.
