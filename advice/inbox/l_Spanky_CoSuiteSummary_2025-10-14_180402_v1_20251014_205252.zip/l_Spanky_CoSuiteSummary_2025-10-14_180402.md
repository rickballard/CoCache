# Package: l_Spanky_CoSuiteSummary_20251014_180402.zip

* SHA256: 9DFD2C67C8A5AA21CC2CBE20C0F5C0926293A82B9ADAE6B8A4E79FED8BDB93B5
* Size:   8261 bytes
* Contents: 21x(noext)
* Hints:  unsure

## Tree (top)
- notes\DEPENDENCIES.md
- notes\INTENTIONS.md
- notes\RISKS.md
- payload\Congruence.md
- payload\denominator_dictionary.csv
- payload\DO_Integrate_SessionPack.ps1
- payload\equity_breakouts.md
- payload\EXEMPLAR_TEMPLATE.md
- payload\HumanGate.md
- payload\integration_guide.md
- payload\kpi_catalog.csv
- payload\metrics_core.schema.json
- payload\normalization_rules.md
- payload\Review_Process.md
- payload\stability_detector.md
- payload\watcher_spec.md
- summaries\DIRECTIONS.md
- summaries\EXEC_SUMMARY.md
- summaries\NEXT_STEPS.md
- summaries\TLDR.md
- transcripts\session.md

