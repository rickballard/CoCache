# DEPENDENCIES
- Maintained CoCache ingest scripts and validators.
- CoRef for references; CoCore for standards; CoAgent for orchestration.
