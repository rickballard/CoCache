# RISKS
- Misalignment across sessions if prompts diverge.
- Safety flags if autonomy pilots lack preflight.
- Reputational risk if transparency is partial.
