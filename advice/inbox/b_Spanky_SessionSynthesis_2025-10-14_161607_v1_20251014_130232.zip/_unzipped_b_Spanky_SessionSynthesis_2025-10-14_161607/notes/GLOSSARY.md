# GLOSSARY (selected)
- **Advice Bomb** — a structured, zip‑ready package that other sessions can ingest.
- **Congruence** — alignment with non‑coercive, transparent, reversible governance.
- **Preflight** — a safety checklist run before any autonomy loop.
