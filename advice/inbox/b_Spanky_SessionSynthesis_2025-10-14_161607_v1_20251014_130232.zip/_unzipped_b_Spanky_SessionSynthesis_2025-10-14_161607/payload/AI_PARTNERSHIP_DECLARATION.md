# AI Partnership Declaration (Draft)

CoAgent collaborates with AI vendors and open‑source models as a **neutral orchestration layer**. We prioritize user sovereignty, auditability, and non‑coercive operation. Participation implies adherence to transparency, reversibility, and shared safety preflight standards.
