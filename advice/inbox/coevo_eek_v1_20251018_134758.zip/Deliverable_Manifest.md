filename: coevo_eek_v1_20251018_134758.zip
version: v1
timestamp: 20251018_134758
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
