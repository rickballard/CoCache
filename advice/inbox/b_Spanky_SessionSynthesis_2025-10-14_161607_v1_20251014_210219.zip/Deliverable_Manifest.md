filename: b_Spanky_SessionSynthesis_2025-10-14_161607_v1_20251014_210219.zip
version: v1
timestamp: 20251014_210219
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
