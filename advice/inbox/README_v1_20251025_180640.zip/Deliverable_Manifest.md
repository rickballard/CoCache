filename: README_v1_20251025_180640.zip
version: v1
timestamp: 20251025_180640
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
