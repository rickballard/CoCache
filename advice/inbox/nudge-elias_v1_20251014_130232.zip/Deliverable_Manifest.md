filename: nudge-elias_v1_20251014_130232.zip
version: v1
timestamp: 20251014_130232
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
