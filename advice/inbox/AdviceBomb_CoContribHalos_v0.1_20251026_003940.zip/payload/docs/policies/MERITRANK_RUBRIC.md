# MeritRank Rubric (v0.1)
Weights (range):
- evidence_strength: 0..5
- relevance: 0..5
- independence: -3..+2
- civic_impact: 0..3
- endorsements_quality: 0..3
- recency: -2..+2

Compute: sum → normalize to 0..10. Always store full breakdown next to total.
