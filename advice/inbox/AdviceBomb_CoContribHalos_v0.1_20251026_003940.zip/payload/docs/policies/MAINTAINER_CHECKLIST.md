## Maintainer Checklist (v0.1)
[ ] Two independent reviewers recorded (IDs + notes)
[ ] Sources linked for each claim
[ ] Consent recorded for halo publication (if any)
[ ] COIs disclosed and scored
[ ] MeritRank computed with breakdown
[ ] Next review date set
