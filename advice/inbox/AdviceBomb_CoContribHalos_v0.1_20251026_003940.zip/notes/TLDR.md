# TLDR
Stand up a small, high-integrity directory of proposed contributors (10–20 to start) with an opt-in **Digital Halo** (claims/attestations/proofs). Keep facts verifiable, publish the rubric, require two reviewers, and set annual re-reviews. Off-chain now; optional periodic on-chain anchoring later.
