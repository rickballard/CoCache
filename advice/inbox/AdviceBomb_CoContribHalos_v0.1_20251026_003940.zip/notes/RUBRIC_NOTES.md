# Rubric Notes
Show per-dimension scores; never present a single number without breakdown. Penalize undeclared conflicts. Reward independence and recent, verifiable work.
