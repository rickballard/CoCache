# SOURCES

- This session’s PS7 logs and commands (user-supplied).
- Local repos: HH (Godspawn), CoAgent (paths assumed as noted).
- Mermaid documentation (rendered via CDN at runtime in viewer).