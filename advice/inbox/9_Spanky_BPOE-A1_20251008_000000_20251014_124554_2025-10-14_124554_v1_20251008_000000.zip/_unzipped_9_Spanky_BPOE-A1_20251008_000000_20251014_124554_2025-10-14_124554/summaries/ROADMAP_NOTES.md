# ROADMAP_NOTES

1) Orchestrator for bulk DO execution with failure fences and resumability.
2) Diagram schema growth: swimlanes, ports, side-anchored arrows, grouping.
3) Optional offline Mermaid bundling (no CDN).
4) Automated harvesters for CoWraps/Advicebombs (user-pointed paths).