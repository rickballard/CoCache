# Draft VIOLET Receipt

