filename: Spanky_Request_Pack_v2_2_2025-10-08_2025-10-14_124554_v2_20251014_130232.zip
version: v2
timestamp: 20251014_130232
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
