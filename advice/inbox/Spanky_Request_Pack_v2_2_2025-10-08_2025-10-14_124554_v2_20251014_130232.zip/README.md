Title: Spanky_Request_Pack_v2_2_2025-10-08_2025-10-14_124554
Intent: Backfilled legacy advice
Owner: Backfill
Version: 2025-10-14T13-02-32
Status: settled
Guardrails:
  MaxSizeKB: 256
  MaxCadenceMins: 30
  MaxChangePct: 20
Change-Notes:
  - Backfilled from legacy content; preserved original timestamp

## Source Files
- docs\advice_bombs\batch_20251014_124554\.19_Spanky_CPDA-CADI_20251008_225001\payload\attachments\session-uploads\Spanky_Request_Pack_v2_2_2025-10-08_2025-10-14_124554.zip
- docs\advice_bombs\batch_20251014_124554\.23_Spanky_CoAgent_20251008_225757\Spanky_CoAgent_20251008_225757\payload\attachments\Spanky_Request_Pack_v2_2_2025-10-08_2025-10-14_124554.zip
- docs\advice_bombs\batch_20251014_124554\.24_Spanky_CADE-Defense_20251009_030727\payload\attachments\session-uploads\Spanky_Request_Pack_v2_2_2025-10-08_2025-10-14_124554.zip
- docs\advice_bombs\batch_20251014_124554\.33_Spanky_MeritRank_20251009_184459\payload\Spanky_Request_Pack_v2_2_2025-10-08_2025-10-14_124554.zip
- docs\advice_bombs\batch_20251014_124554\.38_Spanky_CoAgentMVP3_20251009_191118\payload\Spanky_Request_Pack_v2_2_2025-10-08_2025-10-14_124554.zip
- docs\advice_bombs\batch_20251014_124554\.39_Spanky_GVB_20251009_192232\notes\Spanky_Request_Pack_v2_2_2025-10-08_2025-10-14_124554.zip
- docs\advice_bombs\batch_20251014_124554\.46_Spanky_CoCivium_20251009_161652\Spanky_Build\payload\source\Spanky_Request_Pack_v2_2_2025-10-08_2025-10-14_124554.zip
- docs\advice_bombs\batch_20251014_124554\.47_Spanky_RickPublicBridge_20251009_162406\payload\Spanky_Request_Pack_v2_2_2025-10-08_2025-10-14_124554.zip
- docs\advice_bombs\batch_20251014_124554\.9_Spanky_BPOE-A1_20251008_000000\payload\attachments\session-uploads\Spanky_Request_Pack_v2_2_2025-10-08_2025-10-14_124554.zip)
