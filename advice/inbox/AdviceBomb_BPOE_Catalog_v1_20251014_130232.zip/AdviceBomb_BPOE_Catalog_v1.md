# BPOE Catalog v1 (AdviceBomb)
- Bucketed ~100-item catalog with visibility flags (Public/Caution/Secret/R&D).
- Includes opt-in depersonalized uploads, CoSession/CoWrap/CoCache, friendly panel names.
