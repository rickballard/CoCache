Title: manifest
Intent: Backfilled legacy advice
Owner: Backfill
Version: 2025-10-17T20-25-06
Status: settled
Guardrails:
  MaxSizeKB: 256
  MaxCadenceMins: 30
  MaxChangePct: 20
Change-Notes:
  - Backfilled from legacy content; preserved original timestamp

## Source Files
- docs\intent\manifest.json)
