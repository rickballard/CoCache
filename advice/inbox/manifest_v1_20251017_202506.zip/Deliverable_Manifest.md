filename: manifest_v1_20251017_202506.zip
version: v1
timestamp: 20251017_202506
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
