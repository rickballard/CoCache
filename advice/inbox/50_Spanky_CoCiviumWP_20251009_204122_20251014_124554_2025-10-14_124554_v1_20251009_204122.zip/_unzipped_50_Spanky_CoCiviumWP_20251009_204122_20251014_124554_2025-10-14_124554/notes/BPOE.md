# BPOE Notes (Wikipedia Drafting)
- Keep editing in userspace until independent, in-depth sources exist.
- Maintain COI disclosure on user page.
- Minimal External links: official site (+ repo if canonical).