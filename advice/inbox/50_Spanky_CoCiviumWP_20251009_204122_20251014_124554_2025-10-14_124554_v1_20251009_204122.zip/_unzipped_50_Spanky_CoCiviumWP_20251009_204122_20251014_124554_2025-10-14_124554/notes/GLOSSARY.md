# Glossary
- **AfC**: Articles for Creation review queue.
- **COI**: Conflict of Interest; disclose on user page and avoid direct mainspace edits.
- **Userspace**: Pages under `User:NAME/...` not part of the encyclopedia proper.
