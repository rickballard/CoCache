# Risks
- Early AfC submission triggers decline and creates a negative review trail.
- Overuse of primary/self sources leads to speedy deletion/decline.
- Concept-term pages without sources risk deletion as neologisms/dictionary entries.
