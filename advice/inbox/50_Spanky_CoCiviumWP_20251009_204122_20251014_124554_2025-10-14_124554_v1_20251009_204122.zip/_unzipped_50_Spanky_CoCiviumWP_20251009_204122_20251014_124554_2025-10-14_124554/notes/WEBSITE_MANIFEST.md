# Website Manifest (External links policy)
- External links to include (when article exists):
  - Official website (one link).
  - Optional: canonical GitHub repository.
- Exclude: personal blogs, Substack, social media (except as official link if absolutely necessary).