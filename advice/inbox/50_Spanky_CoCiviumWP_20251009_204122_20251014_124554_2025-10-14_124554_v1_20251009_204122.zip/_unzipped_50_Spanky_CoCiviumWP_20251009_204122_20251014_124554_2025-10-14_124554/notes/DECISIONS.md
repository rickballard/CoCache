# Decisions
- Do **not** submit to AfC until sourcing threshold is met.
- Do **not** use self-published materials as references (Substack/site/GitHub).
