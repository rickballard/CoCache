# Roadmap Notes
1) Create Wikidata item.
2) Secure independent pilot/evaluation; target publish on partner channels.
3) Brief reputable journalists/researchers; seek in-depth coverage.
4) Once 3–6 solid sources exist, finalize draft and submit AfC.