**CoAgent** is the neutral, open-core workspace where humans and multiple AIs collaborate safely.  
Free forever for individual CoCivites; enterprises pay for governance/operations.  
We introduce RBAC successors (CTC/DAC) and congruence scoring, plus zero-footprint wisdom donation.
