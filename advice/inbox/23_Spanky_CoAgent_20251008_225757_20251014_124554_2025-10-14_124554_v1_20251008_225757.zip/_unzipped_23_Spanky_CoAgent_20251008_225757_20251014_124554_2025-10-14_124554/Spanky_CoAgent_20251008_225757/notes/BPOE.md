# BPOE Notes
- Zero-footprint exit and depersonalized wisdom donation.
- Evidence-rich outputs: plan, diffs, tests, congruence score.
- Sidecar-friendly logs, reproducibility, and session stitching.
