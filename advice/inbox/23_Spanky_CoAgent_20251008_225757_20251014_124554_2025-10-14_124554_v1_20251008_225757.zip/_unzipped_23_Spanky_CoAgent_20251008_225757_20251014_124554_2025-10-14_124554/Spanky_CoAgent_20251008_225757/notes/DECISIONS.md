# Decisions
- Neutral-ground product framing.
- Free forever for individual CoCivites (open-core).
- Enterprise monetization only in governance/ops, never core capability lock-in.
- Adopt CTC/DAC as RBAC successors.
