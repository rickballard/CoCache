# Risks
- GitHub Copilot Agent gravity may reduce appetite for third-party runtimes.
- Protocol churn (MCP versions) may demand adapter maintenance.
- Under-investment in durability/observability could stall adoption.
- Mis-positioning could confuse OSS community if enterprise line blurs.
