# Intentions (marking unfinished with '(Unfinished)')
- Public competitor analysis with praise and best-use guidance — **Done**.
- Strategy paper with public+internal split — **Done**.
- Long-range 10-year plan with indicative horizons — **Done**.
- Implement RBAC successor (CTC/DAC) in code — **(Unfinished)**.
- Congruence dashboard and scoring pipeline — **(Unfinished)**.
- Enterprise workspace (multi-tenant, secrets vault, compliance) — **(Unfinished)**.
- MCP-first tooling adapter library — **(Unfinished)**.
