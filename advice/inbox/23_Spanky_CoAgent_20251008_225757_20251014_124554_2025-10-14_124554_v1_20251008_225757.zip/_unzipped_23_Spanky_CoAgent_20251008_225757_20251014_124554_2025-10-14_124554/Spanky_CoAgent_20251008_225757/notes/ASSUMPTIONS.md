# Assumptions
- Market converges on supervised, tool-rich, protocolized agents.
- Enterprises prioritize observability/governance over 'raw model IQ'.
- MCP gains traction as the default connector protocol.
