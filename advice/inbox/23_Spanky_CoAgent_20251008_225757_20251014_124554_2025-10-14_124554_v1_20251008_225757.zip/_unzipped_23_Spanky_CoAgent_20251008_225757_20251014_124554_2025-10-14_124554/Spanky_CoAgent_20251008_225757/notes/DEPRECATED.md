# Deprecated / To Reconsider
- Static RBAC as primary model for future hybrid orgs.
- Zip-password based opsec for secrets (prefer private repos + signed commits).
