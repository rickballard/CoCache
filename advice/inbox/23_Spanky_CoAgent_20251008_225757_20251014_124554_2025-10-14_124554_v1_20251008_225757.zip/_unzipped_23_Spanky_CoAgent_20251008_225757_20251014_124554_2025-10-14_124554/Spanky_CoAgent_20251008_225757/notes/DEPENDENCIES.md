# Dependencies
- GitHub Enterprise API/Apps for private repo integration.
- MCP-compliant tool adapters for cross-ecosystem interoperability.
- Document DB or file-based durable store for run-state and memory.
- Signing infrastructure for agent commits.
