filename: 23_Spanky_CoAgent_20251008_225757_20251014_124554_2025-10-14_124554_v1_20251008_225757.zip
version: v1
timestamp: 20251008_225757
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
