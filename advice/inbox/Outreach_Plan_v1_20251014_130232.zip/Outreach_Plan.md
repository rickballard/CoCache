# Outreach Plan — Pybus Pattern (reusable)

**Ladder (4 weeks):**  
W0 Email (bounded ask) → W1 2‑pager + 90‑sec demo → W2 20‑min call (3 questions) → W3 offer student studio (micro‑grant, no strings).

**Abort conditions:** demo not sanitized, InSeed page 404, claims can’t be demonstrated in 48h, combative language present, no operator availability.

**Tracking:** keep a simple CSV CRM in repo; log send, reply, next action.
