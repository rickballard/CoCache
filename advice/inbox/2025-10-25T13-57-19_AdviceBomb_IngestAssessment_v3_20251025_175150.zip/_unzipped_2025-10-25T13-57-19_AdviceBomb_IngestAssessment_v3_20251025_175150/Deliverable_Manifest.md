filename: AdviceBomb_IngestAssessment_v3_20251025_175150.zip
version: v3
timestamp: 20251025_175150
source_session: IngestAssessment
target_session: CoPrime
status: ready-for-ingestion
