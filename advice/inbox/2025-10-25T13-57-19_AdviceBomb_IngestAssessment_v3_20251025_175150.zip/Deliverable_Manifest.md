filename: 2025-10-25T13-57-19_AdviceBomb_IngestAssessment_v3_20251025_175150.zip
version: v3
timestamp: 20251025_175150
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
