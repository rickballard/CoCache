---
name: Exemplar Intake
about: Propose a policy exemplar
title: "[EX]: <short title>"
labels: ["exemplar","triage"]
assignees: []
---
## Snapshot
## Lifecycle Status
## Evidence Grade (why)
## Risks & Mitigations
## Links & Provenance
## Minimal Pilot Design
