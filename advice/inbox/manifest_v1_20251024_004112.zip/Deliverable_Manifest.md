filename: manifest_v1_20251024_004112.zip
version: v1
timestamp: 20251024_004112
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
