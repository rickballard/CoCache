Title: manifest
Intent: Backfilled legacy advice
Owner: Backfill
Version: 2025-10-24T00-41-12
Status: settled
Guardrails:
  MaxSizeKB: 256
  MaxCadenceMins: 30
  MaxChangePct: 20
Change-Notes:
  - Backfilled from legacy content; preserved original timestamp

## Source Files
- docs\staging\CoTheorySeed_20251023\docs\intent\manifest.json)
