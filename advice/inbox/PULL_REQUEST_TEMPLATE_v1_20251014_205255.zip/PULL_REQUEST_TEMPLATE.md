## CoSteward Seed — Checklist
- [ ] Added `/CoSteward` folder with templates, scripts, workflows
- [ ] `streams.yml` capped to ≤4 human-focus streams
- [ ] `heartbeats/` present (seed file acceptable)
- [ ] Workflows: WIP cap + Heartbeat included
- [ ] `run.ps1` verified locally (non-destructive install)
- [ ] Links added to CoCache global index (follow-up PR ok)
