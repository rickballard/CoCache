filename: ChromeExtensions_2025-10-08_195356_v1_20251021_192159.zip
version: v1
timestamp: 20251021_192159
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
