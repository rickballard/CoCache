# Changelog

- Created Gate Letter v1.7.2 (story-forward, no em dashes, CoSym motif).
- Drafted OAPP v0.4 preview with metrics and controls.
- Added decision-stamp template and DO.ps1 dry-run script.
- Assembled receipts, risks, and decisions for ingest by CoSuite sessions.