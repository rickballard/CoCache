Title: index_manifest
Intent: Backfilled legacy advice
Owner: Backfill
Version: 2025-10-18T09-58-22
Status: settled
Guardrails:
  MaxSizeKB: 256
  MaxCadenceMins: 30
  MaxChangePct: 20
Change-Notes:
  - Backfilled from legacy content; preserved original timestamp

## Source Files
- docs\index_manifest.json)
