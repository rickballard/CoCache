# Threat Models (Seed)
- Sentry / Scout contexts
- Torino & Palermo mapping
- Blind-spot notes (sunward approaches)
