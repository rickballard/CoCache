# ✅ Checklist: Drop AdviceBombs

- [ ] Zip and timestamp each payload with CoTheoryAB_ prefix
- [ ] Include README, MANIFEST (optional), and _intent.json if needed
- [ ] Ensure DO Block has smoke-check and safety logic
- [ ] Deliver AdviceBomb via dialogue and confirm deployment with ✅
