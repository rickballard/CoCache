# METRICS (Falsifiable targets)

- Auditability coverage ≥ 95% (CoAgent logs).
- Median time‑to‑trace ≤ 90s (task-based test).
- SDK endpoint detection ≥ 80% on test list; label precision ≥ 0.90.
- Evidence shelf ready before first email (binary).
