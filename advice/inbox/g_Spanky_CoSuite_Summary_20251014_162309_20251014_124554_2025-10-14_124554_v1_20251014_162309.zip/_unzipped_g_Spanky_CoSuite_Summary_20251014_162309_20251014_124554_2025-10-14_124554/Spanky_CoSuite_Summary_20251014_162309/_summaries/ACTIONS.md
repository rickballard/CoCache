# ACTIONS (Next 14 days)

- Choose lead artifact (SDK visibility vs Guardrails). Owner: Rick. Due: +1d.
- Fill 2‑pager and storyboard; record 90‑sec demo. Owner: Rick. Due: +3d.
- Publish InSeed Capstone v0.5 + pledge (if mentioned). Owner: InSeed web. Due: +5d.
- Prepare Evidence shelf (2‑pager, demo, metrics). Owner: Rick. Due: +5d.
- Send outreach email; log CRM; schedule follow‑ups. Owner: Rick. Due: +6d.
