# Risks & Mitigations
- Credibility risk → publish minimal InSeed page + evidence shelf.
- Over‑claiming → falsifiable metrics only; 48h demonstrability rule.
- Vendor flame‑wars → market‑structure framing only.
