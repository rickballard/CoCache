# Decisions
- Lead with SDK visibility unless guardrails demo is stronger.
- InSeed appears late; only when web copy is live.
