filename: GrandResetManifest_v1_20251005_192850.zip
version: v1
timestamp: 20251005_192850
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
