Title: AdviceBomb_CoAgent_Outreach_CLRIM_20251024_124930
Intent: Backfilled legacy advice
Owner: Backfill
Version: 2025-10-24T12-49-30
Status: settled
Guardrails:
  MaxSizeKB: 256
  MaxCadenceMins: 30
  MaxChangePct: 20
Change-Notes:
  - Backfilled from legacy content; preserved original timestamp

## Source Files
- advice\incoming\AdviceBomb_CoAgent_Outreach_CLRIM_20251024_124930.zip)
