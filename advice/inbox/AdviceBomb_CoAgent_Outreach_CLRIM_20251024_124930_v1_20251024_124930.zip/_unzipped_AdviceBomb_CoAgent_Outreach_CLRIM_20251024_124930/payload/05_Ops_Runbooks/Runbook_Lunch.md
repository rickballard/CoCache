Confirm date/headcount; print one‑pagers; capture 3 initiatives with owners; send 24h summary.
