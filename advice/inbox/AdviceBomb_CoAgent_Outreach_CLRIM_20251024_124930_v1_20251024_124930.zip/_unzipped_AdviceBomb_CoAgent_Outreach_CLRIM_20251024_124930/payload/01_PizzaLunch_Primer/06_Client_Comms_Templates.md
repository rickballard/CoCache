Market note; client email; IPS blurb (generic, not advice).
