AI Owner; Assisted‑adviser; Tax‑loss helper; Scenarios; Comms; Mini‑corpus; Liquidity drills; Pricing menu.
