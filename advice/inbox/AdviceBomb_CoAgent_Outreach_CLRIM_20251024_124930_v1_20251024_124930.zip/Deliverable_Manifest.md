filename: AdviceBomb_CoAgent_Outreach_CLRIM_20251024_124930_v1_20251024_124930.zip
version: v1
timestamp: 20251024_124930
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
