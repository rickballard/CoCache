Title: _wrap.manifest
Intent: Backfilled legacy advice
Owner: Backfill
Version: 2025-10-14T20-52-55
Status: settled
Guardrails:
  MaxSizeKB: 256
  MaxCadenceMins: 30
  MaxChangePct: 20
Change-Notes:
  - Backfilled from legacy content; preserved original timestamp

## Source Files
- docs\advice_bombs\batch_20251014_124554\n_AB_CoSteward_Spine_UPG_20251014_224344\AB_CoSteward_Spine_UPG_20251014_224344\_wrap.manifest.json)
