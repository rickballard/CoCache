# MISSING_TLDR.md

This required file was not found in the original ZIP.