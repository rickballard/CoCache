filename: 8_Spanky_CCSeedWrap_20251008_020133_20251014_124554_2025-10-14_124554_v1_20251008_020133.zip
version: v1
timestamp: 20251008_020133
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
