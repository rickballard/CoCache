# Glossary
- **Canon**: immutable documents, superseded by versioned successors.
- **CC (Cognocarta Consenti)**: assembled doctrine/consent corpus; megascroll aggregates components.
- **BPOE**: operational wisdom and constraints emphasizing human limits.
- **DO block**: packaged, deterministic action sequence runnable from Downloads.
- **CoWrap**: end-of-session wrap that moves artifacts into repo.
