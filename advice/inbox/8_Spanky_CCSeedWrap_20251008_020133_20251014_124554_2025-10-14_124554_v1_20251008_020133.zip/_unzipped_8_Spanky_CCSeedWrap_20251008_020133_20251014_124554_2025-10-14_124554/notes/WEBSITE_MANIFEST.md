# Website Manifest (current)
- Source: `gh-pages` branch, path `/`
- CNAME: `cocivium.org`
- HTTPS: pending cert; enforcement attempted but blocked until cert exists.
- Probe (earlier): `https://cocivium.org` → 404 (site not found) during propagation; `https://rickballard.github.io/CoCivium/` OK.
