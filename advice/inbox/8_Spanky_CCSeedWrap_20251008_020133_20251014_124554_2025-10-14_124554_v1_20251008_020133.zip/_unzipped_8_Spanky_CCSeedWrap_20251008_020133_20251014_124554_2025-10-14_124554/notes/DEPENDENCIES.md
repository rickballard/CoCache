# Dependencies
- PowerShell 7.x, git, GitHub CLI (`gh`) authenticated.
- Repo path assumption: `~/Documents/GitHub/CoCivium`.
- GitHub Pages configuration access (repo admin) for CNAME and source.
- DNS control for `cocivium.org` (A/AAAA records for apex, CNAME for `www`).
