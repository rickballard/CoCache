# Sources (in-session)
- Repo: rickballard/CoCivium (branches: main, gh-pages, docs/cc-seed).
- PR: #417 — CC seed docs.
- Commands and logs from PowerShell transcript supplied in-session.
