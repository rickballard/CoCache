# AI Owner Charter
- Maintain inventory, enforce policy, approve use cases/corpus, chair review, ensure audit trails.
