# AI Policy Template (1 page)
- Owner, scope, human-in-the-loop, approved corpus, logging, validation, vendors, incidents.
