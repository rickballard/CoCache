# Trigger Checklist
- Define triggers; map to tilts; confirm IPS guardrails; pre-approve compliance language.
