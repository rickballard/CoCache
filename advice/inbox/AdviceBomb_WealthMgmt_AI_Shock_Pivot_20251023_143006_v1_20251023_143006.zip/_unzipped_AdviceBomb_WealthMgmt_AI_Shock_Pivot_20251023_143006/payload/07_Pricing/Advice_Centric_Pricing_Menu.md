# Advice-Centric Pricing Menu
Tier 1/2/3 retainer framing; adjust per compliance.
