# SOURCES
Synthesized CoCivium guidance and general best practices. Use live regulatory/macro sources for decisions.
