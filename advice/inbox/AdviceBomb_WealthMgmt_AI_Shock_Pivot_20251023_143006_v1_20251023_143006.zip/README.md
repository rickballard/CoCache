Title: AdviceBomb_WealthMgmt_AI_Shock_Pivot_20251023_143006
Intent: Backfilled legacy advice
Owner: Backfill
Version: 2025-10-23T14-30-06
Status: settled
Guardrails:
  MaxSizeKB: 256
  MaxCadenceMins: 30
  MaxChangePct: 20
Change-Notes:
  - Backfilled from legacy content; preserved original timestamp

## Source Files
- advice\incoming\AdviceBomb_WealthMgmt_AI_Shock_Pivot_20251023_143006.zip)
