filename: AdviceBomb_WealthMgmt_AI_Shock_Pivot_20251023_143006_v1_20251023_143006.zip
version: v1
timestamp: 20251023_143006
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
