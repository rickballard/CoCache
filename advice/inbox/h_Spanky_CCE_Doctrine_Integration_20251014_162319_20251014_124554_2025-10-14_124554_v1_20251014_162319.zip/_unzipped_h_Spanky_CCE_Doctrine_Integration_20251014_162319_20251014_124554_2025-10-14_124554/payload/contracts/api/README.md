# API contract example (placeholder)
