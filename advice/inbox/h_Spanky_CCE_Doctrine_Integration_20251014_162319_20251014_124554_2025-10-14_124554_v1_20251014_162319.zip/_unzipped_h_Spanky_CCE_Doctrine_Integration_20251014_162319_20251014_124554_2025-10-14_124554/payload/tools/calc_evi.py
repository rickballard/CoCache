#!/usr/bin/env python3
print("EVI: 0.04 < Cost_of_Dual_Path — merge recommended")