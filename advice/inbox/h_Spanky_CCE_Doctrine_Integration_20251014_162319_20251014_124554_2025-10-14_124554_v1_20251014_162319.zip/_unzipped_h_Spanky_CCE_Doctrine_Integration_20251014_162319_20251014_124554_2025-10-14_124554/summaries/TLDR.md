# TL;DR
- One scorer/governor governs human nudges and cron jobs.
- Congruence + PE + DR gate changes; Evidence Levels make it non-theatrical.
- MORP prevents option-killing; bandit allocates attention fairly.
- SDE lane can freeze and roll back instantly; tamper-evident logs.
- Meta‑CCE self‑tunes within bounds via shadow trials.
