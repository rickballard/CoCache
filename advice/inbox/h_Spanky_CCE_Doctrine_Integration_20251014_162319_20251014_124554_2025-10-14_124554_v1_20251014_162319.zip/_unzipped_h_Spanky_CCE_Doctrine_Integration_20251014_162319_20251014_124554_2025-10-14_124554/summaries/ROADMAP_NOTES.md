# Roadmap Notes (Week 1 Cutover)
1) Land configs & workflows in CoCache.
2) Enable stoplight in Yellow mode.
3) Wire contract tests for one API and one prompt chain.
4) Turn on nightly overlap + Race/Merge suggestions.
5) Run an SDE tabletop; freeze/unfreeze drill.
6) Start Meta‑CCE in shadow (20–25%).