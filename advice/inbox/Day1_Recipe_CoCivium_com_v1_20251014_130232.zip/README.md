Title: Day1_Recipe_CoCivium_com
Intent: Backfilled legacy advice
Owner: Backfill
Version: 2025-10-14T13-02-32
Status: settled
Guardrails:
  MaxSizeKB: 256
  MaxCadenceMins: 30
  MaxChangePct: 20
Change-Notes:
  - Backfilled from legacy content; preserved original timestamp

## Source Files
- docs\advice_bombs\batch_20251014_124554\.26_Spanky_CoCivium-Strategy_20251009_031142\payload\Day1_Recipe_CoCivium_com.md)
