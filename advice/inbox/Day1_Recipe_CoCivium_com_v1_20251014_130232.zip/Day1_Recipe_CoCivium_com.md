# Day‑1 Recipe — CoCivium™.com Bring‑Up

**Prereqs:** Clean GIBindex terms; CoCore rules; CoCache provenance; repo archetypes; PR/Issue templates.  
**Build:** Extract → Transform (org/com) → Validate (strict on .com) → Preview → Steward+ChatGPT approve → Deploy (mirrored).  
**Separation:** .com writes are proposals only; never direct to source repos.
