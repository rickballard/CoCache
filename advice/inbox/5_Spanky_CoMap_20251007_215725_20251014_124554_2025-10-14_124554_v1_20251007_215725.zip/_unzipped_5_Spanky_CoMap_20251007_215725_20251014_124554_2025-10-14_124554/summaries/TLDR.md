# TL;DR

We defined **CoMap**: a viral, shareable governance spider-diagram tool with fixed metrics and adjustable scores. 
Payload contains metrics schema, methodology, repo skeleton, UX flow, and starter templates. 
Ready to stage as a **CoModule** and iterate to a standalone repo.
