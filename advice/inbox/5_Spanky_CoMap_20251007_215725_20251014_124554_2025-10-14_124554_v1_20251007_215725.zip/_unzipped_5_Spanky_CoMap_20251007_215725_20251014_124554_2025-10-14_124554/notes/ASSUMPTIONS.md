# Assumptions

- Users prefer **ease-of-use** over methodological depth initially.
- Comparisons to fiction (Federation/Empire) increase **shareability**.
- Watermarking and embeddable widgets will **drive traffic** back to CoCivium.
