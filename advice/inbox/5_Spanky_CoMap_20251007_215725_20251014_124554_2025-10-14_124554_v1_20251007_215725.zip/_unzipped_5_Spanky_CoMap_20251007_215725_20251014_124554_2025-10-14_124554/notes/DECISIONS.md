# Decisions

- Name selected: **CoMap**.
- Immutable vertex set per schema version; user-adjustable **scores/weights** only.
- Include fictional and real-world templates to seed engagement.
- Start as **CoModule** under CoCivium; plan for **own repo** when ready.
