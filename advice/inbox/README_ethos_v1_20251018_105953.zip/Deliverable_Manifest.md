filename: README_ethos_v1_20251018_105953.zip
version: v1
timestamp: 20251018_105953
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
