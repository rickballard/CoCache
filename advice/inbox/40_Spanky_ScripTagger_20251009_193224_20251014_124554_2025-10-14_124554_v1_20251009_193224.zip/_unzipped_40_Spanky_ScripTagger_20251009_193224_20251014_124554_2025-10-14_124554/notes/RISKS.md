# Risks
- **Bias perception**: address via transparent methodology, diverse seed set, and audits.
- **Privacy**: unintentional capture of bystanders or minors; enforce redaction and local-first defaults.
- **Store compliance**: microphone/background behavior, overlay/foreground requirements.
- **Misidentification**: cautious confidence scores; do not publish until independently supported.
- **Abuse/brigading**: rate limits, independence checks, and weight caps per identity.
