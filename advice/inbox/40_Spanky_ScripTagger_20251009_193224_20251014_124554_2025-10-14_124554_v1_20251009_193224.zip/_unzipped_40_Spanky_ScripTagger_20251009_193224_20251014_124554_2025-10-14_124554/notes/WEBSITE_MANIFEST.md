# Website Manifest (added/changed)
- `/docs/scripttagger/index.html` — overview
- `/docs/scripttagger/design.html` — design notes
- `/docs/scripttagger/methodology.html` — methodology & disclaimers
- `/docs/scripttagger/demo.html` — interactive demo
- `/sw.js` — PWA service worker
- `/downloads/scripttagger.html` — apology/early-access + now download buttons
