# Dependencies
- GitHub Pages for hosting; repos: rickballard/Opename, rickballard/MeritRank.
- Browser APIs: Web Share, Clipboard; PWA Service Worker for caching.
- Optional: GH CLI (`gh`) for releases; PS7 on Windows for bootstrap scripts.
- Future: Mobile OS permissions (microphone, background audio), app store policies.
