# Deprecated / Replaced
- Text-only nav brand → replaced with logo+text brand link.
- Transcript-first default → replaced by summary-first default.
