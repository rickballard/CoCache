# Decisions
- Summary-first default; transcript optional/off by default.
- Positive-only publication to RepTag; negatives assist internal separation.
- Vendor-neutral “Ask my AI” handoff; private AI chats not collected.
- “Capture. Tag. Think.” is the tagline.
- Start database with non-controversial seed set + strong tombstone/redaction process.
