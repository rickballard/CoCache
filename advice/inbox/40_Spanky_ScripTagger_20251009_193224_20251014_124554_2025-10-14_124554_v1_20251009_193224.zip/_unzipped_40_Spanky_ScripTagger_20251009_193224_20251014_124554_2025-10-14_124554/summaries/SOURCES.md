# Sources / Touchpoints
- Repos: `rickballard/MeritRank`, `rickballard/Opename`
- Live pages (indicative): `/docs/scripttagger/`, `/docs/scripttagger/design.html`, `/docs/scripttagger/methodology.html`, `/docs/scripttagger/demo.html`, `/downloads/scripttagger.html`
- GitHub Release: `scripttagger-demo-windows-x64.zip` + `checksums.txt`
