# Deprecated / To watch

- Any archived repos should be excluded from bulk flips.
- Track repos that become site-driven and switch visibility/protections accordingly.
