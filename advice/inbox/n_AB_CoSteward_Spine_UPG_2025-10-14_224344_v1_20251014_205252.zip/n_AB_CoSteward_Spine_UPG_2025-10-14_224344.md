# Package: n_AB_CoSteward_Spine_UPG_20251014_224344.zip

* SHA256: 305B7317AACDECCDA6A66095FA24184440B1AB0F7DDB868766575BAA90166CF7
* Size:   11228 bytes
* Contents: 17x(noext)
* Hints:  unsure

## Tree (top)
- AB_CoSteward_Spine_UPG_20251014_224344\_wrap.manifest.json
- AB_CoSteward_Spine_UPG_20251014_224344\DO_InstallTo_CoCache_and_PR.ps1
- AB_CoSteward_Spine_UPG_20251014_224344\README.md
- AB_CoSteward_Spine_UPG_20251014_224344\run.ps1
- AB_CoSteward_Spine_UPG_20251014_224344\streams.yml
- AB_CoSteward_Spine_UPG_20251014_224344\.github\pull_request_template.md
- AB_CoSteward_Spine_UPG_20251014_224344\.github\workflows\heartbeat.yml
- AB_CoSteward_Spine_UPG_20251014_224344\.github\workflows\wip-cap.yml
- AB_CoSteward_Spine_UPG_20251014_224344\governance\Steward-Code.md
- AB_CoSteward_Spine_UPG_20251014_224344\sandbox\mined\ideas-hello.md
- AB_CoSteward_Spine_UPG_20251014_224344\scripts\check_wip.py
- AB_CoSteward_Spine_UPG_20251014_224344\scripts\new_heartbeat.ps1
- AB_CoSteward_Spine_UPG_20251014_224344\scripts\render_ideacards.ps1
- AB_CoSteward_Spine_UPG_20251014_224344\templates\DOR_DoD.md
- AB_CoSteward_Spine_UPG_20251014_224344\_handoff\PR_BODY.md
- AB_CoSteward_Spine_UPG_20251014_224344\_handoff\README_FOR_REORG_SESSION.md
- AB_CoSteward_Spine_UPG_20251014_224344\_spanky\INTENTIONS.md

