Title: RickPublic_AdviceBomb_import_REPORT
Intent: Backfilled legacy advice
Owner: Backfill
Version: 2025-10-23T12-57-56
Status: settled
Guardrails:
  MaxSizeKB: 256
  MaxCadenceMins: 30
  MaxChangePct: 20
Change-Notes:
  - Backfilled from legacy content; preserved original timestamp

## Source Files
- advice\incoming\RickPublic_AdviceBomb_import_REPORT.md)
