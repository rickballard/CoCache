# Dependencies
- Working demo slice; 2‑pager scaffold; evidence shelf link.
- Operator availability within 24h for follow‑through.
