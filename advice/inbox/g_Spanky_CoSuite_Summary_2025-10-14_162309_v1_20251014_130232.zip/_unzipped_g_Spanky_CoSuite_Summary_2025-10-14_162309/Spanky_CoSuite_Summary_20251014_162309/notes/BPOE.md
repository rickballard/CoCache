# BPOE Notes
- Standardize advice‑bomb structure; small, auditable artifacts; DO scripts.
- Evidence shelf required before outreach to avoid credibility bleed.
