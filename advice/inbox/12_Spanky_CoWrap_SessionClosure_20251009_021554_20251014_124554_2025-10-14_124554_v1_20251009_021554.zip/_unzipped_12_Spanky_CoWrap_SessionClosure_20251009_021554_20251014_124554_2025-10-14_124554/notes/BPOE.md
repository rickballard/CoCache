# BPOE

Log of session guardrails and enforcement.