# CoWrap Spec Closure Session

Finalizing session with BPOE-compliant Spanky package.