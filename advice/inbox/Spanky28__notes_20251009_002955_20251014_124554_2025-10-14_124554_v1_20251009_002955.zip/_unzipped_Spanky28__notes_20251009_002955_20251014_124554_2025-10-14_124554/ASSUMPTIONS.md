# Assumptions
- Continuation uses the new thread and re-patches orchestrator placeholders.
- You will combine these parts under `Downloads\Spanky28\`.
