# HumanGate
Triggers: dual-use, minors/sensitive data, rights_burden_index ≥70, due-process <60, weak inference + high stakes.
Outputs: mitigation checklist, redaction notes, consent/transparency plan. Panel can block merges.
