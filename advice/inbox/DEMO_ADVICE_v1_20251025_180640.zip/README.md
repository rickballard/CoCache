Title: DEMO_ADVICE
Intent: Smoke test
Owner: ManualTest
Version: 2025-10-25T18-06-40
Status: iterating
Guardrails:
  MaxSizeKB: 256
  MaxCadenceMins: 30
  MaxChangePct: 20
Change-Notes:
  - 

## Context (session-summarized)
<add concise context here>

## Value / Justifications
<bullet list of expected value and why this is useful>

