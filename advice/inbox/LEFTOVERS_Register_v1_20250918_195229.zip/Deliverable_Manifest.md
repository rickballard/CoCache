filename: LEFTOVERS_Register_v1_20250918_195229.zip
version: v1
timestamp: 20250918_195229
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
