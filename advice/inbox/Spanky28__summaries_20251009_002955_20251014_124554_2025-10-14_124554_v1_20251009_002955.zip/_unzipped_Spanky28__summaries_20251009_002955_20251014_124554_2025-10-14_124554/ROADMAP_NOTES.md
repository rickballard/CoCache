# Roadmap Notes
- Add CI: PR artifacts via `tools/zip-rebuild.ps1` with size gates.
- Add CI: release guard + SHA256 publish.
- Add adapter: schema validation + Evidence Ledger stubs + CoWrap auto-append.
- Enforce `.editorconfig` / `.gitattributes` (UTF-8, LF).
