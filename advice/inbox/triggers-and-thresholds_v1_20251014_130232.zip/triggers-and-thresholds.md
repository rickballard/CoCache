# Triggers & Thresholds (Seed)
- Impact probability thresholds by size class
- Lead-time gates for escalation steps
- Communication & UN/IGO notification templates (to define)
