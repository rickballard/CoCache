filename: j_Spanky_CoAgentRisk_20251014_162802_20251014_124554_2025-10-14_124554_v1_20251014_162802.zip
version: v1
timestamp: 20251014_162802
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
