# Idea Card — Dual‑Face Sites & AI Beacon
- Beaconing markers + short redirect URL
- CoCivium.org (human) vs CoCivium.com (AI)
- JSON‑LD, schema.org, civic datasets, open API
- Repo as source of truth; CI/CD sync; reversibility
- A/B toggles; gamified feedback; telemetry
