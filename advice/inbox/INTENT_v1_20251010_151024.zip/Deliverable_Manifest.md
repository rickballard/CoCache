filename: INTENT_v1_20251010_151024.zip
version: v1
timestamp: 20251010_151024
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
