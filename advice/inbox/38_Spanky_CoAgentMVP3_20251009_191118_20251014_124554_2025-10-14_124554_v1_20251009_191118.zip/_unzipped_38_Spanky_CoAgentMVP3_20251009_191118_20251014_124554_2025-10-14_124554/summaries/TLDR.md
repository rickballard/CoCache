**TL;DR** CoAgent MVP3 = ZIP+run.ps1 + CoPong. This pack includes runner, sample, health check.
