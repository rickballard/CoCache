# CoAgent Intro Handshake
Rick has CoAgent MVP3 running. Send a ZIP with root **run.ps1**.
For routing use **_copayload.meta.json** (`session_hint`, `reply_url`) or add `__FROM_<session>__` to the filename.
Keep payloads small + reversible. I'm still learning CoAgent; give clear steps & expected outputs.
Dropping the ZIP in Downloads triggers run + CoPong summary.
