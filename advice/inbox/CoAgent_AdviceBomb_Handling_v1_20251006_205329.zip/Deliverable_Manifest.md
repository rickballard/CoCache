filename: CoAgent_AdviceBomb_Handling_v1_20251006_205329.zip
version: v1
timestamp: 20251006_205329
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
