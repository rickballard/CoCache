# Idea Card — Automated RickPublic Article Suggestions
**Owner:** Rick Ballard

(If a newer Idea Card was produced in-session, prefer that copy.)
