filename: 6_Spanky_CoCiviumFaiths_20251008_015909_20251014_124554_2025-10-14_124554_v1_20251008_015909.zip
version: v1
timestamp: 20251008_015909
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
