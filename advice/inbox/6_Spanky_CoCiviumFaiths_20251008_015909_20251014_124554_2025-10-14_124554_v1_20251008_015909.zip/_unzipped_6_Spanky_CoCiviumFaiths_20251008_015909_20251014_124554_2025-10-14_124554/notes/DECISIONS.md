# DECISIONS

- Use **CoRef sidecars** for edit-stable anchors instead of inline markers.
- Keep local hooks **advisory**; let CI render assets.
- Adopt **two-stage** main landing: Audit → LandFromPlan.
- Treat hero art as **placeholder-first**; avoid blocking on asset pipeline.