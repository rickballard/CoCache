# ASSUMPTIONS

- Steward has push rights to main on seed repos.
- CI environment can render SVG → PNG or accept skipping when Inkscape absent.
- Public visibility is preferred over bundling large artifacts in Spanky pack.