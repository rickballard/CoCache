# INTENTIONS

- Seed **Faiths in Dialogue** and expand Christianity deep-dive. **(Done)**
- Add **crosswalk, cases, red team, policy patterns**, and manifest. **(Done)**
- Establish **Congruence Doctrine** index + CoRef generator. **(Done)**
- Create **CoRef** concept-first sidecar scaffolding and exemplar. **(Done)**
- Provide **hero graphic placeholder** and plan for symbol ring. **(Done; placeholder only)**
- Harden **CoRender**: CI fallback; non-blocking hooks. **(Done)**
- Deliver **Godspawn Part 3** advice pack. **(Done)**
- Ensure **land on main** or verified off-main neutrality via two-stage audit. **(Done)**
- Produce **CoWrap** session close. **(Done)**

## Unfinished
- Full hero graphic with 100+ faith symbols and distance logic. **(Unfinished)**
- Automated steward merge policy & periodic branch prune CI. **(Unfinished)**
- Payload-full Spanky variant with embedded repo copies. **(Unfinished)**