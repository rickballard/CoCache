# DEPRECATED

- Blocking pre-commit for graphics renders — replaced by CI.
- Inline indexing markers — replaced by CoRef sidecars.