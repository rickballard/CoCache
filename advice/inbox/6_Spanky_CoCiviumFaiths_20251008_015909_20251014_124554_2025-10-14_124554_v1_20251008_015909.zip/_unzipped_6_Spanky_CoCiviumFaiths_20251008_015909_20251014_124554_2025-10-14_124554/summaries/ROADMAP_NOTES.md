# ROADMAP NOTES

1. Implement steward merge policy + periodic prune CI.
2. Produce full hero art (100+ symbols; ring distance = alignment).
3. Extend CoRef to additional insights and novels; publish hover UI spec.