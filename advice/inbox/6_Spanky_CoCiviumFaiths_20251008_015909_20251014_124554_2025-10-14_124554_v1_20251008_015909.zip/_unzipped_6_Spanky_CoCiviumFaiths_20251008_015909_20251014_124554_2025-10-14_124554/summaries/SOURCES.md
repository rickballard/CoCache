# SOURCES

- Session logs and user-provided instructions. No external web citations used.
- Public GitHub repos for artifact locations (see payload index).