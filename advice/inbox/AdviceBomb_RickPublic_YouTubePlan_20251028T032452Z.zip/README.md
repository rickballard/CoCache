# AdviceBomb · RickPublic YouTube Plan (additive, no inbox)

**Purpose:** Hand this package to the **CoPrime** session to implement an additive YouTube/Docs scaffold in the **RickPublic** repo *without* disrupting existing Substack staging.  
**Do _not_ ingest here** — place this zip under **CoCache/advice/inbox/** per intake rules.

Intake spec: https://github.com/rickballard/CoCache/blob/main/advice/inbox/README.md

## Summary
- Keep Substack staging exactly as-is (`/candidates`, `/sotw`, `/templates`).
- Add YouTube scaffolding (`/media/youtube/…`, templates, issue form).
- Add living docs: roadmap + strategy under `docs/intent/`.
- Optional light Docs front-door pages (`docs/index.md`, `docs/youtube/index.md`, `docs/substack/index.md`) — **only if** CoPrime chooses to publish Pages.
- Leave breadcrumbs: CoSync note after merge.

## Contents
- `rickpublic/docs/intent/rickpublic-youtube-roadmap.md` — live checkbox plan.
- `rickpublic/docs/intent/rickpublic-youtube-strategy.md` — channel strategy (format/voice/metrics/growth).
- `.github/ISSUE_TEMPLATE/youtube-episode.yml` — per-episode issue form.
- `templates/youtube/` — script + manifest templates.
- `CHANNEL_MANIFEST.json` + `BOILERPLATE.md` — cadence & rights boilerplate.
- `tools/New-YouTubeEpisode.ps1` + `tools/New-SubstackPost.ps1` — helpers.
- `INSTALL.ps1` — safe, additive installer (short branch → PR).

## Install (CoPrime)
1) Unzip this into a *temporary* folder.  
2) Run **`INSTALL.ps1`** and provide the path to the local **RickPublic** clone when prompted (or set `$RepoPath`).  
3) Review PR, squash-merge.  
4) Create a CoSync note on merge (script will stub one).

**Principles:** Repo = source of truth · Additive changes only · No AdviceBomb intake here.
