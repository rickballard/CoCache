param(
  [string]$RepoPath = "$HOME\Documents\GitHub\RickPublic"
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$env:GIT_TERMINAL_PROMPT='0'

if(-not (Test-Path $RepoPath)){ throw "Repo path not found: $RepoPath" }
if(-not (Test-Path (Join-Path $RepoPath ".git"))){ throw "Not a git repo: $RepoPath" }

function Note([string]$m){ "[{0:yyyy-MM-ddTHH:mm:ssZ}] {1}" -f (Get-Date).ToUniversalTime(), $m }

Set-Location $RepoPath
git switch main | Out-Null
git pull --ff-only | Out-Null
$branch = "feat/rickpublic-youtube-scaffold-{0}" -f (Get-Date -Format yyyyMMdd-HHmm)
git switch -c $branch | Out-Null
Note "On $branch"

# Copy additive files from the AdviceBomb
$src = Split-Path -Parent $MyInvocation.MyCommand.Path
$map = @(
  "rickpublic\docs\intent\rickpublic-youtube-roadmap.md","docs\intent\rickpublic-youtube-roadmap.md",
  "rickpublic\docs\intent\rickpublic-youtube-strategy.md","docs\intent\rickpublic-youtube-strategy.md",
  "rickpublic\.github\ISSUE_TEMPLATE\youtube-episode.yml",".github\ISSUE_TEMPLATE\youtube-episode.yml",
  "rickpublic\templates\youtube\script.md","templates\youtube\script.md",
  "rickpublic\templates\youtube\video.manifest.json","templates\youtube\video.manifest.json",
  "rickpublic\CHANNEL_MANIFEST.json","CHANNEL_MANIFEST.json",
  "rickpublic\BOILERPLATE.md","BOILERPLATE.md",
  "rickpublic\tools\New-YouTubeEpisode.ps1","tools\New-YouTubeEpisode.ps1",
  "rickpublic\tools\New-SubstackPost.ps1","tools\New-SubstackPost.ps1",
  "rickpublic\docs\index.md","docs\index.md",
  "rickpublic\docs\youtube\index.md","docs\youtube\index.md",
  "rickpublic\docs\substack\index.md","docs\substack\index.md"
) 

for($i=0;$i -lt $map.Count;$i+=2){
  $from = Join-Path $src $map[$i]
  $to   = Join-Path $RepoPath $map[$i+1]
  New-Item -ItemType Directory -Force -Path (Split-Path $to -Parent) | Out-Null
  Copy-Item -LiteralPath $from -Destination $to -Force
}

# Add CoSync breadcrumb
$noteDir = Join-Path $RepoPath ("docs\intent\advice\notes\{0}" -f (Get-Date -Format yyyyMMdd))
New-Item -ItemType Directory -Force -Path $noteDir | Out-Null
$utc = (Get-Date).ToUniversalTime().ToString("yyyyMMddTHHmmssZ")
@"
# CoSync: RickPublic YouTube roadmap + strategy installed
- Branch: $branch
- Created: $(Get-Date -Format o)
- Scope: additive; Substack staging unchanged; no AdviceBomb intake
- Next: open Episode issue for trailer; scaffold folder; publish first long + Shorts
"@ | Set-Content -Encoding UTF8 (Join-Path $noteDir "CoSync_$utc.md")

git add .
git commit -m "docs: YouTube roadmap + strategy; episode issue template; helpers (additive)"
try {
  git push -u origin $branch
  if (Get-Command gh -ErrorAction SilentlyContinue) {
    gh pr create --fill --title "Docs: YouTube roadmap & strategy + episode form" --body "Additive: keeps Substack staging as-is; no AdviceBomb intake; breadcrumbs added."
  } else {
    Note "gh CLI not found; open PR manually."
  }
} catch {
  Note "Push/PR step failed: $($_.Exception.Message)"
}
Note "Install complete."
