# Title:
## Hook (0:00–0:03)
## Stakes (0:03–0:12)
## Lens (CoTheory 2×2)
## Three takeaways
## One move
## CTA
