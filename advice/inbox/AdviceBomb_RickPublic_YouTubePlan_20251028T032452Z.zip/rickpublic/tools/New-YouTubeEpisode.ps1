param([string]$Slug = "trailer")
$root = (git rev-parse --show-toplevel)
$dir  = Join-Path $root ("media/youtube/E{0}_{1}" -f (Get-Date -Format yyyyMMdd), $Slug)
New-Item -ItemType Directory -Force -Path $dir | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $dir 'overlays') | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $dir 'sources') | Out-Null
Copy-Item "$root/templates/youtube/script.md" (Join-Path $dir 'script.md')
Copy-Item "$root/templates/youtube/video.manifest.json" (Join-Path $dir 'video.manifest.json')
Write-Host "Created $dir"
