param(
  [ValidateSet("insights","coevo")] [string]$Stream = "insights",
  [string]$Slug = "new-post"
)
$root = (git rev-parse --show-toplevel)
$path = Join-Path $root ("posts/{0}/{1}_{2}.md" -f $Stream,(Get-Date -Format yyyy-MM-dd),$Slug)
New-Item -ItemType Directory -Force -Path (Split-Path $path -Parent) | Out-Null
Set-Content -Encoding UTF8 -Path $path -Value @"
---
title: ""
slug: "$Slug"
summary: ""
tags: ["CoCivium","InSights"]
series: "InSights"
---
# Headline

(Body)
"@
Write-Host "Created $path"
