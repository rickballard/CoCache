# RickPublic
Weekly remixes, field notes, and essays from the CoCivium/CoSuite journey.

- Latest video → [/youtube](./youtube/)
- Newsletter → [/substack](./substack/)
