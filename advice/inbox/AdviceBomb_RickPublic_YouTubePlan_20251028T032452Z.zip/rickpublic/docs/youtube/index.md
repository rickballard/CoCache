**YouTube** — 3–5 min Remix & Repair + Field Notes. Start with the trailer; then latest playlist.
