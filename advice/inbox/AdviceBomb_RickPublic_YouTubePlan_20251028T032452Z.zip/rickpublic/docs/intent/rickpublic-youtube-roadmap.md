# RickPublic · YouTube Roadmap (living)

This file is the **source of truth** for the RickPublic channel rollout. Update checkboxes as you ship.

> Scope: *Additive only*. Substack staging remains in **/candidates** and **/sotw**. No AdviceBomb intake here (CoCache/CoPrime own that).

## Phase 0 — Baseline & guardrails
- [ ] Confirm: this repo **does not ingest** AdviceBombs (CoCache → CoPrime pipeline stays canonical).
- [ ] Keep Substack staging paths as-is (`/candidates`, `/sotw`, `/templates`).
- [ ] Add minimal YouTube scaffolding under `/media/youtube/` when first episode is started.

## Phase 1 — Strategy & scaffolds
- [ ] Land **strategy doc** at `docs/intent/rickpublic-youtube-strategy.md`.
- [ ] Land this **roadmap doc** (you are here).
- [ ] Add **issue template**: `.github/ISSUE_TEMPLATE/youtube-episode.yml`.
- [ ] Add **templates**: `templates/youtube/script.md`, `templates/youtube/video.manifest.json`.
- [ ] Add/merge **CHANNEL_MANIFEST.json** (cadence, pillars, CTA rotation).

## Phase 2 — Front door (docs/) [optional]
- [ ] `docs/index.md` highlights latest Substack + embeds latest video.
- [ ] `docs/youtube/index.md` with “Start here” trailer + playlist anchors.
- [ ] `docs/substack/index.md` best-of + subscribe link.
- [ ] GitHub Pages workflow present; enable Pages to serve `/docs` (no CNAME changes yet).

## Phase 3 — First drops
- [ ] Create Issue via **YouTube Episode** template: “Trailer — No Crowns.”
- [ ] Generate folder: `/media/youtube/EYYYYMMDD_trailer/` from templates.
- [ ] Record & edit trailer; attach thumb + description; publish; link in `docs/youtube/index.md`.
- [ ] Ship Week 1 “Remix & Repair” episode (3–5m); cut 2–3 Shorts.

## Phase 4 — Growth loops & iteration
- [ ] Title/thumbnail A/B on the first 4 videos; target **CTR ≥ 6–8%**.
- [ ] Hook retention ≥ **70% at 0:30**; reshoot or re-order if low.
- [ ] Shorts cadence: **2–3 per long**; post to Community tab weekly.
- [ ] Cross-post: Substack on Sun PM with transcript & embeds.
- [ ] Quarterly **live Q&A** (collect questions via GitHub Issue + Substack poll).

## Phase 5 — Review & scale
- [ ] 90-day review: Returning Viewers trend up; Suggested traffic > Browse.
- [ ] Expand formats: “Field Notes” monthly; “Explained in a Diagram” bi-weekly.
- [ ] Speaker kit playlist: 3 best talks + 1 explainer + 1 case.

---
**Changelog:** Append date / commit / note when you tick boxes.
