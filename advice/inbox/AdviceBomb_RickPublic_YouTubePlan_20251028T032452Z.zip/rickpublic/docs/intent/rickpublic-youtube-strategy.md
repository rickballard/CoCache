# RickPublic · YouTube Strategy (living)

**Channel promise:** *Weekly 3–5 min civic-systems remixes: reframe big stories and popular creators through CoCivium’s “no corruption, no coercion, no crowns” lens, ending with one actionable move.*

## Formats
- **Remix & Repair (3–5m, weekly):** Hook → rights-safe beat → what people heard vs. what it means → CoTheory 2×2 → One move → CTA.
- **Field Notes (5–8m, monthly):** One country/case → rule-of-thumb → how a CoSuite tool applies.
- **Explained in a Diagram (2–3m, bi-weekly later):** Animated CoTheory 2×2 / Perspective Plane.

## Episode skeleton (reuse)
0:00–0:03 Hook (promise a payoff)  
0:03–0:12 Source beat (CC/public domain still/b-roll or quote)  
0:12–1:10 Stakes + context (1 stat, 1 story)  
1:10–2:30 CoTheory lens (2×2: Centralization↔Openness × Power↔Accountability)  
2:30–3:40 Three takeaways (1 sentence each)  
3:40–4:30 One move (citizen / policymaker / builder)  
4:30–4:40 CTA (rotate)

## Rights & sourcing (safe remix)
- Prefer **Public Domain/CC-BY/CC-BY-SA** assets (NASA, UN, OECD, C‑SPAN, EU bodies, Wikimedia, Pexels/Pixabay video).
- If excerpting non-CC creators: keep it **short** and **transformative** (critique/education), avoid the “heart” of the work, add on‑screen credit and in‑description credits; maintain an `ATtributions.md` per episode folder.
- Maintain `BOILERPLATE.md` (fair‑use blurb + tag menu) and include in descriptions.

## Visual identity
- Minimal/clean: grayscale base + single accent (CoCivium color).
- Signature overlays: **CoTheory 2×2** & Perspective Plane, thin lines, subtle grid.
- Thumbnails: close-crop face + 2–3 word verdict (*No Crowns Fix*, *Audit the AI*).

## Cadence & timing
- Start **Fri 18–20 ET** for 4 weeks; A/B against **Sun 19–21 ET**; select winner from CTR, AVD, Returning Viewers.

## Growth loops
- From each long, cut **2–3 Shorts** (hook + takeaway + CTA).
- Community tab: weekly poll/prompts; pin comment with a discussion hook + link to a GitHub Issue for collaboration.
- Cross-post to **Substack** each Sun PM with transcript & embeds.

## Metrics (targets)
- **CTR:** 6–8%+; experiment title/thumbnail within 48–72h if below target.
- **Retention @ 0:30:** ≥70%; re-order/open with a stronger hook if weak.
- **Avg % viewed (3–5m):** ≥45%.
- **Returning Viewers:** trending up month over month.
- **Traffic:** grow Suggested over Browse by day 30.

## CTAs (rotate)
- “Join the public build (link in pinned comment).”
- “Comment ‘No Crowns’ for the 2×2 template.”
- “Subscribe for the weekly remix.”
- “Nominate a system to remix next week.”

## Ops (repo-first)
- Per episode: `/media/youtube/EYYYYMMDD_<slug>/` with `script.md`, `video.manifest.json`, `sources/`, `overlays/`, `ATtributions.md`.
- Substack unchanged: keep `/candidates` & `/sotw` flows.
- **No AdviceBomb intake here.** If you package one, move the ZIP to **CoCache/advice/inbox/**.
