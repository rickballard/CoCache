Subscribe at https://rickpublic.substack.com
