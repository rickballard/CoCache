**Fair-use & rights checklist**
- Transformative purpose (commentary/education)? ✅
- Short, necessary excerpts only; avoid the “heart” of the work. ✅
- Clear separation & attribution on-screen and in description. ✅

**Description boilerplate**
This video transforms third-party material via commentary, analysis, and education for civic understanding (fair use). Sources and credits below.

**Tags menu (pick 6–12)**
CoCivium, governance, accountability, open data, civic tech, AI alignment, audit, no crowns, public interest, policy
