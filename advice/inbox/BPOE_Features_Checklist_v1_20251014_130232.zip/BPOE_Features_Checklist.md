# BPOE Features — Launch Checklist (Public)
- Pre-checked features with warnings.
- Zero-footprint, privacy-first defaults, anonymous mode, dark mode, voice-vibing.
