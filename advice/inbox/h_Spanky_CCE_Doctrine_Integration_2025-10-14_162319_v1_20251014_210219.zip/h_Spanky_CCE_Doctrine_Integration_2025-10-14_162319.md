# h_Spanky_CCE_Doctrine_Integration_20251014_162319

Mirror: [h_Spanky_CCE_Doctrine_Integration_20251014_162319.zip](./h_Spanky_CCE_Doctrine_Integration_20251014_162319.zip)

_Added via DO_Ingest-MissingAdviceBombs on 2025-10-14T21:02:18_
