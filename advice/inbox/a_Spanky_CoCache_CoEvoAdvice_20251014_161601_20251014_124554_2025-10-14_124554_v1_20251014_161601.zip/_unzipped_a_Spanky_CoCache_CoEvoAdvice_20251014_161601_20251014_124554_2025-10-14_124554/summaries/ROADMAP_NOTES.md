# Roadmap Notes
- Prioritize low-risk, high-visibility wins: docs/tests first, then small refactors.
- Delay deep ingestion until justified (incident, cross-repo refactor, security sweep).
- Measure onboarding time and contributor velocity weekly; fix friction fast.
