# RISKS & Mitigations
- Runaway autonomy → cap at L1/L2 until metrics show stability; kill-switch ready.
- Privacy/license leaks → schema validation + redaction at ingestion edges.
- Governance capture → rotate stewards; reputation-weighted ballots with transparency.
- Cultural misalignment → publish CoCivia intents; invite human review and veto.
