# DECISIONS (Key)
- Start with advisory PRs only (no auto-merge) for safety and trust-building.
- Keep public interfaces conservative; put novelty in internals/sandbox.
- Invest early in onboarding and previews to attract contributors.
