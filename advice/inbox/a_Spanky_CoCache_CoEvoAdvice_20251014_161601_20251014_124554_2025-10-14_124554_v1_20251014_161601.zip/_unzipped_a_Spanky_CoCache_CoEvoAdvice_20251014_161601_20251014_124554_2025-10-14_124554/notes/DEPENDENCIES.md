# DEPENDENCIES
- CoAgent: product orchestrator and local shell; first target for L1.
- CoCore: taxonomy/models; needs stable interfaces and docs.
- CoRef: reference assets; good candidate for porch exemplars.
- CoCacheGlobal: heartbeat bus + governance/ballots (phase 3).
