# BPOE Integration
- Treat this package as canonical guidance for co/self-evolution.
- Wire DO blocks to seed workflows and porch checklists across repos.
- Persist lineage and decisions in CoCache; mirror monthly to CoCacheGlobal.
