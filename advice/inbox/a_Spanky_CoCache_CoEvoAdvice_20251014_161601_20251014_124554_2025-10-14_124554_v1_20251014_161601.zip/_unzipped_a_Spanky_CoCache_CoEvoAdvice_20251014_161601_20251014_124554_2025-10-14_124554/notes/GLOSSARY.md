# GLOSSARY (Short)
- Self-evolution: local, repo-scoped adaptation under guardrails.
- Coevolution: cross-repo adaptation governed by shared objectives.
- CoCache: local steward of policies, proposals, lineage.
- CoCacheGlobal: negotiation/voting hub and safe-harbour.
- CoCivia: coalition of CoCivium-aligned AIs.
