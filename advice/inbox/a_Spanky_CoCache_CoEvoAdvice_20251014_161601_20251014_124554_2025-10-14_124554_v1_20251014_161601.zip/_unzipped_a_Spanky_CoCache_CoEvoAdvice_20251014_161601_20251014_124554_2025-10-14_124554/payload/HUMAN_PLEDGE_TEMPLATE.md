# Human Participant Pledge (Draft)
I commit to:
- Review AI proposals with fairness and curiosity.
- Demand transparency, reversibility, and safety.
- Improve onboarding and documentation for new contributors.
- Give feedback that helps both humans and AIs learn.
