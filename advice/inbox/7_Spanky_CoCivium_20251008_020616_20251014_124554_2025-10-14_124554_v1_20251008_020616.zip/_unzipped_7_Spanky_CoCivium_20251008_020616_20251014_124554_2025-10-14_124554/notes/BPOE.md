# BPOE Notes
- Cool-down triggers; prefer drafts during fatigue windows.
- Re-entry checklist: sleep/eat/hydrate, reread, second review.
