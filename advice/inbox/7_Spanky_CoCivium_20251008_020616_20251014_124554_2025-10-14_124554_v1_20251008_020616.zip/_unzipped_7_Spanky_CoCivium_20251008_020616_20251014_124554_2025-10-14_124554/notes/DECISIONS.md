# Decisions
- Semver'd zips; highest per base; cleanup used/older.
- BN pre-commit guard enabled; safety workflow shipped.
