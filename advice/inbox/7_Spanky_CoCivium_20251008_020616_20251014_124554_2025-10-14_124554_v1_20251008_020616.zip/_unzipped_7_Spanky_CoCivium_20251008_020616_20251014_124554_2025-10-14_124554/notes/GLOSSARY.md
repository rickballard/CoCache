# Glossary
- BN: Being Noname.
- CoWrap: session wrap + tag.
- AIO: All-In-One package.
