# Deprecated
- One-off scripts → standardized zip + do.ps1 pattern.
