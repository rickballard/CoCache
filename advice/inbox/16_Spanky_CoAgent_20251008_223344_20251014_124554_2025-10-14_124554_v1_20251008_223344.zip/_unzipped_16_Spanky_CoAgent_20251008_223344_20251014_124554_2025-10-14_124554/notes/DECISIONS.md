# DECISIONS
Hybrid client; single signed build + flags; Ethics VM; streams converge at Belt 3; CSX thresholds to graduate CE→AE.