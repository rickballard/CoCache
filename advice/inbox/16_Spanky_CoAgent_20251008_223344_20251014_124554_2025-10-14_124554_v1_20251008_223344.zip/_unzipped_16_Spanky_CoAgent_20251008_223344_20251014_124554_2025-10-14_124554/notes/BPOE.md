# BPOE
AE vs CE classes; rings & rollback; repo policies; continuity (ledger/recall/DropGuard).