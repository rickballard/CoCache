# ASSUMPTIONS
Belts accepted if fair; Recall Cards suffice; Sandbox fidelity ≥0.90; Advice-Bomb contributions scale.