# GLOSSARY
AE, CE, CSX, BPOE, CoPayload, CoCache(L/T/G), HITL, Shadow Sandbox, Lex/Praxis.