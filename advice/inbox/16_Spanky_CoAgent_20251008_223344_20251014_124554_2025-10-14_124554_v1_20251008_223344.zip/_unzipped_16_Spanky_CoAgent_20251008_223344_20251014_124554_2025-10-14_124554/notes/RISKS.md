# RISKS
Governance bypass; cache poisoning; jurisdiction pressure; UX churn; memory loss.