filename: 16_Spanky_CoAgent_20251008_223344_20251014_124554_2025-10-14_124554_v1_20251008_223344.zip
version: v1
timestamp: 20251008_223344
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
