filename: Spanky28__transcripts_20251009_002955_20251014_124554_2025-10-14_124554_v1_20251009_002955.zip
version: v1
timestamp: 20251009_002955
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
