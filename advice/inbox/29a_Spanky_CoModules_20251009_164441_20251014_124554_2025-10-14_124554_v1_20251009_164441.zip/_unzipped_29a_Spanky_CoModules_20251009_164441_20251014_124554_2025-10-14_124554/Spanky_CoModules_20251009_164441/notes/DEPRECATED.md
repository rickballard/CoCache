# Deprecated
- Earlier heredocs with inline -Encoding markers in content.

