# Glossary
- BPOE: norms encoded into code/CI
- CoWrap: running log under CoCache/CoWrap.md

