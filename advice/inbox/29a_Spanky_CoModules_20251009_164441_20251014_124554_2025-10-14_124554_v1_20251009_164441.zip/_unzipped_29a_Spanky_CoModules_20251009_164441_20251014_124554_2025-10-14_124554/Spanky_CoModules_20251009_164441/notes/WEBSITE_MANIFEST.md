# Website Manifest (placeholder)
- Docs index, CoCache switchboard prominent.

