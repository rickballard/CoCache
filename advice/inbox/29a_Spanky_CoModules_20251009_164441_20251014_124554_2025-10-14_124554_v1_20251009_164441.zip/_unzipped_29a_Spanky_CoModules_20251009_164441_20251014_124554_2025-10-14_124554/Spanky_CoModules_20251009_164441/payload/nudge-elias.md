Subject: quick nudge — your careerOS starter is waiting (stable links inside)

