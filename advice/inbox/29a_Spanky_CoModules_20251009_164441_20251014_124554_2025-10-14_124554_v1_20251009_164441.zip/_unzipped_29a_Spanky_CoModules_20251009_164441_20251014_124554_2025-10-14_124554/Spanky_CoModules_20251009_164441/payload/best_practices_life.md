# LifeOS — Best Practices (excerpt)
- Healthy defaults; outcomes focus; local-first data.

