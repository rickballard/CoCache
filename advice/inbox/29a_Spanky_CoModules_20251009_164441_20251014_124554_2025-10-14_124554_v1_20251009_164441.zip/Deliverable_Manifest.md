filename: 29a_Spanky_CoModules_20251009_164441_20251014_124554_2025-10-14_124554_v1_20251009_164441.zip
version: v1
timestamp: 20251009_164441
source_session: Backfill
target_session: CoPrime
status: ready-for-ingestion
