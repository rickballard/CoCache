## What’s in this PR
- New/updated exemplar(s).

## Checklist
- [ ] Required front matter keys present
- [ ] Evidence grade justification included
- [ ] HumanGate required? Linked notes
- [ ] Non-endorsement disclaimer present
- [ ] Links/provenance provided or 'TBD' + issue ref
