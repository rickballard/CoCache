CoCore: records; CoCache: runs/dashboards; CoAgent: lints + routing; MeritRank/RepTag: use congruence; GIBINDEX codes in front matter.
