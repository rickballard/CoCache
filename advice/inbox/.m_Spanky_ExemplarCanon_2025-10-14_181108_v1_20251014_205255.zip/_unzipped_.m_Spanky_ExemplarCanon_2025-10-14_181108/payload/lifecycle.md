States: concept → prototype → pilot → observational → RCT → scaled → deprecated. Promotions via PR with reviewer sign-off; keep deprecated indexed.
