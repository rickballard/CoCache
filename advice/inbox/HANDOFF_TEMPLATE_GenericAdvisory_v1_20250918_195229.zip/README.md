Title: HANDOFF_TEMPLATE_GenericAdvisory
Intent: Backfilled legacy advice
Owner: Backfill
Version: 2025-09-18T19-52-29
Status: settled
Guardrails:
  MaxSizeKB: 256
  MaxCadenceMins: 30
  MaxChangePct: 20
Change-Notes:
  - Backfilled from legacy content; preserved original timestamp

## Source Files
- docs\advice_bombs\batch_20251014_124554\.43_Spanky_GrandMigration_20251009_194020\payload\HANDOFF_TEMPLATE_GenericAdvisory.md)
