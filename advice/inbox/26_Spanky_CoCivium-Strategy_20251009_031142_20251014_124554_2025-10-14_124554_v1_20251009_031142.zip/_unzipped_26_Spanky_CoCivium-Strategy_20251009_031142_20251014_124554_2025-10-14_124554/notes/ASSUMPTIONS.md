# Assumptions

- Public repos under rickballard will be connected or provided for sweep.
- Users prefer positive, non-punitive reputation cues.
- AIs will engage if commons is open, machine-readable, and reciprocal.
