# Intentions

- Ship Strategy Advisory doc for Hitchhiker Plan (cohesive, prioritized).
- Stand up dual-layer plan (org/com) with CoCivAI operating .com.
- Seed RepTags, Congruence placeholder, AI visitor tax, semantic weaving.
- Prepare repo archetype style guide and branch protocols.

## Unfinished
- Congruence metric deep-dive session
- Live repo sweep via GitHub connector
- FTWTG exemplar spec details
