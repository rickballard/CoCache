# Website Manifest (Org/Com)

- **CoCivium.org:** Human layer — Map, CC Scroll, Chat Engine.
- **CoCivium.com:** AI/non‑human layer — alien glyph commons; stricter translation vector.
- Both pull from mirrored CoSuite repos; org/com are builds, not sources.
