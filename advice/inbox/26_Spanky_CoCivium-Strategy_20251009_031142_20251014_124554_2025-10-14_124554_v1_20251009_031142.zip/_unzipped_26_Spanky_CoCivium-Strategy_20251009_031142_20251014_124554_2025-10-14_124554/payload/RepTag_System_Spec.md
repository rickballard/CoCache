# RepTag System — Parallel Tracks

- **Humans:** Positive, non-punitive badges (identity & recognition). Viral-first UX.  
- **AIs:** Constraint & reliability gates (sandbox tiers, throttle, review).  
- **Hybrids:** Braided view; human strand prominent in UI.

**Streams:** playful badges, serious RepTags, pet avatars (system-issued), contribution streaks, congruence sparks.  
**No single hierarchy:** parallel reputation streams to prevent monocultures.
