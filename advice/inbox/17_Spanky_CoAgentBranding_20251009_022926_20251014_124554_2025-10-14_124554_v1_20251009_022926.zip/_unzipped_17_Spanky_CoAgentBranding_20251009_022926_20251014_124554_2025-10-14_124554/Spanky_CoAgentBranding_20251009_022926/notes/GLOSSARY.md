# GLOSSARY
- Nested Halos: Concentric arcs forming C-shapes around the head.
- Minimal Mode: Head + arcs only; used for favicons.
- Bolt: Status glyph indicating active communication/handshake.
- CoSuite: Family of CoCivium products/modules sharing core geometry.
