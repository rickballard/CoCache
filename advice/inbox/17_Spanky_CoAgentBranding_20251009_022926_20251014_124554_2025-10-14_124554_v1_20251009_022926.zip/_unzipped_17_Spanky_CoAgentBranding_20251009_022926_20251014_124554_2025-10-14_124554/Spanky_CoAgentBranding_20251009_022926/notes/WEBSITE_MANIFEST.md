# WEBSITE MANIFEST (Brand Assets)
- Favicon: /branding/favicon-16.png, -32, -64
- App icon (square): /branding/logo-square-*.png
- Wide header: /branding/logo-wide-*.png (no-bolt for static header; bolt allowed in hero animation)
- Splash: /branding/splash-*.png (dark and light versions)
- Palette tokens: /branding/palette.json
