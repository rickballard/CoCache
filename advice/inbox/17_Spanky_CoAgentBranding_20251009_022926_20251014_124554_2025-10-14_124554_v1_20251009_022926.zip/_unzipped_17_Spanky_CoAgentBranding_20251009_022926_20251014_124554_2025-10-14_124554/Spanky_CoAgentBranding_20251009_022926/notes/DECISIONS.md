# DECISIONS
- CoCivium remains grayscale-only.
- CoAgent monochrome by default; rainbow for docs/splash.
- Lightning bolt is status indicator, not static mark.
- Dual export (light/dark) for all assets.
