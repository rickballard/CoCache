# INTENTIONS
- Establish coherent CoAgent visual identity aligned to CoCivium.
- Provide drop-in assets for productization with light/dark support.
- Document usage rules so modules inherit geometry without brand drift.
- (Unfinished) Optional SVG master set and CSS token pack later.
