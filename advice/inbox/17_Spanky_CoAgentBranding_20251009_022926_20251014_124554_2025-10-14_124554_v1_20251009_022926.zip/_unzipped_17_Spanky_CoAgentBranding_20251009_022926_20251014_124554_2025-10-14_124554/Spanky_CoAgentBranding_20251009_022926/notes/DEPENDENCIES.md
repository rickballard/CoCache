# DEPENDENCIES
- Raster generation used Pillow (build-time only).
- Fonts for splash titles (fallbacks applied).
- CoCivium grayscale master brand.
