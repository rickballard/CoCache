# Membership Agreement (template)
Members attest to: (a) truthful Receipts; (b) re-attestation cadence; (c) incident disclosures; (d) audit cooperation.
