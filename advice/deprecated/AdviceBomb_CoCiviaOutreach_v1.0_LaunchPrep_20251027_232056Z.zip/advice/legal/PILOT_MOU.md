# Pilot MoU (template)
Parties: CoCivia, Vendor, Buyer. Scope: publish Receipt + Annex; run procurement clause; measure KPIs; publish deltas.
