# Antitrust Checklist
- Neutral criteria; no price coordination; open membership pathways; due process for status changes.
