# Club Bylaws (v1.0, seed)
- Purpose, membership tiers, voting on **standards only** (not vendor status), conflict-of-interest rules, transparency & logs.
