# Defamation Checklist
- Cite primary sources; date-stamp claims; avoid imputing motives; publish errata/change-log on corrections.
