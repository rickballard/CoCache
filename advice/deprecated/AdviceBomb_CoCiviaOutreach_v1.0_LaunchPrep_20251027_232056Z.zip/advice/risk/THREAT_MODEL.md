# Threat Model (policy/comms)
- Legal-chill attacks → Mitigation: counsel review + checklists
- Astroturf pushback → Mitigation: publish criteria + logs
- Mis/disinformation → Mitigation: source links + freshness stamps
