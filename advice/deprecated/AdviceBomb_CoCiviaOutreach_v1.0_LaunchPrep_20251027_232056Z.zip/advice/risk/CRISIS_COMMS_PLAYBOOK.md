# Crisis Comms Playbook (seed)
- 0–2h: acknowledge receipt; 24h: publish facts; 72h: full postmortem. Dedicated page + timeline.
