# CoCivia Brief (6–8p skeleton)
1) Context & thesis
2) The Alignment Receipt (fields, schema, examples)
3) The Impact Annex (definitions, formulas, reporting cadence)
4) Procurement adoption (clauses, pilots, platforms)
5) Interop (EU/UK/CA/JP/AU mapping)
6) Governance & due process
7) Cost vs. Uplift: TCO & KPIs
Appendix: Sources, glossary
