# Comms Calendar (T-minus plan)
T-30: publish Brief; embargoed editor calls; line up pilots  
T-14: submit exclusive op-ed; finalize clause & .org page  
T-7: publish pilot receipts; preview registry  
T-0: op-ed goes live; .org splash; announce pilots & registry  
T+30/90: publish KPI deltas; onboard next cohort
