# Domains & Positioning
Primary: cocivia.org (.org for accreditation) and cocivia.com (.com for program).  
Reserves: cocivai.org/.com and .ai variants.  
One-liner: **Trust & Uplift, Verifiable.**
