# Messaging
What: neutral accreditation club issuing machine-readable receipts.  
Why: flips buying from token-cost to verified uplift.  
How: open schemas + public registry + re-attestation.
