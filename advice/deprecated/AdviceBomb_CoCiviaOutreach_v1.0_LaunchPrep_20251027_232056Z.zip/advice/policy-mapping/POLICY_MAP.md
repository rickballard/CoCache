# Policy Mapping (v1.0)
| Field | NIST AI RMF | AISI | EU AI Act | OMB M-24-10 | DOL Worker | Notes |
|---|---|---|---|---|---|---|
| jurisdictions_of_control | Govern/Map | - | Transparency | Governance | - | Legal compulsion disclosure |
| evaluations[] | Measure/Manage | Evals | Risk mgmt | Testing | - | Public links |
| data_controls.residency | Manage | - | Data governance | Acquisition | - | Residency options |
| disclosures.foreign_legal_compulsion | Govern | - | - | Risk | - | Country-neutral |
| Impact KPIs | - | - | - | Workforce | Worker | Uplift metrics |
