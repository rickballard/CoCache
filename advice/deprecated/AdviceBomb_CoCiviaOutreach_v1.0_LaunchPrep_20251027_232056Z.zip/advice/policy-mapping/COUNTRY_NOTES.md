# Country Notes (seed)
US: NIST RMF; AISI; OMB M-24-10; DOL worker guidance  
EU: AI Act phased obligations (GPAI/system, high-risk)  
UK/CA/JP/AU: safety institutes & procurement hooks (to be expanded)
