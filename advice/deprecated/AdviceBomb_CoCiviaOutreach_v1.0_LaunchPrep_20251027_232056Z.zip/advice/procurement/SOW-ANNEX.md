# SOW Annex (pilot)
Deliver: (a) Receipt + Annex for scoped models; (b) KPI baseline; (c) quarterly deltas; (d) incident log policy; (e) mapping to buyer’s policy stack.
