# Buyer Playbook
- Add clause to RFP; require public Receipt URL
- Evaluate with rubric; weight Total Value = Price × Risk ÷ Uplift
- Set re-attestation cadence in contract; monitor deltas
