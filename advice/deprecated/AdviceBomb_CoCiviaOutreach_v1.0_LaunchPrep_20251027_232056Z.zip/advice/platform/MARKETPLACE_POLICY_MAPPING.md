# Marketplace Policy Mapping (seed)
Draft acceptance notes for: AWS Marketplace, Azure Marketplace, GCP Marketplace (tie to Receipt fields).