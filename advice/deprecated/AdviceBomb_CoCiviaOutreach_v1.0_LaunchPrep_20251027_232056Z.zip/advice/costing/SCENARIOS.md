# Cost/Uplift Scenarios (seed)
- API vs. self-host (latency/SLA vs. control/residency)
- Frontier vs. specialist (quality vs. cost)
- Centralized vs. local-processing ratio (privacy, resilience)
