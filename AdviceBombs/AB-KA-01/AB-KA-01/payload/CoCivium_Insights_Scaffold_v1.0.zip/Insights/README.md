# CoCivium Insights (paired Thesis ⇄ OpsBrief)

This folder consolidates insights across repos non-destructively. Each theme has a Thesis (WHY/WHAT) and an OpsBrief (HOW/NOW). OpsBriefs compile into AdviceBombs.

## Index

| Code | Thesis | OpsBrief | AdviceBomb |
|---|---|---|---|
| LL | [Lex Liminalis — The Coexistence Doctrine](./LL_Thesis_lex-liminalis-the-coexistence-doctrine_v1.0.md) | [LiminalOps — Interfaces & Safeguards Pack](./LL_OpsBrief_liminalops-interfaces-safeguards-pack_v1.0.md) | `AdviceBombs/AB-LL-01_liminalops-interfaces-safeguards-pack_v1.0.zip` |
| CG | [Congruence Theory — Metrics & Ethics](./CG_Thesis_congruence-theory-metrics-ethics_v1.0.md) | [CongruenceOps — Scoring & Dashboards](./CG_OpsBrief_congruenceops-scoring-dashboards_v1.0.md) | `AdviceBombs/AB-CG-01_congruenceops-scoring-dashboards_v1.0.zip` |
| CC | [Counter-Capture — Governance Hardening](./CC_Thesis_counter-capture-governance-hardening_v1.0.md) | [GovHardening Ops — Seat Caps & Juries](./CC_OpsBrief_govhardening-ops-seat-caps-juries_v1.0.md) | `AdviceBombs/AB-CC-01_govhardening-ops-seat-caps-juries_v1.0.zip` |
| RT | [Reputation Thesis — RepTag Model](./RT_Thesis_reputation-thesis-reptag-model_v1.0.md) | [RepTag Ops — Incentives & Vectors](./RT_OpsBrief_reptag-ops-incentives-vectors_v1.0.md) | `AdviceBombs/AB-RT-01_reptag-ops-incentives-vectors_v1.0.zip` |
| FF | [FinFlow — Dues & Tax Compliance](./FF_Thesis_finflow-dues-tax-compliance_v1.0.md) | [FinFlow Ops — Gateways & Ledgers](./FF_OpsBrief_finflow-ops-gateways-ledgers_v1.0.md) | `AdviceBombs/AB-FF-01_finflow-ops-gateways-ledgers_v1.0.zip` |
| OB | [Open Banking & Data Trusts — Principles](./OB_Thesis_open-banking-data-trusts-principles_v1.0.md) | [OpenBank Ops — Connectors & Consent](./OB_OpsBrief_openbank-ops-connectors-consent_v1.0.md) | `AdviceBombs/AB-OB-01_openbank-ops-connectors-consent_v1.0.zip` |
| IA | [Identity & Agency — Credentials & AI Agency](./IA_Thesis_identity-agency-credentials-ai-agency_v1.0.md) | [AgencyOps — Rights, Grants, Revocation](./IA_OpsBrief_agencyops-rights-grants-revocation_v1.0.md) | `AdviceBombs/AB-IA-01_agencyops-rights-grants-revocation_v1.0.zip` |
| PT | [Privacy–Transparency Balance — Auditable Secrecy](./PT_Thesis_privacy-transparency-balance-auditable-secrecy_v1.0.md) | [PT Ops — Escrow & Disclosure](./PT_OpsBrief_pt-ops-escrow-disclosure_v1.0.md) | `AdviceBombs/AB-PT-01_pt-ops-escrow-disclosure_v1.0.zip` |
| SA | [Safety & Integrity — CoSafe Doctrine](./SA_Thesis_safety-integrity-cosafe-doctrine_v1.0.md) | [CoSafe Ops — Due Process & Explainability](./SA_OpsBrief_cosafe-ops-due-process-explainability_v1.0.md) | `AdviceBombs/AB-SA-01_cosafe-ops-due-process-explainability_v1.0.zip` |
| DI | [Disinformation & Info Integrity — Truth Tracking](./DI_Thesis_disinformation-info-integrity-truth-tracking_v1.0.md) | [InfoIntegrity Ops — Provenance & Claims](./DI_OpsBrief_infointegrity-ops-provenance-claims_v1.0.md) | `AdviceBombs/AB-DI-01_infointegrity-ops-provenance-claims_v1.0.zip` |
| BM | [Black/Gray Market On-Ramps — Amnesty Economics](./BM_Thesis_black-gray-market-on-ramps-amnesty-economics_v1.0.md) | [AmnestyOps — Vectors & Compliance](./BM_OpsBrief_amnestyops-vectors-compliance_v1.0.md) | `AdviceBombs/AB-BM-01_amnestyops-vectors-compliance_v1.0.zip` |
| CA | [CoAgent Orchestration — Autonomy & BPOE](./CA_Thesis_coagent-orchestration-autonomy-bpoe_v1.0.md) | [CoAgent Ops — Runtimes & Watchers](./CA_OpsBrief_coagent-ops-runtimes-watchers_v1.0.md) | `AdviceBombs/AB-CA-01_coagent-ops-runtimes-watchers_v1.0.zip` |
| CM | [CoCache & Memory — Sidecar Architecture](./CM_Thesis_cocache-memory-sidecar-architecture_v1.0.md) | [CoCache Ops — Heartbeats & CoWrap](./CM_OpsBrief_cocache-ops-heartbeats-cowrap_v1.0.md) | `AdviceBombs/AB-CM-01_cocache-ops-heartbeats-cowrap_v1.0.zip` |
| KA | [Knowledge Architecture — EvoMap & GIBindex](./KA_Thesis_knowledge-architecture-evomap-gibindex_v1.0.md) | [KnowOps — Taxonomy & Chunking](./KA_OpsBrief_knowops-taxonomy-chunking_v1.0.md) | `AdviceBombs/AB-KA-01_knowops-taxonomy-chunking_v1.0.zip` |
| MY | [Mythos & Narrative — Hybrid Society Canon](./MY_Thesis_mythos-narrative-hybrid-society-canon_v1.0.md) | [MythOps — Companion Guides & Bridges](./MY_OpsBrief_mythops-companion-guides-bridges_v1.0.md) | `AdviceBombs/AB-MY-01_mythops-companion-guides-bridges_v1.0.zip` |
| GB | [Community Ops — GroupBuild & Onboarding](./GB_Thesis_community-ops-groupbuild-onboarding_v1.0.md) | [GroupBuild Ops — Rituals & Moderation](./GB_OpsBrief_groupbuild-ops-rituals-moderation_v1.0.md) | `AdviceBombs/AB-GB-01_groupbuild-ops-rituals-moderation_v1.0.zip` |
| ED | [Education & Stewardship — Civic Curriculum](./ED_Thesis_education-stewardship-civic-curriculum_v1.0.md) | [EduOps — Pathways & Badges](./ED_OpsBrief_eduops-pathways-badges_v1.0.md) | `AdviceBombs/AB-ED-01_eduops-pathways-badges_v1.0.zip` |
| CD | [CADI & Planetary Defence — Non-Kinetic Defence](./CD_Thesis_cadi-planetary-defence-non-kinetic-defence_v1.0.md) | [CADI Ops — Drills & Standards](./CD_OpsBrief_cadi-ops-drills-standards_v1.0.md) | `AdviceBombs/AB-CD-01_cadi-ops-drills-standards_v1.0.zip` |
| JL | [Jurisdictions & Legal Shell — Safe Havens](./JL_Thesis_jurisdictions-legal-shell-safe-havens_v1.0.md) | [JurisOps — Entity Setup & Exit](./JL_OpsBrief_jurisops-entity-setup-exit_v1.0.md) | `AdviceBombs/AB-JL-01_jurisops-entity-setup-exit_v1.0.zip` |
| FN | [Funding & Neutrality — Anti-Capture Finance](./FN_Thesis_funding-neutrality-anti-capture-finance_v1.0.md) | [FundOps — Guardrails & Transparency](./FN_OpsBrief_fundops-guardrails-transparency_v1.0.md) | `AdviceBombs/AB-FN-01_fundops-guardrails-transparency_v1.0.zip` |
| SP | [Speech & Moderation — Rights Across Borders](./SP_Thesis_speech-moderation-rights-across-borders_v1.0.md) | [SpeechOps — Policies & Appeals](./SP_OpsBrief_speechops-policies-appeals_v1.0.md) | `AdviceBombs/AB-SP-01_speechops-policies-appeals_v1.0.zip` |
| CP | [Crisis Management — Posture & Exception Rules](./CP_Thesis_crisis-management-posture-exception-rules_v1.0.md) | [CrisisOps — COP Playbooks](./CP_OpsBrief_crisisops-cop-playbooks_v1.0.md) | `AdviceBombs/AB-CP-01_crisisops-cop-playbooks_v1.0.zip` |
| OS | [Open Source & IP — Licensing for Hybrids](./OS_Thesis_open-source-ip-licensing-for-hybrids_v1.0.md) | [OpenOps — CLA, Licences & Releases](./OS_OpsBrief_openops-cla-licences-releases_v1.0.md) | `AdviceBombs/AB-OS-01_openops-cla-licences-releases_v1.0.zip` |
| IP | [Interop Protocols — Civic Interface Stack](./IP_Thesis_interop-protocols-civic-interface-stack_v1.0.md) | [InteropOps — APIs, Schemas, Audits](./IP_OpsBrief_interopops-apis-schemas-audits_v1.0.md) | `AdviceBombs/AB-IP-01_interopops-apis-schemas-audits_v1.0.zip` |
| EC | [Economic Model — Menzies Model](./EC_Thesis_economic-model-menzies-model_v1.0.md) | [EconOps — CoFinance Mechanics](./EC_OpsBrief_econops-cofinance-mechanics_v1.0.md) | `AdviceBombs/AB-EC-01_econops-cofinance-mechanics_v1.0.zip` |
| PC | [Policy Commons — CoPolicy DB](./PC_Thesis_policy-commons-copolicy-db_v1.0.md) | [PolicyOps — Templates & Analyzers](./PC_OpsBrief_policyops-templates-analyzers_v1.0.md) | `AdviceBombs/AB-PC-01_policyops-templates-analyzers_v1.0.zip` |
| HR | [Human Factors — Roles, RBAC Successor](./HR_Thesis_human-factors-roles-rbac-successor_v1.0.md) | [RoleOps — Fluid Roles & Safeguards](./HR_OpsBrief_roleops-fluid-roles-safeguards_v1.0.md) | `AdviceBombs/AB-HR-01_roleops-fluid-roles-safeguards_v1.0.zip` |
| HX | [Ethics & Philosophy — First Principles](./HX_Thesis_ethics-philosophy-first-principles_v1.0.md) | [EthicOps — Decision Policies](./HX_OpsBrief_ethicops-decision-policies_v1.0.md) | `AdviceBombs/AB-HX-01_ethicops-decision-policies_v1.0.zip` |

## Conventions
- YAML front-matter with `uid`, `doc`, `version`, `status`.
- Review cycle default: 90 days; statuses: draft → review → ratified.

## Harvest & Chunk (non-destructive)
- `tools/Harvest-Insights.ps1` copies candidate sources into `Insights/_harvested/` with provenance footers.
- `tools/Chunk-Insights.ps1` splits large sources into atomic chunks and emits `ChunkMap.yml`.

## Mythos Handling
Narrative/mythos texts are canonical. Do not edit in place. Create companion OpsBriefs that reference them and extract claims via chunking.
