---
uid: DI
doc: OpsBrief
title: InfoIntegrity Ops — Provenance & Claims
version: 1.0
status: draft
pair_uid: DI
review_cycle_days: 90
links:
  thesis: Insights/DI_Thesis_disinformation-info-integrity-truth-tracking_v1.0.md
  advice_bomb: AdviceBombs/AB-DI-01_infointegrity-ops-provenance-claims_v1.0.zip
---

# Ops Summary
(One page: what ships this quarter and why it matters.)

# Interfaces & Protocols
(Define concrete APIs/processes, governance committees, audit logs.)

# 90-Day Plan
(M1→M3 milestones with acceptance tests.)

# Governance & Safeguards
(Capture tripwires, role rotation, jury pools, funding diversification caps.)

# Checklists
(Due process, data minimization, transparency report publication.)

# Posture Playbook (COP-0…COP-4)
(Triggers, actions, comms templates, rollback/exit steps.)

# Metrics & Telemetry
(What goes to the Congruence Dashboard; frequency; owners.)

# Packaging → AdviceBomb
(Contents, manifest, run.ps1 contract; outputs: .md + out.txt.)
