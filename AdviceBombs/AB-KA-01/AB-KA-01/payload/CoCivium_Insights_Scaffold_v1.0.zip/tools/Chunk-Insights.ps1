Param(
  [Parameter(Mandatory=$true)][string]$InFile,
  [string]$OutDir = (Join-Path $PSScriptRoot "..\Insights\_chunks"),
  [int]$MaxChars = 1200
)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
$InFile = (Resolve-Path $InFile).Path
$OutDir = (Resolve-Path $OutDir).Path
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$content = Get-Content -Raw -Path $InFile -Encoding UTF8
# Split by H1/H2 headers first
$parts = $content -split "(?ms)^(# .+|## .+)\s*$"
# Fallback to fixed-size chunks
if ($parts.Count -le 1) { $parts = $content -split "(.{1,$MaxChars})(?!\S)" | Where-Object { $_ -and $_.Trim() -ne "" } }
$base = [IO.Path]::GetFileNameWithoutExtension($InFile)
$dir = Join-Path $OutDir $base
New-Item -ItemType Directory -Force -Path $dir | Out-Null
$map = @()
for ($i=0; $i -lt $parts.Count; $i++) {
  $chunk = $parts[$i].Trim()
  if ($chunk.Length -eq 0) { continue }
  $fn = "{0:000}.md" -f ($i+1)
  $path = Join-Path $dir $fn
  $chunk | Set-Content -Path $path -Encoding UTF8
  $map += [pscustomobject]@{ file=$path; order=($i+1) }
}
$yml = Join-Path $dir "ChunkMap.yml"
$map | ConvertTo-Yaml | Set-Content -Path $yml -Encoding UTF8
Write-Host "Chunked to $dir"