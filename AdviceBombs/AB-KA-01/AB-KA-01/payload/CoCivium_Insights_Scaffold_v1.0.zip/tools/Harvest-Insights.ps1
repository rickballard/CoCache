Param(
  [Parameter(Mandatory=$true)][string[]]$RepoRoots,
  [string]$OutDir = (Join-Path $PSScriptRoot "..\Insights\_harvested"),
  [string[]]$Patterns = @("*.md","*.markdown","*.txt"),
  [int]$MaxDepth = 20,
  [switch]$DryRun
)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
$OutDir = (Resolve-Path $OutDir).Path
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$index = @()
function Get-FrontMatter($content) {
  if ($content -match "(?s)^---\s*(.*?)\s*---") {
    try {
      $yaml = $Matches[1]
      return $yaml
    } catch { return $null }
  } else { return $null }
}
foreach ($root in $RepoRoots) {
  $rootPath = (Resolve-Path $root).Path
  foreach ($pat in $Patterns) {
    Get-ChildItem -Path $rootPath -Recurse -Depth $MaxDepth -Include $pat -File | ForEach-Object {
      $src = $_.FullName
      $rel = $src.Substring($rootPath.Length).TrimStart('\','/')
      $content = Get-Content -Raw -Path $src -Encoding UTF8
      $fm = Get-FrontMatter $content
      $title = $null; $uid = $null; $doc = $null
      if ($fm) {
        $yaml = $fm | ConvertFrom-Yaml
        $title = $yaml.title
        $uid = $yaml.uid
        $doc = $yaml.doc
      }
      $dest = Join-Path $OutDir ($rel -replace "[\\/]", "__")
      if (-not $DryRun) {
        Copy-Item -LiteralPath $src -Destination $dest -Force
        Add-Content -Path $dest -Value "`n`n<!-- Source: $src -->" -Encoding UTF8
      }
      $index += [pscustomobject]@{ source=$src; out=$dest; title=$title; uid=$uid; doc=$doc }
    }
  }
}
$csv = Join-Path $OutDir "harvest_index.csv"
$json = Join-Path $OutDir "harvest_index.json"
$index | Export-Csv -Path $csv -NoTypeInformation -Encoding UTF8
$index | ConvertTo-Json -Depth 5 | Set-Content -Path $json -Encoding UTF8
Write-Host "Harvest complete. Index at $csv and $json"