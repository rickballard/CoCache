# AdviceBomb AB-HR-01 — RoleOps — Fluid Roles & Safeguards

How to use:
1) Read the OpsBrief.
2) Run `run.ps1`.
3) Review outputs.
