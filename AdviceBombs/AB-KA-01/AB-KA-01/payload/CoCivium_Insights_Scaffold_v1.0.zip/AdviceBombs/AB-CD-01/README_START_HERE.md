# AdviceBomb AB-CD-01 — CADI Ops — Drills & Standards

How to use:
1) Read the OpsBrief.
2) Run `run.ps1`.
3) Review outputs.
