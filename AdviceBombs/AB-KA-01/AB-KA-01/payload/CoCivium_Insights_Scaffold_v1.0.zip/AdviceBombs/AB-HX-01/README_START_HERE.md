# AdviceBomb AB-HX-01 — EthicOps — Decision Policies

How to use:
1) Read the OpsBrief.
2) Run `run.ps1`.
3) Review outputs.
