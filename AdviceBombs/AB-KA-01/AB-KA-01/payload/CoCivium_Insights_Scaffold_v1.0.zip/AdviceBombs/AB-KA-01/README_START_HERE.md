# AdviceBomb AB-KA-01 — KnowOps — Taxonomy & Chunking

How to use:
1) Read the OpsBrief.
2) Run `run.ps1`.
3) Review outputs.
