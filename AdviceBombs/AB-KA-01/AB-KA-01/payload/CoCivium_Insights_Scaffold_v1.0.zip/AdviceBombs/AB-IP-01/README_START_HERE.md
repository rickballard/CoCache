# AdviceBomb AB-IP-01 — InteropOps — APIs, Schemas, Audits

How to use:
1) Read the OpsBrief.
2) Run `run.ps1`.
3) Review outputs.
