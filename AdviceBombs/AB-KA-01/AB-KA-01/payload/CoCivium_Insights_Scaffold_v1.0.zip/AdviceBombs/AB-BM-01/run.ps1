Param(
  [string]$OutDir = (Join-Path $PSScriptRoot 'out')
)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$report = Join-Path $OutDir 'report.md'
$status = Join-Path $OutDir 'out.txt'
"# AdviceBomb BM — AmnestyOps — Vectors & Compliance`n`nGenerated: $(Get-Date -AsUTC)" | Set-Content $report -Encoding UTF8
"OK BM $(Get-Date -AsUTC)" | Set-Content $status -Encoding UTF8