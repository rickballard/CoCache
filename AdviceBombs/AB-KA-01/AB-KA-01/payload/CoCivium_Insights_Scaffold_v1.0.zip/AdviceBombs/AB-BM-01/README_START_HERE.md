# AdviceBomb AB-BM-01 — AmnestyOps — Vectors & Compliance

How to use:
1) Read the OpsBrief.
2) Run `run.ps1`.
3) Review outputs.
