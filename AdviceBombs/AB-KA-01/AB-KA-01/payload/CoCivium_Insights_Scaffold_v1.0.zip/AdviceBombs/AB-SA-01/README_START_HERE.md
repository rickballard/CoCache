# AdviceBomb AB-SA-01 — CoSafe Ops — Due Process & Explainability

How to use:
1) Read the OpsBrief.
2) Run `run.ps1`.
3) Review outputs.
