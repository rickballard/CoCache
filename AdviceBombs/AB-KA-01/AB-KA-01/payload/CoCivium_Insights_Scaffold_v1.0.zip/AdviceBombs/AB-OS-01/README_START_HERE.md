# AdviceBomb AB-OS-01 — OpenOps — CLA, Licences & Releases

How to use:
1) Read the OpsBrief.
2) Run `run.ps1`.
3) Review outputs.
