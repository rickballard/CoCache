# AdviceBomb AB-SP-01 — SpeechOps — Policies & Appeals

How to use:
1) Read the OpsBrief.
2) Run `run.ps1`.
3) Review outputs.
