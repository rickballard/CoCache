# AdviceBomb AB-FN-01 — FundOps — Guardrails & Transparency

How to use:
1) Read the OpsBrief.
2) Run `run.ps1`.
3) Review outputs.
