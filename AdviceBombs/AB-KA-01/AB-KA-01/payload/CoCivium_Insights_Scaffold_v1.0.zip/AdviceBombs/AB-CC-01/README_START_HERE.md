# AdviceBomb AB-CC-01 — GovHardening Ops — Seat Caps & Juries

How to use:
1) Read the OpsBrief.
2) Run `run.ps1`.
3) Review outputs.
