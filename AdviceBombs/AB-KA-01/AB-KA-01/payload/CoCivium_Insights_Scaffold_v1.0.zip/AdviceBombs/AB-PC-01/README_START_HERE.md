# AdviceBomb AB-PC-01 — PolicyOps — Templates & Analyzers

How to use:
1) Read the OpsBrief.
2) Run `run.ps1`.
3) Review outputs.
