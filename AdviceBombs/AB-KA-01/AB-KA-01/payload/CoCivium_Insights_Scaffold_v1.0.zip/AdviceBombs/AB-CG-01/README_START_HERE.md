# AdviceBomb AB-CG-01 — CongruenceOps — Scoring & Dashboards

How to use:
1) Read the OpsBrief.
2) Run `run.ps1`.
3) Review outputs.
