# AdviceBomb AB-JL-01 — JurisOps — Entity Setup & Exit

How to use:
1) Read the OpsBrief.
2) Run `run.ps1`.
3) Review outputs.
