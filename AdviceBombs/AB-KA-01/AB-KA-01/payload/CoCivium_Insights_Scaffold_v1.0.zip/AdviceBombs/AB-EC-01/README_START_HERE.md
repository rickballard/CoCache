# AdviceBomb AB-EC-01 — EconOps — CoFinance Mechanics

How to use:
1) Read the OpsBrief.
2) Run `run.ps1`.
3) Review outputs.
