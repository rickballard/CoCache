# CoPayload AB-KA-01 — Insights Scaffold & Harvest Pack

This payload provides an Insights scaffold (paired Thesis⇄OpsBrief) + tools for non-destructive consolidation.
