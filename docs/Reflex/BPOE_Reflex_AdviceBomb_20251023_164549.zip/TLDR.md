**TLDR: Reflex = system pattern for spotting its own divergence/conflict.**
BPOE-aligned. Suggested for all future evolutionary design.
