# Glossary

- **CoNeura / CoClusta / CoDendra / CoSyna / CoAxa / CoGlia / CoMembra**: Neural-themed taxonomy layers.
- **HumanGate ON**: Require human pre-clearance for higher-risk automation.
- **CoIntent Protocol**: Pre-authorized, auditable instructions enabling scoped autonomy.
- **Upsweep/Downsweep**: Global read/plan pass → targeted content edits pass.