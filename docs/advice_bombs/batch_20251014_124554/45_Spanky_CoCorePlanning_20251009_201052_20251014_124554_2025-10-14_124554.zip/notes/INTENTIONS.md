# Intentions

- Seed CoCore with immutable top-level models; deep-dive case study per CoClusta.
- Build machine-readable business plans in CoCache; publish safe extracts to repos.
- Prepare Upsweep → Down­sweep workflow: machine index (AI) + human index (keystone docs).
- **Status:** Unfinished — pending Grand Migration completion.