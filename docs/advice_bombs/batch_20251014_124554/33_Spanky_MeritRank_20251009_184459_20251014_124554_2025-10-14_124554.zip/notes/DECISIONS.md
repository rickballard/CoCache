# Decisions
- Required status set to `badge` (replacing longer context string).
- Deploy job skipped on PR via event guard.
- Pages upload performed during build; deploy job publishes artifact.
