# Risks
- Other checks may fail without blocking merges; monitor dashboards until stabilized.
- Pages concurrency collisions possible across workflows targeting Pages.
