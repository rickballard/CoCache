# Website/Pages Manifest
- Base: https://rickballard.github.io/MeritRank/
- badge.json: /badge.json
