# Deprecated / Superseded
- Hard-coded watcher calls in PowerShell profile (replaced with guarded hook).
