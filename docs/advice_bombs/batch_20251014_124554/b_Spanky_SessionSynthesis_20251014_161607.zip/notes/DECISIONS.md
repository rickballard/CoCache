# DECISIONS
- Adopt a consistent zip structure and manifests across advice bombs.
- Require checksums and status lines for ingest.
- Separate “claims” (CoRef) from “guidance” (CoCore/CoCache).
