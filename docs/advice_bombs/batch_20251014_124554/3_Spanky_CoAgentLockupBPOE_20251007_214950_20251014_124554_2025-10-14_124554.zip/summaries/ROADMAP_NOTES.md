# Roadmap Notes
- Implement "Safe Mode" launcher.
- Add client-side heap budget warning.
- Session-count watcher with auto-CoWrap prompt.
- One-click "Resume in Fresh Session" path.
- Optional service status widget in UI.