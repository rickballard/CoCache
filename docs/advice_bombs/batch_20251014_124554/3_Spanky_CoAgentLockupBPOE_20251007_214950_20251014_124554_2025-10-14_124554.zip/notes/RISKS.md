# Risks
- Overly aggressive blocking may frustrate users -> ensure clear remediation.
- Telemetry surface may create privacy concerns -> keep local/ephemeral and opt-in.
- False positives on resource checks -> provide bypass switch with warning.