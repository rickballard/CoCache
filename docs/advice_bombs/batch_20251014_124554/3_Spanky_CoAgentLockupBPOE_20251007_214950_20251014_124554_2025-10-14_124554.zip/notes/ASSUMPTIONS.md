# Assumptions
- User can operate an alternate browser/device for quick A/B tests.
- Sidecar logging can be rate-limited without breaking core flows.
- Basic service health pings are permitted by provider policies.