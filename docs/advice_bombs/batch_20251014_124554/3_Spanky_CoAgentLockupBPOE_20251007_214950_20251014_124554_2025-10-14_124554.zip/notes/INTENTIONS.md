# Intentions
- Package lockup lessons as portable CoWrap (Spanky). (Done)
- Add Lockup Triage advisory to repo. (Done)
- Add Session Hygiene guardrails. (Done)
- Add HealthGate preflight checks. (Done)
- Add Continuity Resume protocol. (Done)
- Integrate UI Safe Mode and heap monitor. (Unfinished)
- Implement session-count warnings and auto-CoWrap suggestion. (Unfinished)