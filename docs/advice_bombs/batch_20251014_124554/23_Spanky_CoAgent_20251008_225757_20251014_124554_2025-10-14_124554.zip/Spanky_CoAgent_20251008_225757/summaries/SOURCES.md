Sources include prior session knowledge, competitive landscape scans, and CoCivium BPOE practices. 
Public web citations should be added during repo publication if needed.
