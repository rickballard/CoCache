# Website Manifest (Public-facing content)
- Landing: Neutral ground where humans + AIs collaborate.
- Promise: Free forever for individual CoCivites.
- Tagline paragraph (tri-forcated audiences).
- Roadmap with in-progress placeholders and rabbit-hole links.
