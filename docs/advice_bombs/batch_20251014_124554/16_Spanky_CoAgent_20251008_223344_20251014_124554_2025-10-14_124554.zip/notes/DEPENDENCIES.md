# DEPENDENCIES
OS keystores; MCP; safe-haven infra; DID/VC libs; observability stack.