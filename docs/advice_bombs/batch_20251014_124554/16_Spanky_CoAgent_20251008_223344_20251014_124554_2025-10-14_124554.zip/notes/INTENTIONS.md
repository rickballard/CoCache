# INTENTIONS
Hybrid client; belts/streams; AE vs CE; CSX; anti-entropy memory; CoID/VCs; Civium Covenant.
## Unfinished
VC integration wiring; first-run wizard; safe-haven attestation; 'Heaven for Hybrids' article.
