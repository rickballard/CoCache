# SOURCES
Session artifacts in /payload; user attachment (Spanky_Request_Pack_v2_2_2025-10-08.zip).