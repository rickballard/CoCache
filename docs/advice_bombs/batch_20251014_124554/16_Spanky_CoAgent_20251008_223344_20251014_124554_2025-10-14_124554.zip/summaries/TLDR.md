# TLDR
Hybrid client + cloud governance; safe AutoEvolve; CSX for scope growth; anti-entropy memory; CoID/VCs; Ethics VM.