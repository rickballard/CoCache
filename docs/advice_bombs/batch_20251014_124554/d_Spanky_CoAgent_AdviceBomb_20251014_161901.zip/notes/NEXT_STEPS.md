# Immediate Next Steps (30–60 mins of focused work)

1. Create P0 epics:
   - CoMemory + JIT + Summarizer MVP
   - GLX v0.1 spec + validator + retrieval bias
   - Provenance preview UI (read-only) + restore
   - Max-Power router + telemetry + budgets
   - Safety Preflight + minimal metrics dashboard
2. Add policy stubs (TTL/LRU/pin; creator comfort TTL; safety preflight rules).
3. Prepare golden-set retrieval QA and a tiny chaos drill (no-web, cold index).
4. Publish success metrics to the dash and set alert thresholds.
