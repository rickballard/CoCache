Planned (including early intentions and pivots):
- Rename CoCEO → TOS-AI everywhere and define role clearly.
- Make the homepage self-explanatory (explainer, checklist, CTA).
- Establish Roles landing and permalinks.
- Normalize logos and keep exemplars credible.

(Unfinished)
- Complete logo set; ensure 160×160 PNGs in /assets/img/exemplars.
- Create /roles/index.html (CoPolitic) and propagate role pattern to other repos.
- Add one-pager PDF build, link-checker action, and a11y polish.
