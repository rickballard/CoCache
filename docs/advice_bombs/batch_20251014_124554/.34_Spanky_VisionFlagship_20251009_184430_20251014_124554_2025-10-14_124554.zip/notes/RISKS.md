# Risks
- Scope creep into implementation.
- Visual clutter in hero image (mitigate with ten-foot rule).
- Misread as product promise; mitigated by illustrative disclaimer.
- Tone mismatch across audiences; addressed via outline + details blocks.
