# Assumptions
- Readers can parse Markdown; sponsors appreciate brevity with optional depth.
- Headset UX is aspirational; non-virtual analogue must stand alone.
- JSON schema stays minimal to avoid scaring non-technical readers.
