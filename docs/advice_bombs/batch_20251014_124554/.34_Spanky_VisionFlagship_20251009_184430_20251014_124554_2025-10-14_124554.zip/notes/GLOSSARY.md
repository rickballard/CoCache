# Glossary (human-friendly)
- Mudfling — a meeting where words fly and nothing lands.
- Lightring — a pause and circle where shared clarity forms.
- EvoPath — five-step trail from self regulation to congruence.
- Sprite — bright impulse; color/size/motion signal kind.
- Idea Card — leaf card with words in veins and schema in core.
- Concept Node — cluster of cards strong enough to stand; aura + lineage.
- Aura — small signal for maturity and credibility (RepTag).
