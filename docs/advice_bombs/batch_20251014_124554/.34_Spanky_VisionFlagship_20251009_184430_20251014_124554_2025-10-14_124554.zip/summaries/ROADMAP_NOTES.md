# Roadmap Notes
- v0.1: story + model + lifecycle + hero brief + ethics + before/after + outline + draft paper + HP ZIP.
- v0.2: flesh paper prose; add JSON appendix; figure callouts; educator kit.
- v0.3: hero image render; public site page; sponsor one-pager.
