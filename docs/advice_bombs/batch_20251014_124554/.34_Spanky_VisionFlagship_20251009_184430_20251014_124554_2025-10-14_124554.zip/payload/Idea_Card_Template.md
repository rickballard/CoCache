---
id: IC-YYYYMMDD-####
title: <crisp mnemonic>
authors: [display names]
created: YYYY-MM-DD
updated: YYYY-MM-DD
kind: [problem|insight|practice|hypothesis|story]
evopath_waypoint: [1|2|3|4|5]
links: []
reptag: { maturity: 0, credibility: 0 }
---

## Essence

## Why it matters

## Relations

## Evidence / Examples

## Next moves
