# Advisory Pointer
Use the prior **Advice Bomb (canonical)** and **Inspiration Pack** for full assets.
This package provides the session synthesis and installer. Place prior zips under `CoCache/AdviceBombs/` or use the installer to copy advisory/inspiration folders when present.
