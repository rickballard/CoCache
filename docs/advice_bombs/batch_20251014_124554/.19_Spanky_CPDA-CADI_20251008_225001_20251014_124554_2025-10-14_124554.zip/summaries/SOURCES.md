# Sources (Pointers)
- JPL CNEOS Sentry/Scout; Torino/Palermo scales; Planetary Defense Conference scenarios.
- DART mission outcomes; NEO population/debiased models.
- UN IAWN/SMPAG guidance on NEO threats.
