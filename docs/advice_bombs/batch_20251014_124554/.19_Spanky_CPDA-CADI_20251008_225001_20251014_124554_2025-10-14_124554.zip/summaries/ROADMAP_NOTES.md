# Roadmap (Seed)
- Week 1: Create `cpda` & `cadi` repos; enable Pages; paste docs.
- Month 1: Publish threat/mitigation specs; define transparency cadence; recruit initial Circles.
- Quarter 1: First external review; finalize rebrand plan checkpoint.
