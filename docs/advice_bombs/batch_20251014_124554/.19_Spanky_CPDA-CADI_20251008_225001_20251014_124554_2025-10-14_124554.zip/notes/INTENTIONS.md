# Intentions
- Seed CPDA umbrella and CADI flagship with open, forkable scaffolds.
- Keep early posture innocuous; later rebrand to CoCivium.
- (Unfinished) Draft DAO/mesh minimal constitution; prepare transparency cadence templates.
