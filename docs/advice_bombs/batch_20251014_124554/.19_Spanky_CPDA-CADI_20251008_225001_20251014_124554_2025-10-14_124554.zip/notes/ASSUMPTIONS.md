# Assumptions
- Warning windows for meaningful deflection require years.
- Public legitimacy benefits from neutrality + transparency.
- Rebrand timeline ≈ 2 years (subject to readiness/Audit).
