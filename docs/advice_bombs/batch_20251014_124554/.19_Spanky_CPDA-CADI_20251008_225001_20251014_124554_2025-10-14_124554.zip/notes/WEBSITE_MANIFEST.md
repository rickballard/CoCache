# Microsite Manifest (Seed)
- `cpda/docs/index.md` — umbrella page
- `cpda/docs/initiatives/cadi.md` — CADI showcase
- Assets: quadrant-plot.svg, radar-readiness.svg
- Future: portfolio wheel, timeline strip, transparency dashboards
