# Key Decisions
- Portfolio-seed approach: CADI first; CPDA umbrella later becomes CoCivium.
- No-kings governance (Stewards/Contributors/Circles/Mandates).
- Graphics: Quadrant (headline) + Radar (readiness gaps).
