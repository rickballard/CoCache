# Risks
- Jurisdictional capture; optics of neutrality.
- Incomplete detection coverage; blind spots.
- Governance token design pitfalls; key management failures.
- Mitigation tech political constraints (e.g., nuclear).
