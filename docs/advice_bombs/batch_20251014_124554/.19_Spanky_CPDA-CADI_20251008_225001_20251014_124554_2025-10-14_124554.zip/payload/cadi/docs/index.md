# CADI Documentation

- **Quadrant Plot** (impact energy vs warning time) — `assets/quad.svg`
- **Readiness Radar** — `assets/radar.svg`
- **Threat Models** — `../specs/threat-models.md`
- **Mitigation Options** — `../specs/mitigation-options.md`
- **Triggers & Thresholds** — `../specs/triggers-and-thresholds.md`
