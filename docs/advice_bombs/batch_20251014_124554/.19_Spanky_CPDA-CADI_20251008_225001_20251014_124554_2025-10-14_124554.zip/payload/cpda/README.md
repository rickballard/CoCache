# CoCivium Planetary Defence Alliance (CPDA)
*A neutral, anti-capture commons umbrella. First flagship: CADI (CoCivium Asteroid Defence Initiative).*
Planned transition in ~2 years to the enduring name **CoCivium** as additional initiatives come online.

- **Purpose-lock:** steward open, non-proprietary public-benefit systems, resistant to capture by any state, corporation, or individual.
- **No kings:** rotating **Stewards**, open **Contributors**, self-organising **Circles**, time-bound **Mandates**; DAO/mesh rules for strategy; legal shells = compliance scaffolding.

Microsite lives in `/docs` (GitHub Pages). First initiative spotlight: see `docs/initiatives/cadi.md`.
