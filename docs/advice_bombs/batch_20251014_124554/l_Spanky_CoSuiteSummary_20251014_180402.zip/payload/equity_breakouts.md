# Equity Breakouts
Minimum: age bands, income quintiles, rural vs urban.
Add per domain (justice/health/surveillance): protected-class breakouts per law; allow redaction for re-identification risk.
