# Glossary

- **RickGuard**: Tiered protection switch (Seed/Critical/Off) across many repos.
- **Seed**: Low-friction mode with notifications.
- **Critical**: Tight protections (status checks + reviews).
- **BPOE**: Best Path of Effort — optimize process for speed with safe defaults.
