# Dependencies

- GitHub CLI (`gh`) authenticated with admin on target repos.
- Classic Branch Protection endpoints (public repos) — Rulesets require Pro/Org or public visibility.
- PS7 environment on Windows with proper quoting (`--input -`) for JSON payload piping.
