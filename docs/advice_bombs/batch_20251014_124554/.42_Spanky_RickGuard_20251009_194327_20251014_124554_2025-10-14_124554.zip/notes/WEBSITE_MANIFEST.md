# Website Manifest (starter)

- **CoCivium.org**: may become the sole editing interface for CoCivium; if so, keep Critical until stewards established.
- **CoCache / CoModules**: public during seeding for PS7-based parsing and editing.
