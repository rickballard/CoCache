# Assumptions

- Most repos are in **seed** phase; **CoCivium** is **Critical**.
- Public visibility is acceptable for scaffolding until websites become primary interfaces.
- Owner prefers fewer manual steps; bulk ops via `Set-RickGuardAll`.
