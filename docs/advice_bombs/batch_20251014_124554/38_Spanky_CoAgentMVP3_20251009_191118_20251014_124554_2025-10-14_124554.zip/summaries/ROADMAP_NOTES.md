1) MVP3 shell 2) Guardrails 3) Sandbox 4) Autostart.
