# Intentions
- MVP3 dual panel, pairing cables.

## Unfinished
- Shell prototype; consent flows.
