# Glossary
- CoAgent, CoPong, BPOE.
