# Deps
- PowerShell 7; Windows Zip APIs.
