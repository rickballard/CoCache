# Assumptions
- R/W Downloads; trusted payloads.
