# Decisions
- Release pinning; avoid fragile here-strings; commit handoff zip into repo.

