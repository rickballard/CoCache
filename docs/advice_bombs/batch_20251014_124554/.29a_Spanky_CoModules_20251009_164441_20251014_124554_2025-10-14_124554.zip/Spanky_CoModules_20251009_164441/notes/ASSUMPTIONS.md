# Assumptions
- Public CoWraps discoverable; resume via CoCache/CoWrap.md + RESUME.md.

