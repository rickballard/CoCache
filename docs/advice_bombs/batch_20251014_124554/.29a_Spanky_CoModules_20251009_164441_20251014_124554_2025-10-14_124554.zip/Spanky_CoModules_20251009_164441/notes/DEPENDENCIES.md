# Dependencies
- gh CLI, GitHub Actions, PowerShell 7+

