# Risks
- Artifact drift without CI; missing validation guards.

