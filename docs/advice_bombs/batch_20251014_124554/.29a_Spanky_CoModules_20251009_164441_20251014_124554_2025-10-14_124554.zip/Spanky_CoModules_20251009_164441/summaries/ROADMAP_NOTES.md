# Roadmap Notes
- CI artifacts on PRs; CoWrap bot; release guards; evidence ledger integration.

