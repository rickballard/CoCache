# AI Ethics — Best Practices (excerpt)
- Transparency, Autonomy, Non-coercion, Auditability.

