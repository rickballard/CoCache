# Dependencies
- PowerShell 7.5.x
- Git/GitHub Actions (or equivalent CI)
- `%USERPROFILE%\Downloads\CoTemp` structure (logs/pairs/scripts/tools)
- CoAgent repo with `tools/Start-MVP3-Orchestrator.ps1`
