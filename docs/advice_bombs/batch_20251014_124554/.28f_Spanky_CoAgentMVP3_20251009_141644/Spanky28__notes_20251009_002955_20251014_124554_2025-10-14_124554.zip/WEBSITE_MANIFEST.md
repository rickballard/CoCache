# Website Manifest (placeholder)
- Static page listing releases, CoWraps, checksums, pinned download links.
