# Intentions
- Ship lightweight, read-only host checks (HealthGate). 
- Keep CoAgent scope tight: orchestrate workflows, not OS tuning.
- Add stall-out detection UX + logging.
- Provide hotkey storm tracer and AppKey neutralizer.
- Create PR and auto-merge path for protected branches.
(Unfinished) Integrate third-party diagnostics hand-offs with consent UI.
