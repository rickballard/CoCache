# Assumptions
- User has Git repos at Documents/GitHub/CoAgent and CoCivium.
- User can run PowerShell as admin when needed.
