# Glossary
- BPOE: Business Process Orchestrator Engine.
- HealthGate: Preflight host health check for CoAgent.
- AppKey: Windows Explorer special key mapping (Calculator is AppKey 18).
