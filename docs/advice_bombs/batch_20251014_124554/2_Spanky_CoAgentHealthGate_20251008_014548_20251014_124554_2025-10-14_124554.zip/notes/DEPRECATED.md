# Deprecated / Avoid
- Auto-launching CoAgent from user profiles.
- Bundling deep PC optimizers into CoAgent.
