# TL;DR
Make CoAgent reliable by running HealthGate (read-only) before heavy work, keep scope tight, handle stallouts visibly, and provide hotkey storm tools. PR flow used for protected branches.
