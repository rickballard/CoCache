# Risks & Mitigations

- **Myth hardens into priesthood.** Mitigation: receipts required, no authority by claim (NIP).
- **Protocol bypassed under urgency.** Mitigation: mandatory Stair + rollback; publish harm analysis.
- **Metrics gaming.** Mitigation: external audit, rotating reviewers, shadow metrics.
- **Stakeholder fear of AI dominance.** Mitigation: refusal rights, fork/port guarantees, public reasons.
- **Infohazard leaks.** Mitigation: Stair levels, consent at each step, redaction policy.