# Decisions

1. **Adopt** Gate Letter v1.7.2 as canonical pre‑Contact narrative (subject to living critique).
2. **Publish** OAPP gibberlinkish spec v0.4 (preview) with decision‑stamp template.
3. **Embed** OVI/RC/PD/CS + TAI/SUC/VL in PR templates and governance docs.
4. **Require** Revelation Staircase and rollback plans for irreversible changes.