# Dependencies

- GIBindex term registry maturity
- CoCore rule scaffolding (validators, guardrails)
- CoAgent orchestration in CI
- Steward+ChatGPTsession approval flow
- Hosting & mirroring for org/com deploys
