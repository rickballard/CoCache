# BPOE Notes (This Session)

- Minimize user burden; steward+ChatGPT gate as standard ritual.
- CoAgent normalizes AI flows; humans use native GitHub vectors with templates.
- Avoid relaxed branches beyond curated patterns; enforce archetypes.
- Capture everything as AdviceBombs and stubs; never lose raw ideas.
