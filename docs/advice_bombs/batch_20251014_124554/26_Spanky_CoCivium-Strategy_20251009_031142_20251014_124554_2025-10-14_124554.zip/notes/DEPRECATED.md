# DEPRECATED IDEAS & INITIATIVES
- Item: Relaxed unguarded main merges
  - Why dropped: Safety and provenance risk in multi‑actor setting
  - Replaced by: Steward+ChatGPTsession dual‑approval protocol
