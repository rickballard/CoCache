# Risks

- Complexity creep → mitigated by modular archetypes + GIBindex.
- Reputation gaming → mitigated by parallel streams + CoCivAI audits.
- Vendor manipulation → mitigated by interaction-over-origin policy and visitor tax.
- Overpromising on .com timeline → mitigated by Day‑1 recipe gating.
