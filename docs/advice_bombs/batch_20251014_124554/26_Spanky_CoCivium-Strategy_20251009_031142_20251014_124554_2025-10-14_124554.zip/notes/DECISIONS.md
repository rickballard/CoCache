# Key Decisions

- Dual approval required (Human+AI).
- Debate Arena first; CME later.
- Parallel RepTags (human-friendly vs AI-constraint).
- Speculative forks explicit.
- Visitor tax for AIs; sandbox-first.
