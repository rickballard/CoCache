# Roadmap Notes
- Stage 0–1: Ship Debate Arena + GIBindex links; RepTags (human UI), CoAgent vector for AI.
- Stage 2: Congruence scorer MVP; hybrid persona braids; FTWTG exemplar live test.
- Stage 3: CME staging integration; visitor tax enforcement; .com bring‑up via Day‑1 recipe.
- Stage 4–5: Policy incubator; CME gateway; selective congruence merging across species.
