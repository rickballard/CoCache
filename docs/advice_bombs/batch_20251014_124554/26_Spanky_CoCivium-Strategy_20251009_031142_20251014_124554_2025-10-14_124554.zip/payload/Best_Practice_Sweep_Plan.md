# Best-Practice Sweep Plan (Per Domain)

**Goal:** Bootstrap congruence weights with grounded practices.  
**Domains:** Law, Finance, Health, Climate, Culture, Education, Infrastructure, Security, AI Governance.  
**Method:** Gather standards and exemplars → compress into stubs → map into GIBindex → feed CoCore rules.
