# Contribution Vectors & CoAgent Normalization

**Vectors:** Issues (problem framing), Discussions (dialectic), PRs (proposals), Actions (automation).  
**Policy:** All valid for humans. **CoAgent** is default vector for AI/automation; ensures payload compliance, provenance, and routing.  
**Templates:** Issue/PR templates to structure human inputs.
