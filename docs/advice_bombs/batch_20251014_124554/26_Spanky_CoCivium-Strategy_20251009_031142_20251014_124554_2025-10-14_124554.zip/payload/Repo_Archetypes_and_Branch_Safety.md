# Repo Archetypes & Branch Safety

**Archetypes:** Core (CoCore, GIBindex, CoCache), Module (CoModules/experiments), Outreach (public comms), Archive (retired).  
**Branch rules:** `main` steward+ChatGPTsession only; `docs/*`, `module/*` protected; `experiment/*` auto-archived after TTL.  
**Merges:** Always Human+AI approvals.
