# INTENTIONS (Marking Unfinished)
- [x] Provide scripts: portfolio mirror, zip packer, GH Action.
- [x] Provide registrar/DNS hardening guidance.
- [x] Provide continuity kit structure.
- [ ] (Unfinished) Hardware shortlist for Tier‑1 LAN box.
- [ ] (Unfinished) 1‑page Registrar Hardening + Restore cheat sheets.
- [ ] (Unfinished) CoCacheGlobal interim + Scandinavia mirror deployment plan.
