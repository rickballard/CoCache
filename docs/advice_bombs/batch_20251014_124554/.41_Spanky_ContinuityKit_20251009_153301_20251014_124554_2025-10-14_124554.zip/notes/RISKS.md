# RISKS
- Delay in setting up mirrors increases window of single‑homing risk.
- Human error copying ZIPs (mitigate by spot‑checking restore).
- Misconfigured DNSSEC/locks (mitigate with quarterly checklist).
