# DECISIONS
- MVP path first: manual ZIPs to Synology; automate later.
- Keep Bitwarden as primary secret manager; paper only for recovery codes.
- Vendor-neutral continuity docs live in CoCache.
