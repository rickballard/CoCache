# DEPENDENCIES
- PowerShell 7, git, tar, gpg (optional for signatures).
- GitHub PAT (read repos), deploy SSH key for mirror host.
- Optional: rclone + B2/compatible object storage.
