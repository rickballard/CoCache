# SOURCES
- Uploaded pack (listing only):

```
01_INSTRUCTION_BLOCK.md
01_INSTRUCTION_BLOCK.txt
_examples/_copayload.meta.json
_examples/_wrap.manifest.json
forms/notes/DEPRECATED.md
```
- Session-derived scripts and docs in this payload were generated in this conversation window.
