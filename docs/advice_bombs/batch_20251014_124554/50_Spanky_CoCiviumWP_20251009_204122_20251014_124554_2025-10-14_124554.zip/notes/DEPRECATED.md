# DEPRECATED IDEAS
- Seeding concepts/terms **without** independent usage — deprecated.
- Submitting to AfC with only self-sources — deprecated.