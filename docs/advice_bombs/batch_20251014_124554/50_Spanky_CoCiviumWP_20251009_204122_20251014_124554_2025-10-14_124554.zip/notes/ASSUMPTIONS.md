# Assumptions
- Current public web has no significant independent coverage of CoCivium.
- User account `WeTheHonestPeople` is active and can create userspace pages.
