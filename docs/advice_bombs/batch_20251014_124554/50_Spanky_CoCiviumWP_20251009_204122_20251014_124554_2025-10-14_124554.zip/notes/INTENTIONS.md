# Intentions
- Build AfC-ready draft driven **only** by independent sources.
- Generate legitimate third-party coverage (pilot, academic paper, reputable media).

## Unfinished
- Independent sources (>=3 significant coverage) — **Unfinished**
- Case-study with measurable outcomes — **Unfinished**
- Wikidata item creation — **Unfinished**