# TL;DR
No independent coverage ⇒ keep CoCivium in userspace. Build third-party sources, then submit via AfC using the neutral draft skeleton.