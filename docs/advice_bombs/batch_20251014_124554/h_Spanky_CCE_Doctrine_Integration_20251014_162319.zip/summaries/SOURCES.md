# Sources & Influences
- ISO/IEC 42001, NIST AI RMF, ISO/IEC 23894
- NIST SSDF SP 800‑218, SLSA, in‑toto, cosign, SBOM (SPDX/CycloneDX)
- OWASP ASVS, OWASP LLM Top 10
- SRE (SLOs, error budgets), DORA metrics, OpenTelemetry, OpenFeature
