Param([string]$Path='templates/ThreadCard.yaml')
Write-Host "Validating $Path (placeholder)"; exit 0
