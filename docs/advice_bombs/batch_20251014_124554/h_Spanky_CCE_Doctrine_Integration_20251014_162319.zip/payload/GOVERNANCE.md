# GOVERNANCE (Two‑Key & Roles)

- Two‑key required for: Pivot, SDE thaw, policy relaxation, Extraordinary Evolution.
- Roles map to GitHub Teams in roles/two_key.yaml.
- Quarterly Congruence Axis Review: axes may be redefined; weights refit only within bounds.
