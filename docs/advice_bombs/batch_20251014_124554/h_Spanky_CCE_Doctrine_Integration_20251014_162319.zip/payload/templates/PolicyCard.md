# PolicyCard

Old→New params, shadow cohort stats, uplift with CI, safety floors check, rollback steps, signature.
