# Prompt contract example (placeholder)
