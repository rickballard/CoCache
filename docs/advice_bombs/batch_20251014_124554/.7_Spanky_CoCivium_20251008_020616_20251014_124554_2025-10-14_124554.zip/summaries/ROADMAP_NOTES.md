# Roadmap
1) Finalize CC_InlineCores.
2) Expand megascroll sections.
3) Governance for canonicity transitions.
