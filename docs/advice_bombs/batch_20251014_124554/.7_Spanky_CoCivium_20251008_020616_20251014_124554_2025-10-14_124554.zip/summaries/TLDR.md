# TL;DR
ZIP cycles run from Downloads with do.ps1, pick latest per base, auto-clean, sync BN, seed scaffolding, and produce CoWraps.
