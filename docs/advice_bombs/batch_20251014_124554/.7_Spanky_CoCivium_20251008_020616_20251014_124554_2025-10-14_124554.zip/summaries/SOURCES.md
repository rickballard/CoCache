# Sources
- PowerShell transcripts and git outputs in-session.
