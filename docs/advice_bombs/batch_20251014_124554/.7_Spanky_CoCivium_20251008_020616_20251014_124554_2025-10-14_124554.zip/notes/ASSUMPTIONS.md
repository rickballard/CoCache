# Assumptions
- Steward operates on `main` with small reversible commits.
