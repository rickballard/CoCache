# Intentions
- Seed pillars/BPOE/CC.
- Keep exact **Being Noname** phrasing.
- Use zip + do.ps1 cycles from Downloads; tidy automatically.

## Unfinished
- Finalize CC_InlineCores implementation + params.
- Expand megascroll sections into full charter.
