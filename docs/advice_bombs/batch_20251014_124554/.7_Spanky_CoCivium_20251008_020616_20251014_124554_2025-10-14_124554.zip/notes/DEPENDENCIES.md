# Dependencies
- Git, PowerShell 7+, optional GitHub Actions.
