# INTENTIONS
- Implement CoGene schema + sidecars for 1–2 anchor docs. (Unfinished)
- Add PR gates for Established/Canonical units. (Unfinished)
- Draft Governance Spec for voting/quorums. (Unfinished)
