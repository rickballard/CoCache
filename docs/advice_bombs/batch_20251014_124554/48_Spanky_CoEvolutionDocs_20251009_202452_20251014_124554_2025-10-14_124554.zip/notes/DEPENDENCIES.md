# DEPENDENCIES
- GitHub Actions for policy enforcement.
- Best Practices Registry for bp_alignment scoring.
- Identity/pseudonym system for decision provenance.
