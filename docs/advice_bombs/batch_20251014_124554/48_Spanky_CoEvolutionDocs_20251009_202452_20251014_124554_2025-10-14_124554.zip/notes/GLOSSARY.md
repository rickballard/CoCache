# GLOSSARY
- CoGenes: internal shorthand for stable content units.
- CLU: Content Lineage Unit (external label if needed).
- Canon Ladder: tier progression from Experimental to Canonical.
