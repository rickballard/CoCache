# DEPRECATED IDEAS & INITIATIVES
- Idea/Initiative: 
- Why dropped: 
- When dropped: 
- What it evolved into (if anything):
