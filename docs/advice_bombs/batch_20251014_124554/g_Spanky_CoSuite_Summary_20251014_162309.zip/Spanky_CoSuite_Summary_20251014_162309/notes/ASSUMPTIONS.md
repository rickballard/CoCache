# Assumptions
- External partners respond to bounded asks and evidence.
- Students prefer anonymity by default; consent governs publication.
