# DEPRECATED
- Any earlier CoAgent marks that lack three-halo geometry or lack dual-background exports.
