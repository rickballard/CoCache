# ASSUMPTIONS
- Dark mode common → white-stroke variants required.
- Favicons must remain ultra-simple to be recognizable.
- Consumers accept transparent PNGs.
