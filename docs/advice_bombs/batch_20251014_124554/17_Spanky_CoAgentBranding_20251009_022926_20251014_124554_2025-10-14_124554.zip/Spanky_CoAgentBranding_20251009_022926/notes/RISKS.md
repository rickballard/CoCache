# RISKS
- Overuse of rainbow reduces gravitas — restrict to docs/splash.
- Bolt animation can distract — keep subtle and episodic.
- Module divergence if geometry rules not documented.
