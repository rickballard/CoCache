# SOURCES
- Session-generated assets; CoCivium grayscale references provided by user earlier this year.
