# ROADMAP NOTES
- Optional: Generate SVG master set + CSS variables.
- Optional: Provide 'no-bolt' wide variant pack and animated bolt assets (Lottie/GIF).
- Optional: Module starter templates reusing geometry + unique glyphs.
