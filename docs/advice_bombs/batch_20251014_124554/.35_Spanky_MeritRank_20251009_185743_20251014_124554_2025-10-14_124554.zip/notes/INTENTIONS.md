# Intentions

## Completed
- Externalized scoring constants; added tests.
- Mapper smoke locally and in CI.
- CI fixes: pytest invocation, PYTHONPATH.
- Branding: "Digital Halo" in README + brand notes.

## Unfinished
- Expand mapper fixtures and domain hints. (Unfinished)
- Full chat transcript capture. (Unfinished)
- CI matrix expansion (OS/Python). (Unfinished)