# CoWrap Spec 1.0

This defines a standard for session capture.