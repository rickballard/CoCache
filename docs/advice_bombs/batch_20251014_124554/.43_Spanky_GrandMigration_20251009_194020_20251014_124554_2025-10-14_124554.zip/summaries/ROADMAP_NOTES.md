# Roadmap Notes
- Short-term: Productization wires OmniBar v2 KPIs; ops replaces SMTP placeholders.
- Medium-term: Sweep session runs multi-repo polish pass using templates.
