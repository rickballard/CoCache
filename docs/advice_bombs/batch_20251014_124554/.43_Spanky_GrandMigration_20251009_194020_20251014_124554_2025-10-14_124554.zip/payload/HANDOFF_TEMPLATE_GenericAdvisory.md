---
handoff: TEMPLATE
repo: TARGET_REPO
session: SOURCE_SESSION
actor: GPT-5 Thinking (ChatGPT)
created_local: 2025-10-09T19:40:20Z
ttl_days: 14
kind: advisory
version: v1
---

# Generic Advisory / Handoff

**TL;DR**
- <one-liner outcome>

**Actions taken**
- <bullet of concrete, reversible actions>

**Impacts**
- <user-visible / CI / release impacts>

**Safe revert**
- <exact steps to undo>

**Requested next actions (owner → session)**
- [ ] <checkboxed items with owners>

**Signals / KPIs (if applicable)**
- <what to watch; where to view>

**Attachments / Links**
- <paths in CoTemp / PRs / issues>
