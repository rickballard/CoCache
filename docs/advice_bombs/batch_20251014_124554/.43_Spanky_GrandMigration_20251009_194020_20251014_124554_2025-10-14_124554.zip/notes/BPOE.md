# BPOE Notes
- Centralization of IssueOps/BPOE material into CoCache.
- Slim shims in other repos; pointers instead of duplication.
