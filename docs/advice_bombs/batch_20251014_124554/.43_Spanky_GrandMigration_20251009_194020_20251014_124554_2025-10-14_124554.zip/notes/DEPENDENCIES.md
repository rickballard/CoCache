# Dependencies
- GitHub CLI (`gh`) for repo visibility/archive operations.
- Local PowerShell 7+ environment.
- Repo permissions sufficient to change visibility/archive.
