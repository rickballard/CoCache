# Assumptions
- Maintainer privileges available for CoCivium.
- CI statuses not required post-archive.
