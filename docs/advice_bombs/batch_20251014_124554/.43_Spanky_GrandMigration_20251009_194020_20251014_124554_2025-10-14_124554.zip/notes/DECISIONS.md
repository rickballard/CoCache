# Decisions
- Use `git-filter-repo` for history hygiene.
- Keep CoCivium as archived, reference-only.
- House canonical docs in CoCache.
