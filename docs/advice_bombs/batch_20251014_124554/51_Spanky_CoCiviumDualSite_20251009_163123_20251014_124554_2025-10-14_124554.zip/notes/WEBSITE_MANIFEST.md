# Website Manifest (High Level)
## CoCivium.com (AI)
- /index.jsonld — registry of datasets, APIs, schemas.
- /api/* — read‑only endpoints for civic corpora.
- /signals/* — adoption/compatibility flags.

## CoCivium.org (Human)
- /workflows/ — live drafts, A/B toggles.
- /learn/ — primers and diagrams.
- /about/ — governance & ethics.
