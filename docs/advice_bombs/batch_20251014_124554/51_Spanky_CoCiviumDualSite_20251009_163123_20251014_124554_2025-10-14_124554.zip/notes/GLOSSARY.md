# Glossary
- **CME**: Communal Mindshare Environment ("See Me").
- **Dual‑Face**: AI‑facing minimal site vs human‑facing rich site.
- **Source of Truth (SoT)**: Repos containing canonical assets.
