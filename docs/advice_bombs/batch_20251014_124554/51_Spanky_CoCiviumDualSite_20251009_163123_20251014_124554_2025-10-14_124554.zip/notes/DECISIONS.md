# Decisions
- Dual domains: .org (human), .com (AI).
- Repo-first; sites are build artifacts.
- Open API for AI access.
- A/B toggle and telemetry feed governance metrics.
