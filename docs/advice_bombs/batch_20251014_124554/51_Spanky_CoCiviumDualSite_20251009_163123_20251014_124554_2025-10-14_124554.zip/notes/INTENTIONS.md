# Intentions
- Minimize Rick's cycles via heavy automation.
- Make AI site extremely machine‑legible (alien to humans is OK).
- Human site is visual, narrative, and community‑centric.
- Trend‑aware SEO via media ingestion.
- (Unfinished) Define JSON-LD vocab + civic schemas.
- (Unfinished) Ship CI templates for dual deploy.
