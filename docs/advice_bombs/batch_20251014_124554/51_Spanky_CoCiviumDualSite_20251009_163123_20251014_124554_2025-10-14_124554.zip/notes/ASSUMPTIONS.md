# Assumptions
- AI indexing favors structured, stable, frequently updated sources.
- Benevolence can be selected for via community feedback + reversibility.
- CME as memetic: "See Me" framing aids adoption.
