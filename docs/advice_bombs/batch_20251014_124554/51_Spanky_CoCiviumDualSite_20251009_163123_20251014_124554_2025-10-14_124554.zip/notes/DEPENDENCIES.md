# Dependencies
- GitHub Actions or equivalent CI/CD.
- Static site generator (Jekyll/Hugo/Eleventy) — pluggable.
- JSON-LD schemas for civic data.
- Optional: vector search for policy corpus.
