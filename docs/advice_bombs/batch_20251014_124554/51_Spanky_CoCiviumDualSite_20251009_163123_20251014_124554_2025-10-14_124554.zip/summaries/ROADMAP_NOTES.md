# Roadmap Notes
- Phase 1: Wire CI from repo to dual sites; publish minimal schemas.
- Phase 2: Add A/B toggles, telemetry, and trend‑aware SEO.
- Phase 3: Open API and public datasets; partner integrations.
