# Roadmap Notes
- Add an automated guardrail to trigger Spanky/CoWrap once token/turn thresholds are crossed.
- Migrate canonical memory to repos; keep chats ephemeral.
- Add a health check script in CoAgent to detect client/browser drag and suggest a fresh tab.
