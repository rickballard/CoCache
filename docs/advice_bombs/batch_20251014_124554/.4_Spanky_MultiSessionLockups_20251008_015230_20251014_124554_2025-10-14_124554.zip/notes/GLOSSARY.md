# Glossary
- **Spanky**: Forced deep-capture archive zip with strict structure and counts.
- **AdviceBomb**: Self-contained zip of guidance and assets.
- **BPOE**: Best‑Practice Operating Environment.
