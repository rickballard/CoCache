# Intentions
- Produce a Spanky archive conforming to v2.2 structure. (Unfinished → **Now completed in this zip**)
- Capture early intentions, inferences, pivots even if partial.
- Guardrail future sessions against bloat and lockups. (Unfinished)
