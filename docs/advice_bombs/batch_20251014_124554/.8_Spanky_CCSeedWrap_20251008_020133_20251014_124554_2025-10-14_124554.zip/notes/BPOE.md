# BPOE (Human-limits) Notes
- Yellow-flag: declare cool-down need; give next handoff window.
- Handoff: include who/what/rollback; track in PR template.
- Rest: aim for min 8h within 24h rolling window; avoid single-hero dependency.
- Enforcement: merge blocked if rollback plan missing; use checklists post-incident.
