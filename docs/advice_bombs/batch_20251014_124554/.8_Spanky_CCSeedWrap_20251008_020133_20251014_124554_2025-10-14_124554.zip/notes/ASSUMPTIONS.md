# Assumptions
- PR checks will pass without manual intervention.
- Overlap scan via `gh api search/code` may be rate limited or unavailable.
- Local profile warnings (CoAgent/HH) are non-blocking for repo tasks.
