# Deprecated / superseded
- Early CCBootstrap packs v0.1.1–v0.1.4 due to quoting/param errors.
- Overlap script versions with unterminated strings; replaced by fixed variant.
