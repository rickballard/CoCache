# Intentions
- Reseed Cognocarta Consenti (CC) using CoCivium Principles. (Done)
- Start CC Megascroll with includes mechanism. (Done - seed created)
- Record human-limits guidance into BPOE wisdom on-repo. (Done - snippets + notes)
- Adopt naming scheme for canon/cc/highlighted/readables. (Done)
- Keep steps small, reversible, clearly graded for immutability. (Done)
- Package DO blocks as versioned zips runnable from Downloads. (Done - DoKit + examples)
- Ensure GitHub Pages serves `cocivium.org` with HTTPS enforced. (Unfinished: cert pending)
- Merge PR #417 to main after checks. (Unfinished)
