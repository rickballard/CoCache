# Risks
- Pages certificate issuance delay → HTTPS enforcement blocked temporarily.
- Stale local edits might block branch/switch operations if not stashed.
- Rate limits on GitHub search APIs affecting overlap report freshness.
