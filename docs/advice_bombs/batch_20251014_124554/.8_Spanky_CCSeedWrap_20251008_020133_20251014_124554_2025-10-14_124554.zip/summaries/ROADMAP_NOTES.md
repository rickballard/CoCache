# Roadmap
1) Merge PR #417 to main; wire CI to validate CC docs format.
2) Re-try HTTPS enforcement once certificate is ready; add 301 redirect from `www` → apex.
3) Extend megascroll to assemble additional CC components by include manifest.
4) Promote BPOE guidance into PR templates and CI checks.
5) Introduce version catalog for DO packages.
