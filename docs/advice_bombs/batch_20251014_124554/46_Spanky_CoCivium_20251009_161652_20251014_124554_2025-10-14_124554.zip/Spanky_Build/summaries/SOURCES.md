# SOURCES
- This session's advisories and V@ package.
- Attached user archive (manifest embedded in transcripts/session.md).
- Camunda comparison whitepaper (context, not embedded).
