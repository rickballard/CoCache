# WEBSITE MANIFEST (Seed)
- Academy index page.
- Orchestration Playbook page.
- Repo Index landing page with keystone links.
