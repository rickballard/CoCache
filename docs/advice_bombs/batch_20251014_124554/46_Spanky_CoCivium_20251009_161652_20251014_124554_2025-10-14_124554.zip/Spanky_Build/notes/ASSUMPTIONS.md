# ASSUMPTIONS
- Repos follow predictable folder patterns for docs/assets/scripts.
- Recipient session can run scanners and emit JSON/YAML.
