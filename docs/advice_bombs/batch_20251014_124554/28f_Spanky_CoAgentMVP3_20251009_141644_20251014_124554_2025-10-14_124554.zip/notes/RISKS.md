# Risks
- Stuck PS7 pane (mitigate with watchdog).
- Pair-file races if multiple orchestrators run.
- Line-ending churn without `.gitattributes` → keep UTF-8 / LF consistent.
