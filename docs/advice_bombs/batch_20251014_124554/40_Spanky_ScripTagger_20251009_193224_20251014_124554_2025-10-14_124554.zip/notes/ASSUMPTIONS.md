# Assumptions
- Most events are posted online with sufficient metadata for inference.
- Users prefer short, digestible outputs immediately after events.
- Neutral posture, transparency and auditability are vital to credibility.
