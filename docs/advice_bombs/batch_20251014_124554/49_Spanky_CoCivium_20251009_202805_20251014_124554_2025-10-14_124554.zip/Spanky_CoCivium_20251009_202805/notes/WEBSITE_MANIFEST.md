# Website Manifest
- Public docs link to CoCache insights for strategic state.
