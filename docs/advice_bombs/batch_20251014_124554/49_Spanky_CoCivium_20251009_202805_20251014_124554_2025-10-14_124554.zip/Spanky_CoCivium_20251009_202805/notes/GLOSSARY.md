# Glossary
- CoCache, context graph, advice bomb, Spanky.
