# ASSUMPTIONS

- Target repos exist at typical paths (e.g., ~/Documents/GitHub/CoAgent, .../Godspawn/HH).
- User can run local DO blocks / PowerShell scripts.
- External artifacts (CoWraps/Advicebombs) are retrievable from the user’s own storage if needed.