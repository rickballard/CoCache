# DEPRECATED

- Monolithic “huge” DO blocks that embed hundreds of lines of code directly.
  - Replaced by **zip-first** approach with short runners.