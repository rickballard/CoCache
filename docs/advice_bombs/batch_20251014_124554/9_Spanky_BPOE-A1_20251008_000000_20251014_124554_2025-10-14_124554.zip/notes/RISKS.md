# RISKS

- Missing third-party inputs (CoWraps, Advicebombs) degrade completeness.
- Browser CDN access for Mermaid viewer may be blocked in offline environments.
- Path differences on non-default repo locations.