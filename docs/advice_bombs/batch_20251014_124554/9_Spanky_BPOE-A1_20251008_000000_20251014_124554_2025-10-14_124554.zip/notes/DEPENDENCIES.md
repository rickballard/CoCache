# DEPENDENCIES

- PowerShell 7+ (tested 7.5.3).
- Git (optional, for commit/push steps in installers).
- Mermaid (loaded via CDN in viewer HTML; no local install required).
- Local file system permissions to write under repo roots and %USERPROFILE%\Downloads.