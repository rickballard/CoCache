# WEBSITE_MANIFEST

- CoAgent UI enhancements:
  - greeting.js (daily greeting + congruence link)
  - cocivium-overlay.js + assets/cocivium-overlay.css (cosmic overlay on congruence click)
- Demo/SAMPLE:
  - sample-watermark.css/js + demo-chip.css/js (Alt+S, ?sample=1, ?wm=TEXT, ?printwm=1)