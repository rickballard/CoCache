Publishable assets:
- CoAgency-Visual-Core.(svg|png)
- CoAgency-Visual-Orbits.(svg|png)
- CoAgency-Theory.md
- CoAgency-Implementation.md
- terms/CoAgency/*.md