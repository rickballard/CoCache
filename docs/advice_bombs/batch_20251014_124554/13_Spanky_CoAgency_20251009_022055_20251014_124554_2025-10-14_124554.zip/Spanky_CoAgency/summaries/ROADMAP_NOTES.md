MVP (next 90 days):
1) TrustFlag landing + proofs.
2) Congruence Engine MVP + Agency Statements.
3) Recognition White Paper + pilot CivicID handshake.
4) CoTreaty draft templates.