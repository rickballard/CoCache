Problems uses diagram; monthly JS dates.
