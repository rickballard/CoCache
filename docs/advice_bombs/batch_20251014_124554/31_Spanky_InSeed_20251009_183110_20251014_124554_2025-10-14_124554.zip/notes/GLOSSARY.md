CEOS=CEO/Steward; TOS‑AI=Transitions Office Steward.
