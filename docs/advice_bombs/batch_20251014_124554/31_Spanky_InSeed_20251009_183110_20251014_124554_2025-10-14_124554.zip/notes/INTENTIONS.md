# INTENTIONS
- Keep user's wording/order; improve SVG readability.
- Rolling dates via JS (22mo start, +30mo).
- Unfinished: light background, align boxes, route TOS‑AI arrow, PNG fallback.
