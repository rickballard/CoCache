# GLOSSARY

- **CoRef**: Concept-first sidecar indexing with edit-robust anchors.
- **BPOE**: Best Possible Operational Experience.
- **CoRender**: Asset render pipeline with CI fallback for SVG → PNG.
- **Spanky**: Session packaging format (this bundle).
- **CoWrap**: Session wrap note committed to repo.