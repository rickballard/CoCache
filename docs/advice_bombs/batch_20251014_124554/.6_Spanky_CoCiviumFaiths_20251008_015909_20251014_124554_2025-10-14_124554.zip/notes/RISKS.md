# RISKS

- CI render drift if font stacks differ.
- Topic branches can accumulate; mitigated by periodic audits and prune.
- Faiths content is sensitive; tone and cross-tradition alignment requires careful review.