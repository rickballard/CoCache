# DEPENDENCIES

- Public GitHub repos: CoCivium, Godspawn, CoAgent (read/clone).
- Git tooling and CI runners for render workflows.
- Optional: Inkscape on CI for PNG renders; local optional.