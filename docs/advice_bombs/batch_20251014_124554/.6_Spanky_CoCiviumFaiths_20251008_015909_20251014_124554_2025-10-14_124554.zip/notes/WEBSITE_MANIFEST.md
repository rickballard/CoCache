# WEBSITE_MANIFEST

- Site sections draw from `insights/Congruence/**` (CoCivium).
- CoRender CI ensures hero assets are rendered for web deployment.
- Sidecar `.coref.json` files power deep-linking and hover markers client-side.