# Intentions
- Ship grid, polish UX, add analytics and lead alerts.

## Unfinished
- Deploy CF Worker; wire URL; verify Company Revealed.
