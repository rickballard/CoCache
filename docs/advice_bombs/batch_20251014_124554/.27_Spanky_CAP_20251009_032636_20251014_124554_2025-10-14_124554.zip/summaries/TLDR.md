Grid + analytics + lead alerts shipped; CF Worker pending deploy.
