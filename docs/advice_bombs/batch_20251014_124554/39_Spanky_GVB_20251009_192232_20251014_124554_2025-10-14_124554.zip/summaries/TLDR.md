# TL;DR
CoCivium is the successor to commodity-masquerading community. Assets + scripts inside.
