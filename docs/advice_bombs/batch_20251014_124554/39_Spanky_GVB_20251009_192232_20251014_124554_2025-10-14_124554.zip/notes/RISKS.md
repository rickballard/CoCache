# Risks
- Third-party link rot; messaging misread; SEO duplication.
