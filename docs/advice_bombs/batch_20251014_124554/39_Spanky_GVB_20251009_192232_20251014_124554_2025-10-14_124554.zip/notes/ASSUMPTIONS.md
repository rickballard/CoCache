# Assumptions
- Substack won't autoplay; reader clicks soundtrack.
