# ASSUMPTIONS
- Audience prefers concise, inference-dense writing.
- Friday slot likely optimal (validate).
