# RISKS
- Bias perceptions → stronger sourcing.
- License risks → license gate.
- Fatigue → concise core + repo deep-links.
