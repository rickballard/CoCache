# DEPENDENCIES
- Substack + analytics; git + gh CLI.
- Licensed datasets; PS7 environment.
