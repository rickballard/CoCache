# INTENTIONS
- Weekly pipeline to map trending issues to CoCivium.
- Build truth brand; attract contributors.
- (Unfinished) Message Mapper microservice and engagement dashboard.
