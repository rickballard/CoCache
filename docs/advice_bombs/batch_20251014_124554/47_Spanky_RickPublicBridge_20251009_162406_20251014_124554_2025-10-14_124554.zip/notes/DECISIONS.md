# DECISIONS
- Freeze Baseline W1–W4.
- Single-variable experiments starting W5.
- Resonance Score to promote/retire patterns.
