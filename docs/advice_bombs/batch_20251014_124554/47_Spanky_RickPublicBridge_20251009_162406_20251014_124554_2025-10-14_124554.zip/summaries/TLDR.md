# TL;DR
- Weekly mapped articles; baseline first; methods always appended.
