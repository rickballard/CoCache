# Dependencies

- **Repos:** CoCore, CoCivium (policies/constitution), CoAgent, CoCache, GIBindex, CoRef, RickPublic, InSeed.com
- **People/Roles:** Rick (steward), future Academy editors, CoAgent maintainers.
- **Conventions:** CoRef IDs for models; GIBindex term tags; Advice-bomb packaging; BPOE playbooks.
