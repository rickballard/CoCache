# Decisions (This Session)

- Training is internal (Academy/EvoPath), not RickPublic.
- Docs-first curriculum; video derivative later.
- InSeed.com is applied/commercial mirror of Academy.
- Beaconing strategy: org manifest, per-repo manifests, topics, cross-links.
- CoAgent positioning: emphasize repo-native ops, BPOE, congruence, sovereignty.
