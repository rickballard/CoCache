﻿# Appendices

- **DO Header Spec v0.1 (stub)**
  - title, repo, requires, risk, est_runtime, brief, steps[], rollback, outputs
- **Risk Linter Rules (stub)**
  - writes/network/secrets/destructive detectors; blocklist/allowlist
- **MVP KPIs**
  - PR cadence, lead time, rollback count, error rate, user NPS
- **Glossary**
  - CoPingPong, Generics, Consent-first, BPOE, RepTag, etc.
