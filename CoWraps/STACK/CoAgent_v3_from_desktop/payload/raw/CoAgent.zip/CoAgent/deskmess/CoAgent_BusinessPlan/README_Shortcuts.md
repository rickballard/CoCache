﻿# CoAgent — Working Shortcuts
- [Planning_Readiness_Checklist.md](Planning_Readiness_Checklist.md)
- [Go_No-Go.md](Go_No-Go.md)
- [RFCs/](RFCs)
- [Tests/](Tests)
- [samples/](samples)
- [scripts/](scripts)
