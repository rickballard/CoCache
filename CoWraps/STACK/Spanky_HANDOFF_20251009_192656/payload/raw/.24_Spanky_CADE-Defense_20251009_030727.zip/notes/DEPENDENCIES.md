# DEPENDENCIES
- Mirror accounts and runners (GitLab/Codeberg).
- IPFS pinning provider.
- Secret management & CI token rotation.
- Telemetry sink + immutable log store.
