# RISKS
- Vendor/API lockouts — mitigated via CoAgent abstraction.
- GitHub DMCA/ToS actions — mitigated by mirrors/IPFS and legal review.
- Narrative brigading — mitigated by provenance + countersignal network.
