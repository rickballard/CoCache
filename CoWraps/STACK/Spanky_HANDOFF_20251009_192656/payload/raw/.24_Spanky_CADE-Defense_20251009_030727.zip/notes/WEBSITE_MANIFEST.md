# WEBSITE_MANIFEST
- Public Defense & Transparency page (signed releases, drills calendar, postmortems).
- Mirror locator page with canonical endpoints.
