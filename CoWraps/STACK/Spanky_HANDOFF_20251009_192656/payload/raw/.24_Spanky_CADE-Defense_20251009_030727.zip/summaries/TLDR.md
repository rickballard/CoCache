# TLDR
- Spanky CADE package built with drills, notes, and continuity safeguards.
