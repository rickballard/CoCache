# Malwarebytes Coexistence Notes
- Initially keep Web Protection OFF; test browser responsiveness.
- If re-enabled, exclude Defender paths from MBAM and vice versa.
- Do not install Browser Guard unless explicitly required.