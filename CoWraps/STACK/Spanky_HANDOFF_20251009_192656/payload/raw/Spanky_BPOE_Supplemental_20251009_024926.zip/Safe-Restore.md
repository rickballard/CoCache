# Safe Restore of Chrome Profile
Restore only these from backup:
- Bookmarks / Bookmarks.bak
- Custom Dictionary.txt

Avoid restoring:
- Preferences
- Cookies, Cache, History