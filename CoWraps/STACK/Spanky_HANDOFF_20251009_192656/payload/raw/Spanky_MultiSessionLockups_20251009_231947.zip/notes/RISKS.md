# Risks

- Post-build edits can break counts or checksums.
