# Decisions

- Minimal but complete archive per QA.
- Include QA_PROMPT.md if available; otherwise use placeholder.
