# Assumptions

- items == transcripts + payload + notes + summaries.
