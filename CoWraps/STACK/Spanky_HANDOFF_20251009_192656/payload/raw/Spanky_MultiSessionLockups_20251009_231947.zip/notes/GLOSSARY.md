# Glossary

- Spanky: structured deliverable zip.
- BPOE: Best‑Practice Operating Environment.
