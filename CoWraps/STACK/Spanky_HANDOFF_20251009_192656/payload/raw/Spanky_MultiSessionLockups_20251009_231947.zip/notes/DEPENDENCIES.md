# Dependencies

- Verify-SpankyDeliverables.ps1 / Verify-SpankyDeliverables-Plus.ps1 (optional).
