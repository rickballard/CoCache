# Intentions

- Provide a compliant Spanky deliverable for this session.
- Mark unfinished tasks as (Unfinished) where applicable.
