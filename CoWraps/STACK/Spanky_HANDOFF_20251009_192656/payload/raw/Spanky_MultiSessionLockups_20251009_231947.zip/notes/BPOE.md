# BPOE Notes — MultiSessionLockups

- Treat chats as volatile; repos/zips as durable memory.
- Establish session size guardrails and auto-archive.
