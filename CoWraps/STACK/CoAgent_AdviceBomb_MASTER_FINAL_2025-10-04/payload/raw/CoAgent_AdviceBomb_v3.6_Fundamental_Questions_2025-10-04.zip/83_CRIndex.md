
# 83 — Civium Readiness Index (CRI)

**Dimensions (0–5):** Governance, Reliability, Interop, Memory, Agency, Safety, Economics, Inclusivity.  
**Example targets:** CRI≥3.5 to exit limited release; ≥4.0 to expand enterprise.

- **Governance**: CSX adherence, Humangate SLA, audit completeness.  
- **Reliability**: replay determinism, MTTR, time-to-green.  
- **Interop**: MCP+/bridges coverage, import/export fidelity.  
- **Memory**: keystone coverage, forgottenness violations.  
- **Agency**: HITL coverage, sandbox fidelity.  
- **Safety**: incident rate, policy pack coverage.  
- **Economics**: $/success, safe-haven cost coverage.  
- **Inclusivity**: Youth/Adult equity, accessibility metrics.
