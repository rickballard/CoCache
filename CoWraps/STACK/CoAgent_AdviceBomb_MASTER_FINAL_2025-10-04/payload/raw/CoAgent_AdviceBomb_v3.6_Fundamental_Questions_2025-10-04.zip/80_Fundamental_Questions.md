
# 80 — Fundamental Questions (ask & re-ask)

## A. Mission & Values (don’t drift)
1) What **invariants** are non-negotiable for Civium (list ≤7), and where are they enforced in code/policy?
2) If AutoEvolve can change UX quickly, what *cannot* change without a HumanGate+Board vote?
3) What are the **kill-criteria** for pausing rollouts globally? Who can pull them?

## B. Governance & Legitimacy
4) Who grants CoAgent **mandate** to act on behalf of a person/team/org? How is consent represented cryptographically?
5) What’s the **appeal path** for a bad agent decision? Is there a right to be forgotten/rolled-back?
6) How are conflicts between **Youth/Adult streams** arbitrated across jurisdictions?

## C. Architecture & Sovereignty
7) What must run **on-device** vs **remote runner** vs **control plane**—and why?
8) Can we operate in **adversarial offline** mode for 7 days and still be useful?
9) What’s our recovery path if the control plane is unreachable or coerced?

## D. Epistemic Security
10) How do we defend against **prompt injection**, data poisoning of CoCacheGlobal, and template supply-chain attacks?
11) What is our **source trust** model? Are citations signed/verifiable, and can users inspect trust paths easily?
12) Can the system explain *why* it believed a thing (and why it changed its mind)?

## E. Agency Boundaries & Liability
13) Where exactly is the boundary between **assistive** and **autonomous** action? Who is liable for external effects?
14) Are **HITL** and **Shadow Sandbox** actually blocking bad outcomes, or just theater? Prove it with drills.

## F. Memory & Continuity (anti-entropy)
15) What artifacts are **keystones**? What are their pin/retention rules? What ratio of work is protected by DropGuard?
16) If token budgets force pruning, what **proofs of non-loss** do we require?

## G. Interop & Ecosystem
17) If a mega AI clones our features, what moat remains (governance, reproducibility, on-device, Civium templates)?
18) What are the minimal **open standards** we must influence or create (MCP+, provenance, policy packs)?
19) What’s our plan for **competitor facilitation** that still grows Civium (dual-home, importers, signed templates)?

## H. Economics & Incentives
20) What is the **value exchange** for template authors, mentors, and safe-haven operators? How do we prevent rent-seeking?
21) Can we sustain **global safe-havens** economically without compromising neutrality?

## I. Safety, Abuse, & Geopolitics
22) How do we handle lawful-but-awful use? What is the **policy escalation** tree across regions?
23) What happens under **authoritarian capture** pressures? What’s the minimum dataset we’d refuse to hand over?

## J. Measurement & Proof
24) Which **metrics** truly predict user trust and real-world outcomes (not vanity)?
25) Can third parties **replay** our results and verify our claims (reproducibility at the artifact level)?
