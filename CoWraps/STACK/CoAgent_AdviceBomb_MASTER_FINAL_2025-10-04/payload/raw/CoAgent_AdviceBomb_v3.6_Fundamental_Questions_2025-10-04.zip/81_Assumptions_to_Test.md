
# 81 — Assumptions to Test (change our minds quickly)

1) Users will accept belts/streams gating if promotions feel fair and fast.  
   **Falsify by:** A/B with panic-drop usage and satisfaction delta.

2) CSX can safely graduate surfaces from CE→AE using AES≥0.80.  
   **Falsify by:** Post-transfer incident rate vs control for 8 weeks.

3) Safe-haven Recall Cards are enough to get network effects without data centralization.  
   **Falsify by:** Measure retrieval precision/recall vs centralized baselines on public tasks.

4) Shadow Sandbox predicts production deltas at SFS≥0.90.  
   **Falsify by:** Weekly correlation vs production; track misses and root causes.

5) Users will adopt **Advice-Bombs** as a contribution method.  
   **Falsify by:** Contribution rate, merge rate, and time-to-merge vs Git-style PRs.
