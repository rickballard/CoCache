# CoAgent — v3.6 Fundamental Questions & Probes — 2025-10-04
**Purpose:** A concise set of hard questions, testable assumptions, and concrete probes to de-risk CoAgent and advance CoCivium.
CoPayload advisory; no side effects. Start with `80_Fundamental_Questions.md`.
