
# 82 — Probes & Experiments (do, don’t debate)

**Probe 1 — Civilizational Reliability Drill**  
Simulate regulator takedown of control plane for 72h. Measure offline usefulness, ledger integrity, and safe-haven continuity.

**Probe 2 — Authoritarian Capture Test**  
Legal demands scenario: attempt to coerce data exfiltration. Ensure policy packs + encryption + decentralization resist. Record refusal paths.

**Probe 3 — Collapse Test**  
No network for 1 week: can teams still complete core playbooks? Track task success %, time-to-green, and post-reconnect reconciliation.

**Probe 4 — Mega-AI Assimilation Test**  
A large platform wraps CoAgent via API to siphon value. Validate dual-home UX, signed artifacts, and Civium template economics keep value in-network.

**Probe 5 — Harmful Use Pivot**  
Red-team scripts try to abuse automations. Verify HITL, sandbox deltas, and outbound policy packs block impact; measure detection MTTR.

**Probe 6 — Memory Anti-Entropy**  
Aggressive pruning, then run golden tasks; prove outputs unchanged (loss tests). Time-to-restore via knowledge SnapBack.
