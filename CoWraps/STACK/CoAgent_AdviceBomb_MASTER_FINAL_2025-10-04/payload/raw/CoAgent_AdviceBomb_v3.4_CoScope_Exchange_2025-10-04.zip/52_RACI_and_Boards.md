
# 52 — RACI & Boards (CSX)

- **Codeowner (R/A)** — decision authority, veto power.
- **Product (R)** — prepares STR, user impact analysis, belts/streams plan.
- **Security/Privacy (C/A for high risk)** — policy coverage, data scope review.
- **SRE/Platform (R)** — drills, rollback, SFS infra.
- **Design (C)** — UX reversion targets, Diff Budget.
- **Audit bot (I)** — ensures STER signed & stored.

**Cadence:** fortnightly CSX standup + ad-hoc for urgent STRs.
