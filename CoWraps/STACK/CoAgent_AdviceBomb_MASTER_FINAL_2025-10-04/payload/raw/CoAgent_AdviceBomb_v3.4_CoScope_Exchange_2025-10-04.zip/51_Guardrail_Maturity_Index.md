
# 51 — Guardrail Maturity Index (GMI)

**Scale 0–4** by domain (examples: agent graphs, external effects, permissions, routing, UI variants).

- **0 Ad hoc**: manual checks, no tests, no dashboards.
- **1 Documented**: written SOPs, partial tests, basic logs.
- **2 Instrumented**: structured logs, unit/integration tests, dashboards, on-call.
- **3 Governed**: policies enforced, sandbox in CI, periodic drills, per-user rollback proven.
- **4 Certified**: third-party style audits, continuous simulation, automatic policy proofs, incident MTTR < 15m sustained, postmortems published.

**Promotion rule:** sustained ≥ level for **2 release cycles** + green drills → eligible for scope transfer consideration.
