
# CoAgent — v3.4 CoScope Exchange (CSX) — 2025-10-04
**Goal:** A formal, measurable process to **expand what qualifies for AutoEvolve** as tech/guardrails mature —
without sacrificing safety, auditability, or trust. This is a CoPayload advisory (no side effects).

**CoBrand (default):** **CoScope Exchange (CSX)**  
**Alternates:** CoEvolve Compact (CEC), AutoEvolve Transfer Protocol (ATP), Civium Scope Treaty (CST).

Open `50_CoScope_Exchange_Spec.md` first.
