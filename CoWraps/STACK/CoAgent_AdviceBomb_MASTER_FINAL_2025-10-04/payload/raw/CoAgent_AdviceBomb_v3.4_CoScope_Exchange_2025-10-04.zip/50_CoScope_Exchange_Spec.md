
# 50 — CoScope Exchange (CSX) — Scope Transfer Process

**Purpose:** Expand AutoEvolve scope responsibly. Move change classes from **CoEvolve** (human-gated) → **AutoEvolve**
only when measurable guardrail maturity and operational performance meet thresholds.

## Canonical terms (CoBrand)
- **CSX** — *CoScope Exchange* process and board.
- **STR** — *Scope Transfer Request* (proposal to move a change-surface or capability from CE→AE).
- **STER** — *Scope Transfer Evaluation Record* (the signed decision + evidence).
- **GMI** — *Guardrail Maturity Index* (0–4).
- **SFS** — *Shadow Sandbox Fidelity Score* (0.0–1.0).
- **PCI** — *Policy Coverage Index* (0–100% of required policies enforced/tested).
- **AES** — *AutoEvolve Eligibility Score* (0–100 composite).

## Lifecycle
1) **Propose (STR)** → authored by Product/Platform with change-class, scope, belts/streams affected.
2) **Measure** → collect GMI/SFS/PCI/bench & incident stats for the last N weeks.
3) **Score** → compute AES (weighted composite). 
4) **Review (CSX Board)** → Codeowner + Product + Sec/Privacy + SRE. Quorum required.
5) **Pilot** → move to AE in **dogfood/staff rings** with abort thresholds; per-user rollback enabled.
6) **Ratify** → publish STER; update BPOE policies/flag metadata; schedule drills.
7) **Revoke (if needed)** → automatic rollback + STER addendum if thresholds are violated.

## Default thresholds (raise, don’t lower, over time)
- **GMI ≥ 3.0** for the domain (e.g., agent graphs, external effects).
- **SFS ≥ 0.90** on representative tasks (sandbox predicts real deltas).
- **PCI ≥ 95%** policies enforced & tested for the scope.
- **Incidents**: 0 P0/P1 related to this surface in last **8 weeks**.
- **Replay** determinism ≥ **97%** on sampled runs.
- **User reversion** (UX) < **8%** post-change across belts/streams.
- **Cost per success** non-inferior (±0%) or better.

## What can be transferred first
- **Routing/limits** (timeouts, retries, price/latency trade-offs).
- **Non-destructive UI variants** (layout density, palettes, help density).
- **Playbook parameterization** within policy budgets.

## What remains CE until further maturity
- **Permissions/data-scope changes**, **external effects**, **schema/security/privacy**. These can graduate later if GMI/SFS/PCI materially exceed thresholds for sustained periods and drills are green.

## Evidence required in the STER
- Current/target risk class, thresholds & results, drills summary, abort criteria, flags impacted, belts/streams impact analysis, fallback plan.
