
# 54 — CSX Protocol Flows

## STR (Scope Transfer Request)
- Proposed scope (from CE→AE), change class(es), flags affected, belts/streams affected.
- Evidence bundle references: benchmarks, SFS runs, drills, incident history.

## Review
- Triage (auto checks): thresholds met? flags tagged? abort thresholds configured?
- CSX Board meeting (30 mins): approve/deny/defer with actions.

## Pilot
- Enable AE in **dogfood** (then **staff**) with per-user rollback.
- Monitor gates: error, reversion, cost, MTTR.
- If green 7 days → expand to 1% external; if red → auto rollback & STER addendum.

## Ratify
- Publish STER to `/bpoe/audits/approvals/` and update `/bpoe/autoevolve.policy.yaml`.
