
# run.ps1 — CoScope Exchange (no side effects)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Write-Host "CoScope Exchange v3.4 — file map" -ForegroundColor Cyan
Get-ChildItem $here -Recurse | Select-Object FullName,Length | Format-Table -AutoSize
'status: ok — csx advisory generated' | Out-File -FilePath (Join-Path $here 'out.txt') -Encoding utf8 -Force
