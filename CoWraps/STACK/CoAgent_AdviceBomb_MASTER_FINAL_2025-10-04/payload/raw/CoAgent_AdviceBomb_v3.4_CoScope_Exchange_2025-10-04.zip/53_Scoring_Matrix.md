
# 53 — AutoEvolve Eligibility Score (AES) — Scoring Matrix

AES = 0.30·GMI_norm + 0.20·SFS + 0.20·PCI_norm + 0.10·Replay_norm + 0.10·Incidents_norm + 0.10·Reversion_norm

- **GMI_norm**: GMI/4.0
- **PCI_norm**: PCI/100
- **Replay_norm**: min(Replay%, 100)/100
- **Incidents_norm**: 1 - min(incident_points,1) where 1=any P0/P1 in 8w, 0 otherwise
- **Reversion_norm**: 1 - min(reversion/0.08, 1)

**Default AES pass bar:** **≥ 0.80** to attempt AE in canary rings.
