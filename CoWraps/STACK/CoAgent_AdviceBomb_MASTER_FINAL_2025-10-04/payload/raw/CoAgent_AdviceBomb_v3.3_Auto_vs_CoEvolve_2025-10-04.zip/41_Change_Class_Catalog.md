A UI micro → AE; B UI structural → AE; C Templates bounded → AE; D Routing/limits → AE; E Agent graph → CE; F Permissions/data → CE; G External effects → CE; H Security/privacy → CE; I Schema → CE.
