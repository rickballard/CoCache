
# 63 — BPOE Updates (Repo)
Add under `/bpoe/`:
- `coevo.ledger/` (jsonl of ledger records, hashed)
- `weeding.plans/` (signed plans)
- `recall.cards/` (versioned cards)
- `watchers/` (queries/jobs)
- `dashboards/` (coverage, forgottenness, golden task stability)
