
# 62 — Continuity Watchers
- **Keystone Coverage Watcher**: scans recall sets; alerts if keystone cards are missing.
- **Forgottenness Monitor**: surfaces artifacts whose FS exceeds threshold; opens Advice‑Bombs to refresh/teach.
- **Drift Detector**: compares outputs on golden tasks pre/post pruning; blocks merges that change outcomes.
- **Lineage Linter**: prevents merges without parent/child links and redirects.
