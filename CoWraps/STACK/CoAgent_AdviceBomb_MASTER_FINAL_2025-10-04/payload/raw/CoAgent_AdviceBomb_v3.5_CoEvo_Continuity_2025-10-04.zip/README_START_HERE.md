
# CoAgent — v3.5 CoEvo Continuity & Anti‑Entropy — 2025-10-04
**Goal:** Make CoEvolution **cumulative**, not forgetful. Prevent useful work from being thinned out or dropped by
“self‑cleaning” AI behaviors or token‑budget shortcuts. Provide policies, mechanisms, and metrics to preserve
institutional memory while still de‑duplicating noise.

Open `60_CoEvo_Continuity_Spec.md` first. CoPayload advisory; no side effects.
