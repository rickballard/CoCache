
# 61 — Token Budget Playbook (Don’t lose the plot)

## Canonical vs Working Memory
- **Canonical store**: source of truth (ledger). Never pruned by token limits.
- **Working memory**: context windows, caches, and session memory. Always reconstructed from canonical via recall cards.

## Layering
1) **Keystone recall layer** — always present (budget reserved).  
2) **Task‑intent layer** — selects relevant recall cards via structured queries (not just vectors).  
3) **Freshness layer** — recent changes and live signals.  
4) **Explainer layer** (on demand) — expandable details for low‑confidence steps.

## Techniques
- **Summarize‑with‑provenance**: every recall card stores canonical IDs and citation spans.  
- **ID‑first prompts**: refer to stable IDs, not only free text.  
- **Context budgeter**: allocates tokens per layer; never steals from keystone budget.  
- **Loss tests**: run micro‑benches after pruning to ensure outputs are unchanged on golden tasks.

## Tooling
- **Recall index** (hybrid keyword+vector) with **GIBindex** hints.  
- **Card generator** with regression checks.  
- **Coverage dashboards**: keystone inclusion, golden task stability.
