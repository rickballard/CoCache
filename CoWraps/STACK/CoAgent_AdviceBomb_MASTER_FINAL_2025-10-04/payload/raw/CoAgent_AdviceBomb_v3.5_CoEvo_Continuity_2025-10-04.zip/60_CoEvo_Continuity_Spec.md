
# 60 — CoEvo Continuity & Anti‑Entropy

## Principles (non‑negotiable)
1) **Cumulative, not forgetful.** CoEvolution must never be a “cleaning sprint” that erases value.
2) **Weed noise, not signal.** De‑duplication is allowed only with **proof of non‑loss**.
3) **Canonical before Context.** Long‑term memory lives in **canonical artifacts**; prompts use **recall cards** to fit token budgets.
4) **Pin with purpose.** Anything “keystone” is **pinned** with an expiry and review cycle; never deleted implicitly.
5) **Lineage or it didn’t happen.** Every artifact has lineage (parents/children), hashes, and usage telemetry.

## Mechanisms
- **CoEvo Ledger** (durable store): registry of artifacts (IDs, hashes), lineage graph, status (active/merged/deprecated), retention class, pins, last‑accessed, “forgottenness score” (see below).
- **DropGuard**: rejects deletions/merges without a **Weeding Plan** that includes proof‑of‑non‑loss and reviewer signoff.
- **Recall Cards**: distilled summaries (with citations and stable IDs) that stand in for the full artifact in LLM context.
- **Active Set Selection**: runtime chooses a **budgeted set** of recall cards by task intent, but **guarantees** inclusion of keystone pins.
- **Continuity Watchers**: jobs that compute forgottenness score, detect drift (declining references to keystones), and open Advice‑Bombs to restore coverage.
- **SnapBack for Knowledge**: not just UI; enable **knowledge SnapBack** to restore prior state of the ledger and recall sets.

## Retention Classes
- **Keystone** (must keep), **Critical**, **Important**, **Ephemeral**.  
  Each has min retention, review cadence, and pin policy.

## Forgottenness Score (FS)
FS = w1·(unreferenced_days) + w2·(decay_of_downstream_usage) − w3·(recent_reads) − w4·(pin_weight).  
Thresholds trigger **refresh** (rewrite recall card) or **review** (human eyes).

## Anti‑Entropy Weeding
- Allowed: merging near‑dupes into a canonical record **with** a coverage test suite and cross‑refs preserved.
- Forbidden: deleting unique artifacts without lineage links and coverage tests.

## KPIs
- Coverage of keystones in recall sets (%),  
- Recall precision/recall on benchmark tasks,  
- % merges with coverage proofs,  
- Forgottenness violations caught,  
- Time‑to‑restore (knowledge SnapBack).

## Belt/Stream behaviors
- Youth: longer pins, friendlier recall cards, stricter DropGuard.  
- Adult: tighter budgets but keystone guarantees unchanged.
