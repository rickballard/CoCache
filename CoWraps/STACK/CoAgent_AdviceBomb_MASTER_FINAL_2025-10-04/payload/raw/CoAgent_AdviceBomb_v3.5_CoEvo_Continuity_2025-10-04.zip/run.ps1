
# run.ps1 — v3.5 CoEvo Continuity (no side effects)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Write-Host "CoAgent v3.5 — CoEvo Continuity & Anti-Entropy" -ForegroundColor Cyan
Get-ChildItem $here -Recurse | Select-Object FullName,Length | Format-Table -AutoSize
'status: ok — v3.5 advisory generated' | Out-File -FilePath (Join-Path $here 'out.txt') -Encoding utf8 -Force
