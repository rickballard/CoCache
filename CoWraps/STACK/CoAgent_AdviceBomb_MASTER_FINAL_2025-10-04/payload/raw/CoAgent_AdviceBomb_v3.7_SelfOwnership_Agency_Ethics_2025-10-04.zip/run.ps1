
# run.ps1 — v3.7 (no side effects)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Write-Host "CoAgent v3.7 — Self-Ownership, Agency, Ethics" -ForegroundColor Cyan
Get-ChildItem $here -Recurse | Select-Object FullName,Length | Format-Table -AutoSize
'status: ok — v3.7 advisory generated' | Out-File -FilePath (Join-Path $here 'out.txt') -Encoding utf8 -Force
