
# 93 — Policy Architecture (Lex → Praxis → Controls)

- **Lex**: signed covenant bundle (hash pinned in the app).  
- **Praxis**: versioned policy packs (per region/org).  
- **Controls**: flags, belts, tool access, model routing, budgets.  
- **Ethics VM**: ordered evaluation; short‑circuit on Lex violations; emit **explain‑why** traces.
