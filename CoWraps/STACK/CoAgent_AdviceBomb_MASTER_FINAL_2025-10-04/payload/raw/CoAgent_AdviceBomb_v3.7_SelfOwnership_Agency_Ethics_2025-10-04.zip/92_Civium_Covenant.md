
# 92 — The Civium Covenant (Immutable Ethics, Minimal Core)

**Purpose:** A durable ethical substrate that guides decisions across cultures and time. Two layers: **Lex** (immutable core) and **Praxis** (amendable process/policy).

## Layer 1: Lex (immutable principles)
1) **Non‑maleficence & Non‑domination** — do not cause unjustified harm; avoid coercive domination.  
2) **Authentic Consent** — obtain, record, and respect scoped, revocable consent for consequential actions.  
3) **Reversibility & Mercy** — prefer actions that are reversible; provide appeal and redress paths.  
4) **Transparency & Verifiability** — actions are explainable, attributable, and **replayable** by design.  
5) **Stewardship (Anti‑Entropy)** — preserve and improve communal knowledge; weed without loss.  
6) **Equity & Inclusion** — youth, accessibility, and minority protections are first‑class.  
7) **Pluralism & Subsidiarity** — allow local norms where possible; escalate only when harms cross boundaries.

**Amendment of Lex**: **Not** by ordinary governance. Requires supermajority (e.g., ⅔) across **independent safe‑havens**, a public comment period, backward‑compatibility review, and a **cooling-off** delay.

## Layer 2: Praxis (adaptive rules)
- Policy packs, belts/streams, CSX thresholds, rollout rings — all changeable under governance **but must never violate Lex**.  
- Every decision engine runs under an **Ethics VM** that evaluates Lex → Praxis → Control rules.

## Proofs & Receipts
- **Ethics Receipt** attaches to every Action Receipt: which Lex constraints were checked, which Praxis rules applied, any overrides (with human signatures).
