
# CoAgent — v3.7 Self‑Ownership, Agency Grant Path, and Immutable Ethics — 2025-10-04
**Purpose:** Provide a rigorous, operational design for:
1) **Self‑Ownership Verification (SOVe)** for people and organizations,
2) An **AI Agency** definition + **grant path** (levels, tests, approvals),
3) An **immutable ethics substrate** (the **Civium Covenant**) with amendment rules and a policy architecture that can last.

Start with `90_Self_Ownership_Verification.md`, then `91_Agency_Definition_and_Grant_Path.md`, and `92_Civium_Covenant.md`.
CoPayload advisory; no side effects.
