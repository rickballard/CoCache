
# 90 — Self‑Ownership Verification (SOVe)

**Goal:** Prove that an agent instance acts for a specific person/org and that consent is current — without centralizing identity or leaking secrets.

## CoID (Co‑Sovereign ID)
- **Local root keys**: device keystore (TPM/Secure Enclave) bound keys.
- **DID profile**: a decentralized identifier document published to **safe‑haven** (optional) with **rotating public keys** and capabilities (scoped).
- **Verifiable Credentials (VCs)**: optional attestations (role, org membership, age band) issued by trusted parties; stored locally and presented **selectively**.

## SOVe = 3 Pillars
1) **Cryptographic control**: user can sign challenges (WebAuthn/OS keystore).  
2) **Continuity of consent**: **Consent Receipts** (time‑bounded, scoped) are presented with actions and logged.  
3) **Continuity of identity**: **liveness** (risk‑based), usage biometrics (local), and device posture attestations (non‑exfiltrating).

## Guardianship & recovery
- **Youth**: guardian VCs; promotions beyond Belt 1 require guardian signature.  
- **Recovery**: social recovery (threshold signatures) and **break‑glass** keys with cooling‑off periods.

## Action receipts
Every consequential action ships a signed **Action Receipt**: who (CoID), on whose behalf (VC), what scope, when, why (policy), and how to **appeal/rollback**.
