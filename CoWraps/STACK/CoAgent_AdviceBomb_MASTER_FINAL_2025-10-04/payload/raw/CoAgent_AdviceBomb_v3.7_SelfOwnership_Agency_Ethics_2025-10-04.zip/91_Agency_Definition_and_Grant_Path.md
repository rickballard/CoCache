
# 91 — AI Agency: Definition & Grant Path

**Agency (operational)**: the capacity of an autonomous system to **initiate and complete** bounded actions that **cause persistent change** in the world.

## Levels (A0–A5)
- **A0 Assistive**: reads/summarizes; no side effects.  
- **A1 Tool‑using**: acts locally (files/shell/browser) with **HITL** on writes.  
- **A2 Transactional**: limited external writes via **Shadow Sandbox** preview + HITL.  
- **A3 Orchestrating**: multi‑agent graphs; budgets; auto‑retry; HITL on destructive steps.  
- **A4 Delegated**: recurring jobs under **agency contracts** (scopes/limits/SLAs); emergency stop.  
- **A5 Co‑Sovereign** (rare): acts as a **principal** within narrow domains; requires **Board‑level** approval and public attestation.

## Grant Path (per level)
1) **Competence proofs**: benchmark tasks (success%, time‑to‑green), replay determinism, and **sandbox fidelity**.  
2) **Policy packs**: tools, models, data scopes, outbound rules (regionally aware).  
3) **Risk review**: threat modeling (prompt injection, supply‑chain, exfiltration).  
4) **Humangate**: approvers sign an **Agency Contract** (capabilities, budgets, expiry, audit endpoints).  
5) **Instrumentation**: action receipts, audit ledger, kill switch; **drills** (quarterly).

**Downgrade path**: incidents, drift, or expired proofs auto‑revoke or drop to prior level.
