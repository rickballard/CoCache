
# 94 — Attestations & Verifiable Credentials (VCs)

- **DID methods**: `did:key` locally; `did:web` or safe‑haven anchored for public roles.  
- **VC types**: age‑band, org role, guardian link, residency, competency badges (belts), agency approvals.  
- **Selective disclosure**: present only what’s needed (ZK-friendly where possible).  
- **Revocation**: short‑lived VCs + status lists; agency contracts carry expiry.
