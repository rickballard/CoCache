
# 95 — Ethics VM (EVM*) — Runtime Guard

**Inputs**: action plan, context, consents, policy pack, Lex bundle.  
**Outputs**: allow/deny/defer, required HITL, receipts (ethics + action), explanations.

**Flow**: Lex checks → Praxis checks → Controls → Risk gates (sandbox/HITL) → Execute → Receipts + Logs.  
**Determinism**: decisions must be reproducible from artifacts + logs.  
**Audit**: third parties can re-run Ethics VM with the same inputs and verify outputs.
