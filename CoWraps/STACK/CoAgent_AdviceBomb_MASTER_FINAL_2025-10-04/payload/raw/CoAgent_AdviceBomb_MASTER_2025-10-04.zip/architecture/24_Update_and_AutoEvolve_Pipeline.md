
# Update & AutoEvolve

- Single signed build; **flags+rings+rollback** manage evolution.
- Auto-evolve allowed surfaces: microcopy/tours/layout variants/playbook params/routing.
- CoEvolve (Humangated) for permissions/data scope/agent graph/core policy/schema.
- CSX (CoScope Exchange) governs expansion of AE over time.
