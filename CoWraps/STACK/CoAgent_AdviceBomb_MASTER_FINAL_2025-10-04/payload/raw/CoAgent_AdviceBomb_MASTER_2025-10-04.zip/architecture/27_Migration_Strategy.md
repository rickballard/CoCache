
# Migration & Packaging

- **One artifact** for desktop/PWA; first-run writes a **launch profile** (Youth/Adult, belt, ring).
- Add **native helper** for OS integrations (file/shell/clipboard, computer-use).
- Optional **web facade** for light usage; prompts deep-link into client for privileged operations.
