
# Cost Model

- Local compute reduces API egress; remote runners used for bursty or heavy tasks only.
- Safe-haven caches dedupe Recall Cards & templates globally; bandwidth-efficient content addressing.
- Telemetry is opt-in; aggregate-only by default; enterprise plans fund safe-haven operations.
