
# Safe-Haven Servers (Global)

- Jurisdictional diversity; transparent hosting; public SLA/attestation.
- Accept only signed artifacts (CoPayloads, Recall Cards). Validate signature+policy before publish.
- Provide **CDN-like** access with ETag/versioning and audit pages per artifact.
