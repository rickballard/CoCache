
# Security Model

- **E2EE profiles**; local secrets vault using OS keystore.
- **Policy-first** tool access (allow/deny by stream/belt/workspace).
- **Shadow Sandbox** for dangerous actions; **HITL** for external writes.
- Ed25519 signatures on artifacts; append-only audit ledger; exportable proofs.
