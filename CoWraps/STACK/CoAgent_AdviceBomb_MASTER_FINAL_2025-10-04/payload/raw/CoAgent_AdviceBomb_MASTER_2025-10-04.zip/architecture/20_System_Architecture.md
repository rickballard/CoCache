
# CoAgent System Architecture — 2025-10-04

## Decision
**Hybrid-controlled client**: thick local app (or PWA with native helpers) + cloud control plane + optional remote runners.
- Local = Panels (Ping/Pong/Pair/Browser), MCP tool router, policy enforcer, secrets vault, CoPayload packager, observability sidecar.
- Cloud = flags/rings/CSX registry, identity/licensing, telemetry aggregator, template registry, org policy distributions.
- Compute = local runner + **ephemeral remote runners** for heavy or risky jobs (Shadow Sandbox, browser automation).
- Data = **CoCacheLocal** (device), **CoCacheTeam** (org realm), **CoCacheGlobal** (safe-haven distributed overlay).
- Trust = ed25519 signing, append-only audit ledger, STER/STR for scope transfers, per-user rollback snapshots.

## Why not web-only?
- Needs local tools (files/shell/IDE, computer-use), offline, and strict data residency. Web-only limits capability, increases egress risk.
- Hybrid gives **rapid evolution** via flags/rings while preserving **offline & privacy** and enabling **per-user rollback**.

## Why not client-only?
- You'd lose centralized control, CSX governance, coordinated rollouts, and global caching benefits.
