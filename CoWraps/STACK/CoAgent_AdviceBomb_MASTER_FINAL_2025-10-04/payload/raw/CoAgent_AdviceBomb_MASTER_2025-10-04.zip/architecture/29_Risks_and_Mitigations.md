
# Risks & Mitigations

- **Fragmentation**: solved by single signed build + flags.
- **Data leaks**: policy engine, vault, E2EE, sandbox + HITL.
- **Cache poisoning**: signatures + allowlist publishers + attestation.
- **Jurisdictional pressure**: multi-region safe havens + transparency reports.
