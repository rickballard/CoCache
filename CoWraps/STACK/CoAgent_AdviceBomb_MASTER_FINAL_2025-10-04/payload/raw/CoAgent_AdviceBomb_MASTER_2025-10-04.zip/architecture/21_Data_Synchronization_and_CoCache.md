
# CoCache: Local, Team, Global

- **CoCacheLocal**: content-addressed store + recall index (SQLite/Parquet); E2EE-backed; opt-in sync.
- **CoCacheTeam**: org-scoped realm; CRDT event log; policy-filtered replication.
- **CoCacheGlobal**: federated safe-haven servers; stores signed **Recall Cards** and public templates/artifacts; region-sharded; privacy by design.

**Sync model**
- Content-addressed chunks; CRDT for metadata; **policy engine** determines what may leave the device.
- **Recall Cards** (summaries with citations) travel; raw secrets do not.
