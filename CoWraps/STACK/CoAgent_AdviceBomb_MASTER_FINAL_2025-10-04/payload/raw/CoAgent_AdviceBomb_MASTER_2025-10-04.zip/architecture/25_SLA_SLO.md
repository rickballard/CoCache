
# SLOs & Gates

- Time-to-green < 60s (self-heal/retry); MTTR < 15m for P0.
- UX reversion < 10%; replay determinism ≥ 95% in MVP; cost per success non-inferior post-change.
- Global cache availability ≥ 99.9%; safe-haven publish TTL < 5m.
