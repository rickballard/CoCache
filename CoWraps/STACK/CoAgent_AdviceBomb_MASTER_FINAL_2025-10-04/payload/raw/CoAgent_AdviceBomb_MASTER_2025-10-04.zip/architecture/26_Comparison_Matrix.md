
# Client vs Web vs Hybrid — Comparison

| Criterion | Web-only Service | Client-only | **Hybrid-controlled client (Chosen)** |
|---|---|---|---|
| Local tool access (files/shell/IDE/computer-use) | Weak | Strong | **Strong** |
| Offline | Weak | Strong | **Strong** |
| Security & residency | Centralized risk | Local by default | **Local by default + policy-controlled sync** |
| Rapid evolution (flags/rings) | Strong | Medium | **Strong** |
| Per-user rollback | Hard | Local only | **Built-in** |
| Governance (CSX, Humangate) | Strong | Weak | **Strong (control plane)** |
| Global knowledge network | Easy | Hard | **Easy via safe-haven overlay** |
