# CoAxa Checklist

- [x] Defined Subdomains
- [ ] Drafted Primers