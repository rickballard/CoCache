# Systemic Rigidity

TODO: Populate this subdomain scaffold with relevant CoTheory content.
