# Capture Resistance

TODO: Populate this subdomain scaffold with relevant CoTheory content.
