# CoWrap Package

This package bundles the summary of our InSeed polish session.  
Use it as a handoff to bootstrap the *next session*.

Files included:
- SUMMARY.md → What we did, learned, planned, scope forward.
- README.md → This file.

---
