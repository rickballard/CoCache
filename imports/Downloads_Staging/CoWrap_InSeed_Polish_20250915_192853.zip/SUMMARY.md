# CoWrap: InSeed One-Pager Polish

## What We Did
- Generated and refined InSeed hero imagery (earbuds + vapor with AI terms).
- Created scripts to automate site content updates (canonical bio, ODT-based content, advice-pass, rebuild-onepager).
- Opened PRs on relevant repos:
  - InSeed: `site/content-from-odt`, `site/rebuild-onepager`, `site/canonical-bio`
  - GroupBuild-website: `site/advice-pass-1`, `site/canonical-bio`

## Learnings
- Em-dash avoidance matters for human-authentic copy (signal of AI text).
- Duplication of CTAs/sections and “Draft” ribbons must be systematically stripped.
- Hero image can replace top-quote block; ODT copy should drive site content verbatim.
- Large sessions get bloated: CoWrap resets are critical for responsiveness.

## Not Captured on Repo
- BPOE wisdom: CoWrap resets as standard hygiene, session bloat detection insufficient, merge automation scripts need hardening for dirty-tree handling.
- CoAgent roadmap note: potential VS Code (and other editor) integration for smoother dev workflows, but weigh against typical civic user base (non-devs).

## Plans
- Polish InSeed site with new hero, ODT copy (single-page scroll nav, deduped CTAs).
- Ensure GroupBuild site surfaces advice/principles cleanly, footer anchored.
- Tighten Merge-And-Deploy script (guard null-valued status calls).

## Scope for Next Session
- Apply hero image to InSeed index.html (replace quote block).
- Commit final polished one-pager with ODT copy, no duplication.
- Verify live deploys (inseed.com, groupbuild.org).
- Review GoDaddy hosting costs (GroupBuild placeholder) vs GitHub Pages.
- Discuss CoAgent integrations (VS Code, JetBrains, Jupyter) on roadmap.

---
