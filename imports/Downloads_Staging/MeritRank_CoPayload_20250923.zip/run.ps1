param(
  [string]$RepoRoot = (Join-Path $PSScriptRoot 'MeritRank_unpacked_20250923-200127')
)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
Write-Host "Running MeritRank CoPayload smoke..." -ForegroundColor Cyan
$smoke = Join-Path $RepoRoot 'scripts\CoEve_Smoke.ps1'
if (-not (Test-Path $smoke)) {
  throw "Smoke script not found at $smoke"
}
pwsh -File $smoke -RepoRoot $RepoRoot
Write-Host "Smoke completed." -ForegroundColor Green