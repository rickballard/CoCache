# MeritRank CoPayload Report

## Inventory of file types

### .md (6 files)
- report/SESSION_SUMMARY.md
- report/LESSONS_BPOE.md
- snippets/README_QUICK_SMOKE_BLOCK.md
- snippets/README_BADGES.md
- snippets/brand/BRAND.md
- snippets/policy/TRUST_SAFETY.md

### .ps1 (8 files)
- scripts/CoEve_SyncMain.ps1
- scripts/CoEve_Smoke.ps1
- scripts/CoEve_DevSetup.ps1
- scripts/CoEve_AllGreen.ps1
- scripts/CoEve_WatchLatestCI.ps1
- scripts/CoEve_CI_Triage.ps1
- scripts/CoEve_CI_ReRun.ps1
- scripts/CoEve_Branding_PR.ps1

### .sh (1 files)
- scripts/CoEve_Smoke.sh

## Static scan (TODO/FIXME)

No TODO/FIXME markers found.
