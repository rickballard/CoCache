param(
  [string]$RepoPath, [int]$MaxFileKB = 256)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
if(-not (Test-Path $RepoPath)){ throw "Repo not found: $RepoPath" }
$ai = Join-Path $RepoPath 'docs\hubs\AI-INDEX.json'
New-Item -ItemType Directory -Force -Path (Split-Path $ai -Parent) | Out-Null
$files = Get-ChildItem -Path $RepoPath -Recurse -File -ErrorAction SilentlyContinue | Where-Object {
  $_.Extension -match '\.(md|txt|json|yml|yaml)$' -and $_.FullName -notmatch '\\.git\'
} | Select-Object FullName, Length
function Summarize([string]$text, [int]$limit=300){
  $t = $text -replace '\s+', ' '
  if($t.Length -gt $limit){ $t = $t.Substring(0, $limit) + '…' }
  return $t
}
$items = @()
foreach($f in $files){
  if(($f.Length / 1KB) -gt $MaxFileKB){ continue }
  try{
    $rel = $f.FullName.Replace($RepoPath, '').Trim('\')
    $body = Get-Content -Raw -ErrorAction SilentlyContinue $f.FullName
    if(-not $body){ continue }
    $title = ($body -split "`n" | Select-Object -First 1) -replace '^\s*#\s*',''
    if(-not $title){ $title = (Split-Path $rel -Leaf) }
    $tags = @()
    if($rel -match 'docs\cc\'){ $tags += 'cognocarta' }
    if($rel -match 'docs\hubs\'){ $tags += 'hub' }
    if($rel -match 'README\.md$'){ $tags += 'readme' }
    $items += [pscustomobject]@{
      path = $rel; title = $title; size_bytes = [int]$f.Length;
      summary = Summarize $body 400; tags = $tags
    }
  } catch { }
}
$payload = [pscustomobject]@{
  generated = (Get-Date).ToUniversalTime().ToString("o"); count = $items.Count; items = $items
}
$payload | ConvertTo-Json -Depth 8 | Set-Content -Path $ai -Encoding UTF8
Write-Host "[OK] AI-INDEX updated: $ai"
