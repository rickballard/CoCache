param([string]$StatusFile,[string]$OutSvg)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
$slam = 0
if(Test-Path $StatusFile){
  $line = Get-Content -Raw $StatusFile
  if($line -match 'SLAM=(\d{1,3})'){ $slam = [int]$Matches[1] }
}
$color = if($slam -ge 70){'#d73a49'} elseif($slam -ge 40){'#dbab09'} else {'#28a745'}
$txt = @"
<svg xmlns="http://www.w3.org/2000/svg" width="148" height="20" role="img" aria-label="slam:$slam">
  <linearGradient id="s" x2="0" y2="100%"><stop offset="0" stop-color="#bbb" stop-opacity=".1"/><stop offset="1" stop-opacity=".1"/></linearGradient>
  <rect rx="3" width="148" height="20" fill="#555"/><rect rx="3" x="55" width="93" height="20" fill="$color"/><path fill="$color" d="M55 0h4v20h-4z"/>
  <rect rx="3" width="148" height="20" fill="url(#s)"/>
  <g fill="#fff" text-anchor="middle" font-family="DejaVu Sans,Verdana,Geneva" font-size="11">
    <text x="28" y="15">slam</text><text x="100" y="15">$slam</text>
  </g>
</svg>
"@
New-Item -ItemType Directory -Force -Path (Split-Path $OutSvg -Parent) | Out-Null
$txt | Set-Content -Path $OutSvg -Encoding UTF8
Write-Host "[OK] Badge -> $OutSvg"
