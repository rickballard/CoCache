param([string]$RepoPath,[string]$StatusFile)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
$readme = Join-Path $RepoPath 'README.md'
if(-not (Test-Path $readme)){ return }
$badgeSvg = Join-Path $RepoPath 'docs\site\badges\slam.svg'
& pwsh (Join-Path $PSScriptRoot 'Write-BadgeSvg.ps1') -StatusFile $StatusFile -OutSvg $badgeSvg | Out-Null
$rel = 'docs/site/badges/slam.svg'; $line = "![SLAM]($rel)"
$txt = Get-Content -Raw $readme
if($txt -notmatch '\!\[SLAM\]\('){
  $txt = "$line`n`n$txt"; $txt | Set-Content -Path $readme -Encoding UTF8; Write-Host "[OK] README badge added."
} else { Write-Host "[OK] README already has SLAM badge." }
