param([string]$ConfigPath = "$PSScriptRoot\..\zt-indexes.config.json")
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
$cfg = Get-Content -Raw $ConfigPath | ConvertFrom-Json
$sr = Split-Path -Parent $ConfigPath | Join-Path -ChildPath 'scripts'
$repo = $cfg.Repos.CoCivium
$script = @"
param([string]`$RepoPath, [string]`$StatusFile)
Set-StrictMode -Version Latest; `$ErrorActionPreference='Stop'
& pwsh '$sr\Generate-HUMAN-INDEX.ps1' -RepoPath `$RepoPath -StatusFile `$StatusFile | Out-Null
& pwsh '$sr\Generate-AI-INDEX.ps1' -RepoPath `$RepoPath | Out-Null
& pwsh '$sr\Update-Readme-Badges.ps1' -RepoPath `$RepoPath -StatusFile `$StatusFile | Out-Null
Push-Location `$RepoPath
try{
  git add README.md docs/hubs/HUMAN-INDEX.md docs/hubs/AI-INDEX.json docs/site/badges/slam.svg 2>`$null | Out-Null
  if( (git status --porcelain) ){
    git commit -m "docs(hubs): refresh HUMAN/AI indexes + SLAM badge [ZT]" 2>`$null | Out-Null
    git push '$($cfg.GitRemote)' '$($cfg.DefaultBranch)' 2>`$null | Out-Null
  }
} finally { Pop-Location }
"@
$tmp = Join-Path $env:TEMP 'run-indexers.ps1'
$script | Set-Content -Path $tmp -Encoding UTF8
function Ensure-Task($name, $exe, $args, $work, $triggers, $desc){
  try{
    $exists = Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue
    if($exists){ Unregister-ScheduledTask -TaskName $name -Confirm:$false -ErrorAction SilentlyContinue | Out-Null }
    $a = New-ScheduledTaskAction -Execute $exe -Argument $args -WorkingDirectory $work
    Register-ScheduledTask -TaskName $name -Action $a -Trigger $triggers -Description $desc -RunLevel Highest | Out-Null
    "[OK] "+$name
  } catch { "[WARN] Failed "+$name+": "+$_ }
}
$trg = @((New-ScheduledTaskTrigger -AtLogOn),(New-ScheduledTaskTrigger -Once (Get-Date).AddMinutes(7) -RepetitionInterval (New-TimeSpan -Minutes $cfg.IndexerIntervalMinutes) -RepetitionDuration ([TimeSpan]::MaxValue)))
Ensure-Task "CoCivium-Indexers" "pwsh.exe" "-NoProfile -ExecutionPolicy Bypass -File `"$tmp`" -RepoPath `"$repo`" -StatusFile `"$($cfg.StatusFile)`"" $sr $trg "Refresh HUMAN/AI indexes + badge and push"
"Done."
