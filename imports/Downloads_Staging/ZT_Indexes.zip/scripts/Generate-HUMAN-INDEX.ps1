param(
  [string]$RepoPath, [string]$StatusFile, [int]$RecentDays = 7)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
if(-not (Test-Path $RepoPath)){ throw "Repo not found: $RepoPath" }
$hub = Join-Path $RepoPath 'docs\hubs\HUMAN-INDEX.md'
New-Item -ItemType Directory -Force -Path (Split-Path $hub -Parent) | Out-Null
$status = (Test-Path $StatusFile) ? (Get-Content -Raw $StatusFile -ErrorAction SilentlyContinue) : ''
$quick = @()
$quick += (Test-Path (Join-Path $RepoPath 'README.md')) ? '* [README](../README.md)' : $null
$quick += (Test-Path (Join-Path $RepoPath 'docs\cc\scroll.md')) ? '* [Cognocarta (scroll)](../cc/scroll.md)' : $null
$quick += (Test-Path (Join-Path $RepoPath 'docs\site\index.html')) ? '* [Public Site (local HTML)](../site/index.html)' : $null
$quick = $quick | Where-Object { $_ }
Push-Location $RepoPath
try{
  $since = (Get-Date).AddDays(-1 * $RecentDays).ToString('yyyy-MM-dd')
  $log = git log --since="$since" --pretty=format:"* %ad — %s (%h)" --date=short 2>$null
} finally { Pop-Location }
if(-not $log){ $log = @("* (no commits in last $RecentDays days)") }
$md = @()
$md += "# HUMAN-INDEX"
$md += ""
if($status){ $md += "> **BPOE Status**: $status" }
if($quick.Count){ $md += ""; $md += "## Quick Links"; $md += ($quick -join "`n") }
$md += ""
$md += "## Recent Changes (last $RecentDays days)"
$md += ($log -join "`n")
$md += ""
$md += "## Notables"
$md += "- Keep docs authoritative. Drafts → `docs/redacted_bin/` when redacted."
$md += "- SLAM Green <40, Amber 40–69, Red ≥70 ⇒ rotate."
$mdText = ($md -join "`n") + "`n"
$mdText | Set-Content -Path $hub -Encoding UTF8
Write-Host "[OK] HUMAN-INDEX updated: $hub"
