# ZT Indexes
Created 2025-09-15T180907Z UTC.

## Install scheduled indexers (local, zero touch)
```powershell
$root = "$HOME\Downloads\ZT_Indexes"
Set-Location $root
.\scripts\Install-Indexers.ps1 -ConfigPath .\zt-indexes.config.json
```
This creates **CoCivium-Indexers** task: regenerates HUMAN/AI indexes & SLAM badge, commits, pushes.

## Apply repo patches
```powershell
.\scripts\Apply-RepoPatches.ps1 -ConfigPath .\zt-indexes.config.json
```
Adds a CI workflow that also refreshes indexes hourly and on push.
