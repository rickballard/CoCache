# CoCivium Insights — Seed v1.0

This pack installs the requested Insights/* Thesis and Ops Brief skeletons.
- Edit each file in-place.
- Keep placeholders in UPPERCASE (no `<angle>` placeholders) to avoid CI false-positives.

## Install
1) Download this zip.
2) Extract anywhere.
3) From your repo root (must be a git repo), run:
   `pwsh -NoProfile -File ./Install-Insights.ps1`
   - Add `-Overwrite` if you want to replace existing files.
