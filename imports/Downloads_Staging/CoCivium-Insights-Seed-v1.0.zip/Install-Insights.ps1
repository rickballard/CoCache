Param(
  [switch]$Overwrite = $false
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$seed = Join-Path $here 'Insights'
if (-not (Test-Path -LiteralPath $seed)) { throw "Seed 'Insights' folder not found next to installer." }

$repoRoot = (git rev-parse --show-toplevel) 2>$null
if (-not $repoRoot) { throw "Not inside a git repo. cd into your repo and run again." }
Push-Location $repoRoot
try {
  $dst = Join-Path $repoRoot 'Insights'
  if (-not (Test-Path -LiteralPath $dst)) { New-Item -ItemType Directory -Force -Path $dst | Out-Null }

  $copied = @()
  Get-ChildItem -LiteralPath $seed -File | ForEach-Object {
    $target = Join-Path $dst $_.Name
    if ((Test-Path -LiteralPath $target) -and -not $Overwrite) {
      return
    }
    Copy-Item -LiteralPath $_.FullName -Destination $target -Force
    $copied += $target
    git add -- $target 2>$null | Out-Null
  }

  if ($copied.Count -gt 0) {
    git commit -m "docs(Insights): seed v1.0 skeletons" 2>$null | Out-Null
    Write-Host ("✓ Installed {0} Insights docs." -f $copied.Count)
  } else {
    Write-Host "Nothing to install (all files already present)."
  }
} finally {
  Pop-Location
}
