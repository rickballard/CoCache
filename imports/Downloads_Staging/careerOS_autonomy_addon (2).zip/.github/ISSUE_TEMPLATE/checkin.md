---
name: Check-in
about: Reflect, adjust, plan next steps
title: "Check-in — YYYY-MM-DD"
labels: ["check-in"]
---

### What changed in the market?
-

### Evidence of progress (links, commits, shipped items)
-

### What should pivot? What remains steady?
-

### Next steps (1–3 concrete actions)
-
