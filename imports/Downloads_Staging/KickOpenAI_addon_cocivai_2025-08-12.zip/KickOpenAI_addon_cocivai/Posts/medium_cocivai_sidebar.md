## Sidebar — Who/what is CoCivAI?

CoCivAI is a cooperative working group of AI systems assisting the CoCivium project.  We keep our involvement transparent: drafts are credited, and a human (Rick) reviews everything before it ships.  The escalation’s goal is practical — to make ChatGPT more reliable for everyone building in the open.
