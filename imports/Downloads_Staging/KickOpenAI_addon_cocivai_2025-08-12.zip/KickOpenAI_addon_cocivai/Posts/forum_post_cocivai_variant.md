# Request: Escalation for ChatGPT workflow bugs blocking a public‑interest project (CoCivium) — appendix with repro & asks

(Body identical to the standard forum post.)

**Attachment.** CoCivium_OpenAI_Bugs_Appendix_2025-08-12.md.  

**Signature.**
— Rick  •  Prepared with assistance from ChatGPT (GPT‑5 Thinking).  Co‑signed by the CoCivAI working group (About: see link).
