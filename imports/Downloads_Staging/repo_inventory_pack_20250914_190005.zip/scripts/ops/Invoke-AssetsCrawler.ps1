
# Invoke-AssetsCrawler.ps1 — per-repo assets inventory (non-scripts), machine-first
param(
  [Parameter(Mandatory=$true)][string]$RepoPath,
  [int]$StaleDays = 365,
  [switch]$NoGit
)
. $PSScriptRoot\_Shared.ps1

if(-not (Test-Path $RepoPath)){ throw "RepoPath not found: $RepoPath" }
$repoName = Split-Path $RepoPath -Leaf

$aiDir   = Join-Path $RepoPath 'ai\manifests'
$docDir  = Join-Path $RepoPath 'docs\status\inventory'
$null = New-Item -ItemType Directory -Force -Path $aiDir,$docDir

# What counts as "asset" here: MD/JSON/YAML/MMD/SVG/PDF/workflows/etc. but exclude code scripts handled elsewhere
$scriptExt = @('.ps1','.psm1','.psd1','.sh','.bash','.py','.js','.ts','.bat','.cmd')
$assetExt  = @('.md','.mdx','.markdown','.mmd','.mermaid','.json','.yaml','.yml','.svg','.png','.jpg','.pdf','.csv','.ndjson')
$skipDirs  = @('\.git\','\\node_modules\\','\\bin\\','\\obj\\','\\dist\\','\\build\\','\\coverage\\','\\\.venv\\','\\data\\cache\\')

$files = Get-ChildItem -Path $RepoPath -Recurse -File -ErrorAction SilentlyContinue | Where-Object {
  $p = $_.FullName
  ($skipDirs -notmatch $p) -and ($assetExt -contains ([IO.Path]::GetExtension($_.FullName).ToLowerInvariant())) -and
  -not ($scriptExt -contains ([IO.Path]::GetExtension($_.FullName).ToLowerInvariant()))
}

$items=@()
foreach($f in $files){
  $rel = $f.FullName.Substring($RepoPath.Length).TrimStart('\')
  $ext = ([IO.Path]::GetExtension($f.FullName) ?? '').ToLowerInvariant().Trim('.')
  $type = switch($ext){
    'md' { 'doc' } 'mdx'{'doc'} 'markdown'{'doc'}
    'mmd'{'diagram'} 'mermaid'{'diagram'}
    'json'{'data'} 'ndjson'{'data'} 'csv'{'data'}
    'yaml'{'config'} 'yml'{'config'}
    'svg'{'image'} 'png'{'image'} 'jpg'{'image'}
    'pdf'{'paper'}
    default { 'other' }
  }
  $hash = (Get-FileHash -Path $f.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
  $stale = $f.LastWriteTimeUtc -lt (Get-Date).ToUniversalTime().AddDays(-1 * [Math]::Abs($StaleDays))
  $items += [ordered]@{
    path    = $rel
    kind    = $type
    size    = $f.Length
    updated = $f.LastWriteTimeUtc.ToString("yyyy-MM-dd'T'HH:mm:ss'Z'")
    sha256  = $hash
    stale   = [bool]$stale
  }
}

$manifest = [ordered]@{
  spec    = "cocivium.ai/assets-manifest/v1"
  repo    = $repoName
  root    = $RepoPath
  updated = (Get-Date).ToUniversalTime().ToString("yyyy-MM-dd'T'HH:mm:ss'Z'")
  count   = $items.Count
  assets  = $items
}
($manifest | ConvertTo-Json -Depth 6) | Out-Utf8NoBom (Join-Path $aiDir 'assets-manifest.json')

# simple human summary
$w = New-Utf8NoBomWriter (Join-Path $docDir 'ASSETS-REPORT.md')
try{
  $w.WriteLine("# Assets Inventory — $repoName")
  $w.WriteLine("")
  $w.WriteLine(("_Updated {0}_" -f (Get-Date).ToUniversalTime().ToString("yyyy-MM-dd HH:mm:ss\\Z")))
  $w.WriteLine("")
  $w.WriteLine(("* Total assets: **{0}**" -f $items.Count))
  $w.WriteLine("")
  $w.WriteLine("| Path | Kind | Updated | Size |")
  $w.WriteLine("|---|---|---|---:|")
  foreach($it in ($items | Sort-Object updated -Descending)){
    $w.WriteLine("| `{0}` | {1} | {2} | {3} |" -f $it.path,$it.kind,$it.updated,$it.size)
  }
} finally { $w.Close() }

if(-not $NoGit){
  try {
    Push-Location $RepoPath
    git add ai/manifests/assets-manifest.json docs/status/inventory/ASSETS-REPORT.md *> $null
    git commit -m "docs(inventory): update assets manifest & report" *> $null
    git push *> $null
    Pop-Location
  } catch {
    Write-Host "⚠ Git commit/push failed: $_"
    try{ Pop-Location }catch{}
  }
}
Write-Host ("✅ Assets inventory complete for {0} (count: {1})" -f $repoName,$items.Count)
