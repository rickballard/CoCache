
# Invoke-RepoInventory.ps1 — multi-repo driver (scripts + assets) with aggregate report
param(
  [string]$Root = (Join-Path $HOME 'Documents\GitHub'),
  [string[]]$Repos = @(),           # if empty, auto-discover under $Root
  [int]$ScriptsStaleDays = 180,
  [int]$AssetsStaleDays  = 365,
  [switch]$NoGit
)
$ops = $PSScriptRoot
. "$ops\_Shared.ps1"

# Discover repos
$all = @()
if($Repos.Count){
  foreach($r in $Repos){ $p = Join-Path $Root $r; if(Test-Path (Join-Path $p '.git')){ $all += $p } }
}else{
  $all = Get-ChildItem $Root -Directory -ErrorAction SilentlyContinue | Where-Object {
    Test-Path (Join-Path $_.FullName '.git')
  } | Select-Object -ExpandProperty FullName
}

if(-not $all){ throw "No repos found under $Root" }

# Run per-repo crawlers (read-only scan; only writes manifests & reports)
foreach($repo in $all){
  try {
    & "$ops\Invoke-ScriptsCrawler.ps1" -RepoPath $repo -StaleDays $ScriptsStaleDays -NoGit:$NoGit
  } catch { Write-Host "⚠ Scripts crawler failed for $repo :: $_" }
  try {
    & "$ops\Invoke-AssetsCrawler.ps1" -RepoPath $repo -StaleDays $AssetsStaleDays -NoGit:$NoGit
  } catch { Write-Host "⚠ Assets crawler failed for $repo :: $_" }
}

# Aggregate into CoCache (if present)
$coCache = Join-Path $Root 'CoCache'
if(Test-Path $coCache){
  $aggDir = Join-Path $coCache 'docs\status\inventory'
  [IO.Directory]::CreateDirectory($aggDir) | Out-Null

  $rows = @()
  foreach($repo in $all){
    $name = Split-Path $repo -Leaf
    $man = Join-Path $repo 'ai\manifests\scripts-manifest.json'
    if(Test-Path $man){
      try {
        $data = Get-Content $man -Raw | ConvertFrom-Json -EA Stop
        $rows += [pscustomobject]@{
          Repo   = $name
          Total  = [int]$data.count
          Orphan = @($data.scripts | ? { $_.flags.orphan }).Count
          WIP    = @($data.scripts | ? { $_.flags.wip }).Count
          Deprec = @($data.scripts | ? { $_.flags.deprecated }).Count
          Stale  = @($data.scripts | ? { $_.flags.stale }).Count
          Updated= $data.updated
        }
      } catch {}
    }
  }

  $w = New-Utf8NoBomWriter (Join-Path $aggDir 'MASTER-SCRIPTS-INDEX.md')
  try{
    $w.WriteLine("# Master Scripts Index")
    $w.WriteLine("")
    $w.WriteLine(("_Updated {0}_" -f (Get-Date).ToUniversalTime().ToString("yyyy-MM-dd HH:mm:ss\\Z")))
    $w.WriteLine("")
    $w.WriteLine("| Repo | Total | Orphan | Deprecated | WIP | Stale | Updated |")
    $w.WriteLine("|---|---:|---:|---:|---:|---:|---|")
    foreach($r in ($rows | Sort-Object Repo)){
      $w.WriteLine("| {0} | {1} | {2} | {3} | {4} | {5} | {6} |" -f $r.Repo,$r.Total,$r.Orphan,$r.Deprec,$r.WIP,$r.Stale,$r.Updated)
    }
  } finally { $w.Close() }

  if(-not $NoGit){
    try {
      Push-Location $coCache
      git add docs/status/inventory/MASTER-SCRIPTS-INDEX.md *> $null
      git commit -m "docs(inventory): update master scripts index" *> $null
      git push *> $null
      Pop-Location
    } catch {
      Write-Host "⚠ Git commit/push failed (aggregate): $_"
      try{ Pop-Location }catch{}
    }
  }
}

Write-Host "✅ Repo inventory pass complete."
