
# Invoke-ScriptsCrawler.ps1 — per-repo scripts inventory & report
param(
  [Parameter(Mandatory=$true)][string]$RepoPath,
  [int]$StaleDays = 180,
  [switch]$NoGit
)
. $PSScriptRoot\_Shared.ps1

if(-not (Test-Path $RepoPath)){ throw "RepoPath not found: $RepoPath" }
$repoName = Split-Path $RepoPath -Leaf

# Output locations
$aiDir   = Join-Path $RepoPath 'ai\manifests'
$docDir  = Join-Path $RepoPath 'docs\status\inventory'
$null = New-Item -ItemType Directory -Force -Path $aiDir,$docDir

# Scan
$skipDirs = @('\.git\','\\node_modules\\','\\bin\\','\\obj\\','\\dist\\','\\build\\','\\coverage\\','\\\.venv\\','\\data\\cache\\','\\\.tox\\')
$files = Get-ChildItem -Path $RepoPath -Recurse -File -ErrorAction SilentlyContinue | Where-Object {
  $p = $_.FullName
  ($skipDirs -notmatch $p) -and (Get-LanguageFromExt $_.FullName)
}

$items = @()
foreach($f in $files){
  $rel = $f.FullName.Substring($RepoPath.Length).TrimStart('\')
  $lang = Get-LanguageFromExt $f.FullName
  $header = Get-TopCommentBlock -Path $f.FullName -Lang $lang
  $meta = Get-PurposeAndUsage -Header $header -Lang $lang
  $stem = [IO.Path]::GetFileNameWithoutExtension($f.Name)
  $refCount = Get-RefCount -RepoPath $RepoPath -RelPath $rel -Stem $stem
  $flags = Get-FlagSummary -Path $f.FullName -Header $header -Updated $f.LastWriteTimeUtc -StaleDays $StaleDays
  $hash = (Get-FileHash -Path $f.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
  $orphan = ($refCount -eq 0)

  $items += [ordered]@{
    path       = $rel
    language   = $lang
    size       = $f.Length
    updated    = $f.LastWriteTimeUtc.ToString("yyyy-MM-dd'T'HH:mm:ss'Z'")
    sha256     = $hash
    purpose    = $meta.purpose
    usage      = $meta.usage
    refs       = $refCount
    flags      = [ordered]@{
      orphan     = $orphan
      wip        = $flags.wip
      deprecated = $flags.deprecated
      stale      = $flags.stale
    }
  }
}

# Save JSON
$manifest = [ordered]@{
  spec    = "cocivium.ai/scripts-manifest/v1"
  repo    = $repoName
  root    = $RepoPath
  updated = (Get-Date).ToUniversalTime().ToString("yyyy-MM-dd'T'HH:mm:ss'Z'")
  count   = $items.Count
  scripts = ($items | Sort-Object { $_.flags.deprecated }, { -not $_.flags.orphan }, -Descending, updated -Descending)
}
($manifest | ConvertTo-Json -Depth 6) | Out-Utf8NoBom (Join-Path $aiDir 'scripts-manifest.json')

# Save Markdown report
$w = New-Utf8NoBomWriter (Join-Path $docDir 'SCRIPTS-REPORT.md')
try {
  $w.WriteLine("# Scripts Inventory — $repoName")
  $w.WriteLine("")
  $w.WriteLine(("_Updated {0}_" -f (Get-Date).ToUniversalTime().ToString("yyyy-MM-dd HH:mm:ss\\Z")))
  $w.WriteLine("")
  $w.WriteLine(("* Total scripts: **{0}**" -f $items.Count))
  $w.WriteLine(("* Flags — orphan: **{0}**, deprecated: **{1}**, WIP: **{2}**, stale: **{3}**" -f @(
    ($items | ? { $_.flags.orphan }).Count,
    ($items | ? { $_.flags.deprecated }).Count,
    ($items | ? { $_.flags.wip }).Count,
    ($items | ? { $_.flags.stale }).Count)))
  $w.WriteLine("")
  $w.WriteLine("| Path | Lang | Updated | Flags | Purpose/Usage | Refs |")
  $w.WriteLine("|---|---|---|---|---|---:|")
  foreach($it in ($items | Sort-Object { $_.flags.deprecated -or $_.flags.orphan -or $_.flags.wip -or $_.flags.stale } -Descending, updated -Descending)){
    $flags = @()
    if($it.flags.orphan){ $flags += "orphan" }
    if($it.flags.deprecated){ $flags += "deprecated" }
    if($it.flags.wip){ $flags += "wip" }
    if($it.flags.stale){ $flags += "stale" }
    $flagStr = $(if($flags){ $flags -join "," } else {"·"})
    $pu = ($it.purpose ?? "").Trim()
    if([string]::IsNullOrWhiteSpace($pu)){ $pu = ($it.usage ?? "").Trim() }
    $pu = ($pu.Substring(0, [Math]::Min(120, $pu.Length)))
    $w.WriteLine("| `{0}` | {1} | {2} | {3} | {4} | {5} |" -f $it.path,$it.language,$it.updated,$flagStr,$pu,$it.refs)
  }
} finally {
  $w.Close()
}

# Optional git commit (only writes docs/ai manifests)
if(-not $NoGit){
  try {
    Push-Location $RepoPath
    git add ai/manifests/scripts-manifest.json docs/status/inventory/SCRIPTS-REPORT.md *> $null
    git commit -m "docs(inventory): update scripts manifest & report" *> $null
    git push *> $null
    Pop-Location
  } catch {
    Write-Host "⚠ Git commit/push failed: $_"
    try{ Pop-Location }catch{}
  }
}
Write-Host ("✅ Scripts inventory complete for {0} (count: {1})" -f $repoName,$items.Count)
