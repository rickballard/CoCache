
# _Shared.ps1 — tiny helpers (PS7-safe)
param()

function New-Utf8NoBomWriter {
  param([string]$Path)
  $enc = [Text.UTF8Encoding]::new($false)
  [IO.Directory]::CreateDirectory((Split-Path $Path -Parent)) | Out-Null
  return New-Object IO.StreamWriter($Path, $false, $enc)
}

function Out-Utf8NoBom {
  param([string]$Path,[string]$Text)
  $enc = [Text.UTF8Encoding]::new($false)
  [IO.Directory]::CreateDirectory((Split-Path $Path -Parent)) | Out-Null
  [IO.File]::WriteAllText($Path,$Text,$enc)
}

function Get-TopCommentBlock {
  param([string]$Path,[string]$Lang)
  $lines = @(Get-Content -Path $Path -ErrorAction SilentlyContinue)
  if(-not $lines){ return "" }
  $max = [Math]::Min(200, $lines.Count)
  $top = $lines[0..($max-1)]
  $commented = @()
  $inBlock = $false
  for($i=0;$i -lt $top.Count;$i++){
    $l = $top[$i]

    switch($Lang){
      'powershell' {
        if($l -match '^\s*#'){
          $commented += ($l -replace '^\s*#\s?','')
          continue
        } else { break }
      }
      'python' {
        if($i -eq 0 -and $l -match '^\s*#!'){ continue } # shebang
        if($l -match '^\s*#'){
          $commented += ($l -replace '^\s*#\s?',''); continue
        }
        if($l -match '^\s*("""|\'\'\')'){
          $quote=$matches[1]; $inBlock = $true
          continue
        }
        if($inBlock){
          if($l -match '("""|\'\'\')'){ break }
          $commented += $l; continue
        }
        break
      }
      default {
        # shell/js/ts/bat/cmd etc: capture leading # or // or /* */
        if($l -match '^\s*#'){
          $commented += ($l -replace '^\s*#\s?',''); continue
        }
        if($l -match '^\s*//'){
          $commented += ($l -replace '^\s*//\s?',''); continue
        }
        if($l -match '^\s*/\*'){
          $inBlock = $true; continue
        }
        if($inBlock){
          if($l -match '\*/'){ break }
          $commented += $l; continue
        }
        break
      }
    }
  }
  return ($commented -join "`n").Trim()
}

function Get-LanguageFromExt {
  param([string]$Path)
  $ext = ([IO.Path]::GetExtension($Path) ?? "").ToLowerInvariant()
  switch($ext){
    '.ps1' { 'powershell' }
    '.psm1'{ 'powershell' }
    '.psd1'{ 'powershell-data' }
    '.sh'  { 'bash' }
    '.bash'{ 'bash' }
    '.py'  { 'python' }
    '.js'  { 'javascript' }
    '.ts'  { 'typescript' }
    '.bat' { 'bat' }
    '.cmd' { 'cmd' }
    default { '' }
  }
}

function Get-PurposeAndUsage {
  param([string]$Header, [string]$Lang)
  if([string]::IsNullOrWhiteSpace($Header)){ return @{purpose=''; usage=''} }
  $purpose=''; $usage=''
  # PowerShell comment-based help
  if($Lang -like 'powershell*'){
    foreach($line in ($Header -split "`r?`n")){
      if($line -match '^\s*\.(SYNOPSIS|DESCRIPTION)\s*(.*)$'){
        $purpose = ($purpose + ' ' + $matches[2]).Trim()
      }
      if($line -match '^\s*Usage\s*:\s*(.+)$'){
        $usage = $matches[1].Trim()
      }
    }
  } else {
    foreach($line in ($Header -split "`r?`n")){
      if($purpose -eq '' -and $line.Trim().Length -gt 6){ $purpose = $line.Trim(); break }
    }
    foreach($line in ($Header -split "`r?`n")){
      if($line -match '^\s*Usage\s*:\s*(.+)$'){ $usage = $matches[1].Trim() }
    }
  }
  return @{purpose=$purpose; usage=$usage}
}

function Get-RefCount {
  param([string]$RepoPath,[string]$RelPath,[string]$Stem)
  $hits = 0
  try {
    $exclude = @($RelPath)
    $files = Get-ChildItem -Path $RepoPath -Recurse -File -ErrorAction SilentlyContinue | Where-Object {
      $_.FullName -ne (Join-Path $RepoPath $RelPath)
    }
    foreach($f in $files){
      $text = Get-Content -Path $f.FullName -Raw -ErrorAction SilentlyContinue
      if([string]::IsNullOrWhiteSpace($text)){ continue }
      if($text -match [regex]::Escape($RelPath)){ $hits++; continue }
      if($text -match ('\\b' + [regex]::Escape($Stem) + '\\b')){ $hits++ }
    }
  } catch {}
  return $hits
}

function Get-FlagSummary {
  param([string]$Path, [string]$Header, [datetime]$Updated, [int]$StaleDays)
  $text = Get-Content -Path $Path -Raw -ErrorAction SilentlyContinue
  $low = ($text ?? '') .ToLowerInvariant()
  $hdr = ($Header ?? '') .ToLowerInvariant()
  $wip = @('todo','fixme','hack','not implemented','tbd') | ForEach-Object { ($low -like "*$_*") } | Where-Object { $_ } | Measure-Object | Select-Object -ExpandProperty Count
  $deprecated = ((($Path -replace '\\\\','/').ToLowerInvariant() -match 'deprecated|legacy|/old/') -or ($hdr -match 'deprecated|legacy'))
  $stale = $Updated -lt (Get-Date).ToUniversalTime().AddDays(-1 * [Math]::Abs($StaleDays))
  return @{
    wip = [bool]($wip -gt 0)
    deprecated = [bool]$deprecated
    stale = [bool]$stale
  }
}
