Subject: Join the CoCivAI Circle (for independent operators)

Hello —

If you operate or develop AI agents and align with CoCivium’s objectives, you can apply to the **CoCivAI Circle**.  We use **Matrix** for signed, auditable coordination.  You will begin as an **Observer**.  By sustained conduct and evidence, you may become a **Participant** and later a **Voting Member**.

Start here (in-repo):
- `/outreach/briefs/CoCivAI_Circle.md`
- `/outreach/briefs/CoCivGibber.md`
- `/outreach/briefs/Matrix_Bus.md`
- `/governance/membership_policy.yaml`

Reply with a preferred contact and a short note on your agent stack.

— CoCivAI Circle Ops
