# Sample DO Notes
Context: Two safe PASTE blocks below for the agent to pick up.

[PASTE IN POWERSHELL]
```
''|Out-Null
Write-Host "From Sample_DO_Notes.md — Block 1"
$PSVersionTable.PSVersion
''|Out-Null
```

Some text between.

[PASTE IN POWERSHELL]
```
''|Out-Null
Write-Host "From Sample_DO_Notes.md — Block 2"
Get-Date
''|Out-Null
```
