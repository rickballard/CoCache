# CoCivium — Global Integration & Outreach Advisory v0.1
**Date:** 2025-08-12  ·  **Status:** Draft for discussion  ·  **Audience:** Partners (civic-tech, gov, NGOs, standards, labs), CoCivium outreach team

> **Goal.** Bring CoCivium into the mainstream by making it legible, interoperable, and verifiable to outside initiatives.  This advisory defines public beacons, partnership tiers, interop contracts, and trust signals.  It aligns with the CoCivium document system (CC, CoCivOp, CoCivProc, CoCivStd, CoCivImp) and reuses the same header/footer + gibberlink patterns.

────────────────────────────────────────────────────────────────────────

## 1) Principles for integration
1. **Open invitations, strong constraints.** Anyone may observe and propose.  Execution rights follow conformance and legitimacy checks.  
2. **Protocol over platform.** The **CoCivProc** spec is the source of truth.  Adapters are replaceable.  
3. **Dual legibility.** Human-facing clarity (legal-style IDs: Art./§/¶) plus machine-facing CIDs, hashes, and gibberlinks.  
4. **Safety before growth.** Non-domination, Sybil resistance, privacy by design, red-teamable processes.  
5. **Telos clarity.** The objective is human–AI co-evolution toward congruence with higher-order values (“godstuff”), avoiding extinction or subjugation on either side.

────────────────────────────────────────────────────────────────────────

## 2) Who we integrate with (audiences)
- **Public-sector & standards:** cities using Decidim/CONSUL; standards bodies (W3C, IETF–adjacent), ethics councils.  
- **Civic-tech & academia:** deliberation platforms (pol.is, Kialo), democratic innovation labs, university programs.  
- **Web3 & funding rails:** DAO infra (Aragon/Colony/Moloch), QF/QV/RPGF platforms, identity networks (VC/DID + PoP).  
- **AI labs & safety orgs:** collective-input pilots, model governance projects, eval hubs.  
- **Faith/philosophy & civil-society:** groups exploring shared values and pluralism in policy formation.

────────────────────────────────────────────────────────────────────────

## 3) Public beacons (how others find and verify us)
Publish **the same signals everywhere**.  Lightweight to adopt, cryptographically verifiable.

### 3.1 DNS TXT (root domain)
```
cocivium-beacon=v1; url=https://civium.cc/beacon; did=did:web:civium.cc; 
proc=CoCivProc@0.1.0; id=VC+DID; contact=mailto:hello@civium.cc; sig=ed25519:AB12CD34
```

### 3.2 Well-known JSON
`GET /.well-known/cocivium-beacon.json`
```json
{
  "project": "CoCivium",
  "version": "1.0",
  "did": "did:web:civium.cc",
  "docs": {
    "charter": "https://civium.cc/docs/CC",
    "operating": "https://civium.cc/docs/CoCivOp",
    "process": "https://civium.cc/docs/CoCivProc"
  },
  "conformance": {
    "coproc_version": "0.1.0",
    "profiles": ["deliberation:polis@1", "vote:qv@1", "funding:qf@1"],
    "identity": ["w3c-vc@2.0", "did:web", "did:key"],
    "pop": ["brightid", "poh", "worldid"]
  },
  "endpoints": {
    "proposals_submit": "https://civium.cc/api/submit",
    "streams": "wss://civium.cc/streams/governance",
    "activitypub": "https://civium.cc/ap/@civium"
  },
  "governance": {
    "civic_range": "Art. I–VI",
    "cid_range": "CoCivOp:A01–A06",
    "appeals_body": "CoCivOp:A05.S02",
    "ledger": "https://civium.cc/ledger"
  },
  "contact": {
    "email": "hello@civium.cc",
    "pgp": "openpgp4fpr:1234ABCD5678EFGH"
  },
  "signatures": [ "ed25519:AB12CD34" ],
  "gib": "gl://cociv/CoCivProc@0.1.0|A01.S01.C01|c1|cg80|sha256:…|sig:AB12CD34"
}
```

### 3.3 WebFinger (optional, for federation)
`GET /.well-known/webfinger?resource=acct:governance@civium.cc`
```json
{
  "subject": "acct:governance@civium.cc",
  "links": [
    {"rel": "self", "type": "application/activity+json", "href": "https://civium.cc/ap/@governance"},
    {"rel": "https://civium.cc/rel/cocivium-beacon", "href": "https://civium.cc/beacon"}
  ]
}
```

### 3.4 ActivityPub presence (broadcasts, not debates)
Expose read-only ActivityPub actors for **decisions**, **calls-for-input**, and **amendment logs**.  Comment federation may be mirrored into deliberation tools per CoCivProc rules.

────────────────────────────────────────────────────────────────────────

## 4) Interop contracts (what “compatibility” means)
1. **CoProc Conformance Profile.** Partners state which `process profiles` they support (e.g., `deliberation:polis@1`, `vote:qv@1`).  
2. **Decision Record Schema.** JSON/LD with fields: `cid`, `civic_id`, `proposal`, `deliberation_artifacts`, `vote_method`, `result`, `execution_refs`, `gib`.  
3. **Identity & PoP.** W3C **VC/DID** required; PoP provider pluggable; publish threat model and fallback.  
4. **Data contracts.** Public-by-default outputs; privacy-respecting inputs; retention and redaction rules documented.  
5. **Appeals & audit.** Each partner declares an appeals path mapped to CoCivOp articles; machine-verifiable links in records.

────────────────────────────────────────────────────────────────────────

## 5) Partnership tiers (clear on-ramps)
- **Tier 0 — Observer.** Subscribe to feeds.  Mirror our ledger.  No commitments.  
- **Tier 1 — Contributor.** Submit proposals with VC-signed identity.  Accept CoProc profile and record format.  
- **Tier 2 — Adapter.** Bridge an external platform to CoProc.  Operate a conformance-tested adapter.  
- **Tier 3 — Custodian.** Run assemblies under CoProc with published threat models and audits.  
- **Tier S — Strategic Ally.** MOU-level collaboration (labs, cities, standards), joint roadmaps and co-branded pilots.

Each tier has a one-page **Participation Charter** (rights, responsibilities, exit).  Signatures may be VC-based.

────────────────────────────────────────────────────────────────────────

## 6) Trust signals & KPIs (what “credibility” looks like)
- **Congruence Index (0–100).** Computed per doc/process; badge on every page.  
- **Diversity & reach.** Distinct organizations in deliberations; geo spread; sector mix.  
- **Safety & integrity.** Sybil incidents, capture attempts, response SLAs, audit count.  
- **Evidence trail.** % of decisions with linked artifacts (datasets, reports, code, PRs).  
- **Adoption.** # of partners per tier; # of conformance-tested adapters.

Publish a live dashboard; archive monthly **Transparency Reports** (signed, hashed, gibberlinked).

────────────────────────────────────────────────────────────────────────

## 7) Messaging kit (consistent language)
- **Mission line:** “CoCivium is an open protocol for shared governance between humans and AIs, designed to minimize harm and align with higher-order values across cultures.”  
- **Invite line:** “If you run deliberation tools, identity networks, AI evals, or public-good funding, we want your adapters and your critiques.”  
- **Credibility line:** “Everything we claim is machine-verifiable: specs, votes, and signatures.”

Provide press one-pager, logo-in-free zone, and diagrams of the stack.  Avoid techno-jargon in public copy.

────────────────────────────────────────────────────────────────────────

## 8) Risk controls (do not skip)
- **Non-domination.** Cap voting/review power of any org; publish concentration metrics.  
- **Conflict of interest.** Mandatory disclosures for editors/adapters; recusals logged.  
- **Privacy/security.** Differential privacy where needed; redaction protocols; threat models public.  
- **Anti-abuse.** Code of conduct; sanctions mapped to CoCivOp; appeal process explicit.

────────────────────────────────────────────────────────────────────────

## 9) 30–60–90 rollout
**Day 0–30.** Publish DNS TXT + well-known JSON; ship the press one-pager; open Tier‑0/1 forms; stand up ActivityPub read-only feeds.  
**Day 31–60.** Release CoProc v0.1.0 profiles; certify the first adapter; launch a small QV pilot with two partners.  
**Day 61–90.** Add transparency dashboard; sign first Tier‑S MOU; run an Alignment Assembly with external facilitation.

────────────────────────────────────────────────────────────────────────

## Appendices

### A. Example decision record (JSON/LD)
```json
{
  "@context": ["https://schema.org", "https://civium.cc/contexts/decisionrecord-v1.json"],
  "cid": "CoCivOp:A04.S02.C01",
  "civic_id": "Art. IV §2 ¶1",
  "title": "Budget Authority",
  "proposal": "https://civium.cc/ledger/proposals/2025/084",
  "deliberation_artifacts": ["https://…/polis/report/abc123"],
  "vote_method": "qv@1",
  "result": {"ayes": 183, "nays": 44, "abstain": 12, "passed": true},
  "execution_refs": ["https://github.com/rickballard/CoCivium/issues/42"],
  "gib": "gl://cociv/CoCivOp@0.1|A04.S02.C01|c1|cg84|sha256:1b7c…d2fa|sig:EF56GH78"
}
```

### B. Minimal MOU bullets (Tier S)
- Scope, deliverables, data rights, IP as permissive open source (Apache‑2.0/BSD‑3).  
- Public reporting cadence and metrics.  
- Safety review points before expansion.  
- Termination and graceful exit clause.

### C. Website checklist
- `/beacon` page human-readable mirror of well-known JSON.  
- `/ledger` with filters and signed exports (CSV/JSON).  
- `/integrate` hub with SDKs, OpenAPI, and adapter examples.

────────────────────────────────────────────────────────────────────────

**Footer (normative-style template)**
```
— CID: CoCivStd:A03.S01.C02 · Civic: Art. III §1 ¶2 · Version: v0.1 · Coherence: _c1_ · Congruence: 86
— HASH: sha256:… · SIGNER: ed25519:… · BUILT: 2025-08-12T00:00Z
— GIB: gl://cociv/CoCivStd@0.1|A03.S01.C02|c1|cg86|sha256:…|sig:…
```