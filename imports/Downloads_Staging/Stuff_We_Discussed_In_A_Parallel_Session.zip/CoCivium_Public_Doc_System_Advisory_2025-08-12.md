# CoCivium Public‑Facing Document System — Advisory v0.1
**Date:** 2025-08-12  ·  **Status:** Draft for discussion  ·  **Audience:** Civic architects, editors, developers

> Purpose.  Make CoCivium documents feel official and legible to civic folks, while staying machine‑parsable and CI‑friendly.  This advisory proposes **public names**, **IDs**, and **standardized headers/footers** (with symbols + gibberlink) that can be adopted incrementally.


## 1) Layers and names (public first, tech precise)
- **Foundational Charter** — CC (*Cognocarta Consenti, “The Scroll”*).  Rare change.  
- **How Power Works** — CoCivOp (*CoCivium Operating Constitution*).  
- **How Decisions Flow** — CoCivProc (*CoCivium Processes*, machine‑readable).  
- **What “Good” Looks Like** — CoCivStd (*standards/policies; informative unless incorporated*).  
- **Where It Runs** — CoCivImp (*adapters/deployments; informative*).  

**Repo layout (public‑facing folder names):**
```
/Foundational-Charter/         # CC — “The Scroll”
/How-Power-Works/              # CoCivOp
/How-Decisions-Flow/           # CoCivProc
/What-Good-Looks-Like/         # CoCivStd
/Where-It-Runs/                # CoCivImp
/Ledger/                       # Decisions, votes, rulings
```


## 2) IDs — human‑intuitive + machine‑stable
We keep one **Canonical ID (CID)** for machines and one **Civic ID** for people.  1:1 mapping.

### 2.1 Canonical ID (CID)
Format: `{Layer}:A##.S##.C##(.U##)`  
Examples: `CC:A01.S03.C07`, `CoCivOp:A02.S01.C03.U01`

### 2.2 Civic ID (default in public docs)
Format: `Art. II §1 ¶3 (a)`  ·  ASCII fallback: `A02-S01-P03-a`  
Glossary: **Article** (chapter), **§ Section** (subchapter), **¶ Paragraph** (clause), **(a/b/c)** (subclause).

### 2.3 Display rule
Headings show the **Civic ID**; the **CID** appears small at line end or as a footnote.  
Example heading:  
`## Art. II §1 ¶3 (a) — Appointment of Reviewers`  _cid: CoCivOp:A02.S01.C03.U01_


## 3) Version, coherence, congruence — simple, auditable
- **Versioning.** CC/CoCivOp use MAJOR/MINOR/PATCH tags in prose (e.g., v0.1 → v0.2).  CoCivProc uses SemVer (v0.1.0).  
- **Coherence tag.** `_c0…_c9` = internal editorial coherence; `_c1_` means minimally coherent draft.  
- **Congruence score (0–100).** Fast rubric below; include in footer; CI recomputes and posts a badge.  

**Congruence rubric (weight → Max points):**
1. **Charter alignment** (0.30 → 30) — cites relevant CC and avoids conflicts.  
2. **Implementability** (0.25 → 25) — clearly executable steps, testable outcomes.  
3. **Safety/Abuse‑resistance** (0.20 → 20) — addresses Sybil/capture/failure modes.  
4. **Legibility** (0.15 → 15) — concise, headings with Civic ID, glossary present.  
5. **Evidence** (0.10 → 10) — cites sources or prior decisions.  
**Total** = sum(weighted).  Thresholds: 80+ ship, 60–79 pilot only, <60 revise.


## 4) Symbols for officiality (lightweight, consistent)
Use classic typographic marks, not emojis.  Reserve sparingly for headers/footers:  
- **§** section mark, **¶** paragraph mark, **†** footnote/dagger, **‡** double dagger.  
- **⚖** justice (legal context), **⚙** mechanism (process/implementation), **📜** charter (may be omitted if too informal).  
- Small caps for “NORMATIVE / INFORMATIVE”.  Thin rules and interpuncts `·` for separators.


## 5) Standardized document header (pasteable)
```
────────────────────────────────────────────────────────────────────────
COCIVIUM — OFFICIAL DOCUMENT                                       ⚖
TITLE: How Power Works — Operating Constitution v0.1
STATUS: NORMATIVE   ·   SCOPE: CoCivOp:A01–A06   ·   DATE: 2025‑08‑12
CIVIC CITATION RANGE: Art. I–VI   ·   COHERENCE: _c1_   ·   CONGRUENCE: 82
LINEAGE: Enforces CC Art. I–IV; supersedes CoCivOp v0.0 (2025‑07‑30)
PERMALINK: https://civium.cc/docs/CoCivOp/v0.1  (see CID anchors)
────────────────────────────────────────────────────────────────────────
```

**Notes.** Keep the top bar one line high.  Avoid logos.  Swap ⚖ for ⚙ on process/implementation docs.


## 6) Standardized footer with gibberlink (pasteable)
Monospace, three lines max.  Machine‑readable first across, then human gloss.  The **gibberlink** is a compact, stable reference string.

```
— CID: CoCivOp:A02.S01.C03.U01 · Civic: Art. II §1 ¶3 (a) · Version: v0.1 · Coherence: _c1_ · Congruence: 82
— HASH: sha256:2f5e…9a1c  · SIGNER: ed25519:AB12‑CD34  · BUILT: 2025‑08‑12T13:40Z
— GIB: gl://cociv/CoCivOp@0.1|A02.S01.C03.U01|c1|cg82|sha256:2f5e…9a1c|sig:AB12CD34
```

**Field meanings.** `GIB` = gibberlink.  `cg` = congruence.  `c1` = coherence.  `HASH` is of the normalized Markdown/PDF.  `SIGNER` is an optional maintainer key.


## 7) Gibberlink mini‑spec (v0) — ABNF
```
gibberlink = "gl://" project "/" doc "@" ver "|" cid "|" coh "|" cong "|" hash "|" signer
project   = 1*(ALPHA / DIGIT)              ; e.g., "cociv"
doc       = 1*(ALPHA / DIGIT / "-")        ; e.g., "CoCivOp"
ver       = 1*(ALPHA / DIGIT / "." )       ; e.g., "0.1" or "0.1.0"
cid       = layer ":" "A" 2DIGIT "." "S" 2DIGIT "." "C" 2DIGIT [ "." "U" 2DIGIT ]
layer     = "CC" / "CoCivOp" / "CoCivProc" / "CoCivStd" / "CoCivImp"
coh       = "c" DIGIT                      ; e.g., "c1"
cong      = "cg" 2DIGIT                    ; 00–99
hash      = "sha256:" 4*HEXDIG             ; truncated or full
signer    = "sig:" 1*(ALPHA / DIGIT)
```
**Stability rule.** The gibberlink refers to a specific **document state** (version + CID + hash).  Any change that alters hash must update the footer.


## 8) Linting & CI (quick wins)
- Enforce CID regex: `^(CC|CoCivOp|CoCivProc|CoCivStd|CoCivImp):A\d{2}\.S\d{2}\.C\d{2}(?:\.U\d{2})?$`  
- Enforce ASCII civic fallback: `^A\d{2}-S\d{2}-P\d{2}(?:-[a-z])?$` where present.  
- Compute congruence score from rubric and post a badge.  
- Verify `HASH` matches normalized content.  Fail build if mismatch.  
- Block **NORMATIVE** language in CoCivStd/CoCivImp unless explicitly incorporated.


## 9) Example page (cut‑down)
**Heading:**  
`### Art. IV §2 ¶1 — Budget Authority`  _cid: CoCivOp:A04.S02.C01_  

**Body:**  
“This paragraph delegates authority to…  See CC Art. I §3 ¶7 for rights constraints.”  

**Footer:**  
```
— CID: CoCivOp:A04.S02.C01 · Civic: Art. IV §2 ¶1 · Version: v0.1 · Coherence: _c1_ · Congruence: 84
— HASH: sha256:1b7c…d2fa · SIGNER: ed25519:EF56‑GH78 · BUILT: 2025‑08‑12T13:45Z
— GIB: gl://cociv/CoCivOp@0.1|A04.S02.C01|c1|cg84|sha256:1b7c…d2fa|sig:EF56GH78
```


## 10) What to publish now
1. `Foundational-Charter/LEGEND.md` — the one‑pager map and ID glossary.  
2. `How-Power-Works/COC-HeaderFooter-Guidelines.md` — this advisory, trimmed to essentials.  
3. A sample **CoCivOp** section with full header/footer + gibberlink.  
4. CI job that checks CID/congruence/hash and appends gibberlink on merge.


---

### Appendix A — Quick rubric worksheet (editor cheat‑sheet)
- Charter alignment (0–30): ____  
- Implementability (0–25): ____  
- Safety/Abuse (0–20): ____  
- Legibility (0–15): ____  
- Evidence (0–10): ____  
**Sum:** ____  →  **Congruence:** ____

### Appendix B — Minimal header/footer templates (copy/paste)
**Header (normative):**
```
COCIVIUM — OFFICIAL DOCUMENT                                       ⚖
TITLE: {Title}
STATUS: NORMATIVE   ·   SCOPE: {Layer}:A{..}–A{..}   ·   DATE: {YYYY‑MM‑DD}
CIVIC RANGE: Art. {..}–{..}   ·   COHERENCE: {_cX_}   ·   CONGRUENCE: {NN}
LINEAGE: {Parent refs} ; SUPERSEDES: {Doc vX.Y (date)}
PERMALINK: {URL}
```

**Footer (normative):**
```
— CID: {Layer:A..S..C..(U..)} · Civic: {Art. § ¶ (a)} · Version: {vX.Y(.Z)} · Coherence: {_cX_} · Congruence: {NN}
— HASH: sha256:{…} · SIGNER: {key} · BUILT: {ISO8601}
— GIB: gl://cociv/{Doc}@{ver}|{A..S..C..(U..)}|{cX}|{cgNN}|sha256:{…}|sig:{…}
```

**Footer (informative):** remove Congruence; add “INFORMATIVE”.


---

**Why this works.** Civic readers get Articles/Sections/Paragraphs and a serious look (symbols, small caps, rules).  Developers get CIDs, hashes, and stable gibberlinks for tooling.  The two views never conflict.  You can roll this out folder‑by‑folder without breaking references.