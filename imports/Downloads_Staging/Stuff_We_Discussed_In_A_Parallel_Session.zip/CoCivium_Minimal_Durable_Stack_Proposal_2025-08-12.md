# CoCivium Minimal Durable Governance Stack — Proposal
**Date:** 2025-08-12  
**Authors:** Rick Ballard; ChatGPT (GPT-5 Thinking)

---

## 1) Executive summary
CoCivium needs a lean, enforceable stack that separates *principles* from *procedures* and *policy* from *code*.  The following five layers are sufficient and durable: L0 Charter (CC), L1 Operating Constitution (COC), L2 Process Spec (CPS), L3 Policies & Playbooks (POL), L4 Implementations (IMPL).  An optional L5 Records & Audit (LEDGER) is recommended for evidence and forensics.  Each layer has a narrow purpose, explicit change cadence, and machine‑checkable interfaces where it touches the next layer.  This proposal defines names, boundaries, change‑control, repo layout, and adoption steps.  

## 2) Design principles
1. Minimalism over completeness.  If a rule cannot be enforced or executed, it does not belong in a normative layer.  
2. Strict normative boundary.  L0–L2 are the only sources of MUST/SHALL.  L3–L4 are informative unless incorporated by reference into L2.  
3. Machine‑readable governance.  L2 encodes flows, constraints, and voting math with schemas and test vectors.  Code must prove conformance to L2.  
4. Versioned, auditable change.  Each layer declares its change cadence and approval bar to prevent churn and bikeshedding.  
5. Stable names and sort order.  Prefix folders numerically and keep short codes (CC, COC, CPS, POL, IMPL, LEDGER).  
6. Interfaces, not prose coupling.  L1 exports an Authority Contract to L2.  L2 exports Execution Hooks to L4.  

## 3) Layer model (names, purpose, cadence, artifacts)
### L0 — Charter (CC) — Normative
*Purpose.* First principles, fundamental rights, limits on power, amendment wall.  
*Cadence.* Change only at “constitutional moments.”  Super‑supermajority and long cooling‑off.  
*Artifacts.* `CC_YYYY-MM-DD.md` snapshots with human‑readable change logs.  
*Versioning.* Date‑stamped releases only.  

### L1 — Operating Constitution (COC) — Normative
*Purpose.* Org form, roles, court/appeal structure, assembly mandates, budget authority, amendment method.  
*Cadence.* Rare.  ≥⅔ assembly + judicial review window.  
*Artifacts.* `COC_vX.Y/COC_vX.Y.md`, Authority Contract export.  
*Versioning.* SemVer‑like where **major** = structural change, **minor** = clarification.  

### L2 — Process Spec (CPS) — Normative/Technical
*Purpose.* Canonical machine‑readable governance flows and algorithms (proposal → deliberation → voting schema → execution hooks).  
*Cadence.* Continuous via CIP (Civium Improvement Proposal), with reviews and test vectors.  
*Artifacts.* `cps.schema.json`, `cps.yaml`, golden tests, profile overlays.  
*Versioning.* SemVer.  Outcome‑affecting changes bump **minor**.  Breaking I/O schemas bump **major**.  

### L3 — Policies & Playbooks (POL) — Informative
*Purpose.* Domain policies, safety SOPs, procurement playbooks, data/AI usage guidelines.  
*Cadence.* Frequent as practice evolves.  Advisory unless anchored in L2 checks.  
*Artifacts.* Dated docs.  Link to CPS checks instead of inventing new MUSTs.  
*Versioning.* Date‑stamp files to emphasize advisory status.  

### L4 — Implementations (IMPL) — Informative (conformance required)
*Purpose.* Concrete adapters and deployments (Decidim/pol.is, identity providers, funding rails, GitHub workflows, dashboards).  
*Cadence.* Normal engineering.  Security patches may hot‑patch.  
*Artifacts.* Per‑impl READMEs, CI, and a compatibility matrix against CPS.  
*Versioning.* Standard SemVer.  Conformance suite must pass before release.  

### L5 — Records & Audit (LEDGER) — Orthogonal but Recommended
*Purpose.* Evidence of decisions: votes, deliberation artifacts, budgets, chain‑of‑custody, SBOMs, attestations.  
*Cadence.* Append‑only.  WORM storage or signed snapshots.  
*Artifacts.* Decision logs, attestations, reproducible build manifests, public digests.  
*Versioning.* Date‑based directories.  

## 4) Normative boundary and enforcement
**Normative layers (L0–L2)** use RFC 2119/8174 keywords and are linted.  **Informative layers (L3–L4)** must not introduce MUST/SHALL.  CI blocks PRs that violate this boundary.  CPS is the single source of executable governance truth.  

## 5) Change‑control (recommended defaults)
- **L0 (CC).** ≥80% special electorate, 90‑day cooling‑off, at least one public hearing.  Release tag `CC-YYYY`.  
- **L1 (COC).** ≥⅔ assembly approval plus 14‑day judicial review window.  Tag `COC-vX.Y`.  
- **L2 (CPS).** CIP flow: 7‑day open review, 2 approvals from Process Maintainers, and all test vectors green.  Tag `CPS-vX.Y.Z`.  
- **L3 (POL).** Maintainer merge after 3‑day review or 2 approvals.  Date‑stamped.  
- **L4 (IMPL).** SemVer with CI gates.  Security fixes may bypass normal batching if risk demands.  

## 6) Repository layout (stable, machine‑sortable)
```
00-Charter/
  CC_2025-08-12.md
01-Constitution/
  COC_v1.0/COC_v1.0.md
02-ProcessSpec/
  CPS_v1.2.0/
    cps.schema.json
    cps.yaml
    tests/golden/*.yaml
    profiles/municipal.yaml
03-Policies/
  POL_Safety_AI_2025-09.md
  POL_Procurement_2025-10.md
04-Implementations/
  impl_decidim_adapter_v0.4.2/README.md
  impl_github_workflows_v0.3.1/README.md
05-Ledger/   (optional but reserved)
  decisions/2025/...
  attestations/...
  sbom/...
```

## 7) Interfaces
**L1 → L2 (Authority Contract).** L1 exports powers, caps, and appeal hooks in a small YAML that CPS imports as constraints.  
```yaml
# authority_contract.yaml (exported by COC)
entities:
  assemblies:
    - id: citizen_assembly
      powers: [propose, deliberate, vote]
      budget_cap: 0.02 * treasury   # expressed as formula or resolved value
appeals:
  court: supreme_civium
  window_days: 14
limits:
  term_length_days: 365
  conflict_of_interest: required
```

**L2 → L4 (Execution Hooks).** CPS defines call shapes that implementations must expose and test.  
```yaml
execution_hooks:
  pre_vote_check:
    inputs: [proposal_id, voter_id]
    outputs: [eligible:boolean, reason:string]
  apply_outcome:
    inputs: [proposal_id, outcome_blob, signature]
    outputs: [receipt_digest]
```

## 8) Compatibility matrix (example)
```yaml
cps_version: "1.2.x"
implementations:
  decidim_adapter:
    version: "0.4.2"
    status: conformant
    tested_with: ["1.2.0","1.2.1"]
  github_workflows:
    version: "0.3.1"
    status: partial
    notes: "Missing pre_vote_check; manual gate required."
```

## 9) CI guardrails (cheap, effective)
1. Lint for RFC keywords and forbid normative language in L3/L4.  
2. Validate `cps.yaml` against `cps.schema.json`.  Fail PRs if tests do not pass.  
3. Require an updated compatibility matrix when CPS minor/major changes.  
4. Publish public diff digests for L0/L1 with plain‑English change logs.  

## 10) Minimal templates
**CIP (Civium Improvement Proposal).**  
```markdown
# CIP-XXXX: <title>
Author(s): <names>  
Layer: L2 (CPS)  
Status: Draft | Review | Accepted | Rejected | Superseded  
Summary: <one paragraph>  
Motivation: <why the change is needed>  
Specification: <precise changes to cps.yaml/schema>  
Test Vectors: <links to added/updated tests>  
Migration: <back-compat, risks>  
```
**CPS skeleton.**  
```yaml
meta:
  id: CPS-1.2.0
  description: Canonical Civium governance flow
actors: [proposer, voter, reviewer, executor]
objects: [proposal, ballot, outcome, receipt]
states: [draft, review, voting, tally, enacted, appealed, archived]
transitions:
  - from: draft
    to: review
    guard: proposer_signed and schema_valid
votes:
  method: quadratic_voting
  constraints:
    budget_cap: from_authority_contract
execution_hooks: <as above>
constraints:
  - name: conflict_of_interest_check
    scope: proposer
tests:
  golden:
    - name: qv_simple_pass
      input_digest: "..."
      outcome_digest: "..."
```

## 11) Adoption plan
**Now.** Create folders `00..05`, publish the one‑page legend, add `authority_contract.yaml`, and commit the CPS schema + a first golden test.  
**Next.** Instantiate the CIP process, add CI lints, and wire a basic compatibility matrix for your first two implementations.  
**Later.** Stand up the Records/Audit surface with signed snapshots and public digests.  Expand CPS profiles for municipal and organizational variants.  

## 12) Risks and mitigations
- *Normative creep from policy to spec.*  **Mitigation:** CI lints and reviewer checklist.  
- *Audit gaps weaken trust.*  **Mitigation:** Add LEDGER early, or document external WORM storage location and cadence.  
- *Fragmentation across implementations.*  **Mitigation:** Keep the compatibility matrix current and require conformance before release.  

## 13) Glossary
**Normative.** Binding MUST/SHALL text that governs behavior.  
**Informative.** Guidance that MAY be followed and can deviate with justification.  
**CIP.** Civium Improvement Proposal for CPS changes.  
**Golden test.** Canonical input/output pair used to detect regressions.  

---

## DEC
**Now:** Adopt the layer names/codes, publish the legend, commit the folder skeleton and CPS schema + one golden test.  
**Next:** Enable CIP flow and CI lints, and require a compatibility matrix for implementations.  
**Later:** Stand up the Records/Audit surface and publish public diff digests for L0/L1 changes.  
