# CoCivium.org — Site & “Latest Edition” Advisory v0.1
**Date:** 2025-08-12  ·  **Status:** Draft for discussion  ·  **Audience:** Outreach, design, dev, governance

> Purpose.  Make **CoCivium.org** the authoritative, ceremonial front door that always shows the **latest official edition** of the Scroll and other core texts, while remaining verifiable, accessible, and “governmental” in tone.  This advisory defines IA, design language, trust signals, and the resolver logic that selects the most up‑to‑date edition.

────────────────────────────────────────────────────────────────────────

## 1) Principles (blunt)
1. **One canonical source.** Source of truth lives in the public repo.  The site renders from tagged content only.  
2. **Ceremonial by default.** Public pages show Ceremonial editions.  Canonical/source links are one click away.  
3. **Machine-verifiable trust.** Every document panel shows a **Verified** state (hash, signer, gibberlink).  No unverifiable claims.  
4. **Dual audiences.** “Citizens first” copy; “Architects/Developers” paths are visible but secondary.  
5. **Gravitas without kitsch.** US‑gov style cues, evolved with subtle AI–Human motifs and optional cosmos/neural/fungal accents.

────────────────────────────────────────────────────────────────────────

## 2) Information architecture (top‑level nav)
- **Home**  — hero mission, Latest Editions, what CoCivium is, calls to participate.  
- **Foundational Charter**  — ceremonial CC (latest), with Edition switcher and verification.  
- **How Power Works**  — CoCivOp overview and latest.  
- **How Decisions Flow**  — CoCivProc overview, conformance profiles, adapters.  
- **Ledger**  — signed decisions, amendments, transparency reports, data export.  
- **Integrate**  — beacons, APIs/SDKs, adapters, partner tiers.  
- **Contribute**  — roles, submissions, code of conduct, governance process.  
- **About**  — mission, contact, FAQ, identity & privacy.

Footer: links to `/beacon`, `/.well-known/cocivium-beacon.json`, ActivityPub actors, sitemaps, accessibility, licensing.

────────────────────────────────────────────────────────────────────────

## 3) “Latest Edition” resolver (algorithm)
**Inputs:** the Ledger index, tags in the content repo, and the Beacon metadata.  Order of authority: **Ledger → Repo tags → Beacon**.

**Rules:**  
- Prefer **Ceremonial** over Canonical when both match the same text hash.  
- Among editions, choose the **highest ratified major**; tie‑break by ratification date (newest).  
- Minor clerical updates do **not** change “edition” but do change the **hash** and **build date**.  
- If verification fails, degrade gracefully: show Canonical with a warning.

**Pseudocode:**  
```python
def latest(doc):  # doc in ('CC', 'CoCivOp', 'CoCivProc', 'CoCivStd', 'CoCivImp')
    L = ledger.query(doc)  # signed records
    candidates = filter_valid(L)  # signature + hash match
    if not candidates:
        return fallback_from_repo_tags(doc)
    best = max(candidates, key=lambda x: (x.major, x.ratified_at))
    ceremonial = best.assets.get('ceremonial_pdf')
    if ceremonial and ceremonial.hash == best.text_hash:
        return ceremonial
    return best.assets.get('canonical_html') or best.assets.get('canonical_mdx')
```

**UI copy:** “You are viewing the **Official Ceremonial Edition v1** (ratified 2025‑08‑12).  Verified ✓.”

────────────────────────────────────────────────────────────────────────

## 4) Design language (governmental + evolved)
**Typography.** Serif for charters (true small caps, oldstyle numerals).  Sans for UI.  1.35 line height.  Wide inner margins.  
**Color.** High‑contrast neutrals.  Accent palette restricted to one deep blue and one muted gold.  
**Motifs (subtle):**  
- **AI–Human motif:** interleaved rule marks (fine dot + dash) used as dividers.  
- **Cosmos:** starfield micro‑texture in hero background at 2–4% opacity.  
- **Neural/fungal:** fine branching linework as margin ornaments (SVG, 5–8% opacity).  Decorative only; never compete with text.

**Components.**  
- **Document Card (Hero):** title, edition, ratified date, “Verified ✓” with popover (hash, signer, gib).  
- **Edition Switcher:** dropdown to past editions with verification states.  
- **Verify Panel:** collapsible, shows CID range, gib, hashes, signatures, and “How to verify” link.  
- **Callouts:** “For Citizens”, “For Civic Architects”, “For Developers” boxes.  
- **Decision Timeline:** vertical list of signed ledger entries with filters.  

────────────────────────────────────────────────────────────────────────

## 5) Home page wireframe (content blocks)
1. **Hero (full‑width):** Mission line, two CTAs (“Read the Charter”, “Participate”), Verified badges.  
2. **Latest Editions:** Cards for CC, CoCivOp, CoCivProc.  
3. **What is CoCivium (3‑up):** How Power Works · How Decisions Flow · Where It Runs.  
4. **Open Invitations:** partner tiers, adapter calls.  
5. **Live Ledger Snapshot:** last 5 decisions with filters.  
6. **Trust & Transparency:** congruence index explainer, verification how‑to.  
7. **Footer:** beacons, standards, ActivityPub, contact.

────────────────────────────────────────────────────────────────────────

## 6) Trust & verification UX
- Badge states: **Verified ✓** (hash + signature + ledger), **Unverified !** (no match), **Degraded ⚠** (fallback).  
- Popover shows: text hash, signer key, build date, CID range, gib link, “Copy all.”  
- “Verify yourself” modal with copy‑paste `shasum` command and ledger URL.

────────────────────────────────────────────────────────────────────────

## 7) Technical architecture (lean)
- **Stack:** Next.js (or Astro) + MDX for docs, serverless for Ledger API proxy, static export for most pages.  
- **Content flow:** Repo → CI builds → site artifacts (ceremonial PDF/HTML) with embedded XMP metadata.  
- **Beacons:** publish DNS TXT and `/.well-known/cocivium-beacon.json`.  Home footer links to human‑readable `/beacon`.  
- **Caching:** immutable file names with content hashes.  Cache‑control headers; ETag verification.  
- **Security:** CSP locked down; SRI for all scripts/styles; headers (HSTS, X‑Frame‑Options, etc.).  
- **Accessibility:** WCAG 2.2 AA checks in CI.  
- **Internationalization:** preserve Art./§/¶ IDs and CID anchors across locales.  
- **Search/SEO:** sitemaps, JSON‑LD (CreativeWork + GovernmentOrganization), clean canonical URLs.  

**JSON‑LD (example):**
```json
{
  "@context": "https://schema.org",
  "@type": "CreativeWork",
  "name": "Cognocarta Consenti — Ceremonial Edition v1",
  "url": "https://cocivium.org/charter",
  "version": "1",
  "datePublished": "2025-08-12",
  "isBasedOn": "https://github.com/rickballard/CoCivium/...",
  "identifier": "gl://cociv/CC@1|A01–A12|c3|sha256:…|sig:…"
}
```

────────────────────────────────────────────────────────────────────────

## 8) Domain & routing
- **CoCivium.com → 301** to **CoCivium.org**.  Always set canonical `<link rel="canonical">` to `.org`.  
- `civium.cc` hosts specs/beacons and a developer view; cross‑link from `.org`.  
- `/.well-known` and `/beacon` live on `.org` as human and machine entry points.

DNS TXT beacon (sample):
```
cocivium-beacon=v1; url=https://cocivium.org/beacon; did=did:web:cocivium.org;
proc=CoCivProc@0.1.0; contact=mailto:hello@cocivium.org; sig=ed25519:AB12CD34
```

────────────────────────────────────────────────────────────────────────

## 9) Content governance
- **Owners:** Outreach owns Home/About; Governance owns CC/CoCivOp/CoCivProc pages; Devs own Integrate.  
- **Change control:** ceremonial pages render only from tagged commits; emergency banner available but documented in Ledger.  
- **Analytics:** privacy‑first, aggregate only, public metrics in Transparency Reports.

────────────────────────────────────────────────────────────────────────

## 10) 30–60–90 rollout
**Day 0–30.** Publish skeleton site with Hero, Latest Editions, and Verify Panel.  Wire resolver to Ledger.  Set up beacons.  
**Day 31–60.** Add Ledger snapshot, Integrate hub, partner tiers, conformance profile docs.  
**Day 61–90.** Add translations, ActivityPub feed, transparency dashboard, and first adapter showcase.

────────────────────────────────────────────────────────────────────────

## 11) Design tokens (starter)
```
--font-serif: "Charter", "Iowan Old Style", "Palatino", serif;
--font-sans: "Inter", system-ui, -apple-system, "Segoe UI", sans-serif;
--text-color: #161616;
--rule-color: rgba(0,0,0,.15);
--accent-1: #0b3d91;   /* deep blue */
--accent-2: #b38b00;   /* muted gold */
--motif-opacity: .05;
```
CSS accents: use thin rules `·` separators; small caps in headings; zero emojis; SVG ornaments < 8% opacity.

────────────────────────────────────────────────────────────────────────

## 12) Page templates to produce
- `pages/index.mdx` (Home), `pages/charter.mdx`, `pages/power.mdx`, `pages/process.mdx`, `pages/ledger/index.tsx`, `pages/integrate.mdx`, `pages/contribute.mdx`, `pages/beacon.mdx`.  
- `components/EditionBadge.tsx`, `VerifiedPopover.tsx`, `EditionSwitcher.tsx`, `LedgerList.tsx`.  
- `public/.well-known/cocivium-beacon.json` (build‑generated).

────────────────────────────────────────────────────────────────────────

## 13) Risks & mitigations
- **Drift between site and repo.** Build only from tags; show current git ref in Verify Panel.  
- **Over‑ornamentation.** Keep motifs in margins/backgrounds at low opacity, never in text areas.  
- **Verification fatigue.** Default a single compact “Verified ✓” badge; deeper details are one click.

────────────────────────────────────────────────────────────────────────

**Appendix A — Verify Panel (copy text)**
“Verified ✓  This page matches the ratified text (hash abc…123) signed by ed25519:AB12…  View the decision in the Ledger or verify locally with `shasum -a 256 file.pdf`.”

**Appendix B — Edition switcher states**
- Green ✓ (ceremonial/hash matched).  Blue • (canonical only).  Gray ○ (archived).  Yellow ⚠ (degraded).

**Appendix C — Accessibility checklist**
Landmarks, focus order, skip links, contrast, keyboard nav, readable line length, alt text on motifs as decorative.