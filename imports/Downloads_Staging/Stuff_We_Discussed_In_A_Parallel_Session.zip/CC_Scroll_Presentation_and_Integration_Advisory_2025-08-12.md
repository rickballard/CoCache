# Cognocarta Consenti (“The Scroll”) — Presentation & Integration Advisory v0.1
**Date:** 2025-08-12  ·  **Status:** Draft for discussion  ·  **Audience:** Editors, civic architects, design/dev

> Purpose.  Make the **CC Scroll** read like a timeless Constitution while preserving machine-verifiable integrity.  This document shows how to apply the **Document System Advisory** and the **Global Integration & Outreach Advisory** to the Scroll with a ceremonial look (marketing-first) and a canonical track (machine-first).


## 1) Editions and audiences (one text, two wrappers)
1. **Ceremonial Edition** (public/marketing).  Typographic gravitas, minimal chrome.  Web and print/PDF.  
2. **Canonical Edition** (source of record).  Plain Markdown with precise IDs and metadata.  Feeds the build system.  

**Rule:** The *text of the articles* is identical in both.  Differences are in framing, typography, and metadata carriage.


## 2) Visual stance for the Ceremonial Edition (marketing-first)
1. **Header:** none on first page.  Running heads on subsequent pages: left “Cognocarta Consenti”, right “Article {N}”.  
2. **Footer:** hairline, 10–15% gray.  Page number centered in small caps (e.g., “PAGE VII”).  
3. **Title page:** large small-caps title, centered.  Optional monochrome emblem.  No logos.  
4. **Type:** serif body with true small caps.  Oldstyle numerals preferred.  1.25–1.4 line height.  Wide inner margins.  
5. **Drop caps:** optional on the Preamble only.  Keep dignified, not decorative.  
6. **Symbols:** use classical marks sparingly — \u00A7 for section, \u00B6 for paragraph, † for footnotes.  No emojis.  
7. **Color:** black text.  Gray only for rules and footers (10–15%).  No brand palette inside the core text.


## 3) IDs and citations in the Ceremonial Edition
1. **Human ID (default):** “Art. II \u00A71 \u00B63 (a)”.  Use in headings and internal references.  
2. **Machine ID (CID):** “CC:A02.S01.C03.U01”.  Suppress in the body; place in the colophon/footer (see §5).  
3. **Anchors:** HTML/PDF use CID anchors for stability; human IDs are displayed text.  
4. **Cross-refs:** “See **Art. I \u00A73 \u00B67**.”  Avoid raw CIDs in public-facing copy.


## 4) What to *omit* from the Scroll’s public pages
1. **No congruence score badge on-page.** Compute it in CI, publish in the Transparency Report, not on the Scroll.  
2. **No signer key block on every page.** Keep signatures in the colophon and PDF metadata.  
3. **No process spec snippets.** The Scroll declares principles and powers; procedures live in **CoCivOp/CoCivProc**.  
4. **No vendor/platform names.** The Scroll is timeless.  Implementations belong to **CoCivImp**.


## 5) Ceremonial colophon (minimal, dignified, machine-verifiable)
Place a **three-line colophon** only on the **last page**.  9–10 pt, gray, monospace.  Example:

```
— EDITION: Ceremonial v1  ·  TEXT HASH: sha256:2f5e…9a1c  ·  DATE: 2025-08-12
— CANONICAL SOURCE: CC-The-Scroll_Canonical_v1.md  ·  CID RANGE: CC:A01–A12  ·  LEDGER: https://civium.cc/ledger/cc
— GIB: gl://cociv/CC@1|A01–A12|c3|sha256:2f5e…9a1c|sig:AB12CD34
```

**Notes.** Omit congruence here.  Put signatures (name, office, key) on a separate **Ratification & Amendments** page, not the colophon.


## 6) Canonical Edition (source-of-record)
**Filename:** `CC-The-Scroll_Canonical_v1_2025-08-12.md`  
**Header:** keep the *official* header/footer from the Document System Advisory (CID, coherence, congruence, hash, gib).  
**Body headings:** show both IDs in the first occurrence per article, then human IDs only.

Example canonical heading:
```
## Art. II \u00A71 \u00B63 (a) — Due Process
<small>cid: CC:A02.S01.C03.U01</small>
```


## 7) Metadata carriage (PDF, web, source)
1. **PDF (Ceremonial):** embed XMP metadata fields for CID range, canonical source hash, gibberlink, and signers.  Prefer PDF/A-2b.  
2. **Web reader:** include `meta` tags for CID range and gib.  Provide deep links with CID anchors.  
3. **Source:** canonical Markdown stores the normative header/footer and feeds the build.  Build emits the ceremonial PDF and the web pages.


## 8) Integration with the global beacons
1. **/.well-known/cocivium-beacon.json** lists the *current ceremonial edition* URL and the *canonical source* hash.  
2. **DNS TXT** includes a pointer to the Scroll and DID.  
3. **Ledger:** every new edition gets a ledger entry with signer VCs and the PDF + Markdown hashes.


## 9) Amendments and editions
1. **Amendments live in the Scroll.** Each amendment appends an **Amendments** section, with human IDs and back-links to ratifying decisions in the Ledger.  
2. **Edition policy:** *v1* stays until a ratified amendment requires repagination.  Minor clerical fixes update the **Canonical Edition** only (v1.0.1), and regenerate the ceremonial PDF with a new hash but unchanged edition mark on the title page if the *text* is unchanged.  
3. **Redlines:** publish separate comparative PDFs for amendments.  Never clutter the Scroll with tracked changes.


## 10) Accessibility & internationalization
1. **WCAG 2.2 AA.** Sufficient contrast; real text, not images.  Landmark roles.  
2. **Language tags.** `lang="en"` on HTML.  Provide translation slots that preserve human IDs and CID anchors.  
3. **Alt text.** Any emblem has a neutral alt text like “Civium emblem (decorative)”.


## 11) Deliverables (what to produce)
- `Foundational-Charter/CC-The-Scroll_Canonical_v1_2025-08-12.md`  
- `Foundational-Charter/CC-The-Scroll_Ceremonial_v1_2025-08-12.pdf`  
- `Foundational-Charter/Ratification-and-Amendments_v1.md`  
- Build scripts to emit ceremonial PDF (print CSS + XMP), update beacons, write ledger entry.


## 12) Minimal print & web styles (starter)
**Print CSS tokens (suggested):**
```
@page { size: letter; margin: 28mm 22mm; }
h1, h2, h3 { font-variant-caps: small-caps; letter-spacing: 0.03em; }
body { line-height: 1.35; hyphens: auto; }
hr.rule { border: none; border-top: 0.5px solid #999; opacity: .5; }
footer { color: #666; font-family: ui-monospace, Menlo, Consolas, monospace; font-size: 9.5pt; }
```
**Web reader notes:** progressive enhancement only.  No JS required for reading.  CID anchors in fragment identifiers.


## 13) Rollout steps (cheap, safe)
1. Approve the **two-edition model**.  Freeze the canonical Markdown and feed it to the build.  
2. Generate the ceremonial PDF with the minimal colophon and running heads.  
3. Update **/.well-known**, DNS TXT, and the Ledger with hashes and gibberlink.  
4. Publish a brief **Editor’s Note** explaining the editions and where to verify authenticity.


## 14) Sample ceremonial title block (for designers)
```
COGNOCARTA CONSENTI
— THE FOUNDATIONAL CHARTER OF COCIVIUM —
Ratified by the Founding Assembly, 2025-08-12
```


## 15) Risks & mitigations
- **Risk:** Marketing edits drift from the canonical text.  **Mitigation:** treat canonical Markdown as the single source; all PDFs/Web derived only by build.  
- **Risk:** Over-technical footers spoil the tone.  **Mitigation:** keep a *three-line* colophon on the last page only; move details to metadata and Ledger.  
- **Risk:** Broken links over time.  **Mitigation:** CID anchors + ledger permanence; never change anchors across editions.


---

### Appendix A — Ceremonial colophon template (pasteable)
```
— EDITION: Ceremonial v1  ·  TEXT HASH: sha256:{…}  ·  DATE: {YYYY-MM-DD}
— CANONICAL SOURCE: CC-The-Scroll_Canonical_v1.md  ·  CID RANGE: CC:A01–A12  ·  LEDGER: https://civium.cc/ledger/cc
— GIB: gl://cociv/CC@1|A01–A12|c3|sha256:{…}|sig:{…}
```

### Appendix B — Canonical header/footer reminder
Keep the full metadata (CID/coherence/congruence/hash/gib) in the canonical Markdown.  CI recalculates congruence and hash on change and fails the build on mismatch.

### Appendix C — Ratification page scaffold
- Preamble certification line.  
- Signers table (name, role, jurisdiction, VC link).  
- Ratification vote reference (ledger link).  
- Amendment log with dates and CID anchors.