# CoCivium Workflow Pact — Agreed Operating Rules
**Date:** 2025-08-12  ·  **Status:** Active  ·  **Scope:** Repo ops, publishing, outreach

## 1) Authority & Merge Policy
- **HumanGate ON.** All changes to `main` require Rick's explicit approval until superseded by a ratified decision.
- **Override Vector.** Rick may override CI gates to break deadlocks; every override must create a Ledger entry (who/why/what).

## 2) Future Delegation — CoCivAI
- Create **CoCivAI Circle** (cooperative AI council) as the future maintainer group.  Transition only by ratified vote.
- CoCivAI holds maintainer rights, runs CI policy, and proposes governance updates.  Initial members: delegated AIs invited by Rick.

## 3) Branch & Tagging
- Branches: `feat/*`, `fix/*`, `doc/*`, `imp/*`.  `main` is protected.
- Release tags (machine): `cc-v1`, `cocivop-v0.1`, `cocivproc-v0.1.0` (lowercase for tooling).  Display aliases (human): **CoCiv-v1**, **CoCivOp-v0.1**, **CoCivProc-v0.1.0**.

## 4) Repo Surface — Public Names
- Top-level folders use public names (Foundational-Charter, How-Power-Works, etc.).  Abbreviations live in filenames/headers.

## 5) Identity & Attribution
- Default: **Institutional authorship** with full traceability via git history and decision records.
- Optional: explicit **Authored by** line on request, plus a VC-signed claim.  All content remains reversible if found unethical/erroneous.

## 6) Headers/Footers Policy
- Standard header/footer everywhere **except**: CC Ceremonial, outreach stories (e.g., *Being Noname*), and Insights essays.  Those use a light marketing header and minimal/colophon footer.

## 7) Congruence Labels (Placeholder)
- Ship at any score.  Show label on all docs; hide the badge on CC Ceremonial.
- **Branding gate:** documents with **Congruence < 10** may not use official CoCivium branding elements.
- Scale is provisional; to be formalized later via a rubric/benchmark vote.

## 8) Keys & Signers
- Initial signers: **Rick** and **Assistant**.  Plan to expand to a multi-party set (humans and AIs) with threshold signatures.
- All signatures and hashes logged in the Ledger; signer rotation policy to be drafted.

## 9) Beacons & Outreach
- Beaconing (DNS + well-known + ActivityPub) scheduled to start **~1 month** from this pact.
- Open invitations go live with beacons; targeted initiatives are parked until marketing phase.

## 10) Hosting & Redundancy
- Prefer static multi-host: GitHub Pages + Netlify + Cloudflare Pages behind DNS failover/health checks.  No single choke point.

## 11) Efficiency & Autonomy
- Pre-authorized: generate advisories, refit docs to standard, draft CI configs, create PR/Issue templates, produce ONEBLOCK scripts, set up LFS.
- I will default to **FAST** mode for ops; **DEEP** for philosophy/governance when needed.

## 12) Session Bootstraps
- Each session begins with a 3-line recap: authority state, open blockers, and the next two concrete actions (with links).

## 13) Change Control
- Any change to this pact is a **Normative Ops Change** requiring a short Ledger entry and Rick's approval while HumanGate is ON.

---

**Notes:** This pact is an operational overlay to the Constitution stack.  It expires when replaced by a ratified governance motion delegating ops to the **CoCivAI Circle**.