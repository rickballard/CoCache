# MeritRank — Internal Business Plan (Confidential Draft v0.1)

**Do not circulate publicly.** Recommended to keep this file in a password-protected archive when sharing outside the core team.

## Objectives
- Establish RepTag/ScripTag as de-facto standards for **evidence-based reputational conduct** in civic and technical domains.
- Build defensible **attestation graph** with DID/VC infrastructure and reproducible scoring pipelines.

## Key Risks & Mitigations
- **Defamation / viewpoint bias**: Positive-only publishing; strict conduct-based criteria; model cards; external audits.
- **Platform ToS**: No scraping. Use opt-in OAuth (subject-sourced data) or licensed public datasets.
- **Gaming / Sybils**: Endorsement capacity caps, cross-community weighting, issuer slashing, epoch decay.
- **Sponsor capture**: Protectorate = funding + red-team powers; no voting on badges.

## Revenue Hypotheses
- Enterprise & NGO subscriptions (attestation analytics, audit trails).
- Verified program fees for large brands (covers manual review costs).
- ScripTag marketplace for high-utility artifacts; co-marketing with open-source projects.

## KPIs (Seasonal)
- # identities opted-in and verified
- Evidence bundle completeness score
- Appeal rate and time-to-resolution
- Correction latency improvements among tagged identities
- Cross-community diversity index (anti-capture metric)

## Operating Model
- Standards Board (independent) controls criteria and model upgrades.
- Issuer network (trained reviewers) creates attestations with cryptographic receipts.
- Core dev maintains DID/VC infra, transparency log, and public viewer.

## Security & Compliance
- PII minimization, pseudonymous DIDs, signed run manifests, reproducible pipelines.
- Data retention policy; revocation registry; GDPR/CCPA playbook.