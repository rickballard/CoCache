# MeritRank — Public Business Plan (v0.1)

**Purpose.** Reward and surface identities (brands/microbrands/personas) that demonstrate **evidence-based, pro-social online conduct**.
Badges (RepTags) are **positive-only** attestations backed by transparent evidence.

**Positioning.**
- Not a "people rating" site. It publishes *conduct badges* tied to identity handles (DIDs) with **cited evidence**.
- Neutral to ideology. Criteria are about **information hygiene** and **civic conduct**, not politics.
- Tamper-evident transparency: attestation hashes anchored to a public log; full evidence stored off-chain with content hashes.

**Initial Products.**
1. **RepTag**: Evidence-linked badges across dimensions (Truth Alignment, Evidence Hygiene, Civic Conduct, Anti-Manipulation, Amplification Quality).
2. **ScripTag**: Contributor badges for high-quality **scripts, SOPs, and reproducible artifacts**; emphasizes technical utility and reusability.
3. **MeritRank (working)**: Governance/voting for seasonal awards and standards updates; voters must hold a verified RepTag (or equivalent DID proof).

**Go-To-Market.**
- **Opt-in pilots**: 50–200 identities across research, journalism, open-source, civic-tech.
- **Attestation drives**: OAuth connections to own accounts (e.g., LinkedIn, GitHub) to import **recommendations, commits, PRs, citations**.
- **Awards**: Annual **RepTag Merits**; seasonal leaderboards by *practice*, not person.

**Data & Legal.**
- No adversarial scraping of platforms under restrictive ToS (e.g., LinkedIn). Use **subject-consented** API pulls or **public-with-license** datasets.
- No "blacklists". Absence of a RepTag ≠ negative assessment.
- Appeals, transparency reports, model cards published each epoch.

**Business Model (phased).**
- Phase 1: Philanthropic/Protectorate sponsorship; open standards + public viewer.
- Phase 2: Pro features: audit APIs, enterprise attestations, compliance dashboards.
- Phase 3: Ecosystem marketplace for evidence kits, audits, training, and ScripTag artifacts.

**Moats.** Standards governance + evidence graph + transparent methodology + community endorsement capacity.

**Roadmap (first 3 months).**
- Month 1: Standards v1, threat model, DID/VC plumbing, transparency log prototype.
- Month 2: Pilot with manual adjudication; public viewer; first seasonal compute.
- Month 3: Awards; endorsement caps; light automation for evidence hygiene.