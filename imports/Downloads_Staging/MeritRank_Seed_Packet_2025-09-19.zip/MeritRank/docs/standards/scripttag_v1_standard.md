# ScripTag Standard v1 (Draft)

## Purpose
Badge identities for **high-utility, reproducible scripts/process artifacts** with clear licensing and documentation.

## Criteria
- Reproducibility (steps, versions, dependencies)
- Safety (resource and data handling)
- Licensing clarity (SPDX)
- Evidence of real-world use (issues, PRs, citations)

## Issuance
- Signed attestation with links to repositories/releases and a minimal SBOM or dependency manifest.