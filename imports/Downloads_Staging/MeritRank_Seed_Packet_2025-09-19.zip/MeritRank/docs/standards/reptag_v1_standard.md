# RepTag Standard v1 (Draft)

## Scope
Evidence-backed, **positive-only** conduct badges tied to an identity DID.

## Dimensions
1. Truth Alignment
2. Evidence Hygiene
3. Civic Conduct
4. Anti-Manipulation
5. Amplification Quality

Each attestation references **evidence bundles** (URIs + content hashes) and a **model_version** used to compute a score contribution.

## Issuance
- Issuers must hold an **Issuer VC** and accept slashing if a claim is overturned.
- Attestations are signed JSON objects; hashes appended to a transparency log (periodically anchored to L2).

## Revocation & Appeals
- Revocation pointer included in each claim; appeals are time-boxed with public outcomes logged.
- Seasonal recompute with half-life decay; endorsement capacity is sub-linear in prior reputation.

## Inclusion Policy
- Opt-in subjects, plus a narrow public-figure carve-out for positive-only publication.
- No blacklists; absence of badge is not a negative signal.