# MeritRank (working name) — Seed Packet

This packet contains scaffolding for **RepTag**, **ScripTag**, and a minimal **MeritRank voting engine** concept.
It includes:
- Public-facing business plan (for the MeritRank repo)
- v1 standards drafts for RepTag and ScripTag
- JSON claim schema + example Verifiable Credential (VC) for attestations
- Session plan & checklist (for CoCache)
- A PowerShell bootstrap script to create folders, copy files, and initialize a Git repo

**Date:** 2025-09-19

## Contents
- `MeritRank/docs/business_plan_public.md`
- `MeritRank/docs/standards/reptag_v1_standard.md`
- `MeritRank/docs/standards/scripttag_v1_standard.md`
- `MeritRank/specs/claim_schema.json`
- `MeritRank/specs/attestation_vc_example.json`
- `CoCache/ops/session_plans/2025-09-19_meritrank_stage.md`
- `Setup-MeritRank.ps1`

## How to use
1. Download and unzip this packet.
2. Run `Setup-MeritRank.ps1` in PowerShell 7 to stage a local repo under `Documents\GitHub\MeritRank` (or change the path).
3. Commit and push to GitHub.
4. Drop the CoCache session plan into your `CoCache` repo at `ops/session_plans/`.

> Note: The internal business plan is included as `MeritRank/docs/business_plan_internal.md`.
> If you require a password-protected archive, use 7-Zip locally (see instructions inside the session plan).