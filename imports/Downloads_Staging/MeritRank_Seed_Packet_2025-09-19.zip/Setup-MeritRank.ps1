param(
  [string]$RepoRoot = "$HOME\Documents\GitHub\MeritRank",
  [string]$CoCacheRoot = "$HOME\Documents\GitHub\CoCache"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# Create folders
$paths = @(
  Join-Path $RepoRoot 'docs',
  Join-Path $RepoRoot 'docs\standards',
  Join-Path $RepoRoot 'specs'
)
$paths | ForEach-Object { New-Item -ItemType Directory -Force -Path $_ | Out-Null }

# Copy docs from current directory if present
$here = Get-Location
$files = @(
  'MeritRank\docs\business_plan_public.md',
  'MeritRank\docs\business_plan_internal.md',
  'MeritRank\docs\standards\reptag_v1_standard.md',
  'MeritRank\docs\standards\scripttag_v1_standard.md',
  'MeritRank\specs\claim_schema.json',
  'MeritRank\specs\attestation_vc_example.json'
)
foreach ($f in $files) {
  $src = Join-Path $here $f
  $dst = Join-Path $RepoRoot ($f -replace '^MeritRank\\','')
  Copy-Item -Path $src -Destination $dst -Force
}

# Initialize repo if not already
if (-not (Test-Path (Join-Path $RepoRoot '.git'))) {
  git -C $RepoRoot init
  git -C $RepoRoot branch -M main
  Set-Content -Path (Join-Path $RepoRoot 'README.md') -Value "# MeritRank (working)\n\nPublic materials for RepTag/ScripTag and voting engine research."
}

# Standard OSS files
Set-Content -Path (Join-Path $RepoRoot 'CODE_OF_CONDUCT.md') -Value "# Code of Conduct\n\nBe excellent to each other."
Set-Content -Path (Join-Path $RepoRoot 'CONTRIBUTING.md') -Value "# Contributing\n\nOpen issues, submit PRs. Follow standards."
Set-Content -Path (Join-Path $RepoRoot 'SECURITY.md') -Value "# Security Policy\n\nReport vulnerabilities via security@example.org."

# Add/commit
git -C $RepoRoot add .
git -C $RepoRoot commit -m "chore: seed MeritRank repo with business plan, standards, and specs"

# CoCache session plan
$sessionPlanSrc = Join-Path $here "CoCache\ops\session_plans\*"
$sessionPlanDst = Join-Path $CoCacheRoot "ops\session_plans"
New-Item -ItemType Directory -Force -Path $sessionPlanDst | Out-Null
Copy-Item -Path $sessionPlanSrc -Destination $sessionPlanDst -Force

Write-Host "Seed complete. Review, then push to GitHub with: git -C `"$RepoRoot`" remote add origin <URL>; git -C `"$RepoRoot`" push -u origin main"