---
title: "MeritRank / RepTag / ScripTag — Session Plan"
date: 2025-09-19
status: active
owner: Rick
---

## Scope
Stand up a public-facing MeritRank repo (working name) containing the public business plan and standards drafts; establish DID/VC claim schema; launch a pilot intake for opt-in identities. Manage bloat with a clear checklist and deliverables cadence.

## Deliverables
- Public Business Plan in `MeritRank/docs/`
- Standards v1 drafts for RepTag & ScripTag
- Claim schema (JSON) + example VC
- Transparency log design brief (append-only; L2 anchors)
- Pilot SOP for opt-in evidence intake
- Awards plan (RepTag Merits — seasonal/annual)
- Governance note: Protectorate funding, independent Standards Board

## Legal/Compliance Notes
- No scraping LinkedIn or other platforms in violation of ToS. Use **OAuth** or **user-uploaded exports** (e.g., LinkedIn data export) with explicit consent.
- Publish **positive-only** badges; no blacklists; clear appeals pathway.
- Keep PII off-chain; use DIDs; evidence stored off-chain with content-address hashes.

## Checklist
- [ ] Create GitHub repo `MeritRank` (public)
- [ ] Commit public business plan and standards
- [ ] Add `CODE_OF_CONDUCT.md`, `SECURITY.md`, `CONTRIBUTING.md`
- [ ] Define DID method(s) supported (did:web + did:key initial)
- [ ] Build claim registry (Postgres) and transparency log prototype
- [ ] Draft pilot intake form + OAuth scopes (self-attested evidence)
- [ ] Draft Awards rubric and seasonal cadence
- [ ] Publish methodology & model card
- [ ] Set up appeals workflow & SLAs

## Password-Protected Internal Packet
Use **7-Zip** (local) to create an encrypted archive for `business_plan_internal.md` if distributing:
```
7z a -t7z -pYOURPASSWORD -mhe=on Internal_MeritRank_2025-09-19.7z "docs\business_plan_internal.md"
```

## Bootstrap
Run `Setup-MeritRank.ps1` from the seed packet to lay down structure and initialize the repo.