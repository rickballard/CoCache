Set-StrictMode -Version Latest
$Repo     = Join-Path $env:USERPROFILE 'Documents\GitHub\Godspawn'
$GlossDir = Join-Path $Repo 'HH\gloss'
$GibOut   = Join-Path $Repo 'HH\gibexport'
$Scroll   = Join-Path $GibOut 'gib_scroll_HH_terms.md'

# Ensure output dir exists
New-Item -ItemType Directory -Force -Path $GibOut | Out-Null

# Clear prior scroll
Remove-Item $Scroll -ErrorAction SilentlyContinue
'' | Out-File $Scroll -Encoding UTF8

# Regex to match YAML header
$yamlRegex = [regex]'(?s)^---\s*(.*?)\s*---'

# Process each .md file
Get-ChildItem $GlossDir -Filter *.md | ForEach-Object {
  $in  = $_.FullName
  $out = Join-Path $GibOut $_.Name
  $base = $_.BaseName

  $raw = Get-Content $in -Raw

  # Inject export_to_gibindex: true if missing
  if ($raw -notmatch '^\s*export_to_gibindex\s*:\s*true') {
    $match = $yamlRegex.Match($raw)
    if ($match.Success) {
      $header = $match.Groups[1].Value.Trim()
      $newHeader = @"
---
$header
export_to_gibindex: true
---
"@
      $rest = $raw.Substring($match.Index + $match.Length)
      $final = "$newHeader`n$rest"
    } else {
      $final = $raw
    }
  } else {
    $final = $raw
  }

  # Save term
  $final | Out-File $out -Encoding UTF8

  # Append to stitched scroll
  "### $base`n" | Out-File $Scroll -Append -Encoding UTF8
  $final | Out-File $Scroll -Append -Encoding UTF8
  "`n---`n" | Out-File $Scroll -Append -Encoding UTF8
}

"[$(Get-Date -Format o)] Glossary stitched to $Scroll"