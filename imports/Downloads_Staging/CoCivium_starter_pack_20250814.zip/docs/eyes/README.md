# Eyes Assets

- `docs/img/mission_eye.svg` — Quarterly, mission-facing metrics.
- `docs/img/credibility_eye.svg` — Credibility + risk pips.
- Source data in `/metrics/*.toml`. Renderer in `/tools/render_eyes.py`. Weekly GitHub Action updates assets.
