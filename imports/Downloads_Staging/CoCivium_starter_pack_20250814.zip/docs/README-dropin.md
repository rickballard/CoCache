<p align="center">
  <img src="docs/img/mission_eye.svg" alt="Mission Eye" width="45%" />
  <img src="docs/img/credibility_eye.svg" alt="Credibility Eye" width="45%" />
</p>
<p align="center">
  <a href="docs/decisions/"><img src="docs/img/concord_mark.svg" alt="Concord Mark" height="28"/></a>
</p>
