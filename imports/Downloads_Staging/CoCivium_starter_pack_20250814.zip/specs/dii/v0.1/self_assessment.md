# DII Self-Assessment Report

- **Organization:** 
- **Assessor:** 
- **Date:** 

## Scores (0–100 with bands)
- Transparency: 
- Consentfulness: 
- Inclusivity & Access: 
- Redress & Appeals: 
- Procedural Rigor: 
- Execution Traceability: 
- **Weighted Total (DII):** 

## Evidence Index
List URLs/files supporting checked items.

## Notes & Remediations
Short notes and next steps.
