# Decision Integrity Index (DII) — v0.1

Self-assessment rubric with receipts. Evidence links are mandatory. Scores without receipts are marked **Unverified**.

- Spec: `dii.yml`
- How-to: Fill the checklist, link evidence, commit report. Optionally request verification.
