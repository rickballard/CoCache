# CoCivium Lab (Temporary, within repo)

Temporary workspace during the grand migration. Treat as staging. Artifacts promoted to public locations only when stable. No secrets/personal data. After migration, this content moves to a separate private org.
