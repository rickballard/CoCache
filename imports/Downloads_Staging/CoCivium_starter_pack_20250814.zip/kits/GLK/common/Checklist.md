# Launch Checklist — v0

- [ ] Add `Decision Log` scaffold and link it in README.
- [ ] Add `Concord Mark` with link to first decision log.
- [ ] Set objection window policy (e.g., 72 hours) and quorum.
- [ ] Adopt `Guardrails.md` and store in repo/docs.
- [ ] Enable Decision Log Linter (GitHub Action). Fix any failures.
