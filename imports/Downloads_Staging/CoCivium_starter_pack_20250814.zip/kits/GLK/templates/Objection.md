# Objection

## Summary
A crisp 1–2 sentence statement of the objection.

## Impact
What goes wrong if we ignore this? Be concrete.

## Mitigation
Specific steps we can take to eliminate or reduce the risk.

## Evidence
Links to sources supporting the objection.

## Status
Open / Mitigated / Withdrawn. Link to decision log entry when resolved.
