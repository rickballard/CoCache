# CoCivSecOps — Civic Threat Patterns v0.1

Catalog patterns that subvert consentful governance. Submit PRs with receipts.

1. Astroturf Petition Flood
2. Quorum Raid
3. Agenda Waterfall (bury the lede)
4. Minutes Tamper
5. Rule-Lawyering to Delay
6. Straw-Poll Ambush
7. Procedural Overload (paper cuts)
8. Out-of-Band Lobbying
9. Sockpuppet Amplification
10. Identity Confusion (who is a member?)
11. Vote Dilution via New Members
12. Silence as Consent Trap
13. Framing Bias in Proposals
14. Appeal as Stalling Tactic
15. Evidence Withholding
16. Selective Transparency
17. Meeting Time Gatekeeping
18. Red-Herring Alternatives
19. Execution Drift (bait-and-switch)
20. “Emergency” Powers Overreach
