# Concord Mark — Usage

Add this badge where you publish decisions (README, website). Link it to your Decision Log index. Only use the mark if you have at least one published decision with evidence.

Example Markdown:
[![Concord Mark](docs/img/concord_mark.svg)](docs/decisions/)
