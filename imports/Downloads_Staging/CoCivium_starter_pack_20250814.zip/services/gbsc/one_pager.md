# GroupBuild Sprint Consulting (GBSC)

Two 90-minute sessions to ship your first Decision Log entry, a minimal charter delta, role prompts, and guardrails. Price: $4,500 flat. Deliverables: decision entry with evidence, charter delta, prompt playbook + guardrails, next-two decisions plan.

**Date:** 2025-08-14
