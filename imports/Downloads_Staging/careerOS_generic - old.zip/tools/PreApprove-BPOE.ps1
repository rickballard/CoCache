param([switch]$Approve,[switch]$Reject)
Write-Host 'BPOE stub. Use -Approve or -Reject.'
