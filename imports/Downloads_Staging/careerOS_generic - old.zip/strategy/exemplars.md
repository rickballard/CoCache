🌈 SAMPLE

# Role Exemplars & Salary Intel (Sample)
