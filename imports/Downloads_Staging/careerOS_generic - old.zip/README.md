# careerOS — Generic Edition (Rainbow Sample)

(See email_instructions_part1.txt for steps.)
