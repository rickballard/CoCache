# Safe test: explicit no-op with success code
$ErrorActionPreference = 'Stop'
Write-Host "=== E_NoOp.ps1 ==="
exit 0
