# Safe test: prints environment info and exits
$ErrorActionPreference = 'Stop'
Write-Host "=== A_HelloWorld.ps1 ==="
Write-Host "Hello from PS7 Drag Test."
Write-Host ("PSVersion: {0}" -f $PSVersionTable.PSVersion.ToString())
Write-Host ("Host: {0}" -f $Host.Name)
Write-Host ("CWD: {0}" -f (Get-Location))
Write-Host "Args:" ($args -join ', ')
