# Safe test: shows whether partial pastes matter (has small delay)
$ErrorActionPreference = 'Stop'
Write-Host "=== B_HelloAndWait.ps1 ==="
Write-Host "Starting..."
Start-Sleep -Seconds 2
Write-Host "Done."
