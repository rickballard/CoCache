PS7 Drag Test Kit (no-repo-impact)
----------------------------------
Purpose: Safely test drag-and-drop of scripts and observe behavior.
All scripts are no-op or print-only.

Scripts
- A_HelloWorld.ps1   : Prints environment info. No side effects.
- B_HelloAndWait.ps1 : Prints, waits 2 seconds, prints again. No side effects.
- C_EchoArgs.ps1     : Prints the arguments it received (useful for drag vs manual run).
- D_LongOutput.ps1   : Prints 200 lines to test buffer/scroll behavior.
- E_NoOp.ps1         : Prints a marker and exits 0.

How to use (examples)
1) Drag a script file into PS7 to paste its full path (safe insert, not auto-run).
2) Press Enter to run, or call explicitly:
     & .\A_HelloWorld.ps1
3) To pass arguments:
     & .\C_EchoArgs.ps1 "alpha" "beta with spaces"

Notes
- None of these scripts change files, repos, or settings.
- If Execution Policy blocks running local scripts, you can run once per session:
     Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
