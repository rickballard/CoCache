# Safe test: prints many lines to test buffer/scroll behavior
$ErrorActionPreference = 'Stop'
Write-Host "=== D_LongOutput.ps1 ==="
1..200 | ForEach-Object { Write-Host ("Line {0:000}" -f $_) }
Write-Host "=== END ==="
