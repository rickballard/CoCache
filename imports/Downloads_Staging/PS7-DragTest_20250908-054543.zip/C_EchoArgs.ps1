# Safe test: shows exactly what args were passed via drag vs manual run
$ErrorActionPreference = 'Stop'
Write-Host "=== C_EchoArgs.ps1 ==="
if ($args.Count -eq 0) {
  Write-Host "No args provided."
} else {
  Write-Host ("Args ({0}): {1}" -f $args.Count, ($args -join ' | '))
}
