## Self-evolution (transparent schedulers)

- **Bi-monthly check-ins:** Issues auto-open on the 1st and 15th (UTC).  
- **Monthly email (optional):** Configure secrets to receive a link to your repo’s Issues.  
- **Local prompts (optional):** Use `tools/Schedule-LocalPrompt.ps1` with Task Scheduler.

See `docs/automation.md` for details and setup.
