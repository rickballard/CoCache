---
title: "Open reflection — YYYY-MM-DD"
labels: ["reflection"]
---

Use this thread for free-form notes; paste links, thoughts, or screenshots.
