---
doc: {family: read, name: bpoe-wisdom-snippets}
version: v0.1
immutability: {grade: stable, rule: "edit-w/pr"}
provenance: {origin: human, assembled_from: []}
status: active
---

# BPOE Wisdom Snippets (Human-Limits Playbook)

## Snippet: Yellow-Flag (Self-Report)
```
Status: YELLOW
Reason: <fatigue/overwhelm/health>
Action: Slowing to safe cadence. Seeking backup for <area>.
ETA for recheck: <date/time>
```

## Snippet: Handoff Note (PR Comment)
```
HANDOFF
Context: <what changed, why>
State: <tests, staging/prod status, known issues>
Rollback: <exact command / steps>
Owner (primary/backup): <names/handles>
Next checkpoint: <date/time>
```

## Snippet: Cool-Down Window (Release Checklist)
- [ ] 30–60 min cool-down after deploy
- [ ] Passive monitors only (no rapid churn)
- [ ] Prewritten rollback verified
- [ ] Post-deploy note filed

## Snippet: Rest Block (Calendar / Issue)
```
REST BLOCK
From–To: <start> – <end> (local time)
Coverage: <name of backup>
Escalation: <how to reach, when>
```

## Snippet: PR Template (Safety & Reversibility)
```
## Why
## What changed
## Risk level (Low/Med/High)
## Reversibility (One-command rollback: <cmd>)
## Rollback verified? (y/n)
## Backup maintainer
```
