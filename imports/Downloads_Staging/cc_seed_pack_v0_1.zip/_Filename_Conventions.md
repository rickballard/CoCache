---
doc: {family: read, name: filename-conventions}
version: v0.1
immutability: {grade: stable, rule: "edit-w/pr"}
provenance: {origin: human}
status: active
---

# Repository Filename Conventions

## Canon (immutable)
Pattern: `.canon.<Title>_vMAJOR.MINOR.md`  
Rule: **no in-place edits**. Publish a successor file to change canon.

## CC Components
Pattern: `.cc.<Component>_vMAJOR.MINOR.md`  
Rule: evolve via PR; bump MINOR when text shifts, MAJOR when meaning shifts.

## Highlighted Readables
Pattern: `read/.hl.<slug>_YYYY-MM-DD.md`  
Rule: audience-first, stable URLs.

## Working Notes
Pattern: `work/.note.<topic>_YYYYMMDD_HHMM.md`  
Rule: squashable; may be archived or summarized later.

## Front-Matter (all docs)
```yaml
doc: {family: canon|cc|read|note, name: <short-id>}
version: vX.Y
immutability: {grade: canon|stable|draft, rule: "no-edit|edit-w/pr|free"}
provenance: {origin: human|assembled, assembled_from: []}
status: active|deprecated|superseded
```
