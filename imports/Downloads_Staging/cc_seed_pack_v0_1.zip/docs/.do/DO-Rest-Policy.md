# DO: Rest / Cool-Down Policy

**Trigger**: High-stakes deploy or fatigue signaled.  
**Action**: Enter cool-down window; ensure backup coverage.

Checklist:
- [ ] Yellow-flag self-report posted
- [ ] Cool-down window scheduled (30–60m)
- [ ] Rollback verified & posted
- [ ] Handoff note filed with next checkpoint
