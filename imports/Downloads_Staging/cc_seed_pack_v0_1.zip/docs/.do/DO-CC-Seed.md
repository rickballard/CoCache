# DO: CC Megascroll Seed / Update

**Trigger**: Add or update CC components.  
**Action**: Edit `.cc.CC_Megascroll_*.md` (MINOR bump if meaning unchanged).

Checklist:
- [ ] Provenance `assembled_from` updated
- [ ] New/changed anchors referenced
- [ ] PR template completed (risk, rollback, backup)
