# DO: Canon Change (Successor File)

**Trigger**: A principle meaning must change (not mere wording).  
**Action**: Create a *successor* `.canon.<Title>_vMAJOR.MINOR.md` with bumped MAJOR.

Checklist:
- [ ] New file created with incremented MAJOR
- [ ] Old file gains `status: superseded` note, links to successor
- [ ] PR states: reason for change, reversibility notes
