\
Param(
  [string]$Owner = "rickballard",
  [string]$QueryExtra = ""
)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'

function Gh-Search([string]$q){
  $cmd = @("gh","api","-X","GET","/search/code","-f","q=$q","-F","per_page=50")
  (& $cmd) | ConvertFrom-Json
}

$queries = @(
  "user:$Owner filename:.canon.* extension:md",
  "user:$Owner filename:.cc.* extension:md",
  "user:$Owner filename:BPOE_Wisdom_Snippets.md",
  "user:$Owner filename:_Filename_Conventions.md",
  "user:$Owner \"Cognocarta Consenti\" in:file"
)

if($QueryExtra){ $queries += $QueryExtra }

$results = foreach($q in $queries){
  $res = Gh-Search $q
  [PSCustomObject]@{
    query = $q
    count = ($res.items | Measure-Object).Count
    samples = ($res.items | Select-Object -First 5 -ExpandProperty path)
  }
}

$results | Format-List | Out-String | Set-Content -Encoding UTF8 -NoNewline "_overlap_scan.txt"
Write-Output "Wrote _overlap_scan.txt"
