\
Param(
  [string]$Owner = "rickballard",
  [string]$Repo  = "CoCivium",
  [string]$Branch = "docs/cc-seed",
  [switch]$DryRun
)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'

function Say([string]$m){ "{0}  {1}" -f (Get-Date -Format s), $m }

# 1) Overlap audit (local)
$patterns = @(
  "^\.canon\..+\.md$",
  "^\.cc\..+\.md$",
  "BPOE_Wisdom_Snippets\.md$",
  "_Filename_Conventions\.md$"
)
$localHits = Get-ChildItem -Recurse -File |
  Where-Object { $patterns | Where-Object { $_ -as [regex] -and ($_.Name -match $_) } } |
  Select-Object FullName, Name, Length

# 2) Overlap audit (remote via GitHub code search)
function Gh-Search([string]$q){
  $cmd = @("gh","api","-X","GET","/search/code","-f","q=$q","-F","per_page=50")
  $json = (& $cmd) | ConvertFrom-Json
  return $json.items | Select-Object -ExpandProperty path -ErrorAction SilentlyContinue
}
$queries = @(
  "user:$Owner filename:.canon.* extension:md",
  "user:$Owner filename:.cc.* extension:md",
  "user:$Owner filename:BPOE_Wisdom_Snippets.md",
  "user:$Owner filename:_Filename_Conventions.md",
  "user:$Owner \"Cognocarta Consenti\" in:file"
)
$remoteHits = foreach($q in $queries){ Gh-Search $q | ForEach-Object { @{ query=$q; path=$_ } } }

# 3) Write report
$report = @()
$report += "# CC Seed Overlap Report"
$report += ""
$report += "## Local matches"
$report += ($localHits | ForEach-Object { "- {0} ({1} bytes)" -f $_.FullName, $_.Length })
$report += ""
$report += "## Remote (user:$Owner) matches"
$report += ($remoteHits | ForEach-Object { "- `{0}` → {1}" -f $_.query, $_.path })
$report += ""
$reportPath = "_cc-seed-report.md"
$report -join "`n" | Set-Content -Encoding UTF8 -NoNewline $reportPath
Say "Wrote $reportPath"

# 4) If safe (no conflicting local canon/cc), stage seed files if missing
$files = @(
  ".canon.CoCivium_Principles_v0.1.md",
  ".cc.CC_Megascroll_Seed_v0.1.md",
  "BPOE_Wisdom_Snippets.md",
  "_Filename_Conventions.md",
  "docs/.do/DO-Canon-Change.md",
  "docs/.do/DO-CC-Seed.md",
  "docs/.do/DO-Rest-Policy.md"
)

$conflict = Test-Path ".canon.CoCivium_Principles_v0.1.md" -PathType Leaf -and (Select-String -Path ".canon.CoCivium_Principles_v0.1.md" -Pattern "CORE:HUMAN-LIMITS" -SimpleMatch)
$note = if($conflict){ "Canon exists; will not overwrite." } else { "Canon missing; will add seed." }
Say $note

# Copy pack files if target doesn't exist
$packRoot = "$(Split-Path -Parent $MyInvocation.MyCommand.Path)"
foreach($f in $files){
  $src = Join-Path $packRoot $f
  $dst = $f
  $dir = Split-Path -Parent $dst
  if($dir -and -not (Test-Path $dir)){ New-Item -ItemType Directory -Force -Path $dir | Out-Null }
  if(-not (Test-Path $dst)){
    Copy-Item -Path $src -Destination $dst -Force
    Say "Added $dst"
  } else {
    Say "Skipped (exists): $dst"
  }
}

if($DryRun){ Say "DryRun: not committing."; exit 0 }

# 5) Branch + PR
git checkout -b $Branch 2>$null | Out-Null
git add $files $reportPath
git commit -m "docs(cc): seed Megascroll; BPOE snippets; filename policy; overlap report"
gh pr create --fill --label docs,cc --base main
gh pr merge --squash --auto | Out-Null
Say "PR opened with auto-merge enabled."
