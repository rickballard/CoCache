param(
  [string]$RepoRoot = "$HOME\Documents\GitHub\MeritRank"
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$here = Get-Location

# Ensure repo exists
if (-not (Test-Path $RepoRoot)) {
  throw "RepoRoot '$RepoRoot' does not exist. Create/clone the MeritRank repo first."
}

# Create tools/docs/specs dirs if needed
$paths = @(
  Join-Path $RepoRoot 'tools',
  Join-Path $RepoRoot 'data\intake',
  Join-Path $RepoRoot 'data\evidence',
  Join-Path $RepoRoot 'docs\pipelines',
  Join-Path $RepoRoot 'specs'
)
$paths | ForEach-Object { New-Item -ItemType Directory -Force -Path $_ | Out-Null }

# Copy included files from this packet
$files = @(
  'tools\Scan-MeritRankRepos.ps1',
  'tools\Get-PublicIdentityFeeds.ps1',
  'tools\New-IdentityEvidenceVault.ps1',
  'specs\evidence_ingestion_manifest.json',
  'docs\pipelines\harvesting_pipeline.md',
  'docs\pipelines\identity_feed_catalog_example.csv'
)
foreach ($f in $files) {
  $src = Join-Path $here $f
  $dst = Join-Path $RepoRoot $f
  New-Item -ItemType Directory -Force -Path (Split-Path $dst) | Out-Null
  Copy-Item -Path $src -Destination $dst -Force
}

# Commit the changes
git -C $RepoRoot add .
git -C $RepoRoot commit -m "chore: add PS tools for repo scan + evidence harvesting + pipeline docs" | Out-Null

Write-Host "Installed tools to $RepoRoot. Next steps:"
Write-Host " 1) Run tools\Scan-MeritRankRepos.ps1 -Root '$HOME\Documents\GitHub' -OutDir (Join-Path $RepoRoot 'data\intake')"
Write-Host " 2) Edit docs\pipelines\identity_feed_catalog_example.csv and then run"
Write-Host "    tools\Get-PublicIdentityFeeds.ps1 -Catalog (Join-Path $RepoRoot 'docs\pipelines\identity_feed_catalog_example.csv') -OutDir (Join-Path $RepoRoot 'data\evidence')"