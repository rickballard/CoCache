<#
.SYNOPSIS
  Creates a local evidence vault for a public identity (handle/URL) with a DID stub and manifest.

.EXAMPLE
  .\New-IdentityEvidenceVault.ps1 -RepoRoot "$HOME\Documents\GitHub\MeritRank" -Handle "example@twitter" -Did "did:web:example.org:alice"
#>
param(
  [string]$RepoRoot = "$HOME\Documents\GitHub\MeritRank",
  [string]$Handle,
  [string]$Did
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if (-not $Handle) { throw "Handle is required." }
if (-not $Did)    { throw "DID is required." }

$slug = ($Handle -replace '[^a-zA-Z0-9\-_.]','_').ToLower()
$dir = Join-Path $RepoRoot "data\evidence\$slug"
New-Item -ItemType Directory -Force -Path $dir | Out-Null

$manifest = @{
  subject = @{
    handle = $Handle
    did = $Did
    created_utc = (Get-Date).ToUniversalTime().ToString("o")
  }
  evidence = @()
  notes = "Add evidence items via Get-PublicIdentityFeeds.ps1 or manual curation."
}

$manifest | ConvertTo-Json -Depth 10 | Set-Content -Path (Join-Path $dir "manifest.json") -Encoding utf8
Set-Content -Path (Join-Path $dir "README.md") -Value ("# Evidence Vault for {0}`n`n- DID: {1}`n- Handle: {2}" -f $slug, $Did, $Handle)

Write-Host "Created evidence vault at $dir"