<#
.SYNOPSIS
  Fetches public feeds (RSS/Atom or simple JSON endpoints) for listed identities and writes evidence entries.
  This tool avoids scraping restricted platforms. It works best with blogs, Substack, GitHub releases, YouTube RSS, etc.

.INPUT
  CSV with columns: handle,did,feed_url,platform

.EXAMPLE
  .\Get-PublicIdentityFeeds.ps1 -Catalog "docs\pipelines\identity_feed_catalog_example.csv" -OutDir "data\evidence"
#>
param(
  [string]$Catalog,
  [string]$OutDir = "$HOME\Documents\GitHub\MeritRank\data\evidence",
  [int]$MaxItemsPerFeed = 25
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if (-not (Test-Path $Catalog)) { throw "Catalog CSV not found: $Catalog" }

$rows = Import-Csv -Path $Catalog
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

function New-Hash([string]$s) {
  $bytes = [System.Text.Encoding]::UTF8.GetBytes($s)
  $sha = [System.Security.Cryptography.SHA256]::Create()
  $hash = $sha.ComputeHash($bytes)
  ($hash | ForEach-Object { $_.ToString("x2") }) -join ""
}

foreach ($r in $rows) {
  $handle = $r.handle
  $did    = $r.did
  $feed   = $r.feed_url
  if (-not $handle -or -not $did -or -not $feed) { continue }

  $slug = ($handle -replace '[^a-zA-Z0-9\-_.]','_').ToLower()
  $dir = Join-Path $OutDir $slug
  New-Item -ItemType Directory -Force -Path $dir | Out-Null

  try {
    $resp = Invoke-WebRequest -Uri $feed -UseBasicParsing -TimeoutSec 30
  } catch {
    Write-Warning "Failed to fetch $feed for $handle: $($_.Exception.Message)"
    continue
  }

  $content = $resp.Content

  # Basic RSS/Atom parse (very lightweight)
  [xml]$xml = $null
  $isXml = $false
  try { $xml = [xml]$content; $isXml = $true } catch {}
  $items = @()
  if ($isXml) {
    if ($xml.rss.channel.item) {
      $items = $xml.rss.channel.item
    } elseif ($xml.feed.entry) {
      $items = $xml.feed.entry
    }
  }

  $count = 0
  foreach ($item in $items) {
    if ($count -ge $MaxItemsPerFeed) { break }
    $title = $item.title.'#text'
    if (-not $title) { $title = $item.title }
    $link  = $item.link.href
    if (-not $link) { $link = $item.link }
    $pub   = $item.pubDate
    if (-not $pub) { $pub = $item.updated }

    $fingerprint = New-Hash("$handle|$link|$title")
    $ev = [pscustomobject]@{
      subject = @{
        handle = $handle; did = $did
      }
      uri = "$link"
      title = "$title"
      published = "$pub"
      content_hash = $fingerprint
      captured_utc = (Get-Date).ToUniversalTime().ToString("o")
      source = $feed
      platform = $r.platform
      dimensions_hint = @() # fill during review: EvidenceHygiene, TruthAlignment, etc.
    }
    $outPath = Join-Path $dir ("evidence_" + $fingerprint + ".json")
    $ev | ConvertTo-Json -Depth 6 | Set-Content -Path $outPath -Encoding UTF8
    $count++
  }

  Write-Host "Fetched $count items for $handle"
}

Write-Host "Done. Review evidence json files, then convert to attestations (VCs) using your claim schema."