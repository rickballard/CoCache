<#
.SYNOPSIS
  Scans local repos for mentions of MeritRank/RepTag/ScripTag/CoCivium/CoPolitic and emits a JSON + Markdown report.

.EXAMPLE
  .\Scan-MeritRankRepos.ps1 -Root "$HOME\Documents\GitHub" -OutDir "$HOME\Documents\GitHub\MeritRank\data\intake"
#>
param(
  [string]$Root = "$HOME\Documents\GitHub",
  [string]$OutDir = "$HOME\Documents\GitHub\MeritRank\data\intake"
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$terms = @(
  'MeritRank','RepTag','ScripTag','CoCivium','CoPolitic','CoCache','GIBindex','RepTag Merits','evidence hygiene','DID','Verifiable Credential'
)

$files = Get-ChildItem -Path $Root -Recurse -File -Include *.md,*.txt,*.ps1,*.json,*.yaml,*.yml,*.py,*.ts,*.tsx,*.js -ErrorAction SilentlyContinue

$results = @()
foreach ($file in $files) {
  try {
    $content = Get-Content -Path $file.FullName -Raw -ErrorAction Stop
  } catch {
    continue
  }
  foreach ($t in $terms) {
    if ($content -match [regex]::Escape($t)) {
      # capture surrounding context (first 240 chars around first match)
      $m = [regex]::Match($content, [regex]::Escape($t), 'IgnoreCase')
      if ($m.Success) {
        $start = [Math]::Max(0, $m.Index - 120)
        $len = [Math]::Min(240, $content.Length - $start)
        $snippet = $content.Substring($start, $len).Replace("`r"," ").Replace("`n"," ")
        $results += [pscustomobject]@{
          term = $t
          path = $file.FullName
          repo = (Split-Path -Leaf (Split-Path -Parent $file.FullName))
          snippet = $snippet
        }
      }
    }
  }
}

New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$jsonPath = Join-Path $OutDir ("repo_scan_" + (Get-Date -Format "yyyyMMdd_HHmmss") + ".json")
$mdPath   = Join-Path $OutDir ("repo_scan_" + (Get-Date -Format "yyyyMMdd_HHmmss") + ".md")

# Write JSON
$results | ConvertTo-Json -Depth 5 | Set-Content -Path $jsonPath -Encoding UTF8

# Write Markdown summary
$md = @("# MeritRank Related Mentions — Scan Report", "", "*Generated:* $(Get-Date -Format u)", "")
foreach ($group in $results | Group-Object repo | Sort-Object Name) {
  $md += "## $($group.Name)"
  foreach ($item in $group.Group) {
    $rel = $item.path
    $md += "- **$($item.term)** — `$rel` — …$($item.snippet)…"
  }
  $md += ""
}
$md -join "`n" | Set-Content -Path $mdPath -Encoding UTF8

Write-Host "Scan complete."
Write-Host " JSON: $jsonPath"
Write-Host "  MD : $mdPath"