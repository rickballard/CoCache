# Public Evidence Harvesting Pipeline (Non-Scraping, Consent-Friendly)

**Goal:** Accumulate usable, lawful evidence for RepTag/ScripTag while avoiding platform ToS violations and defamation risk.

## Sources (priority order)
1. **Subject-provided exports/APIs** (LinkedIn export, GitHub, Substack, personal blogs)
2. **Official public feeds** (RSS/Atom, YouTube channel RSS, GitHub releases/commits RSS)
3. **Licensed public datasets** and archived links (e.g., Archive.org snapshots) where permitted

## Process
1. **Catalog** identities in a CSV with `handle,did,feed_url,platform`.
2. Run `Get-PublicIdentityFeeds.ps1` to fetch items and create **evidence JSONs**.
3. Curators review evidence, tag **dimensions** (TruthAlignment, EvidenceHygiene, etc.).
4. Convert curated evidence into **attestations (VCs)** per `specs/claim_schema.json`.
5. Append hashes to the **transparency log**; store full evidence off-chain with content hashes.

## Notes
- No scraping of restricted platforms. Use OAuth or user-provided archives.
- Keep **PII off-chain**; use DIDs; allow opt-out except for narrow public-figure positive-only publication.
- Seasonal recompute with published **methodology and model versions**.