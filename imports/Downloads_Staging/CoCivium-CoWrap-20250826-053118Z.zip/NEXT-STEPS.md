# Next Steps (fast + low-risk)

## A) Fix .gitattributes via GitHub UI (no shell)
1. Open `.gitattributes` in the web UI.
2. Replace the entire file with:
   ```
   * text=auto
   *.md  text eol=lf
   *.ps1 text eol=lf
   ```
3. Commit directly to branch `docs/repo-map-workflows-250826-0025Z`.

## B) Run safe bootstrap locally (optional)
```
pwsh -NoProfile -ExecutionPolicy Bypass -File tools/safe-bootstrap.ps1
```
- Preflights git state, ensures docs placeholders, updates QUICK-NAV, and opens a PR if GitHub CLI is available.

## C) Enable IssueOps buttons
- Add/commit the files in this bundle under `.github/` and `docs/ISSUEOPS.md`.
- Then **click buttons in README or docs/ISSUEOPS.md** to trigger maintenance with zero paste.
