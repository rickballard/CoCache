# IssueOps

Click a button below in the **GitHub web UI** (do not paste these into PowerShell).

[![Run safe bootstrap](https://img.shields.io/badge/Run-safe--bootstrap-blue)](https://github.com/rickballard/CoCivium/issues/new?template=run-safe-bootstrap.yml&labels=issueops,op:safe-bootstrap&title=Run+safe+bootstrap)

[![Fix .gitattributes (LF)](https://img.shields.io/badge/Fix-.gitattributes%20(LF)-blue)](https://github.com/rickballard/CoCivium/issues/new?template=fix-gitattributes.yml&labels=issueops,op:fix-gitattributes&title=Fix+.gitattributes+(LF))

---

## How it works
- Submitting an issue with the `issueops` label kicks off `.github/workflows/issueops.yml`.
- The workflow commits changes and opens/updates a PR automatically.
