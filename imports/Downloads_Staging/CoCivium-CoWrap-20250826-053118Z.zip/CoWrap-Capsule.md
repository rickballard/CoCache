# CoWrap Capsule — CoCivium / RepoAccelerator / IssueOps

**Timestamp (UTC):** 2025-08-26 05:31:18Z

## Repo / Branch
- Repo: `rickballard/CoCivium`
- Working branch: `docs/repo-map-workflows-250826-0025Z` (ahead of origin)

## Done in this session
- Added: `tools/repo-accelerator/BACKLOG.md`
- Added: `docs/REPO-MAP.md`, `docs/WORKFLOWS.md`, `docs/ideas/INDEX.md`
- Added: `tools/safe-bootstrap.ps1` (idempotent, LF-only; updates QUICK-NAV and creates docs placeholders)
- Pushed branch; PR not yet opened

## Current Local State
- `git status -sb` shows: ahead 2, `M README.md` (unstaged change)
- `.gitattributes` error encountered earlier: `text*.md is not a valid attribute name: .gitattributes:13`

## Pain Points Observed
- Pasting YAML/Markdown/buttons into PS7 triggered parse errors (e.g., `name:` not recognized, `[` errors)
- A concatenation typo: `tools/safe-bootstrap.ps1pwsh` (missing space/newline)

## Goals (next tab)
1. Fix `.gitattributes` safely (rewrite + renormalize)
2. Decide: commit or drop pending `README.md` change
3. Add IssueOps buttons (click-to-run) so future fixes are zero-paste

## Quick Options
- **Web UI**: Edit `.gitattributes` via GitHub to:
  ```
  * text=auto
  *.md  text eol=lf
  *.ps1 text eol=lf
  ```
  Commit to `docs/repo-map-workflows-250826-0025Z`.
- **Local one-liner**: `pwsh -NoProfile -ExecutionPolicy Bypass -File tools/safe-bootstrap.ps1`

---

This capsule gives the new chat all the context needed without requiring command pastebacks.
