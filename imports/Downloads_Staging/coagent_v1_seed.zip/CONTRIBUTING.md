PRs welcome. Use conventional commits. Run linters and validate schemas before PR.
