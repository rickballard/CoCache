Report vulnerabilities to security@example.org. Default deny, least privilege, pin images by digest.
