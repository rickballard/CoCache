# Operating Constitution (placeholder)

Replace with the real operating constitution.
