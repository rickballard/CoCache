# Process Spec (placeholder)

Proposal → Deliberation → Vote → Execution.  Replace with real spec.
