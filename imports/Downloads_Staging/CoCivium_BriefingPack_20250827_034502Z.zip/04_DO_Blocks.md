# Lettered DO Blocks (session)

**A** — Create PR for already-pushed branch  
**B** — Commit REGISTRY.md to same branch  
**C** — Strip cache-buster from README hero quote link  
**D** — Print important Branch Protection bits  
**E** — Watch required checks then merge (blocked earlier by BP)  
**F** — Disable local custom hooks for this clone  
**G** — Create PR if missing; otherwise reuse existing one  
**H/H2/H3/H4** — Robustly poll required contexts; merge; temporarily toggle BP if needed; restore BP (schema-correct)  
**I** — Append REGISTRY links to docs/ideas/INDEX.md (uses `Add-Content -Value`)  
**J/J2** — Confirm & disable noisy advisory workflows (fix: state is **active**, not "enabled")  
**K** — Optionally re-enable PR labeler

_All advisory steps kept as non-blocking; only the two required checks block merges._
