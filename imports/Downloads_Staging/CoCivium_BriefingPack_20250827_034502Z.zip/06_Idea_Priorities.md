# Idea Priorities (first pass)

**P1 — Human Gating: targeted mobile notifications**  
- Why: reduces noise, speeds safe approvals, fits solo-to-small-team reality.  
- MVP: `/gate` comment → routes to right human; mobile approve/deny/route.

**P1 — Stable DO-block packaging & paste UX**  
- Why: reduces “leaky block” failures; safer multi-step pastes.  
- MVP: simple “pastepack” format + ready marker in rendered blocks.

**P2 — CoPong hard cap → temp-file ingestion**  
- Why: bypass UI limits for big blocks; improves devex immediately.  
- MVP: CoPongTempCache strategy + ONRAMP docs.

**P2 — Developer Onramp & Tutorial (poetic lead-in)**  
- Why: fastest way to onboard collaborators; establishes voice.  
- MVP: ONRAMP.md linked from README + CoPing/CoPong explainer.

**P3 — Press kit: free-use images folder**  
- Why: enables press/bloggers without heavy brand review.  
- MVP: assets/press/free-use/ + README (license/usage).

**P3 — CoAgent Kit starter course + YouTube shorts**  
- Why: growth loop later; defer until after core hygiene.

**P4 — Vision: Communal Mindspace (media-safe diagram)**  
- Why: north star communication; publish only after private review.

**P4 — Brand-canonical poetic lead-ins/outs**  
- Why: consistency; can follow after ONRAMP.

**P4 — Outreach to GitHub**  
- Why: useful but not urgent until repo narrative is crisp.
