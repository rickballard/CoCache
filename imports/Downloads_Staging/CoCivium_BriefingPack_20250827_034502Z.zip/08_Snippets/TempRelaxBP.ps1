# Temporarily clear required checks to unblock a merge, then restore.
param(
  [string]$Owner  = 'rickballard',
  [string]$Repo   = 'CoCivium'
)

$backup = gh api "repos/$Owner/$Repo/branches/main/protection"
$tmpBackup = New-TemporaryFile
[IO.File]::WriteAllText($tmpBackup,$backup,[Text.UTF8Encoding]::new($false))

$payload = @{
  required_status_checks = @{
    strict = $false
    checks = @()
  }
  enforce_admins = $true
  required_pull_request_reviews = $null
  restrictions = $null
  required_linear_history = $true
  allow_force_pushes = $false
  allow_deletions    = $false
  block_creations = $false
  required_conversation_resolution = $true
} | ConvertTo-Json -Depth 6

$tmp = New-TemporaryFile
[IO.File]::WriteAllText($tmp,$payload,[Text.UTF8Encoding]::new($false))
gh api -X PUT "repos/$Owner/$Repo/branches/main/protection" --input $tmp | Out-Null
Remove-Item $tmp -Force

Write-Host "Temporary relaxation applied. Merge, then restore with SetBranchProtection.ps1."
