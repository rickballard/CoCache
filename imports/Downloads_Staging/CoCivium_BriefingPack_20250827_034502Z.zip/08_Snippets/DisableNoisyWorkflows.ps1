# Disable noisy advisory workflows (keep PR labeler if desired)
param([string]$RepoSlug = 'rickballard/CoCivium')

$patterns = 'repo-quality|^yamllint$|lock-readme|name-pending|readme-name-pending'
$wfs = gh workflow list --repo $RepoSlug --json id,name,state,path | ConvertFrom-Json
$wfs | Where-Object { $_.name -match $patterns -and $_.state -eq 'active' } | ForEach-Object {
  "{0} — disabling..." -f $_.name
  gh workflow disable --repo $RepoSlug $_.id
}
