# Poll PR's head commit until required contexts are green, then merge
param([string]$RepoSlug='rickballard/CoCivium', [string]$Head='ops/bp-policy-v1')

$pr = (gh pr list --repo $RepoSlug --search ("head:{0}" -f $Head) --json number | ConvertFrom-Json)[0].number
$bp = gh api "repos/$($RepoSlug)/branches/main/protection" --jq '.required_status_checks' 2>$null
$required = if($bp){ gh api "repos/$($RepoSlug)/branches/main/protection" --jq '.required_status_checks.checks[].context' } else { @() }
if(-not $required -or $required.Count -eq 0){ $required = @('safety-gate/gate','readme-smoke/check') }

function Get-HeadSha { (gh pr view $pr --repo $RepoSlug --json headRefOid | ConvertFrom-Json).headRefOid }

function ChecksOk([string]$sha, [string[]]$need){
  $cr = @( gh api "repos/$RepoSlug/commits/$sha/check-runs" --jq '.check_runs[] | {name, conclusion}' 2>$null | ConvertFrom-Json )
  $st = @( gh api "repos/$RepoSlug/commits/$sha/status"     --jq '.statuses[]   | {context, state}'     2>$null | ConvertFrom-Json )
  $haveChecks=@{}; foreach($r in $cr){ if($r){ $haveChecks[$r.name]=$r.conclusion } }
  $haveStatus=@{}; foreach($r in $st){ if($r){ $haveStatus[$r.context]=$r.state } }
  foreach($ctx in $need){
    $ok=$false
    if($haveChecks.ContainsKey($ctx)){ $ok=($haveChecks[$ctx] -eq 'success') }
    elseif($haveStatus.ContainsKey($ctx)){ $ok=($haveStatus[$ctx] -eq 'success') }
    if(-not $ok){ return $false }
  }
  return $true
}

$timeoutSec=900; $sleepSec=5; $deadline=(Get-Date).AddSeconds($timeoutSec)
do{
  $sha = Get-HeadSha
  $ok = ChecksOk $sha $required
  if(-not $ok){ Start-Sleep -Seconds $sleepSec }
} while((-not $ok) -and (Get-Date) -lt $deadline)

if(-not $ok){ throw ("Required checks not successful for ${sha}: " + ($required -join ', ')) }

gh pr merge $pr --repo $RepoSlug --squash --delete-branch --admin
