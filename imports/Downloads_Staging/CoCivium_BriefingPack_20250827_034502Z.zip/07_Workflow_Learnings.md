# Workflow Learnings (what we fixed & why it matters)

- **Branch Protection API schema is picky**  
  - Include `required_pull_request_reviews` and `restrictions` (can be `null`) when updating protection wholesale.  
  - Setting checks: send `required_status_checks = { strict: false, checks: [{context: '...'}] }`.

- **Checks vs Statuses**  
  - Some jobs report as **Check Runs** (Actions); others as legacy **Status** contexts. When polling, examine **both**.

- **PowerShell paste pitfalls**  
  - Here-strings must be closed; avoid stray code fences.  
  - Fancy quotes (’ “ —) can break literal arrays. Use here-strings or write files via `Set-Content` with a single literal block.

- **Workflow toggles**  
  - `gh workflow list` returns state `active`/`disabled`. Use `-eq 'active'` when deciding to disable.  
  - Keep non-critical linters as **advisory** to reduce noise.

- **Local hooks vs CI**  
  - Set `git config core.hooksPath .git/hooks` to stop custom hooks locally; rely on CI required checks.

- **Backups**  
  - Monthly portfolio zip + SHA256 + manifest.json; retain last 3; move giant zip to NAS.
