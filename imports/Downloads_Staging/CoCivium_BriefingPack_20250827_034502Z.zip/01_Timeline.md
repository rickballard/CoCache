# Timeline & Actions (2025-08-27)

- Set up **Two-Minds** docs and linked them from Idea Cards → PR **#286** → merged.
- Seeded **Backlog Registry v1** and **Brand Poetry pattern** → PR **#287** → merged (required checks toggled off/on to unblock; then restored properly).
- Normalized **Branch Protection** on `main` to a minimal, fast set of gates:
  - required checks: `safety-gate/gate`, `readme-smoke/check`
  - enforce admins, linear history, and conversation resolution
- Disabled or kept advisory-only the noisy non-required workflows. Re-enabled **PR labeler** only.
- Added script **scripts/ops/SetBranchProtection.ps1** (PR **#288**) to re-apply policy in one shot.
- Generated an **Inbox Harvest** report (docs/ops/INBOX_HARVEST.md) to triage `admin/inbox/**`.
