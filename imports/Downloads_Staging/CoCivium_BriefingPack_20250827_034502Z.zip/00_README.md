# CoCivium Briefing Pack — 2025-08-27

This pack captures what we **did**, what's **in flow**, what's **planned**, key **workflow learnings**, and a short-list of **ideas to prioritize**.
Everything here is ready to copy/paste into your repo or run locally (snippets in `08_Snippets`).

**Current repo:** `rickballard/CoCivium`

**Branch Protection (main):**
- Required checks: `safety-gate/gate`, `readme-smoke/check`
- Admins enforced: **on**
- Linear history: **on**
- Conversation resolution: **on**

**PRs**
- ✅ #286 — *docs(ideas): add Two-Minds simulators (per-card)* (merged)
- ✅ #287 — *docs: backlog registry v1 + poetry pattern* (merged)
- 🟨 #288 — *ops/bp-policy-v1: SetBranchProtection.ps1* (open — add BRANCH_PROTECTION doc then merge)

See the rest of the files in this pack for details.
