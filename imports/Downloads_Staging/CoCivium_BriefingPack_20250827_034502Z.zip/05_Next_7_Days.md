# Next 7 Days — Plan of Attack

1) **Finish PR #288**  
   - Add `docs/ops/BRANCH_PROTECTION.md` (use the snippet in `08_Snippets/BRANCH_PROTECTION.md.txt`).  
   - Push; wait for required checks; merge.

2) **Inbox Harvest → Promotions**  
   - Convert `admin/inbox/**` docx/odt using the robust converter snippet.  
   - Promote: `md` → docs/, images → assets/brand or assets/press, text → idea seeds.

3) **Idea Backlog Nuance Pass**  
   - For each card: fill sections (Problem/Context, Why now, Justification, Strategy, Risks, Metrics, Dependencies, Priority).  
   - Use paired Two-Minds docs to pull out justifications and MVPs.

4) **Portfolio Layout Harmonization**  
   - Establish consistent repo skeleton (README, QUICKSTART, PROJECTS, docs/INDEX, scripts/ops, .github/workflows).  
   - Bring in GroupBuild (design), BeAxa, Godspawn, and create clear purpose & staged objectives for each.

5) **Backups**  
   - Schedule monthly portfolio zips (retention 3) with SHA256 manifest; move to NAS manually for now.
