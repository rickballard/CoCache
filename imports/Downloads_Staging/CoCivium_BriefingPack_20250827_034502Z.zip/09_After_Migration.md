# After Migration — Portfolio Harmonization Checklist

- [ ] Standardize repo skeleton across Co* repos (README, QUICKSTART, PROJECTS, docs/INDEX, scripts/ops, .github/workflows)
- [ ] Bring in GroupBuild design backup/staging — define purpose, owners, staged objectives
- [ ] Bring in BeAxa (RepTags + Scriptags persona) — define data flow & safeguards
- [ ] Bring in Godspawn (novel) — structure 3-part layout + writing workflow
- [ ] Add monthly backup job (local script or GH Actions → NAS handoff)
