# Current Branch Protection (main)

**Required checks**
- `safety-gate/gate` — hard “do no harm” sanity gate
- `readme-smoke/check` — README assets/links don’t 404 locally

**Also on**
- Enforce admins
- Require linear history
- Require conversation resolution

**Why minimal?** Keep flow fast; run other linters as **advisory** (non-blocking).

**Reapply policy (one-shot)**
```powershell
scripts\ops\SetBranchProtection.ps1
```
