# PRs in this session

- **#286** — docs(ideas): add Two-Minds simulators (per-card) — *merged*
- **#287** — docs: backlog registry v1 + poetry pattern — *merged*
- **#288** — ops: add SetBranchProtection.ps1 (canonical BP policy) — *open*
