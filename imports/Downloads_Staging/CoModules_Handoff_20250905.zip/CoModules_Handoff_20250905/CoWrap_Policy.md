
# CoWrap — Heartbeat Wrapper Policy

**Purpose:** Long-running commands must be wrapped so sessions get periodic "alive" output.
Test enforces presence of `Invoke-WithHeartbeat` whenever a script contains likely long ops.

## Where it's enforced
- Test file: `tests/BPOE.Heartbeat.Tests.ps1`
- Scope scanned: `tools/`, `dev/`, `scripts/`
- Long-op regex (subject to evolve):
  - `^\s*(git|gh|Invoke-WebRequest|winget)\b` (multiline)

## Allowed implementation
- Prefer importing `tools/BPOE/CoHeartbeat.psm1` if available.
- Provide a **pass-through fallback** definition if not.

### Minimal pattern

```powershell
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

try {
  $mod = Join-Path $PSScriptRoot '..\tools\BPOE\CoHeartbeat.psm1'
  if (Test-Path $mod) { Import-Module $mod -Force -ErrorAction Stop }
} catch {}

if (-not (Get-Command Invoke-WithHeartbeat -ErrorAction SilentlyContinue)) {
  function Invoke-WithHeartbeat { param([string]$Message,[ScriptBlock]$Script) & $Script }
}

Invoke-WithHeartbeat -Message $MyInvocation.MyCommand.Name {
  # ... original script content including long-running calls ...
}
```

## Remediation workflow
1. Run tests: `Invoke-Pester -Path tests` (or `-CI` where supported).
2. If failure cites "has long ops but no heartbeat":
   - Wrap the script with the minimal pattern above **or** run the helper `wrap-heartbeat.ps1`.
3. Commit, push; verify CI.
