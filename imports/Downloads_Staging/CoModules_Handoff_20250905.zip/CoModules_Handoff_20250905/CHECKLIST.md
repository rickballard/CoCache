# Handoff Checklist (Grand Migration)

## Verify & merge
- [ ] Watch CI on branch `docs/bdbp-coagent-250905-1400`.
- [ ] Merge PR #16 when green.

## Propagate
- [ ] Run `setup-hooks.ps1` in each repo clone to enable repo-managed pre-commit.
- [ ] Ensure `tests/BPOE.Heartbeat.Tests.ps1` and `tests/BPOE.CoPong.Tests.ps1` (or equivalents) exist.
- [ ] Ensure `tools/BPOE/CoHeartbeat.psm1`, `tools/BPOE/CoPing.psm1`, `tools/BPOE/CoTint.psm1` are present (or ported).
- [ ] Apply `wrap-heartbeat.ps1` or manual wrap to any long-op scripts under tools/dev/scripts.
- [ ] Ensure docs that reference `./docs/do/*.ps1` include a CoPong one-liner.

## Policy
- [ ] Keep `main` unprotected until migration completes.
- [ ] After migration: enable minimal status check (PS Tests).
- [ ] Respect color policy: never override error/red semantics; use CoTint line-level calls or reversible takeover.

## Links
See `LINKS.txt` in this zip.
