Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
try { Set-PSRepository PSGallery -InstallationPolicy Trusted } catch {}
try { Get-PackageProvider -Name NuGet -ForceBootstrap | Out-Null } catch {}
try { Install-Module Pester -Scope CurrentUser -Force -MinimumVersion 5.5.0 -Repository PSGallery -SkipPublisherCheck } catch {}
Import-Module Pester -Force
Invoke-Pester -Path tests
