# Advisories (Short)

- Keep **main** *unprotected* until the grand migration completes; then enable a **minimal** check: PS Tests.
- Use **CoPong** one-liners for safe DO Blocks; **CoPing** for review-required steps.
- CI signal source: **PS Tests** + heartbeat and CoPong linters.
- Red remains reserved for failures; tint tools never override error colors.
- Local pre-commit is repo-managed via `.hooks/` (requires `git config core.hooksPath .hooks` per-clone).

## Open tracking
- **PR #16**: Merge when branch CI is green.
- **Issue #17**: Grand migration — roll CoPing/CoPong/heartbeat norms across repos.
- **Issue #18**: Post-migration — enable minimal protections on `main`.
