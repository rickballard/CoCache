Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
if (-not (Test-Path ".hooks")) { New-Item -ItemType Directory -Force -Path .hooks | Out-Null }

# shell wrapper
$sh = @'
#!/usr/bin/env sh
pwsh -NoProfile -ExecutionPolicy Bypass -File "$(dirname "$0")/pre-commit.ps1"
exit $?
'@
[IO.File]::WriteAllText(".hooks/pre-commit", $sh, [Text.UTF8Encoding]::new($false))

# PowerShell logic (tries -CI then falls back)
$ps = @'
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
try { Import-Module Pester -ErrorAction Stop } catch {
  Write-Host "Pre-commit: Pester not available." -ForegroundColor Red; exit 1
}
try {
  Invoke-Pester -Path tests -CI -ErrorAction Stop | Out-Null
  exit 0
} catch {
  try {
    Invoke-Pester -Path tests -ErrorAction Stop | Out-Null
    exit 0
  } catch {
    Write-Host "Pre-commit: PowerShell tests FAILED — aborting commit." -ForegroundColor Red
    exit 1
  }
}
'@
[IO.File]::WriteAllText(".hooks/pre-commit.ps1", $ps, [Text.UTF8Encoding]::new($false))

git config --local core.hooksPath .hooks
Write-Host "Installed repo-managed pre-commit hook at .hooks/"
