# BPOE — Metrics
_Last updated: 2025-10-03 04:31:24 UTC_

JSONL logs in `.coagent/logs`, Analyze-BPOE rolls up metrics.
