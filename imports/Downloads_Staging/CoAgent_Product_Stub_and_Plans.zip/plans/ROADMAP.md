# CoAgent — Working Roadmap
_Last updated: 2025-10-03 04:31:24 UTC_

- P0: Productized launcher, Training Mode, BPOE baseline, fast+checks.
- P1: Signed installer, CoCivium sandbox, TODO queue, status badge.
- P2: Mac/Linux builds, private repo support, redaction, guardrails.
