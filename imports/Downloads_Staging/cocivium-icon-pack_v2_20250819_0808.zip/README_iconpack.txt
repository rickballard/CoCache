# CoCivium icon pack v2 — 20250819_0808

This pack fixes dark-mode contrast by embedding `prefers-color-scheme` CSS in each SVG (used via `<img src="...">` in README). 
It also includes a neutral placeholder `assets/hero/hero.jpg` (1600×900).

## Deploy
```powershell
$Repo = "$HOME\Documents\GitHub\CoCivium"
$Zip  = "$HOME\Downloads\cocivium-icon-pack_v2_20250819_0808.zip"
Expand-Archive -LiteralPath $Zip -DestinationPath "$env:TEMP\cocivium-v2" -Force
& "$env:TEMP\cocivium-v2\Deploy-IconPack.ps1" -RepoDir $Repo

Set-Location $Repo
git checkout -b docs/icon-contrast-fix_c2 2>$null; if ($LASTEXITCODE -ne 0) { git switch docs/icon-contrast-fix_c2 }
git add assets/icons assets/hero/hero.jpg README.md
git commit -m "docs(icons): dark/light aware line icons; add neutral hero.jpg"
git push -u origin HEAD
gh pr create --title "README icons: dark/light aware + hero placeholder" --body "SVGs adapt to color scheme; neutral hero.jpg added. No prose changes." --draft
```
