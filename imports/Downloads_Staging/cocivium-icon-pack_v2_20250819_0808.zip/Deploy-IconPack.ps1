Set-StrictMode -Version Latest; $ErrorActionPreference = 'Stop'

param(
  [string]$RepoDir = "$HOME\Documents\GitHub\CoCivium"
)

$PackRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$IconsSrc = Join-Path $PackRoot 'assets\icons'
$HeroSrc  = Join-Path $PackRoot 'assets\hero\hero.jpg'

if (-not (Test-Path $RepoDir)) { throw "Repo not found: $RepoDir" }

# Ensure destinations
$IconsDst = Join-Path $RepoDir 'assets\icons'
$HeroDst  = Join-Path $RepoDir 'assets\hero'
New-Item -ItemType Directory -Path $IconsDst -Force | Out-Null
New-Item -ItemType Directory -Path $HeroDst -Force | Out-Null

# Copy (overwrite)
Copy-Item -LiteralPath (Join-Path $IconsSrc '*') -Destination $IconsDst -Force
Copy-Item -LiteralPath $HeroSrc -Destination (Join-Path $HeroDst 'hero.jpg') -Force

# Normalize line endings in README (LF + trailing newline)
$Readme = Join-Path $RepoDir 'README.md'
if (Test-Path $Readme) {
  $raw = Get-Content -LiteralPath $Readme -Raw
  $lf  = $raw -replace "`r`n","`n" -replace "`r","`n"
  $lf  = $lf.TrimEnd("`r","`n") + "`n"
  [IO.File]::WriteAllText($Readme, $lf, [Text.UTF8Encoding]::new($false))
}

Write-Host "Icons and hero deployed. Commit suggestion:"
Write-Host '  git add assets/icons assets/hero/hero.jpg README.md'
Write-Host '  git commit -m "docs(icons): dark/light aware line icons; add neutral hero.jpg"'
