<#
Local mirror of CI checks for the "Being Noname" story change.
Exit 0 on success; nonzero on fail.
#>
param(
  [string]$Canonical='insights/Insight_Story_Being_Noname_c2_20250801.md'
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'

function Fail([string]$msg){ Write-Error $msg; exit 1 }

# 1) Stubs exist and point to canonical
$stub1 = 'stories/being-name-pending.md'
$stub2 = 'insights/story-being-name-pending.md'
if(!(Test-Path $stub1)){ Fail "Missing $stub1" }
if(!(Test-Path $stub2)){ Fail "Missing $stub2" }
if(-not (Select-String -Path $stub1 -Quiet -SimpleMatch $Canonical)){ Fail "$stub1 does not link to $Canonical" }
if(-not (Select-String -Path $stub2 -Quiet -SimpleMatch $Canonical)){ Fail "$stub2 does not link to $Canonical" }

# 2) No stray 'name‑pending' (all dash kinds) in docs/insights/stories except allowed files/workflows
$dash = r"[\-\u2010-\u2015\u2212]"
$allowed = @(
  '^stories/being-name-pending\.md$',
  '^insights/story-being-name-pending\.md$',
  '^README\.md$',
  '^\.github/workflows/.*$'
)
$hits = (git ls-files) | Where-Object {
  ($_ -match '^(docs/|insights/|stories/|README\.md|\.github/workflows/)') -and
  -not ($allowed | Where-Object { $_ -as [regex] -and ($_ -match $_) }) -and
  (Select-String -Path $_ -Pattern ("name{0}pending" -f $dash) -Quiet)
}
if($hits){ Fail ("Unexpected 'name-pending' in: `n - " + ($hits -join "`n - ")) }

# 3) Codespell ignore contains 'Noname' (best-effort)
$ignore='docs/lexicon/codespell-ignore.txt'
if(Test-Path $ignore){
  if(-not (Select-String -Path $ignore -Pattern '^(?i)Noname$' -SimpleMatch -Quiet)){
    Write-Warning "Consider adding 'Noname' to $ignore"
  }
}

Write-Host "All local CoChecks passed ✅" -ForegroundColor Green
exit 0
