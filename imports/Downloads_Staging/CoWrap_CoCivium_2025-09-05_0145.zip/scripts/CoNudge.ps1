# CoNudge: focus chat and send a single '.' (Enter) to trigger OE heartbeat logic
param([string]$TitleLike='ChatGPT|OpenAI|Civium|Claude|Gemini|Bard',[int]$DelayMs=250)
Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue

if(-not ("Native.Win32" -as [type])){
  Add-Type -Namespace Native -Name Win32 -MemberDefinition @"
[System.Runtime.InteropServices.DllImport("user32.dll")] public static extern bool SetForegroundWindow(System.IntPtr hWnd);
[System.Runtime.InteropServices.DllImport("user32.dll")] public static extern bool IsIconic(System.IntPtr hWnd);
[System.Runtime.InteropServices.DllImport("user32.dll")] public static extern bool ShowWindow(System.IntPtr hWnd, int nCmdShow);
[System.Runtime.InteropServices.DllImport("user32.dll")] public static extern System.IntPtr GetForegroundWindow();
"@ | Out-Null
}
$p = Get-Process chrome,msedge,firefox,brave,opera -ErrorAction SilentlyContinue |
     Where-Object { $_.MainWindowHandle -ne 0 -and $_.MainWindowTitle -match $TitleLike } |
     Select-Object -First 1

if(-not $p){
  $hwnd = [Native.Win32]::GetForegroundWindow()
  if($hwnd -ne [IntPtr]::Zero){
    $p = Get-Process | Where-Object { $_.MainWindowHandle -eq $hwnd } | Select-Object -First 1
  }
}
if(-not $p){ Write-Warning "No chat window found"; exit 0 }

if([Native.Win32]::IsIconic($p.MainWindowHandle)){ [Native.Win32]::ShowWindow($p.MainWindowHandle,9) | Out-Null }
[Native.Win32]::SetForegroundWindow($p.MainWindowHandle) | Out-Null
Start-Sleep -Milliseconds $DelayMs
[System.Windows.Forms.SendKeys]::SendWait("."); Start-Sleep -Milliseconds 60
[System.Windows.Forms.SendKeys]::SendWait("~")
