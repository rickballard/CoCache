# Import CoWrap helpers (CoPong, CoSnap, CoNudge) and ensure transcript
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Split-Path -Parent $here

# Transcript for CoPong
function Ensure-Transcript {
  $v = Get-Variable -Name __CoPingLog -Scope Global -ErrorAction SilentlyContinue
  $ok = $v -and $v.Value -and (Test-Path $v.Value)
  if (-not $ok) {
    $dir = Join-Path $HOME 'Downloads\CoCivium-Logs'
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    $path = Join-Path $dir ("auto-{0}.ps1log" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
    Start-Transcript -Path $path -IncludeInvocationHeader | Out-Null
    $global:__CoPingLog = $path
  }
}

# Load modules
Import-Module (Join-Path $here 'CoPong.FullSend.psm1') -Force
Import-Module (Join-Path $here 'CoSnap.psm1') -Force

# CoNudge helper (send a single '.' to refresh OE status)
. (Join-Path $here 'CoNudge.ps1')

Ensure-Transcript
Write-Host "✅ CoWrap helpers loaded. Use: CoPong  / CoPong -NoSend / CoNudge / CoSnap [-Paste]" -ForegroundColor Green
