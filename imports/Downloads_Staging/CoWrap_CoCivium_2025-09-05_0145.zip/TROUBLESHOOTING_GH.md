# Troubleshooting `gh` for file-at-ref and PR heads

### Show a file *as it exists at a specific ref*
```powershell
$path = 'insights/Insight_Story_Being_Noname_c2_20250801.md'
$ref  = '<branch or commit SHA>'  # e.g., docs/noname-revert-20250904
gh api -H "Accept: application/vnd.github.raw" "/repos/rickballard/CoCivium/contents/$path?ref=$ref"
```

### If that 404s
- The file **doesn’t exist at that ref** (branch didn’t include it or path differs).
- The **ref name is wrong**. List files at the ref to confirm:
```powershell
gh api "/repos/rickballard/CoCivium/git/trees/$ref?recursive=1" | jq -r '.tree[].path' | Select-String '^insights/'
```
- For PRs, use the *head ref*:
```powershell
$pr = 344
$head = gh pr view $pr --json headRefName -q .headRefName
gh api -H "Accept: application/vnd.github.raw" "/repos/rickballard/CoCivium/contents/$path?ref=$head"
```

### Verify the first line matches the desired H1
```powershell
gh api -H "Accept: application/vnd.github.raw" "/repos/rickballard/CoCivium/contents/$path?ref=$head" |
  Select-String '^(#\s*)Being\s+Noname' -SimpleMatch
```

### Nudge or re-run checks
```powershell
gh pr checks <PR#>
gh run list --branch <branch> --limit 20
gh run rerun <runId>
gh pr merge <PR#> --squash --delete-branch --auto
```
