# CoWrap Pack — CoCivium (2025-09-05_0145)

This folder is a *session bootstrap* so a **new session** can pick up without losing context.

## Quick start (PowerShell)
1. Unzip this pack somewhere convenient.
2. Open **Windows PowerShell** (not cmd) and run:
   ```powershell
   Set-ExecutionPolicy -Scope Process Bypass -Force
   $root = 'CoWrap_CoCivium_2025-09-05_0145'  # replace with your unzip path if different
   ."$root/scripts/Import-CoWrap.ps1"
   ```
3. Use `CoPong` to paste the last logs/history straight into chat (it focuses chat, pastes, and presses Enter).  
   - Copy only: `CoPong -NoSend`  
   - Heartbeat nudge: `CoNudge` (sends a single '.' to trigger OE Status refresh)

## What’s inside
- `docs/BPOE_INSERTS.md` — Drop-in BPOE sections (CoPong one-way, OE heartbeat, CoSnap, CI mitigations, CoWrap).
- `scripts/CoPong.FullSend.psm1` — One-command CoPong (focus + paste + Enter) with robust clipboard and size heuristics.
- `scripts/CoSnap.psm1` — Minimal Windows screenshot helper (active window + optional scroll stitch + paste/send).
- `scripts/CoNudge.ps1` — Helper to focus chat and send a single '.' heartbeat.
- `scripts/CoCheck.ps1` — Local guard to mirror CI: stubs exist & link right; disallow stray 'name‑pending' (incl. Unicode dashes).
- `TROUBLESHOOTING_GH.md` — Reliable `gh` commands to verify file content at a given ref/PR head and common 404 causes.
- `NEXT_ACTIONS.md` — Precise steps to land the “Being Noname” fix and close out this workstream.
- `SESSION_SUMMARY.md` — Done / in‑flow / failures / learnings.

> Tip: keep BPOE as the **source of truth**; don’t rely on assistant memory between sessions.
