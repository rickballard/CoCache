# Next actions to land the "Being Noname" update

1) **Load helpers** (once per shell):
```powershell
.$PWD/scripts/Import-CoWrap.ps1
```

2) **Fix the story file title + mentions** (Unicode‑dash safe):
```powershell
$file = "insights/Insight_Story_Being_Noname_c2_20250801.md"
$dash = "[\-\u2010-\u2015\u2212]"
$txt  = Get-Content $file -Raw
$txt  = $txt -replace "(?m)^(#\s*)Being\s+name${dash}pending\b", '$1Being Noname'
$txt  = $txt -replace "(?i)\bname${dash}pending\b", 'Noname'
$txt  | Set-Content $file -Encoding UTF8
git add $file
git commit -m "insights: Unicode-safe revert - name-pending -> Noname; fix H1"
```

3) **Ensure CI stubs are present and correct**:
```powershell
@"
# Being name-pending — moved

**Redirect:** See [Being Noname (c2, 2025-08-01)](../insights/Insight_Story_Being_Noname_c2_20250801.md).
"@ | Set-Content stories/being-name-pending.md -Encoding UTF8

@"
# Being name-pending — moved

**Redirect:** See [Being Noname (c2, 2025-08-01)](./Insight_Story_Being_Noname_c2_20250801.md).
"@ | Set-Content insights/story-being-name-pending.md -Encoding UTF8
git add stories/being-name-pending.md insights/story-being-name-pending.md
```

4) **Pre-flight checks locally**:
```powershell
.$PWD/scripts/CoCheck.ps1
```

5) **Push + PR (enable auto-merge)**:
```powershell
git push -u origin <your-branch>
gh pr create -t 'Restore "Being Noname" title & mentions' -b 'Reverts name-pending -> Noname; restores H1; adds stubs.' -H <your-branch> -B main
$pr = gh pr view --json number -q .number
gh pr merge $pr --squash --delete-branch --auto
```

6) **If a public page still looks unchanged**:
- You’re probably viewing **main**, while your fix is on a PR branch. Wait for auto-merge; refresh the page after it lands.
- Or verify file-at-ref using `TROUBLESHOOTING_GH.md` commands.
