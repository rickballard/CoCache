<!-- BPOE:CoPingPong START -->
### CoPingPong — one way only (keep it simple)
- **One command:** `CoPong`
  - Copies the last ~200 lines of transcript/history (auto-expands on errors/long tools), **focuses chat, pastes, and presses Enter**.
  - Use `CoPong -NoSend` to copy only.
- **Sizing heuristics:** base=200, min=120, max=600; adds +80 lines for big cmds (`git|gh|npm|dotnet|pip|make|winget|choco`), +120 if recent errors/stack traces.
- **Long output:** at `MaxChars` clamp, CoPong truncates tail (or fallback to PNG via CoSnap).
- **No extra variants:** We standardized away `CoSend` and `CoPong150`. One true path is easier to teach/support.
<!-- BPOE:CoPingPong END -->

<!-- BPOE:OEHeartbeat START -->
### OE Heartbeat (keep the agent on-policy)
- Operator may send a single **`.`** heartbeat every ~20 minutes or when drift is suspected.
- Upon heartbeat, the assistant must:
  1. Post **OE Status** (mode, constraints, verbosity).
  2. Re-affirm **BPOE guardrails** (no block leaks, concise default).
  3. Continue, minimizing context churn.
<!-- BPOE:OEHeartbeat END -->

<!-- BPOE:CoSnap START -->
### CoSnap (screenshots, opt-in)
- `CoSnap` captures **active window** to `~/Downloads/CoCivium-Logs` (PNG).
- `CoSnapScroll -Pages N` stitches PageUp frames vertically.
- `CoSnap -Paste` (or `CoSnapScroll -Paste`) copies image, focuses chat, pastes, sends.
- **Privacy:** opt-in only, visible console message, local-only storage.
- **Use when:** UI state matters (dialogs, disabled buttons, diffs) or JS paste is blocked.
<!-- BPOE:CoSnap END -->

<!-- BPOE:CI START -->
### CI: common fail causes → quick mitigations
| Fail name (typical) | Why it fails | Fast fix (CLI) |
|---|---|---|
| **lock-readme/guard** | README changed in a non-README PR | `git checkout origin/main -- README.md ; git commit -m "ci: drop README change"` |
| **name-pending-stubs-check** | Required stubs missing or wrong link | Ensure **both** files exist and point to `insights/Insight_Story_Being_Noname_c2_20250801.md`:<br>`stories/being-name-pending.md` and `insights/story-being-name-pending.md` |
| **codespell** | Domain words flagged (e.g., `Noname`) | Add to `docs/lexicon/codespell-ignore.txt` then commit. |
| **markdownlint** | Long lines / inline HTML in insights | Add `<!-- markdownlint-disable MD013 MD033 -->` near the top of the file. |
| **yamllint** | Tabs, CRLF, or trailing space in workflow | Convert tabs→spaces, normalize LF; avoid trailing ws. |
| **PR labeler** | Labels missing / pattern mismatch | `gh pr edit <N> --add-label docs` (and others as needed). |
<!-- BPOE:CI END -->

<!-- BPOE:CoWrap START -->
### CoWrap checklist (end-of-session hygiene)
- Land open doc-only PRs (enable `--auto` when policy requires).
- Verify `main` page reflects intended titles/redirects.
- Run `git grep -n -I -i -- 'name-pending' -- 'docs/**/*.md' 'insights/**/*.md'` to catch regressions.
- Keep **BPOE** as source of truth; do not rely on assistant memory.
<!-- BPOE:CoWrap END -->
