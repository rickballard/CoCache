# CoFit TODO (Next Build Phase)

- [ ] Define first 3 archetypes (activist, policy skeptic, civic admin)
- [ ] Draft initial proposal scoring rubric (Markdown)
- [ ] Wire up scoring logic (CLI or GH Actions)
- [ ] Begin capturing objections for Tier‑1 congruence scan
- [ ] Add `README_USE.md` for hands-on walkthrough
- [ ] Draft light UX sketch (ASCII or image placeholder)

> All commits should use relaxed merge protocol for CoModules.
> CoCivium remains relaxed during migration window.
