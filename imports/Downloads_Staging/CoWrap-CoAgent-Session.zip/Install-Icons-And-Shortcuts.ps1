Param(
  [string]$SessionName = "Productize backchatter"
)

$ErrorActionPreference = "Stop"

# Paths
$repoRoot = Join-Path $HOME "Documents\GitHub\CoAgent"
$electron = Join-Path $repoRoot "electron"
$buildDir = Join-Path $electron "build"
$toolsDir = Join-Path $repoRoot "tools"
$iconsDir = Join-Path $toolsDir "icons"
$pair     = Join-Path $toolsDir "Pair-CoSession.ps1"

# Create folders
New-Item -ItemType Directory -Force -Path $buildDir | Out-Null
New-Item -ItemType Directory -Force -Path $iconsDir | Out-Null

# Copy icons from the bundle location to repo locations
$bundle = Split-Path -Parent $MyInvocation.MyCommand.Path
Copy-Item (Join-Path $bundle "CatFace.ico") (Join-Path $buildDir "icon.ico") -Force
Copy-Item (Join-Path $bundle "CatPaw.ico")  (Join-Path $iconsDir "CatPaw.ico") -Force
Copy-Item (Join-Path $bundle "CatEye.ico")  (Join-Path $iconsDir "CatEye.ico") -Force

# Patch electron/package.json "build.icon"
$pkg = Join-Path $electron "package.json"
if (Test-Path $pkg) {
  $j = Get-Content $pkg -Raw | ConvertFrom-Json
  if (-not $j.PSObject.Properties.Match('build')) {
    $j | Add-Member -NotePropertyName build -NotePropertyValue ([pscustomobject]@{}) -Force
  }
  $j.build | Add-Member -NotePropertyName icon -NotePropertyValue "build/icon.ico" -Force
  ($j | ConvertTo-Json -Depth 10) | Set-Content $pkg -Encoding UTF8
  Write-Host "Set build.icon = build/icon.ico in electron/package.json"
} else {
  Write-Warning "package.json not found at $pkg (skip icon patch)"
}

# Create three shortcuts with distinct icons
$desktop = [Environment]::GetFolderPath('Desktop')
$wt      = Join-Path $env:LOCALAPPDATA 'Microsoft\WindowsApps\wt.exe'
$pwsh    = (Get-Command pwsh).Source

function New-Shortcut {
  param(
    [Parameter(Mandatory)][string]$Path,
    [Parameter(Mandatory)][string]$Target,
    [string]$Args = '',
    [string]$WorkingDir = $HOME,
    [string]$IconLocation = $null
  )
  $shell = New-Object -ComObject WScript.Shell
  $sc = $shell.CreateShortcut($Path)
  $sc.TargetPath = $Target
  $sc.Arguments  = $Args
  $sc.WorkingDirectory = $WorkingDir
  if ($IconLocation) { $sc.IconLocation = $IconLocation }
  $sc.Save()
}

# 1) PowerShell 7 (Tabs) → CatPaw
$lnk1 = Join-Path $desktop 'PowerShell 7 (Tabs).lnk'
$icoPS = (Join-Path $iconsDir 'CatPaw.ico') + ",0"
if (Test-Path $wt) {
  New-Shortcut -Path $lnk1 -Target $wt -Args '-w 0 nt -p "PowerShell"' -IconLocation $icoPS
} else {
  New-Shortcut -Path $lnk1 -Target $pwsh -Args '-NoLogo' -IconLocation $icoPS
}

# 2) CoAgent Panel (PS7 Tabs) → CatFace
$lnk2 = Join-Path $desktop 'CoAgent Panel (PS7 Tabs).lnk'
$icoCo = (Join-Path $buildDir 'icon.ico') + ",0"
if (Test-Path $wt) {
  $psCmd = ('$env:COAGENT_SESSION="{0}"; & "{1}"' -f $SessionName, $pair).Replace('"','\"')
  $args2 = ('-w 0 nt -d "~" pwsh -NoLogo -NoExit -Command "{0}"' -f $psCmd)
  New-Shortcut -Path $lnk2 -Target $wt -Args $args2 -IconLocation $icoCo
} else {
  $args2 = "-NoLogo -NoExit -Command `"$env:COAGENT_SESSION='$SessionName'; & '$pair'`""
  New-Shortcut -Path $lnk2 -Target $pwsh -Args $args2 -IconLocation $icoCo
}

# 3) Dev Terminal – PS7 + CoAgent → CatEye
$lnk3 = Join-Path $desktop 'Dev Terminal – PS7 + CoAgent.lnk'
$icoWT = (Join-Path $iconsDir 'CatEye.ico') + ",0"
if (Test-Path $wt) {
  $psCmd = ('$env:COAGENT_SESSION="{0}"; & "{1}"' -f $SessionName, $pair).Replace('"','\"')
  $args3 = ('-w 0 ; nt -p "PowerShell" ; nt -d "~" pwsh -NoLogo -NoExit -Command "{0}"' -f $psCmd)
  New-Shortcut -Path $lnk3 -Target $wt -Args $args3 -IconLocation $icoWT
} else {
  $cmdPath = Join-Path $toolsDir 'CoAgentTwoTabs.cmd'
  @"
@echo off
start "" "" "{pwsh}" -NoLogo
start "" "" "{pwsh}" -NoLogo -NoExit -Command "$env:COAGENT_SESSION='{SessionName}'; & '{pair}'"
"@.Replace("{pwsh}", $pwsh).Replace("{SessionName}", $SessionName).Replace("{pair}", $pair) | Set-Content -Encoding ASCII $cmdPath
  New-Shortcut -Path $lnk3 -Target $cmdPath -IconLocation $icoWT
}

Write-Host "`nShortcuts created on your Desktop:"
Write-Host " - $lnk1"
Write-Host " - $lnk2"
Write-Host " - $lnk3"
Write-Host "`nRebuild Electron to apply the app icon, e.g.:"
Write-Host "  pushd `"$electron`"; npx electron-builder -w dir ; popd"
