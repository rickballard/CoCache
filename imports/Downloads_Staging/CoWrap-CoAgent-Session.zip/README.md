**Timestamp:** 2025-09-15 19:40

# CoWrap: CoAgent Panel & PS7 UX — Session Wrap

This bundle captures what we built/tuned, known issues, and a clean starting plan for the next session.

## What we implemented
- **Section banners**: `Write-EndOfSet` now draws a **top+bottom rainbow bar** with centered label (no background). Includes a `-Colorblind` mode.
- **Pair-CoSession**: one-shot launcher that stops any old Electron, rebuilds `electron/dist/win-unpacked`, optionally ensures the Exec backend, and launches the panel.
- **Exec backend helpers**: `Start-CoExec.ps1` (tries Docker `ttyd`, otherwise uses a minimal HttpListener stub) and `Stop-CoExec.ps1`.
- **CoBreadcrumb scheduled tasks**: stable tasks that write BPOE crumbs to repo docs at intervals.
- **Startup VBS**: hidden/quiet launcher for `Start-CoInboxWatcher.ps1` (avoids console flashes).
- **PowerShell profiles**: hardened PSReadLine “ChatGPT:” dropper that only binds on PS7 with PSReadLine present.
- **Windows Terminal shortcuts**: 3 taskbar-friendly shortcuts with distinct icons.
- **Icon plan**: packaged **CatFace**, **CatPaw**, **CatEye** icons to reduce taskbar confusion and brand CoAgent.

## Key learnings & fixes
- **PSReadLine errors** when bound in Windows PowerShell 5.x. Fix: only hook in **PS7** + guard for module existence.
- **AHK snippets pasted into PS** will error; we now keep profile/launch snippets strictly PowerShell.
- **Electron icon**: `electron-builder` used a default icon because `build.icon` wasn’t effectively set or icon file missing. Fix below.
- **Docker not running** → Electron hit `ERR_CONNECTION_REFUSED`. We added a stub HttpListener so the UI loads without panic.
- **Startup script**: replaced a brittle `.vbs` with a quiet, correctly quoted version.

## Next-session scope (suggested)
1. **Electron icon**: ensure `electron/build/icon.ico` exists and `package.json` has `"build": { "icon": "build/icon.ico" }`, then rebuild.
2. **Exec backend**: add a visible in-app indicator for Exec status (Docker/ttyd vs. stub).
3. **Inbox watcher**: replace the stub with minimal real logic or disable by default.
4. **Profiles**: provide an installer/uninstaller to toggle profile hooks cleanly.
5. **Shortcuts**: finalize icons in repo and document how to pin them.
6. **Repo hygiene**: add PR template + OPERATING_LOG entries for these changes.
7. **Telemetry/logging** (local): capture “paired session”, errors, and banner emits for troubleshooting.

## How to place the icons in your repo
- Put the included `.ico` files here:
  - `CoAgent/electron/build/icon.ico`  ← **CatFace.ico** (app icon & brand)
  - `CoAgent/tools/icons/CatPaw.ico`   ← taskbar shortcut 1
  - `CoAgent/tools/icons/CatEye.ico`   ← taskbar shortcut 2
- Then set `package.json` `"build.icon": "build/icon.ico"` and rebuild.

## Shortcut mapping (recommended)
- **PowerShell 7 (Tabs)** → use Windows Terminal icon or **CatPaw.ico**
- **CoAgent Panel (PS7 Tabs)** → **CatFace.ico**
- **Dev Terminal – PS7 + CoAgent (two tabs)** → **CatEye.ico**

## Files in this bundle
- `README.md` (this file)
- `Install-Icons-And-Shortcuts.ps1` (copies icons to repo + creates three shortcuts with those icons)
- `Profile-ChatDropper.ps1` (safe PS7-only ChatGPT: Enter-hook snippet)
- Icons: `CatFace.ico`, `CatPaw.ico`, `CatEye.ico`

---
