Double-click Run-CoAgent.cmd to start CoAgent (MVP).
