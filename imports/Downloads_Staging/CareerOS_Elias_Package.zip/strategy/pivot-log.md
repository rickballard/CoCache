# Pivot Log

Template
```
## YYYY‑MM‑DD — Pivot name
- From → To:
- Why now:
- Evidence:
- Risks and mitigations:
- Projects to support the pivot:
- Review date:
```
