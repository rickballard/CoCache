# Job Targets

| Company | Role | Why this fit | Warm path / intro | Proof project to attach | Status |
|---|---|---|---|---|---|
|  |  |  |  |  |  |

Maintain 20–40 targets. Prioritize weekly.
