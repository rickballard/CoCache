# Outreach Templates

## Recruiter / Hiring Manager
Subject: API + AI integration engineer — quick value in 30 days

Hi <name>,

I focus on making existing products **AI‑ready**: modern APIs, model‑ready data, and shipped integrations. I attached a one‑page summary and 2 tiny demos. If this is relevant, I’d love to share a 15‑min plan for <company>.

— Elias
