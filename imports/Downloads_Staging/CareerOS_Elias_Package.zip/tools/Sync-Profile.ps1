param(
    [string]$LinkedInHTML = ""
)
<# 
  Placeholder: In future, pass a saved HTML export or pasted profile to parse
  key fields (headline, skills, projects) and refresh local markdown.
#>
Write-Host "Sync-Profile stub. Provide -LinkedInHTML path when ready."
