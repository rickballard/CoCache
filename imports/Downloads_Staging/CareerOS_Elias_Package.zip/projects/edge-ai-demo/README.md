# Edge AI Demo

Goal: Capture a stream on a small device, run a lightweight model, and forward events to a cloud API.
