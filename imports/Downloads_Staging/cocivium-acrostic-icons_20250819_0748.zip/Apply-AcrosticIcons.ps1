Param(
  [string]$RepoDir = (Get-Location).Path,
  [string]$Readme = "README.md"
)
Set-StrictMode -Version Latest; $ErrorActionPreference = 'Stop'
$readmePath = Join-Path $RepoDir $Readme
if (-not (Test-Path $readmePath)) { throw "README not found: $readmePath" }

# 1) Title fix
$text = Get-Content -LiteralPath $readmePath -Raw
$text = $text -replace 'We The People, Empowered\.\s*\(the hook, top-of-fold\)', 'We The People, Empowered.'

# 2) Ensure icons folder exists
$iconRoot = Join-Path $RepoDir 'assets/icons'
if (-not (Test-Path $iconRoot)) { New-Item -ItemType Directory -Path $iconRoot -Force | Out-Null }

# 3) Insert icons before acrostic headings
function Add-Icon {
  param([string]$label, [string]$file, [string]$pattern)
  $img = '<img src="./assets/icons/' + $file + '" alt="' + $label + '" width="20" height="20" />&nbsp; **' + $label + ':**'
  $regex = $pattern
  $script:changed = $script:changed -or ($script:text -match $regex)
  $script:text = [System.Text.RegularExpressions.Regex]::Replace($script:text, $regex, $img, 'Multiline')
}

$script:changed = $false
$script:text = $text

Add-Icon -label 'LIFE' -file 'life.svg' -pattern '^[\s]*\*\*LIFE\*\*:\s*'
Add-Icon -label 'FEELS' -file 'feels.svg' -pattern '^[\s]*\*\*FEELS\*\*:\s*'
Add-Icon -label 'BROKEN' -file 'broken.svg' -pattern '^[\s]*\*\*BROKEN\*\*:\s*'
Add-Icon -label 'UNTIL' -file 'until.svg' -pattern '^[\s]*\*\*UNTIL\*\*:\s*'
Add-Icon -label 'GOVERNMENTS' -file 'governments.svg' -pattern '^[\s]*\*\*GOVERNMENTS\*\*:\s*'
Add-Icon -label 'CoEvolve' -file 'coevolve.svg' -pattern '^[\s]*\*\*[“"]?CoEvolve[”"]?\*\*:\s*'
Add-Icon -label 'SOLUTIONS' -file 'solutions.svg' -pattern '^[\s]*\*\*SOLUTIONS\*\*:\s*'
Add-Icon -label 'FOR YOU' -file 'for-you.svg' -pattern '^[\s]*\*\*FOR YOU\*\*:\s*'

if ($script:changed) {
  Set-Content -LiteralPath $readmePath -Value $script:text -Encoding UTF8
  Write-Host "README updated."
} else {
  Write-Host "No acrostic headings found to update."
}

# 4) Copy icons if the script bundle includes them
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$srcIcons = Join-Path $here 'assets/icons'
if (Test-Path $srcIcons) {
  Get-ChildItem $srcIcons -File | ForEach-Object {
    $dst = Join-Path $iconRoot $_.Name
    if (-not (Test-Path $dst)) { Copy-Item $_.FullName $dst }
  }
  Write-Host "Icons ensured at $iconRoot"
} else {
  Write-Host "Icon source not found; ensure icons exist in assets/icons."
}