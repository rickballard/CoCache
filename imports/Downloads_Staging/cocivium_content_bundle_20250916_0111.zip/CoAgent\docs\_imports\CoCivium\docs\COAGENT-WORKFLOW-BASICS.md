<!-- status: stub; target: 150+ words -->
# CoAgent Workflow Basics (DO➕ Canon)

- DO headers live **outside** code blocks:
  `# 🟢➕ DO <Letter> — YYMMDD-HHMMZ — Short title`

<<<<<<< HEAD
- Final line of a multi-step instruction is a **timestamp-only** code fence.
=======
- End-of-instruction demarcation: final line is a **timestamp-only** code fence:
>>>>>>> bdc1b77 (docs(coagent): canon stub for DO➕ workflow + demarcation rule)

- Colors: 🟢 safe/observe, 🟡 relax/toggle, 🟦 enforce, 🟥 risky/destructive, 🟫 optional.


