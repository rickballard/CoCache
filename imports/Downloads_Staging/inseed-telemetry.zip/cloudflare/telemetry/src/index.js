// InSeed anonymous, opt-in telemetry (privacy-first)

const ALLOWED_EVENTS = new Set(["chk","page"]); // allow-list

export default {
  async fetch(req, env, ctx) {
    const url = new URL(req.url);

    if (url.pathname.startsWith("/admin/")) {
      if (url.searchParams.get("code") !== env.ADMIN_PASSCODE)
        return new Response("forbidden", { status: 403 });

      if (url.pathname.endsWith("/daily")) {
        const day = url.searchParams.get("day") || yyyymmdd(new Date());
        const agg = await aggregateDay(env, day);
        return json(agg);
      }
      if (url.pathname.endsWith("/monthly")) {
        const iso = url.searchParams.get("ym") || yyyymm(new Date());
        const agg = await aggregateMonth(env, iso);
        return json(agg);
      }
      return new Response("ok");
    }

    if (url.pathname === "/__t") {
      const ev = url.searchParams.get("ev") || "";
      if (!ALLOWED_EVENTS.has(ev)) return new Response(null, { status: 204 });

      const k = (url.searchParams.get("k") || "").slice(0, 64);
      const v = (url.searchParams.get("v") || "").slice(0, 16);

      const cf = req.cf || {};
      const evt = {
        ts: Date.now(),
        ev, k, v,
        country: cf.country || "",
        asn: cf.asn || "",
        org: (cf.asOrganization || "").slice(0, 80),
        ref: (req.headers.get("Referer") || "").split("?")[0].slice(0, 120)
      };

      const day = yyyymmdd(new Date());
      const key = `e:${day}:${evt.ts}:${Math.random().toString(36).slice(2,8)}`;
      await env.KV.put(key, JSON.stringify(evt), { expirationTtl: 60 * 60 * 24 * 62 });

      return new Response(null, { status: 204 });
    }

    return new Response("not found", { status: 404 });
  },

  async scheduled(event, env, ctx) {
    try {
      if (event.cron === "0 8 * * *") {
        const d = new Date(); d.setUTCDate(d.getUTCDate() - 1);
        const day = yyyymmdd(d);
        const agg = await aggregateDay(env, day);
        await sendDigest(env, `[InSeed] Daily signals ${day}`, renderTextDaily(agg, day));
      } else if (event.cron === "10 8 1 * *") {
        const now = new Date();
        const prev = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth()-1, 1));
        const ym = yyyymm(prev);
        const agg = await aggregateMonth(env, ym);
        await sendDigest(env, `[InSeed] Monthly signals ${ym}`, renderTextMonthly(agg, ym));
      }
    } catch (e) { /* no-op */ }
  }
};

function yyyymmdd(d){ return d.toISOString().slice(0,10).replace(/-/g,""); }
function yyyymm(d){ return d.toISOString().slice(0,7).replace("-",""); }
function json(obj){ return new Response(JSON.stringify(obj,null,2), { headers: { "content-type": "application/json" } }); }

async function listByPrefix(KV, prefix) {
  let cursor, out = [];
  do {
    const { keys, list_complete, cursor: c } = await KV.list({ prefix, cursor });
    out.push(...keys.map(k => k.name));
    cursor = list_complete ? undefined : c;
  } while (cursor);
  return out;
}

async function aggregateDay(env, day) {
  const keys = await listByPrefix(env.KV, `e:${day}:`);
  const byEvent = {}, byOrg = {}, total = keys.length;

  for (const name of keys) {
    const raw = await env.KV.get(name);
    if (!raw) continue;
    const e = JSON.parse(raw);
    const bucket = `${e.ev}:${e.k}:${e.v}`;
    byEvent[bucket] = (byEvent[bucket]||0) + 1;
    const org = `${e.org||"Unknown"} (${e.country||"??"})`;
    byOrg[org] = (byOrg[org]||0) + score(e);
  }

  const topEvents = topN(byEvent, 12);
  const topOrgs = topN(byOrg, 12);
  return { day, total, topEvents, topOrgs };
}

async function aggregateMonth(env, ym) {
  const year = +ym.slice(0,4), month = +ym.slice(4,6);
  const start = new Date(Date.UTC(year, month-1, 1));
  const end   = new Date(Date.UTC(year, month, 1));
  let total = 0;
  const byEvent = {}, byOrg = {};

  for (let dt = new Date(start); dt < end; dt.setUTCDate(dt.getUTCDate()+1)) {
    const day = yyyymmdd(dt);
    const keys = await listByPrefix(env.KV, `e:${day}:`);
    total += keys.length;
    for (const name of keys) {
      const raw = await env.KV.get(name);
      if (!raw) continue;
      const e = JSON.parse(raw);
      const bucket = `${e.ev}:${e.k}:${e.v}`;
      byEvent[bucket] = (byEvent[bucket]||0) + 1;
      const org = `${e.org||"Unknown"} (${e.country||"??"})`;
      byOrg[org] = (byOrg[org]||0) + score(e);
    }
  }
  return { month: ym, total, topEvents: topN(byEvent, 16), topOrgs: topN(byOrg, 16) };
}

function topN(map, n){
  return Object.entries(map).sort((a,b)=>b[1]-a[1]).slice(0,n).map(([k,v])=>({ k, v }));
}
function score(e){ return e.ev === "chk" ? (e.v === "1" ? 3 : 1) : 1; }

async function sendDigest(env, subject, text) {
  const body = {
    personalizations: [{ to: [{ email: env.MAIL_TO }] }],
    from: { email: env.MAIL_FROM, name: "InSeed Signals" },
    subject,
    content: [{ type: "text/plain", value: text }]
  };
  await fetch("https://api.mailchannels.net/tx/v1/send", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body)
  });
}

function renderTextDaily(agg, day){
  const lines = [
    `InSeed • Daily signals for ${day}`,
    `Total events: ${agg.total}`,
    "",
    "Top event buckets (ev:key:value → count):",
    ...agg.topEvents.map(x=>`  - ${x.k} → ${x.v}`),
    "",
    "Top org interest (ASN org (country) → score):",
    ...agg.topOrgs.map(x=>`  - ${x.k} → ${x.v}`),
    "",
    "Notes:",
    "• Score favors checklist YES answers (potential need).",
    "• No PII is collected; org is ASN organization from network."
  ];
  return lines.join("\n");
}

function renderTextMonthly(agg, ym){
  const lines = [
    `InSeed • Monthly signals for ${ym}`,
    `Total events: ${agg.total}`,
    "",
    "Top event buckets:",
    ...agg.topEvents.map(x=>`  - ${x.k} → ${x.v}`),
    "",
    "Top org interest:",
    ...agg.topOrgs.map(x=>`  - ${x.k} → ${x.v}`),
    "",
    "Ideas:",
    "• Create ‘trap’ content matching top checklist items.",
    "• Outreach to orgs with elevated score (if they reach out)."
  ];
  return lines.join("\n");
}
