Param(
  [string]$Zone = "inseed.com",
  [string]$Passcode
)

Set-StrictMode -Version Latest; $ErrorActionPreference="Stop"

Invoke-WebRequest ("https://{0}/__t?ev=chk&k=q1&v=1" -f $Zone) -UseBasicParsing | Out-Null
Invoke-WebRequest ("https://{0}/__t?ev=chk&k=q2&v=0" -f $Zone) -UseBasicParsing | Out-Null

$day = (Get-Date).ToString("yyyyMMdd")
$res = Invoke-WebRequest ("https://{0}/admin/daily?code={1}&day={2}" -f $Zone,$Passcode,$day) -UseBasicParsing
$json = $res.Content | ConvertFrom-Json
$json | ConvertTo-Json -Depth 5
