Param(
  [string]$Zone = "inseed.com",
  [string]$MailTo = "rballard@inseed.com",
  [string]$MailFrom = "noreply@inseed.com",
  [string]$AdminPasscode = $( [Guid]::NewGuid().ToString("N") ),
  [switch]$SkipWranglerLogin
)

Set-StrictMode -Version Latest; $ErrorActionPreference="Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$proj = Join-Path (Split-Path -Parent $root) "cloudflare/telemetry"
$src  = Join-Path $proj "src"
New-Item -ItemType Directory -Force $proj,$src | Out-Null

# Write files if missing
$wranglerPath = Join-Path $proj "wrangler.toml"
$indexPath    = Join-Path $src  "index.js"

if (-not (Test-Path $wranglerPath)) {
  Copy-Item (Join-Path $root "../cloudflare/telemetry/wrangler.toml") $wranglerPath -Force
}
if (-not (Test-Path $indexPath)) {
  Copy-Item (Join-Path $root "../cloudflare/telemetry/src/index.js") $indexPath -Force
}

# Replace MAIL_TO / MAIL_FROM / ADMIN_PASSCODE in wrangler.toml
$wr = Get-Content $wranglerPath -Raw
$wr = $wr -replace 'MAIL_TO\s*=\s*".*?"', "MAIL_TO = ""$MailTo"""
$wr = $wr -replace 'MAIL_FROM\s*=\s*".*?"', "MAIL_FROM = ""$MailFrom"""
$wr = $wr -replace 'ADMIN_PASSCODE\s*=\s*".*?"', "ADMIN_PASSCODE = ""$AdminPasscode"""
Set-Content $wranglerPath -Value $wr -Encoding UTF8

# Ensure Node/npm
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw "Node.js not found. Install from https://nodejs.org/en/" }
if (-not (Get-Command npm -ErrorAction SilentlyContinue))  { throw "npm not found. Install Node.js which includes npm." }

# Ensure wrangler
if (-not (Get-Command wrangler -ErrorAction SilentlyContinue)) {
  Write-Host "Installing wrangler..." -ForegroundColor Cyan
  npm i -g wrangler | Out-Null
}

if (-not $SkipWranglerLogin) {
  Write-Host "Opening Cloudflare login..." -ForegroundColor Cyan
  wrangler login
}

Push-Location $proj

# Create KV namespace (title can be anything)
$ns = wrangler kv:namespace create INSEED_TELEMETRY --json | ConvertFrom-Json
$kvId = $ns.id
if (-not $kvId) { throw "Failed to create KV namespace (no id)." }

# Patch the ID in wrangler.toml
$wr = Get-Content $wranglerPath -Raw
$wr = $wr -replace 'id\s*=\s*".*?"', ('id = "' + $kvId + '"')
Set-Content $wranglerPath -Value $wr -Encoding UTF8

# Deploy
wrangler deploy

Write-Host "`n=== Installed. Test with ===" -ForegroundColor Green
Write-Host ("iwr ""https://{0}/__t?ev=chk&k=q1&v=1"" -UseBasicParsing | % StatusCode" -f $Zone)
Write-Host ("iwr ""https://{0}/admin/daily?code={1}"" -UseBasicParsing" -f $Zone, $AdminPasscode)

Pop-Location
