InSeed Telemetry (privacy-first)
================================

What this is
------------
- Cloudflare Worker that stores tiny anonymous beacons (no PII) in KV.
- Daily & monthly cron jobs send a digest email via MailChannels.
- Minimal JSON admin endpoints:
    /admin/daily?code=PASSCODE
    /admin/monthly?code=PASSCODE

Files
-----
- cloudflare/telemetry/wrangler.toml  (routes, KV binding, crons, vars)
- cloudflare/telemetry/src/index.js   (worker code)
- scripts/Install-InSeedTelemetry.ps1 (one-shot installer & deployer)
- scripts/Test-InSeedTelemetry.ps1    (fires test events & reads daily)

Quick start (Windows PowerShell)
--------------------------------
  1) Extract this ZIP anywhere (e.g., Downloads\inseed-telemetry)
  2) Open PowerShell in that folder and run:

     .\scripts\Install-InSeedTelemetry.ps1 `
       -Zone inseed.com `
       -MailTo rballard@inseed.com `
       -MailFrom noreply@inseed.com `
       -AdminPasscode YOUR_SECRET

  3) When the browser opens, finish Cloudflare login for Wrangler.
  4) After deploy, test:

     .\scripts\Test-InSeedTelemetry.ps1 -Zone inseed.com -Passcode YOUR_SECRET

Add a beacon from your pages (already present in your checklist):
----------------------------------------------------------------
  new Image().src='/__t?ev=chk&k=q1&v=1';

Notes
-----
- No IPs or UAs are stored; we record ASN organization and country only.
- MailChannels generally works out of the box, but setting SPF/DKIM for
  noreply@inseed.com improves deliverability.
- Edit crons/routes/vars in wrangler.toml if needed.
