# 10 – Ethics, Safety & Privacy Checklist

- Redaction-before-share across vendors
- No secrets in logs; secure storage & retention policy
- Rate limits & budgets to prevent abuse
- Human-in-the-loop escalation path
- Model bias & harmful content filters; allowlist/denylist per task
