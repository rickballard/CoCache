# 11 – Roadmap (30/60/90)

**0–30 days**
- MVP router + adapters + majority/judge
- Provenance log JSON
- Run bake-off on 3 tasks

**31–60 days**
- Constraint checker + policy packs
- Early-exit consensus
- Pilot 1–2 design partners

**61–90 days**
- Learned weights (bandit)
- Debates (round N) optional
- Pricing experiment & GTM content
