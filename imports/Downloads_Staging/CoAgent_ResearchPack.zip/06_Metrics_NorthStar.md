# 06 – Metrics & North-Star

- Activation: first consensus task completed with logs viewed
- Reliability: consensus accuracy vs. single best model
- Disagreement rate & escalations
- Cost/latency per task; % within budget
- Retention & expansion
