# 13 – Stakeholder Map

| Person/Org | Role | Influence | Interest | What they need to see | Next action |
|---|---|---|---|---|---|
