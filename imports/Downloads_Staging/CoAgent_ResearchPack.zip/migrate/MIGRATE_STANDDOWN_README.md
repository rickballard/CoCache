# Migrate: Stand Down (Watcher)

Time: 2025-09-09

A centralized watcher is already running via CoAgentLauncher.
**Do not** create a separate inbox watcher here.

Keep focus on:
- **ccts fallback** remediation (priority)
- Migration-specific repo tasks

To notify Planning:
`Send-CoNote -ToSessionId 'co-planning' -Text "Migrate: checkpoint — <one-liner>."`
