# 14 – Partner/Design-Partner Outreach Template

Subject: Exploring reliable multi-model AI via CoAgent (pilot invite)

Hi <Name>,

We’re testing a consensus layer that orchestrates multiple models, adds policy checks,
and logs provenance. Would you be open to a short call to see if a pilot fits your workflow?

Why you: <reason>. What you’d get: <benefit>. What we need: <tasks, data policy, time>.

Thanks,
<You>
