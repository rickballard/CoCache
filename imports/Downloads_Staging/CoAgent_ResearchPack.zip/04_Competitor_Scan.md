# 04 – Competitor Scan (living doc)

For each product/vendor, fill the table, then write a short narrative comparison.

| Vendor | Product | Multi-model? | Adjudication | Provenance | Pricing model | Latency/cost controls | Target users | Notes |
|---|---|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |  |  |

**Tasks for bake-off** (link to `08_Eval_Framework.md`): …
