# 09 – Go-To-Market Sequencing

- Phase 1: Design partners (2–3 teams); hands-on pilots
- Phase 2: Self-serve beta; templates for repos/IDEs
- Phase 3: Partner integrations; compliance story; case studies

**Content**: demo video, sample logs, “why consensus” primer.
