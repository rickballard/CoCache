# 05 – Pricing & Packaging Scenarios

- **Starter**: N tasks/mo, limited models, basic logs.
- **Pro**: higher caps, adjudicator + constraints, SLA.
- **Enterprise**: on-prem, policy packs, advanced provenance, SSO, audit integrations.

Model: $/task, $/seat, or hybrid. Include budget controls + early-exit consensus to cap costs.
