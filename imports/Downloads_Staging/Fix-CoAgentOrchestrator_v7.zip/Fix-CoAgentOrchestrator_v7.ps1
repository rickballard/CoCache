param(
  [Parameter(Mandatory=$true)][string]$SessionUrl,
  [switch]$Run
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Write-Note([string]$m) { Write-Host "[Fix] $m" }

# 1) Find latest worktree
$WTDir = Get-ChildItem "$HOME\Documents\GitHub\CoAgent__mvp3*" -Directory -ErrorAction SilentlyContinue |
  Sort-Object LastWriteTime -Descending | Select-Object -First 1 | ForEach-Object FullName
if (-not $WTDir) { throw "Worktree not found under Documents\GitHub\CoAgent__mvp3*" }
Write-Note "Worktree: $WTDir"

# 2) Locate orchestrator
$Orch = Join-Path $WTDir 'tools\Start-MVP3-Orchestrator.ps1'
if (-not (Test-Path $Orch)) { throw "Orchestrator not found: $Orch" }
Write-Note "Orchestrator: $Orch"

# 3) Quick parse check BEFORE changes
$tokens=$null;$errors=$null
[void][System.Management.Automation.Language.Parser]::ParseFile($Orch,[ref]$tokens,[ref]$errors)
if ($errors) {
  Write-Note "Parser currently reports issues:`n"
  $errors | Format-Table ErrorId, Message, Extent -AutoSize | Out-String | Write-Host
}

# 4) Backup original
$bak = "$Orch.bak_{0:yyyyMMdd-HHmmss}" -f (Get-Date)
Copy-Item $Orch $bak -Force
Write-Note "Backup saved -> $bak"

# 5) Load content
$text = Get-Content $Orch -Raw

# 6) Targeted fixes for "empty pipe" patterns
# 6a) 'catch { | Out-File ... }'  -> 'catch { $_ | Out-File ... }'
$text = [regex]::Replace($text, '(?ms)catch\s*\{\s*\|\s*Out-File', 'catch { $_ | Out-File')

# 6b) lines like '} | Out-File ...'  -> '"" | Out-File ...' (captures args)
$text = [regex]::Replace($text, '(^\s*)\}\s*\|\s*(Out-File\b[^\r\n]*)', '$1"" | $2', 'Multiline')

# 6c) lines starting with bare pipe to Out-File -> prefix with empty string so there is a left side
$text = [regex]::Replace($text, '(^\s*)\|\s*(Out-File\b[^\r\n]*)', '$1"" | $2', 'Multiline')

# 7) Save patched text to disk
Set-Content -Path $Orch -Value $text -Encoding UTF8
Write-Note "Patched orchestrator written."

# 8) Parse check AFTER changes
$tokens=$null;$errors=$null
[void][System.Management.Automation.Language.Parser]::ParseFile($Orch,[ref]$tokens,[ref]$errors)
if ($errors) {
  Write-Host ""
  Write-Note "Parser still failing:"
  $errors | Format-Table ErrorId, Message, Extent -AutoSize | Out-String | Write-Host

  # show a few likely-offending lines for context
  Write-Host ""
  Write-Note "A few suspicious lines around pipes:"
  Select-String -Path $Orch -Pattern '^\s*\|\s*Out-File|}\s*\|\s*Out-File' -Context 1,1 -SimpleMatch |
    ForEach-Object { "Line $($_.LineNumber): $($_.Line)" } | Out-String | Write-Host

  # restore original and stop
  Copy-Item $bak $Orch -Force
  throw "Parser still failing; original restored."
}

Write-Note "Parser clean after patch."

if ($Run) {
  # 9) Quiet launch: run orchestrator with logs spooled to Downloads\CoTemp\logs
  $LogsRoot = Join-Path (Join-Path $HOME 'Downloads') 'CoTemp\logs'
  New-Item -ItemType Directory -Force -Path $LogsRoot | Out-Null
  $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
  $out = Join-Path $LogsRoot ("orchestrator-$stamp.out.log")
  $err = Join-Path $LogsRoot ("orchestrator-$stamp.err.log")

  Write-Note "Launching orchestrator quietly..."
  $pwsh = (Get-Command pwsh).Path
  $p = Start-Process -FilePath $pwsh `
        -ArgumentList @('-NoLogo','-NoProfile','-File', $Orch, '-SessionUrl', $SessionUrl) `
        -RedirectStandardOutput $out `
        -RedirectStandardError  $err `
        -PassThru
  Write-Note ("Started PID {0}.`n  Out: {1}`n  Err: {2}" -f $p.Id,$out,$err)
  Write-Note "Tail with: Get-Content `"$out`" -Tail 200 -Wait"
}
