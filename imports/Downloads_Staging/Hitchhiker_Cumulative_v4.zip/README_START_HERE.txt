Hitchhiker Plan — Cumulative Draft v4
-------------------------------------
This zip contains all current segments of the Hitchhiker Plan as of this version.

Segments:
- HH_Preface_01.md → Cosmic observers intro
- HH_Preface_02.md → Purpose and philosophy preface

More segments to be added as the draft progresses.
