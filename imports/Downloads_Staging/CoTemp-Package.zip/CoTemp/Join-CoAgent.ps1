# Join-CoAgent.ps1  (ASCII only; PS 5.1+)
Set-StrictMode -Version Latest; $ErrorActionPreference = 'Stop'
param(
  [string]$SessionId = $(if ($env:COSESSION_ID) { $env:COSESSION_ID } else { "co-$($PID)-$(Get-Date -Format 'yyyyMMdd-HHmmss')" })
)

# Roots
$script:CoRoot      = Join-Path $HOME 'Downloads\CoTemp'
$script:SessionRoot = Join-Path $script:CoRoot ("sessions\{0}" -f $SessionId)
$script:Inbox       = Join-Path $script:SessionRoot 'inbox'
$script:Outbox      = Join-Path $script:SessionRoot 'outbox'
$script:Logs        = Join-Path $script:SessionRoot 'logs'
$script:Scripts     = Join-Path $script:SessionRoot 'scripts'
$script:Common      = Join-Path $script:CoRoot   'common'

$null = New-Item -ItemType Directory -Force -Path $script:CoRoot,$script:SessionRoot,$script:Inbox,$script:Outbox,$script:Logs,$script:Scripts,$script:Common | Out-Null
$env:COSESSION_ID = $SessionId

function CoTemp { param([string]$Rel) if ($Rel) { Join-Path $script:CoRoot $Rel } else { $script:CoRoot } }
function CoTemp-Open { ii $script:CoRoot }
function CoSession-Path { param([string]$Rel) if ($Rel) { Join-Path $script:SessionRoot $Rel } else { $script:SessionRoot } }
function CoSession-Open { ii $script:SessionRoot }

# Stable file gate
function Wait-ForStableFile {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$Path,
    [int]$IntervalMs = 400,
    [int]$Consecutive = 4,
    [int]$TimeoutSeconds = 120
  )
  $last = $null; $stable = 0
  $sw = [Diagnostics.Stopwatch]::StartNew()
  while ($sw.Elapsed.TotalSeconds -lt $TimeoutSeconds) {
    if (Test-Path -LiteralPath $Path) {
      $len  = (Get-Item -LiteralPath $Path).Length
      $hash = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash
      $cur  = "$len`:$hash"
      if ($cur -eq $last) { $stable++ } else { $stable = 0; $last = $cur }
      if ($stable -ge $Consecutive) { $sw.Stop(); return $true }
    } else { $stable = 0 }
    Start-Sleep -Milliseconds $IntervalMs
  }
  $sw.Stop(); return $false
}

# Repo mutex
function Use-RepoMutex {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$RepoPath,
    [Parameter(Mandatory)][scriptblock]$Script,
    [int]$TimeoutMs = 2000
  )
  $norm = (Resolve-Path -LiteralPath $RepoPath).Path
  $sha1 = ([System.Security.Cryptography.SHA1]::Create()).ComputeHash([Text.Encoding]::UTF8.GetBytes($norm))
  $hex  = -join ($sha1 | ForEach-Object { $_.ToString('x2') })
  $name = "Global\CoAgentRepo_$hex"
  $mtx  = $null
  try {
    $mtx = New-Object System.Threading.Mutex($false, $name)
    if (-not $mtx.WaitOne($TimeoutMs)) { Write-Warning "Repo mutex busy for: $norm"; return }
    & $Script
  } finally { if ($mtx) { try { $mtx.ReleaseMutex() } catch {} $mtx.Dispose() } }
}

# Save text into CoTemp (strip prompts/continuations)
function CoTemp-Save {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$Name,
    [string]$Text,
    [switch]$FromClipboard,
    [switch]$LF,
    [switch]$Append,
    [ValidateSet('Unknown','String','Unicode','Byte','BigEndianUnicode','UTF8','UTF7','UTF32','Ascii','Default','Oem','BigEndianUTF32')]
    [string]$Encoding = 'UTF8'
  )
  $t = if ($PSBoundParameters.ContainsKey('Text')) { $Text }
       elseif ($FromClipboard) { Get-Clipboard -Raw }
       else { Read-Host 'Enter text (Ctrl+C to cancel)'; return }

  $lines = $t -split "`r?`n" |
    Where-Object { $_ -notmatch '^\s*PS [A-Za-z]:\\.*>\s*$' } |
    ForEach-Object { $_ -replace '^\s*>>\s?', '' }
  $out = ($lines -join "`r`n"); if ($LF) { $out = $out -replace "`r?`n","`n" }

  $full = CoTemp $Name
  $dir  = Split-Path -Parent $full
  if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }

  if ($Append) { Add-Content -LiteralPath $full -Value $out -Encoding $Encoding }
  else         { Set-Content -LiteralPath $full -Value $out -Encoding $Encoding }
  Write-Host "Saved -> $full" -ForegroundColor Green
  return $full
}

function CoTemp-Run {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$Name,
    [switch]$WithWrites,
    [switch]$WithNetwork
  )
  $full = CoTemp $Name
  if (-not (Test-Path $full)) { throw "Not found: $full" }
  try {
    if ($WithWrites)  { $env:COAGENT_ALLOW_WRITES  = '1' }
    if ($WithNetwork) { $env:COAGENT_ALLOW_NETWORK = '1' }
    & $full
  } finally {
    if ($WithWrites)  { Remove-Item Env:COAGENT_ALLOW_WRITES  -EA SilentlyContinue }
    if ($WithNetwork) { Remove-Item Env:COAGENT_ALLOW_NETWORK -EA SilentlyContinue }
  }
}

function Test-DOHeader {
  [CmdletBinding()]
  param([Parameter(Mandatory)][string]$Path)
  $text = Get-Content -Raw -LiteralPath $Path
  $m = [regex]::Match($text, '<#\s*---\s*(?<yaml>[\s\S]*?)\s*---\s*#>')
  if (-not $m.Success) { Write-Error 'Missing commented YAML header block <# --- ... --- #>.'; return $false }
  $yaml = $m.Groups['yaml'].Value
  $need = @('title','repo','risk','consent')
  foreach($k in $need){ if ($yaml -notmatch "(?m)^\s*$k\s*:") { Write-Error "Missing: $k"; return $false } }
  $body = $text.Substring($m.Index + $m.Length)
  if ($body -notmatch '(?m)^\s*#\s*\[PASTE IN POWERSHELL\]\s*$') { Write-Warning "Body missing '# [PASTE IN POWERSHELL]' marker." }
  return $true
}

function Start-CoQueueWatcher {
  [CmdletBinding()]
  param([int]$PollMs = 600, [switch]$Once)
  Write-Host ("Queue watcher: {0} (session {1})" -f $script:Inbox, $env:COSESSION_ID) -ForegroundColor Cyan
  do {
    $items = Get-ChildItem -LiteralPath $script:Inbox -Filter '*.ps1' -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime
    foreach($it in $items) {
      $path = $it.FullName
      if (-not (Wait-ForStableFile -Path $path)) { continue }
      $name = [IO.Path]::GetFileNameWithoutExtension($path)
      $runId = "$(Get-Date -Format 'yyyyMMdd-HHmmss')-$PID"
      $logTxt = Join-Path $script:Logs "$name-$runId.txt"
      $logJson= Join-Path $script:Logs "$name-$runId.json"

      $okHeader = $false
      try { $okHeader = Test-DOHeader -Path $path } catch { $okHeader = $false }
      if (-not $okHeader) { Write-Warning "Header check failed: $path"; continue }

      $sw = [Diagnostics.Stopwatch]::StartNew()
      $result = 'fail'
      try {
        $out = & $path 2>&1 | Out-String
        $result = 'pass'
        $out | Set-Content -LiteralPath $logTxt -Encoding UTF8
      } catch {
        $_ | Out-String | Set-Content -LiteralPath $logTxt -Encoding UTF8
      } finally {
        $sw.Stop()
        $evt = [pscustomobject]@{ ts=(Get-Date).ToString('o'); session_id=$env:COSESSION_ID; script=$path; elapsed_ms=[int]$sw.Elapsed.TotalMilliseconds; result=$result }
        $evt | ConvertTo-Json | Set-Content -LiteralPath $logJson -Encoding UTF8
      }

      $dest = Join-Path $script:Outbox ("{0}-{1}.ps1" -f $name, $runId)
      Move-Item -LiteralPath $path -Destination $dest -Force
      Write-Host ("Processed {0} -> {1}" -f $it.Name, (Split-Path -Leaf $dest)) -ForegroundColor Green
    }
    if ($Once) { break }
    Start-Sleep -Milliseconds $PollMs
  } while ($true)
}

function New-CoHelloDO {
  [CmdletBinding()]
  param([string]$RepoPath = (Join-Path $HOME 'Desktop\CoAgent_SandboxRepo'))
  $session = if ($env:COSESSION_ID){$env:COSESSION_ID}else{"manual"}
  $inbox = Join-Path (Join-Path $HOME 'Downloads\CoTemp') ("sessions\{0}\inbox" -f $session)
  $name = "DO_00_Hello_{0}.ps1" -f (Get-Date -Format 'HHmmss')
  $path = Join-Path $inbox $name
  $ts = Get-Date -Format o
  $body = @"
<# ---
title: "DO-hello"
session_id: "$session"
repo: { name: "Sandbox", path: "$RepoPath" }
risk: { writes: false, network: false, secrets: false, destructive: false }
brief: "Hello from CoTemp"
consent: { allow_writes: false, allow_network: false }
--- #>
# [PASTE IN POWERSHELL]
"Hello from DO in CoTemp - $ts"
`$PSVersionTable.PSVersion
"@
  if (-not (Test-Path $inbox)) { New-Item -ItemType Directory -Force -Path $inbox | Out-Null }
  Set-Content -LiteralPath $path -Value $body -Encoding UTF8
  Write-Host ("Queued -> {0}" -f $path) -ForegroundColor Green
  return $path
}

Write-Host ("Joined CoAgent session: {0}" -f $env:COSESSION_ID) -ForegroundColor Cyan
Write-Host ("Session folder: {0}" -f $script:SessionRoot) -ForegroundColor DarkCyan
