Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
# Sets Minimal gating on branch protection and enables admin bypass (pre-launch policy).
param(
  [string]$Owner='rickballard',
  [string]$Repo='CoCivium',
  [string]$Branch='main',
  [string[]]$RequiredContexts=@(
    'safety-gate/gate',
    'readme-smoke/check',
    'readme-noname-check/check',      # adjust if your repo emits 'readme-name-pending-check/check'
    'name-pending-stubs-check'        # adjust to exact context (with or without '/check')
  )
)
$uri = "/repos/$Owner/$Repo/branches/$Branch/protection"
# Build payload
$payload = @{
  required_status_checks = @{
    strict = $false
    checks = @()
  }
  enforce_admins = $false  # false == allow admin bypass
  required_pull_request_reviews = $null
  restrictions = $null
  required_linear_history = $false
  allow_force_pushes = $false
  allow_deletions = $false
}
foreach($ctx in $RequiredContexts){ $payload.required_status_checks.checks += @{ context = $ctx } }
$json = ($payload | ConvertTo-Json -Depth 8)

$json | gh api -X PUT -H "Accept: application/vnd.github+json" $uri --input -

Write-Host "Branch protection updated on $Branch (Minimal gating + admin bypass ON)." -ForegroundColor Green
