Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
# Ensures .github/labeler.yml follows actions/labeler@v5 (array-of-rule-objects). Overwrites with a sane default if not.
$path = '.github/labeler.yml'
if(-not (Test-Path $path)){ New-Item -ItemType Directory -Force -Path '.github' | Out-Null }
$target = @"
# actions/labeler@v5 schema: each label maps to an ARRAY of rule objects.
# See: https://github.com/actions/labeler
docs:
  - changed-files:
      - any-glob-to-any-file: ['**/*.md','docs/**','insights/**','stories/**']

ci:
  - changed-files:
      - any-glob-to-any-file: ['.github/**']

brand:
  - changed-files:
      - any-glob-to-any-file: ['brand/**','assets/brand/**']

hero:
  - changed-files:
      - any-glob-to-any-file: ['docs/onboarding/**']

ops:
  - changed-files:
      - any-glob-to-any-file: ['admin/**','tools/**']
"@
$needs = $true
if(Test-Path $path){
  $txt = Get-Content $path -Raw
  if($txt -match "(?s)changed-files:"){ $needs = $false }
}
if($needs){ $target | Set-Content $path -Encoding UTF8; Write-Host "Rewrote $path to v5 schema." -ForegroundColor Green }
else { Write-Host "$path already appears v5‑compatible." -ForegroundColor Yellow }
