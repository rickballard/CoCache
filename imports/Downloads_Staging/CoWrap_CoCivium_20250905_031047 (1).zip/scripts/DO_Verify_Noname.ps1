Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
# Verifies the canonical insight on main has the correct H1 and no residual "name‑pending".
param(
  [string]$Owner = 'rickballard',
  [string]$Repo  = 'CoCivium',
  [string]$Canonical = 'insights/Insight_Story_Being_Noname_c2_20250801.md',
  [string]$Ref = 'main'
)
$path = $Canonical -replace '\\','/'
$uri  = "/repos/$Owner/$Repo/contents/$path`?ref=$Ref"
$raw  = gh api -H "Accept: application/vnd.github.raw" $uri
# H1 can have optional leading ✦, must be "Being Noname"
$null = ($raw | Select-String '^(#\s*)(?:✦\s*)?Being\s+Noname' -ErrorAction Stop)
# No "name-pending" with any unicode dash
$dash = '[\-\u2010-\u2015\u2212]'
($raw | Select-String -Pattern ("name{0}pending" -f $dash) -CaseSensitive:$false) | ForEach-Object {
  throw "Residual 'name-pending' on main: $($_.Line.Trim())"
}
Write-Host "Verified on main — H1 and mentions are correct." -ForegroundColor Green
