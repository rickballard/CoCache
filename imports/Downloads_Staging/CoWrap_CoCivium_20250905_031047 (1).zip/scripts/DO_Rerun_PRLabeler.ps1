Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
param([int]$Pr)
if(-not $Pr){ throw "Provide -Pr <number>" }
$head = gh pr view $Pr --json headRefName -q .headRefName
$ids = gh run list --branch $head --limit 30 --json databaseId,name -q '.[] | select(.name | test("PR labeler"; "i")) | .databaseId'
$ids -split "`n" | ForEach-Object {
  if($_){ try { gh run rerun $_ } catch { Write-Warning $_ } }
}
