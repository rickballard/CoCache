Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
function Start-OEHeartbeat {
  param([int]$Seconds=1200)
  if(Get-Job -Name OEHeartbeat -State Running -ErrorAction SilentlyContinue){ return }
  Start-Job -Name OEHeartbeat -ScriptBlock { param($s) while($true){ Write-Host '.' -NoNewline; Start-Sleep -Seconds $s } } -ArgumentList $Seconds | Out-Null
  Write-Host "OE heartbeat started (every $Seconds s)."
}
function Stop-OEHeartbeat {
  Get-Job -Name OEHeartbeat -ErrorAction SilentlyContinue | Stop-Job -PassThru | Remove-Job -Force -ErrorAction SilentlyContinue
  Write-Host "OE heartbeat stopped."
}
Export-ModuleMember -Function Start-OEHeartbeat,Stop-OEHeartbeat
