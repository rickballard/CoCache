Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
# Scans docs/ and insights/ for unicode‑dash variants of name‑pending, prints a short plan.
$paths = @('docs','insights')
$dash = '[\-\u2010-\u2015\u2212]'
$files = git ls-files -- $paths | Where-Object { $_ -match '\.(md|mdx)$' }
$hits = @()
foreach($f in $files){
  $lines = Get-Content $f
  for($i=0;$i -lt $lines.Count; $i++){
    if($lines[$i] -match ("name{0}pending" -f $dash)){
      $hits += [pscustomobject]@{ File=$f; Line=$i+1; Text=$lines[$i] }
    }
  }
}
if($hits.Count -eq 0){
  Write-Host "No residual 'name‑pending' tokens found." -ForegroundColor Green
}else{
  Write-Host "Residual tokens found:" -ForegroundColor Yellow
  $hits | Format-Table -AutoSize
  Write-Host ""
  Write-Host "Suggested branch & commit:" -ForegroundColor Cyan
  Write-Host "  git switch -c docs/grand-migration-Noname"
  Write-Host "  # (Perform careful, reviewed replacements using unicode‑safe dash class)"
  Write-Host "  git add -A && git commit -m 'docs: grand migration – name‑pending → Noname (unicode‑safe)'"
  Write-Host "  gh pr create -t 'Grand migration: Noname' -b 'Unicode‑safe rename sweep; no content change'"
}
