Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
# Unify codespell words across both lists + optional third, dedupe, sort.
$lists = @('.codespell.words','docs/lexicon/codespell-ignore.txt','.codespell/ignore-words.txt')
$seed  = @('coevolve','co-evolution','antifragile','nonhuman','non-humans','cocivai','cocivium',
           'Noname','CoPong','CoNudge','CoSnap','Auto-merge','automerge','Yamllint','Markdownlint','CoCivium')
$set = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach($p in $lists){
  if(Test-Path $p){
    (Get-Content $p | Where-Object { $_ -match '\S' }) | ForEach-Object { [void]$set.Add($_.Trim()) }
  }
}
$seed | ForEach-Object { [void]$set.Add($_) }
$sorted = $set | Sort-Object
$sorted | Set-Content .codespell.words -Encoding UTF8
Write-Host "Wrote unified .codespell.words (count=$($sorted.Count))." -ForegroundColor Green
