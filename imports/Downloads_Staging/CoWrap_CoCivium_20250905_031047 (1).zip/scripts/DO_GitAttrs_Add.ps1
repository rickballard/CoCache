Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
@"
* text=auto eol=lf
*.ps1 text eol=lf
*.yml text eol=lf
*.yaml text eol=lf
*.md text eol=lf
"@ | Set-Content .gitattributes -Encoding UTF8
git add .gitattributes
Write-Host ".gitattributes written and staged." -ForegroundColor Green
