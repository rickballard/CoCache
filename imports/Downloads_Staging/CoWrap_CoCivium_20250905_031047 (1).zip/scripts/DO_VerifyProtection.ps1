Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
param(
  [string]$Owner='rickballard',
  [string]$Repo='CoCivium'
)
$q = @'
query($owner:String!, $repo:String!){
  repository(owner:$owner, name:$repo){
    branchProtectionRules(first:100){
      nodes{
        pattern
        isAdminEnforced
        requiredStatusCheckContexts
      }
    }
  }
}
'@
$resp = gh api graphql -f owner=$Owner -f repo=$Repo -f query="$q" | ConvertFrom-Json
$rules = $resp.data.repository.branchProtectionRules.nodes
if(-not $rules){ throw "No branch protection rules found." }
$rules | ForEach-Object {
  $adminBypass = ($_.isAdminEnforced -ne $true)
  Write-Host "Branch: $($_.pattern); Admin bypass enabled: $adminBypass" -ForegroundColor Cyan
  Write-Host "Required contexts:"
  $_.requiredStatusCheckContexts | ForEach-Object { " - $_" }
}
