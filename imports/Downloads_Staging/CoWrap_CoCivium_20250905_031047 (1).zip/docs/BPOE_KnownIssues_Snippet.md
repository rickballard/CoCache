## Known Issues & CI/GitHub Policy (as of 2025‑09‑05)

### 1) Branch protection with admin bypass **disabled** blocks merges
**Status:** Open • **Impact:** High • **Scope:** All repos with required checks • **Owner:** Eng Prod

**DO**
- Enable **Allow administrators to bypass** on `main`.
- Make advisory jobs truly advisory: `continue-on-error: true` **and** do **not** add them as required contexts.
- Keep minimal required checks only (pre-launch).

**VERIFY (PowerShell)**
- Required contexts reflect “Minimal”, admin bypass is enabled.
- PRs with only docs/CI changes can merge via `--admin`.

**Minimal gating (pre-launch) – Required checks**
- `safety-gate/gate`
- `readme-smoke/check`
- `readme-noname-check/check` *(or your repo’s emitted context, e.g. `readme-name-pending-check/check`)*
- `name-pending-stubs-check` *(or `/check` if that’s the emitted context)*

Optional (do **not** require): `CI Advisory/*` (codespell/markdownlint/yamllint), Labeler, Pages preview, Link checks, Render Eyes.

> If a check is “advisory”, set `continue-on-error: true` in the workflow **and** never add its exact name to branch-protection required contexts.

### 2) Lessons from the “Being Noname” sweep
**DO**
- Use a unicode‑safe dash class for find/replace: `[\-\u2010-\u2015\u2212]`.
- Keep **both** stubs pointing to the canonical insight:
  - `stories/being-name-pending.md`
  - `insights/story-being-name-pending.md`

**Stub body template**
```md
# Stub — Being Noname

See canonical: insights/Insight_Story_Being_Noname_c2_20250801.md
```

**Codespell hardening**
Maintain **both** `.codespell.words` and `docs/lexicon/codespell-ignore.txt` with project tokens:
`Noname, CoPong, CoNudge, CoSnap, CoCivium`.

**Labeler config (actions/labeler@v5)**
Use **array of rule objects** per label:
```yaml
docs:
  - changed-files:
      - any-glob-to-any-file: ['**/*.md','docs/**','insights/**','stories/**']
ci:
  - changed-files:
      - any-glob-to-any-file: ['.github/**']
brand:
  - changed-files:
      - any-glob-to-any-file: ['brand/**','assets/brand/**']
hero:
  - changed-files:
      - any-glob-to-any-file: ['docs/onboarding/**']
ops:
  - changed-files:
      - any-glob-to-any-file: ['admin/**','tools/**']
```

### 3) OE heartbeat (operator discipline)
Start a background job that prints a `.` about every 20 minutes; upon heartbeat, assistant posts **OE Status**, re‑affirms guardrails, and continues with minimal churn.
