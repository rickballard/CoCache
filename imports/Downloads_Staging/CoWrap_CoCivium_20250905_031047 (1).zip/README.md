# CoWrap_CoCivium — How to Use

From your repo root, run in order:

1) `pwsh ./scripts/DO_Verify_Noname.ps1`
2) `pwsh ./scripts/DO_SetBranchProtection_Minimal.ps1` then `pwsh ./scripts/DO_VerifyProtection.ps1`
3) `pwsh ./scripts/DO_BPOE_Append.ps1`
4) `pwsh ./scripts/DO_Sanity_Codespell_Reunion.ps1`
5) (Optional) `pwsh ./scripts/DO_Labeler_V5_Check.ps1` then `pwsh ./scripts/DO_Rerun_PRLabeler.ps1 -Pr 347`
6) (Optional) `pwsh ./scripts/DO_GitAttrs_Add.ps1`
7) `pwsh ./scripts/DO_GrandMigration_Scaffold.ps1`

Extras:
- `scripts/DO_Heartbeat.psm1` — import and run `Start-OEHeartbeat` / `Stop-OEHeartbeat`.
- `docs/BPOE_KnownIssues_Snippet.md` — paste-ready content if you prefer manual edits.
- `SESSION_SUMMARY.md` — what we did / failed / plan / lessons.
