InSeed Site Pack
=================

What this does
--------------
- Normalizes a single TopNav (and prevents double headers)
- Injects /assets/site.js (theme toggle, language picker, anonymous telemetry hooks, checklist binder)
- Adds CSS “quick fixes” block if missing
- Creates /whitepaper/index.html (Exec Summary + Full skeleton)
- Optional Cloudflare dev-mode toggle and targeted purge

How to use
----------
1) Unzip this folder somewhere (e.g., Downloads\inseed-site-pack\)
2) Open PowerShell and run:

   cd "$HOME\Downloads\inseed-site-pack\scripts"
   .\Run-All.ps1 -RepoRoot "$HOME\Documents\GitHub\InSeed" `
     -ZoneId "<YOUR_CF_ZONE_ID>" `
     -Token  "<YOUR_CF_API_TOKEN>"

   (Both ZoneId and Token are optional; if omitted, CF steps are skipped.)

Idempotent: you can re-run any time safely.
