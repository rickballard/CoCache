param([Parameter(Mandatory=$true)][string]$RepoRoot)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'

$build = Get-Date -UFormat %Y%m%d%H%M%S
$assets = Join-Path $RepoRoot 'assets'
$siteCss = Join-Path $assets 'site.css'
$siteJs  = Join-Path $assets 'site.js'
$topnavTmpl = Join-Path $PSScriptRoot '..\templates\topnav.html'
$siteJsSrc  = Join-Path $PSScriptRoot '..\assets\site.js'

New-Item -ItemType Directory -Force -Path $assets | Out-Null
Copy-Item -Force $siteJsSrc $siteJs

$cssRaw = if(Test-Path $siteCss){ Get-Content $siteCss -Raw } else { "" }
if($cssRaw -notmatch 'InSeed v5 quick-fixes'){
@"
/* InSeed v5 quick-fixes */
.topnav + .topnav{ display:none }                 /* if two navs slip in, hide the second one */
.hero, .hero img, .hero-blurb{ margin-bottom:8px !important }
.hero-blurb p{ margin-top:4px !important }
body > footer .container{ max-width:var(--page); margin:0 auto; padding:0 16px; }
.loose-links, footer .micro{ text-align:center }
"@ | Add-Content $siteCss
}

$TopNav = Get-Content $topnavTmpl -Raw

function EnsureHead([string]$s){
  if($s -notmatch '(?i)</head>'){ $s = "<!doctype html><head></head><body>$s</body>" }
  if($s -notmatch '/assets/site\.css'){
    $s = [regex]::Replace($s,'</head>','<link rel="stylesheet" href="/assets/site.css?v='+$build+'">'+"`r`n</head>",1)
  } else {
    $s = [regex]::Replace($s,'/assets/site\.css(\?v=\d+)?','/assets/site.css?v='+$build,1)
  }
  if($s -notmatch '/assets/site\.js'){
    $s = [regex]::Replace($s,'</head>','<script src="/assets/site.js?v='+$build+'"></script>'+"`r`n</head>",1)
  } else {
    $s = [regex]::Replace($s,'/assets/site\.js(\?v=\d+)?','/assets/site.js?v='+$build,1)
  }
  if($s -notmatch 'rel="icon"'){
    $s = [regex]::Replace($s,'</head>','<link rel="icon" href="/favicon.svg" type="image/svg+xml">'+"`r`n</head>",1)
  }
  return $s
}

function EnsureSingleTopNav([string]$s){
  $s = [regex]::Replace($s,'(?is)<nav[^>]*class\s*=\s*["'']topnav["''][\s\S]*?</nav>','')
  if($s -match '(?is)<body[^>]*>'){
    $s = [regex]::Replace($s,'(<body[^>]*>)',{ param($m) $m.Groups[1].Value+"`r`n"+$TopNav },1)
  } else { $s = $TopNav + "`r`n" + $s }
  $s = [regex]::Replace($s,'(?is)(<nav[^>]*class\s*=\s*["'']topnav["''][\s\S]*?</nav>)(?:\s*<nav[^>]*class\s*=\s*["'']topnav["''][\s\S]*?</nav>)+','$1')
  return $s
}

function PatchFile($path){
  $raw = Get-Content $path -Raw
  $raw = EnsureHead $raw
  $raw = EnsureSingleTopNav $raw
  $raw = [regex]::Replace($raw,'(?i)\b(data-?leakage or vendor lock-in)\b(?:\s*(?:,|and)?\s*\1\b)+','$1')
  $raw = $raw -replace 'quickly\\\.', 'quickly.'
  Set-Content $path -Value $raw -Encoding UTF8
}

$whitepaper = Join-Path $RepoRoot 'whitepaper\index.html'
if(!(Test-Path $whitepaper)){
  Copy-Item -Force (Join-Path $PSScriptRoot '..\whitepaper\index.html') $whitepaper
  Write-Host "Created /whitepaper/index.html" -ForegroundColor Green
}

Get-ChildItem $RepoRoot -Recurse -File -Include *.html | Where-Object { $_.FullName -notmatch '\\deprecated\\' } | ForEach-Object {
  PatchFile $_.FullName
}

Write-Host "Apply-InSeedChanges: complete (build $build)" -ForegroundColor Green
