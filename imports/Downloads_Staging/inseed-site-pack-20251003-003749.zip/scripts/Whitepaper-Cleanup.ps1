param([Parameter(Mandatory=$true)][string]$RepoRoot)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
$dep = Join-Path $RepoRoot 'deprecated'
New-Item -ItemType Directory -Force -Path $dep | Out-Null

$patterns = '(amusing|funny|comic|gag|gibber)'
$files = Get-ChildItem $RepoRoot -Recurse -File -Include *.html | Where-Object {
  $_.FullName -notmatch '\\deprecated\\' -and $_.Name -match $patterns
}

foreach($f in $files){
  $rel = $f.FullName.Substring($RepoRoot.Length).TrimStart('\','/')
  $dest = Join-Path $dep ([IO.Path]::GetFileName($f.FullName))
  Write-Host "Moving $rel  ->  deprecated\$([IO.Path]::GetFileName($dest))" -ForegroundColor Yellow
  Move-Item -Force $f.FullName $dest
}
Write-Host "Whitepaper cleanup complete." -ForegroundColor Green
