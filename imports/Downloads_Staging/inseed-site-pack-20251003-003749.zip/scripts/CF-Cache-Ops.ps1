param(
  [ValidateSet('DevOn','DevOff','Purge')][string]$Action,
  [string]$ZoneId,
  [string]$Token,
  [string[]]$Files
)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
if(-not $ZoneId -or -not $Token){ Write-Host "CF-Cache-Ops: ZoneId/Token not provided; skipping." -ForegroundColor Yellow; exit 0 }
$H = @{ Authorization = "Bearer $Token"; 'Content-Type'='application/json' }

switch($Action){
  'DevOn'  { Invoke-RestMethod -Method Patch -Uri "https://api.cloudflare.com/client/v4/zones/$ZoneId/settings/development_mode" -Headers $H -Body '{"value":"on"}'  | Out-Null;
             Write-Host "Cloudflare Development Mode: ON" -ForegroundColor Green }
  'DevOff' { Invoke-RestMethod -Method Patch -Uri "https://api.cloudflare.com/client/v4/zones/$ZoneId/settings/development_mode" -Headers $H -Body '{"value":"off"}' | Out-Null;
             Write-Host "Cloudflare Development Mode: OFF" -ForegroundColor Green }
  'Purge'  {
    if(-not $Files -or $Files.Count -eq 0){ Write-Host "No files to purge." -ForegroundColor Yellow; break }
    $body = @{ files = $Files } | ConvertTo-Json
    $res = Invoke-RestMethod -Method Post -Uri "https://api.cloudflare.com/client/v4/zones/$ZoneId/purge_cache" -Headers $H -Body $body
    if($res.success){ Write-Host "Cloudflare purge: OK" -ForegroundColor Green } else { Write-Host "Cloudflare purge: FAILED"; $res | ConvertTo-Json -Depth 5 }
  }
}