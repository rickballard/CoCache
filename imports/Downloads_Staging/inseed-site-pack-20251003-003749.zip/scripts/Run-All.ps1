param(
  [Parameter(Mandatory=$true)][string]$RepoRoot,
  [string]$ZoneId,
  [string]$Token
)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
$stamp = Get-Date -UFormat %Y%m%d%H%M%S

& "$PSScriptRoot\Whitepaper-Cleanup.ps1" -RepoRoot $RepoRoot
& "$PSScriptRoot\Apply-InSeedChanges.ps1" -RepoRoot $RepoRoot

Push-Location $RepoRoot
git add -A
try {
  git commit -m ("chore(site): normalize nav/js/css; whitepaper skeleton; build "+$stamp) | Out-Null
} catch {
  Write-Host "No changes to commit." -ForegroundColor Yellow
}
git push | Out-Null
Pop-Location

if($ZoneId -and $Token){
  $files = @(
    'https://inseed.com/','https://inseed.com/index.html',
    'https://inseed.com/assets/site.css','https://inseed.com/assets/site.js',
    'https://inseed.com/whitepaper/'
  )
  & "$PSScriptRoot\CF-Cache-Ops.ps1" -Action DevOn -ZoneId $ZoneId -Token $Token
  & "$PSScriptRoot\CF-Cache-Ops.ps1" -Action Purge -ZoneId $ZoneId -Token $Token -Files $files
} else {
  Write-Host "Skipping Cloudflare step (no ZoneId/Token provided)." -ForegroundColor Yellow
}
Write-Host "Run-All: done." -ForegroundColor Green
