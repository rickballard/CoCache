/* InSeed site.js (theme, language, telemetry, checklist) */
(() => {
  const doc = document;
  const themeKey = "inseed-theme";
  const cur = localStorage.getItem(themeKey);
  if (cur) doc.documentElement.dataset.theme = cur;
  const themeBtn = doc.getElementById("themeToggle");
  if (themeBtn) {
    themeBtn.addEventListener("click", () => {
      const next = doc.documentElement.dataset.theme === "light" ? "" : "light";
      if (next) localStorage.setItem(themeKey, next);
      else localStorage.removeItem(themeKey);
      doc.documentElement.dataset.theme = next;
    });
  }
  const langs = [
    {code:"en",  label:"English",        href:"/"},
    {code:"gib", label:"Gibberlink (AI)",href:"/gibberlink/"},
    {code:"de",  label:"Deutsch",        href:"/intl/de/"},
    {code:"fr",  label:"Français",       href:"/intl/fr/"},
    {code:"ja",  label:"日本語",          href:"/intl/ja/"},
    {code:"ko",  label:"한국어",          href:"/intl/ko/"},
    {code:"zh",  label:"简体中文",        href:"/intl/zh/"},
    {code:"et",  label:"Eesti",          href:"/intl/et/"},
    {code:"he",  label:"עברית",          href:"/intl/he/"}
  ];
  const by = Object.fromEntries(langs.map(l=>[l.code,l]));
  const langChooser = doc.getElementById("langChooser");
  const langHead = doc.getElementById("langHead");
  const langMenu = doc.getElementById("langMenu");
  const langKey = "inseed-lang";
  function ordered(p){
    const rest = langs.filter(l=> l.code !== p && l.code !== "gib");
    return (p==="gib") ? [by.gib, by.en, ...rest] : [by[p]||by.en, by.gib, ...rest];
  }
  function render(curCode){
    if (!langHead || !langMenu) return;
    const arr = ordered(curCode);
    const l1 = langHead.querySelector(".l1");
    const l2 = langHead.querySelector(".l2");
    if (l1) l1.textContent = arr[0].label;
    if (l2) l2.textContent = arr[1]?.label || "";
    langMenu.innerHTML = "";
    arr.forEach(l => {
      const b = doc.createElement("button");
      b.className = "lang-item";
      b.setAttribute("role", "option");
      b.setAttribute("aria-selected", l.code === curCode ? "true":"false");
      b.textContent = l.label;
      b.addEventListener("click", () => { localStorage.setItem(langKey, l.code); location.href = l.href; });
      langMenu.appendChild(b);
    });
  }
  const here = (doc.documentElement.getAttribute("lang") || "en").toLowerCase();
  render(localStorage.getItem(langKey) || here || "en");
  if (langHead && langChooser){
    langHead.addEventListener("click", () => {
      const open = langChooser.classList.toggle("open");
      langChooser.setAttribute("aria-expanded", open ? "true" : "false");
    });
    doc.addEventListener("click", e => {
      if (!langChooser.contains(e.target)) {
        langChooser.classList.remove("open");
        langChooser.setAttribute("aria-expanded", "false");
      }
    });
    doc.addEventListener("keydown", e => {
      if (e.key === "Escape") {
        langChooser.classList.remove("open");
        langChooser.setAttribute("aria-expanded", "false");
      }
    });
  }
  window.inseedPulse = (ev, data={}) => {
    try {
      const p = new URLSearchParams({ ev });
      Object.entries(data).forEach(([k,v]) => p.set(k, String(v)));
      const img = new Image();
      img.src = "/__t?" + p.toString();
    } catch {}
  };
  (function bindChecklist(){
    const main = doc.getElementById("check");
    if(!main) return;
    main.classList.remove("njs");
    const qs = [...main.querySelectorAll(".q")];
    const storeKey = "inseed-check-answers";
    const saved = JSON.parse(localStorage.getItem(storeKey) || "{}");
    const bar = doc.getElementById("bar");
    function renderBar(){
      if(!bar) return;
      bar.innerHTML = "";
      qs.forEach((_,i)=>{
        const s = doc.createElement("span");
        if(saved["q"+(i+1)]!==undefined) s.className="on";
        bar.appendChild(s);
      });
    }
    function show(i){
      qs.forEach((d,idx)=>{
        if(idx===i){ d.open=true; d.scrollIntoView({block:"center",behavior:"smooth"}); }
        else { d.open=false; }
      });
      renderBar();
    }
    qs.forEach((d,idx)=>{
      d.addEventListener("click", e=>{
        const btn = e.target.closest("[data-yes]");
        if(!btn) return;
        const val = btn.getAttribute("data-yes")==="1" ? 1 : 0;
        saved[d.dataset.id] = val;
        localStorage.setItem(storeKey, JSON.stringify(saved));
        window.inseedPulse("chk", { k: d.dataset.id, v: val });
        d.open = true;
        setTimeout(()=>{ if(idx<qs.length-1) show(idx+1); }, 200);
      }, {capture:true});
    });
    const start = qs.findIndex((_,i)=> saved["q"+(i+1)]===undefined);
    show(start < 0 ? qs.length-1 : start);
  })();
})();