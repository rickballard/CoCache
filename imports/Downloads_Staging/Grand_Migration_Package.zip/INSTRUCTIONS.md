# Instructions (Absolute, Pinned)
1) Push CoCache/BPOE:
   git -C 'C:\Users\Chris\Documents\GitHub\CoCache\BPOE' remote add origin https://github.com/rickballard/CoCache.git
   git -C 'C:\Users\Chris\Documents\GitHub\CoCache\BPOE' push -u origin main

2) Thin-shim another repo: see thin_shim_stub_examples/*.yml
