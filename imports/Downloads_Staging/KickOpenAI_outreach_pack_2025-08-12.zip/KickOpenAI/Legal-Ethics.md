# Legal & Ethics
1) No impersonation.  Credit assistance transparently.  
2) No private data or third‑party secrets.  Redact emails, tokens, internal links.  
3) Keep tone respectful.  No personal attacks.  
4) Keep claims reproducible and falsifiable.  Link acceptance tests.  
5) Obey forum and GitHub rules.  No spam or mass‑mentioning.  
6) Retain a local copy of everything we post for auditability.
