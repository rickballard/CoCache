# Changelog — KickOpenAI
## 2025-08-12
- Initialized outreach pack templates.  
- Appendix prepared and linked.
