# CoWrap — CoCivium Session Wrap (2025-08-26 19:15:23)
See README in the chat response for details; this file mirrors it.
