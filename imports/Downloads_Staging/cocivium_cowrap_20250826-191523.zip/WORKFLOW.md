(See chat summary for the detailed version.)
