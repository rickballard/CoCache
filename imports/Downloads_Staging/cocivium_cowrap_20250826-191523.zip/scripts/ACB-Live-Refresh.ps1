param(
  [string]$Repo = "rickballard/CoCivium",
  [string]$Path = "docs/backlog/ADVANCED.md"
)

$issues = gh issue list -R $Repo --state open --label "type:task" --label "level:advanced" `
  --json number,title,labels,url,updatedAt | ConvertFrom-Json

function Get-Area($labels){
  $a = $labels | ForEach-Object name | Where-Object { $_ -like 'area:*' } | Select-Object -First 1
  if($a){ return $a.Substring(5) } else { return 'general' }
}

$lines = @()
if(-not $issues -or $issues.Count -eq 0){
  $lines += "_No labeled Issues matched `type:task + level:advanced` right now._"
}else{
  $issues | Group-Object { Get-Area $_.labels } | Sort-Object Name | ForEach-Object {
    $lines += "### $($_.Name)"
    $_.Group | Sort-Object updatedAt -Descending | ForEach-Object {
      $upd = (Get-Date $_.updatedAt).ToString('yyyy-MM-dd')
      $lines += ("- **#{0}** — [{1}]({2}) _(updated {3})_" -f $_.number,$_.title,$_.url,$upd)
    }
    $lines += ""
  }
}

$txt   = Get-Content -Raw -LiteralPath $Path
$block = "<!-- LIVE:BEGIN -->`n{0}`n<!-- LIVE:END -->" -f (($lines -join "`n").TrimEnd())
$txt   = [regex]::Replace($txt,'<!-- LIVE:BEGIN -->.*?<!-- LIVE:END -->',{ param($m) $block },'Singleline') -replace "`r`n","`n"
$txt | Set-Content -LiteralPath $Path -Encoding utf8 -NoNewline
