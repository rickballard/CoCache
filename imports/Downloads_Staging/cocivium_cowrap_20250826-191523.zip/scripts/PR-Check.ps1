param([int[]]$Numbers = @(267,268,272), [string]$Repo = "rickballard/CoCivium")
foreach($n in $Numbers){
  gh pr view $n -R $Repo --json number,state,mergeable,reviewDecision,checks,headRefName,baseRefName | ConvertFrom-Json | 
    Select-Object number,state,mergeable,reviewDecision,headRefName,baseRefName |
    Format-List
}
