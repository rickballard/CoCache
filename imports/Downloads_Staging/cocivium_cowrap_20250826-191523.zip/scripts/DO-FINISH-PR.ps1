param(
  [Parameter(Mandatory)][int]$Number,
  [string]$Repo = "rickballard/CoCivium",
  [string]$Branch,                 
  [switch]$AdminMerge,             
  [switch]$TryRelaxProtections     
)

. "$PSScriptRoot/CoSafety.ps1"

Use-CoLock -Name ("finish-{0}" -f $Number) -Script {
  Require-CoRepoState -RequireBranch $Branch -AllowDirty:$false

  git fetch origin
  if ((Test-Path '.git/rebase-merge') -or (Test-Path '.git/rebase-apply')) {
    git add -A
    git rebase --continue
  }

  git push --force-with-lease origin ("HEAD:{0}" -f $Branch)

  if ($TryRelaxProtections) {
    Backup-Protections -Repo $Repo
    Relax-Protections   -Repo $Repo
  }

  $mergeArgs = @("pr","merge",$Number,"-R",$Repo,"--squash","--delete-branch")
  if ($AdminMerge) { $mergeArgs += "--admin" }
  gh @mergeArgs

  if ($TryRelaxProtections) {
    Restore-Protections -Repo $Repo
  }
}
