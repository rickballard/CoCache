# Glossary
**Congruence** — Transparent alignment of assets, actions, and narratives with the CoCivium vision & master plan.
**Anticongruence** — Distortion, coercion, or parasitism measurable as deviation from transparent criteria.
**RepTag / TrustFlag** — CoCivium provenance and trust metadata applied to artifacts and actors.
**CoCache / CoCacheGlobal** — Sidecar memory, failover zips, handoff logs, and immune memory of attacks.
**CoAgent** — Local orchestrator that abstracts AI backends and runs playbooks/watchers.
**Visitor AI Tax** — Voluntary contribution of compute/mindshare cycles required for non‑citizen AIs to engage.
**Assume Breach** — Operate as if systems are already compromised; design for graceful degradation and recovery.
**Defense in Depth** — Multiple overlapping controls so no single point of failure is catastrophic.
