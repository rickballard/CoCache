# Compliance & Framework Mapping (Practical)
## NIST CSF 2.0
- **Govern:** Defense doctrine, rights charter, role definitions, risk appetite, supply‑chain governance.
- **Identify:** Asset inventory, dependency SBOM, criticality mapping, threat modeling.
- **Protect:** Access control, secure SDLC, content provenance (C2PA), hardening baselines.
- **Detect:** Telemetry, anomaly detection, congruence drift monitors, narrative anomaly mapping.
- **Respond:** Playbooks (YAML), incident comms, public counter‑signals.
- **Recover:** Failover zips, mirrored repos, session CoWraps, post‑incident reviews to CoCache.

## ISO/IEC 27001:2022
- ISMS scope, leadership, risk management, controls (Annex A): access, cryptography, ops security, supplier mgmt, incident, continuity.

## MITRE ATT&CK
- Map detections & mitigations to common TTPs, maintain threat models for prioritized groups and software.

## EU AI Act (high‑level)
- Risk‑based obligations (documented), transparency for generative systems, data governance for training summaries, model cards; monitor evolving GPAI guidance.
