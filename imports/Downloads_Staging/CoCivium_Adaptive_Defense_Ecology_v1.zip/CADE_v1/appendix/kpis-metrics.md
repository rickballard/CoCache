# KPIs & Metrics
- **Congruence Index (CI):** Weighted score across governance, technical controls, transparency, and participation quality.
- **Signal Provenance Rate:** % of public artifacts with verifiable provenance (C2PA/RepTag).
- **Time to Contain (TTC):** Mean time from detection to quarantine.
- **Time to Recovery (TTR):** Mean time to restore essential services after an incident or takedown.
- **False Positive Rate (FPR):** Incorrect quarantines over total investigations.
- **Diversity of Defenders Index:** Heterogeneity score across validator heuristics/humans/AIs.
- **Red‑Team Drill Frequency:** # of completed drills / quarter; closure rate of drill‑discovered gaps.
