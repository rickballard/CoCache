# CoCore: Public-Facing Summary (for README.md)

CoCore is the civic-graph knowledge system used by CoCivium to store modular best-practice models for governance, organizational frameworks, and hybrid society design. It enables users to discover, compose, and adapt civic models and case studies for their needs.

Key features:
- Modular CoNeura hierarchy (CoClusta, CoDendra, CoSyna...)
- One deep-dive case study per cluster
- Designed for AI-augmented co-creation and governance evolution