# Advisory Bomb: CoCore Planning Session

## Purpose of CoCore
CoCore is envisioned as the **backend civic knowledge model**, serving as the authoritative, evolving repository for best-practice templates, CoNeura hierarchy, and real-world case study ingest for the CoCivium system.

## Summary Recommendations:
- **High-level Modeling Focus Only**: Avoid fine-grained workflow modeling except for a small number of flagship case studies.
- **Seed First with Immutable Templates**: Top layers of CoNeura must be AI-curated, not crowdsourced.
- **Case Studies**: Target 1 in-depth case study per CoClusta. Others should be extendable templates.
- **Tooling**: Focus on supporting tool interoperability. Do not bake tools into CoCore, but allow tool metadata and evolution.
- **Autonomous Agents**: Only GPT-4o (and Rick-supervised) may seed the repo initially. CoIntent Protocol required for others.
- **Localization**: English-first. Multilingual/culture-aware variants are deferred until traction/income permits.

## Intended Inter-repo Role:
- **CoCivium**: Front-end and governance interface
- **CoCache**: Memory + orchestration substrate
- **CoAgentKit**: Can wrap CoCore’s API or ingest its outputs for mission execution

See attached `plan_snippets/` folder for ready-to-use text inserts.