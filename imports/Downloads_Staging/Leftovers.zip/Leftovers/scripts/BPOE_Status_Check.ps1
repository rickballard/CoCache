param(
  [string]$OutPath = "$env:USERPROFILE\Downloads\BPOE_Status_Report.txt"
)
Set-StrictMode -Version Latest; $ErrorActionPreference = 'SilentlyContinue'

$lines = New-Object System.Collections.Generic.List[string]
$stamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz'
$lines.Add("## BPOE Status Report — $stamp")
$lines.Add("")

# 1) Exit hook present?
try {
  $ex = Get-EventSubscriber -SourceIdentifier PowerShell.Exiting -ErrorAction SilentlyContinue
  $lines.Add("- Exit hook (PowerShell.Exiting): " + ($(if($ex){"OK"}else{"MISSING"})))
} catch {
  $lines.Add("- Exit hook probe: ERROR " + $_.Exception.Message)
}

# 2) OE timers / jobs
try {
  $evt = Get-EventSubscriber -SourceIdentifier OEStatusTimer -ErrorAction SilentlyContinue
  $job = Get-Job -Name OEStatusTimer -ErrorAction SilentlyContinue
  $lines.Add("- OEStatusTimer (should be none): " + ($(if($evt -or $job){"PRESENT"}else{"none"})))
} catch {
  $lines.Add("- Timer/job probe: ERROR " + $_.Exception.Message)
}

# 3) Crash sentinel
try {
  $sentinel = Join-Path $env:LOCALAPPDATA 'CoBPOE\session.sentinel'
  $lines.Add("- Crash sentinel file present: " + (Test-Path $sentinel))
} catch {
  $lines.Add("- Crash sentinel: ERROR " + $_.Exception.Message)
}

# 4) HumanGate env
try {
  $hg = $env:BPOE_HUMANGATE_ENTER_OK
  if ([string]::IsNullOrWhiteSpace($hg)) { $hg = "(unset)" }
  $lines.Add("- HumanGate ENTER=DO env (BPOE_HUMANGATE_ENTER_OK): " + $hg)
} catch {
  $lines.Add("- HumanGate env probe: ERROR " + $_.Exception.Message)
}

# 5) Profile AST check
try {
  if (Test-Path $PROFILE) {
    [System.Management.Automation.Language.Token[]]$t = $null
    [System.Management.Automation.Language.ParseError[]]$e = $null
    [System.Management.Automation.Language.Parser]::ParseFile($PROFILE,[ref]$t,[ref]$e) | Out-Null
    $lines.Add("- Profile AST: " + ($(if($e -and $e.Count){'ERROR'}else{'OK'})))
  } else {
    $lines.Add("- Profile: missing (OK)")
  }
} catch {
  $lines.Add("- Profile AST probe: ERROR " + $_.Exception.Message)
}

# 6) CoWrap pointer
try {
  $ptr = Join-Path ([Environment]::GetFolderPath('UserProfile')) 'Downloads\CoWrap.latest.json'
  if (Test-Path $ptr) {
    $obj = Get-Content -Raw -LiteralPath $ptr | ConvertFrom-Json
    $lines.Add("- CoWrap pointer: " + $obj.name + " → " + $obj.to)
    $lines.Add("  SHA256: " + $obj.sha256)
  } else {
    $lines.Add("- CoWrap pointer: not found")
  }
} catch {
  $lines.Add("- CoWrap pointer probe: ERROR " + $_.Exception.Message)
}

# 7) Lag sniff (very light)
try {
  $sw = [System.Diagnostics.Stopwatch]::StartNew()
  1..20000 | % { $null = [math]::Sqrt(144) }
  $sw.Stop()
  $lines.Add(("- Lag sniff (sqrt loop): {0} ms" -f [int]$sw.Elapsed.TotalMilliseconds))
} catch {
  $lines.Add("- Lag sniff: ERROR " + $_.Exception.Message)
}

# 8) Process footprint
try {
  $p = Get-Process -Id $PID -ErrorAction SilentlyContinue
  if ($p) {
    $lines.Add(("- Process (WS MB): {0}" -f ([math]::Round($p.WorkingSet64/1MB,1))))
    $lines.Add(("- PSVersion: {0}" -f $PSVersionTable.PSVersion))
  }
} catch {}

# Write
try {
  $dir = Split-Path -Parent $OutPath
  if ($dir) { [IO.Directory]::CreateDirectory($dir) | Out-Null }
  Add-Content -LiteralPath $OutPath -Encoding UTF8 -Value ([string]::Join([Environment]::NewLine, $lines))
  Write-Host "[BPOE_Status_Check] Wrote $OutPath" -ForegroundColor Green
} catch {
  Write-Host "[BPOE_Status_Check] Could not write report: $($_.Exception.Message)" -ForegroundColor Yellow
}