param(
  [Parameter(Mandatory)][string[]]$Paths,
  [string]$Topic = 'Leftovers',
  [string]$To = $(if ($env:COSESSION_ID) { $env:COSESSION_ID } else { 'ANY' })
)

Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
$dl = Join-Path $HOME 'Downloads'
[IO.Directory]::CreateDirectory($dl) | Out-Null

$root = Join-Path $dl 'CoWrap_build_leftovers'
$pay  = Join-Path $root 'payload'
if (Test-Path $root) { Remove-Item -Recurse -Force $root }
[IO.Directory]::CreateDirectory($pay) | Out-Null

foreach($p in $Paths){
  if (Test-Path $p) {
    $dst = Join-Path $pay (Split-Path $p -Leaf)
    Copy-Item -LiteralPath $p -Destination $dst -Force
  }
}

$ts = Get-Date -Format 'yyyyMMdd_HHmmss'
$zip = "CoWrap-$Topic-$ts-to-$To.zip"
$zipPath = Join-Path $dl $zip

# Create zip
$zipStage = Join-Path $root 'zipstage'
[IO.Directory]::CreateDirectory($zipStage) | Out-Null
Copy-Item -Recurse -Force $pay (Join-Path $zipStage 'payload')
if (Test-Path $zipPath) { Remove-Item -LiteralPath $zipPath -Force }
Compress-Archive -Path (Join-Path $zipStage '*') -DestinationPath $zipPath -Force

# Pointer
$sha = (Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash
$ptrObj = [ordered]@{
  zip     = $zipPath
  name    = $zip
  sha256  = $sha
  to      = $To
  topic   = $Topic
  created = (Get-Date).ToString('o')
  repo    = (Get-Location).Path
}
$ptrTmp = Join-Path $dl 'CoWrap.latest.json.tmp'
$ptrOut = Join-Path $dl 'CoWrap.latest.json'
($ptrObj | ConvertTo-Json -Depth 5) | Out-File -LiteralPath $ptrTmp -Encoding utf8
Move-Item -LiteralPath $ptrTmp -Destination $ptrOut -Force

Write-Host "CoWrap created → $zipPath" -ForegroundColor Green
Write-Host "Pointer updated → $ptrOut" -ForegroundColor Cyan