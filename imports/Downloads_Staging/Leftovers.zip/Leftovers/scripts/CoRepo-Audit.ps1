# Non-destructive: summarize what actually landed in CoModules (for post-crash sanity)
param([string]$Repo = "$HOME\Documents\GitHub\CoModules")
Set-StrictMode -Version Latest; $ErrorActionPreference='SilentlyContinue'
if(-not (Test-Path $Repo)){ Write-Host "[CoRepo-Audit] Repo not found: $Repo" -ForegroundColor Yellow; exit 0 }
Push-Location $Repo
try {
  try {
    $branch = (git branch --show-current).Trim()
    Write-Host ("Branch: {0}" -f $branch) -ForegroundColor Cyan
  } catch { Write-Host "git not available" -ForegroundColor Yellow }

  Write-Host "`n--- status ---" -ForegroundColor Yellow
  try { git status --porcelain=v1 } catch { Write-Host "(no git status)" -ForegroundColor DarkGray }

  Write-Host "`n--- recent commits (2h) ---" -ForegroundColor Yellow
  try { git log --since="2 hours ago" --oneline --decorate } catch { Write-Host "(no git log)" -ForegroundColor DarkGray }

  $expected = @(
    'tools/Test-BPOE.ps1',
    'tools/BPOE/CoTint.psm1',
    'tools/BPOE/CoHumanGate.psm1',
    'docs/methods/BPOE_ISSUEOPS_Explainer.md',
    'docs/methods/BPOE_Preflight.md',
    'docs/methods/BPOE_Color_Policy.md',
    'docs/methods/BPOE_HumanGate.md',
    'docs/methods/CoAgent_Product_Advisories.md',
    'docs/methods/BPOE_SESSION_CARD.md',
    'tests/BPOE.CoPong.Tests.ps1',
    'tests/BPOE.Heartbeat.Tests.ps1',
    'tests/BPOE.HumanGate.Tests.ps1'
  )

  Write-Host "`n--- expected artifacts present? ---" -ForegroundColor Yellow
  $expected | ForEach-Object {
    $p = $_
    $status = if (Test-Path $p) { 'OK' } else { 'MISSING' }
    '{0,-52} {1}' -f $p, $status
  }

  Write-Host "`n--- non-empty sizes ---" -ForegroundColor Yellow
  $expected | Where-Object { Test-Path $_ } | ForEach-Object {
    $len = (Get-Item $_).Length
    '{0,-52} {1} bytes' -f $_, $len
  }
} finally { Pop-Location }