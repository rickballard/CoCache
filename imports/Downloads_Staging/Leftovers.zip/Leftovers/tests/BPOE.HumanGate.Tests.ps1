Import-Module "$PSScriptRoot/../tools/BPOE/CoHumanGate.psm1" -Force

Describe "BPOE HumanGate" {
  Context "ENTER disabled" {
    BeforeEach { $env:BPOE_HUMANGATE_ENTER_OK = $null }
    It "rejects blank ENTER" {
      Mock -CommandName Read-Host -MockWith { "" }
      (Invoke-BpoeHumanGate -Action "x") | Should -BeFalse
    }
  }

  Context "ENTER enabled" {
    BeforeEach { $env:BPOE_HUMANGATE_ENTER_OK = "1" }
    It "accepts blank ENTER" {
      Mock -CommandName Read-Host -MockWith { "" }
      (Invoke-BpoeHumanGate -Action "x") | Should -BeTrue
    }
    It "aborts on no" {
      Mock -CommandName Read-Host -MockWith { "no" }
      (Invoke-BpoeHumanGate -Action "x") | Should -BeFalse
    }
  }
}