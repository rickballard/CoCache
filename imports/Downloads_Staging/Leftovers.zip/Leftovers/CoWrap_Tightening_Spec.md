# CoWrap Tightening Spec (3‑Panel Mode)

**Goals**
- Zero clipboard dependency, deterministic delivery.
- Include *droppings* and proof (receipts, pointers) alongside payload so the fresh pane can verify integrity and provenance.

## Writer (Heavy chat) — `CoWrap`
- Build zip under **Downloads**: `CoWrap-<Topic>-<timestamp>-to-<Target>.zip` (Target = `$env:COSESSION_ID` or `ANY`).
- Always write/update an atomic pointer **CoWrap.latest.json** in Downloads with:
  - `zip`, `name`, `sha256`, `to`, `topic`, `created`, `repo` (if applicable).
- Include **INSTALL_NOTES.txt** and **MANIFEST.txt** inside the zip.
- Include **droppings**:
  - The pointer JSON used at build time (as `CoWrap.pointer.json` in the zip).
  - Any receipts or logs created by the heavy pane relevant to the payload.

## Reader (Fresh chat) — `CoUnWrap`
- Prefer **CoWrap.latest.json** if `to` matches this pane or `ANY` (otherwise fall back to newest-by-name heuristic).
- Unpack zip into a staging folder.
- Rename original to **CoWrap_DELETABLE-<original>.zip** in Downloads (clear deletion signal).
- Archive a copy (date-stamped) and write a **receipt** (`CoUnWrap_RECEIPT_<ts>.txt`) containing:
  - Source zip name & SHA256,
  - Destination path,
  - Decision path (pointer vs heuristic),
  - Target (`to`) and topic,
  - Timestamp.
- Never touch clipboard.

## Optional Extras
- On Windows, emit an Explorer-friendly `.url` shortcut to the unwrapped folder as another breadcrumb.
- Add a dry-run flag for audits without unpacking.
