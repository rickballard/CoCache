# Leftovers Handoff (BPOE / CoAgent)

This package is a small, **self-contained** handoff to bridge sessions:
- Read-only **status check** (no changes to your repo).
- Fixed **rescue scripts** for profile issues and quick preflight.
- A compact **HumanGate** module with a Pester test.
- A **CoWrap tightening spec** so future wraps include receipts and droppings.
- A tiny **CoWrap builder** to wrap any file list.

## Quickstart
1. Open PowerShell **(new window)**.
2. Unzip this folder anywhere (e.g., Desktop). Change into it:
   ```powershell
   Set-Location '<unzipped path>/Leftovers'
   ```
3. Run a status report:
   ```powershell
   .\scripts\BPOE_Status_Check.ps1 -OutPath "$env:USERPROFILE\Downloads\BPOE_Status_Report.txt"
   ```
4. If the status report shows **Profile AST: ERROR**, run:
   ```powershell
   .\scripts\CoProfile-Guard.ps1
   ```
5. Optional health:
   ```powershell
   .\scripts\CoPreflight-Min.ps1
   .\scripts\CoRepo-Audit.ps1
   ```
6. To CoWrap any list of files later:
   ```powershell
   .\scripts\Build-CoWrap-Leftovers.ps1 -Paths @('scripts\BPOE_Status_Check.ps1','tools\BPOE\CoHumanGate.psm1') -Topic 'Leftovers'
   ```

## Notes
- HumanGate is **user-scoped** and reversible. Default behavior in CoAgent is ENTER=DO (persisted) while still allowing `no` to abort.
- DO blocks should be **multi-line**, and we avoid here-strings in chat pastes. Prefer repo scripts/modules.
- See **CoWrap_Tightening_Spec.md** for the updated 3-Panel handoff expectations.
