# CoAgent Productization Pack

This pack codifies auto-launching the CoInbox watcher in each PowerShell panel, standardizes Inbox/ToTag, and adds helpers.

TL;DR
- Inbox: `$HOME/Downloads/CoTemp/inbox`
- ToTag: short routing tag (not a URL). Use `CO_CHAT_URL` env var to record a chat URL.
