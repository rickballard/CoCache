# CoAgent Productization Checklist
- Panels set CO_TEMP/CO_TAG and optionally CO_CHAT_URL
- Ensure-InboxWatcher runs without prompts
- Logs to CoTemp/logs
- gh auth checked elsewhere
