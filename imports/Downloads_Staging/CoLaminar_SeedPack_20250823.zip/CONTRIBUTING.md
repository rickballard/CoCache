
# Contributing

- Be kind.  Keep the mission front and center: protect attention; grow minds.  
- No stealth automation features or ToS‑dodging proposals.  
- PRs must include a short rationale and test notes.  
- Keep two spaces after periods in prose.  No trailing spaces in code.
