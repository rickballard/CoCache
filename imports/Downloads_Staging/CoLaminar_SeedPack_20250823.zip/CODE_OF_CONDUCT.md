
# Code of Conduct

Be respectful.  Assume good intent.  No harassment.  Report issues to maintainers via GitHub Issues.
