
# Kid Mode — Compliance Notes (draft)

- Verifiable parental consent flow.  
- Minimize data: no content logs outside the device; only aggregates for weekly report.  
- Family control deep‑links for autoplay/search/history.  
- Clear language, no dark patterns.  Delete/export controls.
