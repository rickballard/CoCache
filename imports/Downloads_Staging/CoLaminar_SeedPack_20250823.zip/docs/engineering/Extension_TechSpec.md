
# Extension Tech Spec

- Manifest V3.  Permissions: storage, activeTab, scripting.  
- Content script selectors for Shorts/home/comments.  
- Options page persists `brightfeedPolicy` to `chrome.storage.sync`.  
- Popup: shows Focus/Growth; fetches Clean Feed from web app origin.  
- CI: pack zip on each push; lint manifest and JS.
