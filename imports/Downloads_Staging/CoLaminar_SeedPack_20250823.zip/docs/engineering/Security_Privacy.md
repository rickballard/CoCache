
# Security & Privacy (MVP)

- Local‑first storage.  Optional household sync later.  
- OAuth only for third‑party APIs.  No passwords.  
- Audit log for all proposed/applied changes.  
- Kid Mode: consent, minimization, clear deletion/export.
