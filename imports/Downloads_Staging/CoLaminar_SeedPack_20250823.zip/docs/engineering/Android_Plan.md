
# Android Plan (draft)

- Focus on Firefox/Chromium extensions first.  
- Native shell optional; avoid Accessibility automation.  
- Ship on Fenix (Firefox) Add‑ons if feasible; otherwise sideload with clear instructions.
