
# iOS Safari Content Blocker — Plan (draft)

- App bundle with content‑blocking JSON (hide Shorts/home/comments patterns).  
- Safari Web Extension for policy UI and "Clean Feed" pane.  
- Family controls: deep‑link to Screen Time settings; provide guidance screens.  
- TestFlight internal first; App Store family category later.
