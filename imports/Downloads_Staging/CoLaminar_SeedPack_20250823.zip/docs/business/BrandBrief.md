
# Brand Brief (draft)

**Name:** CoLaminar  
**Tagline:** Smooth the stream.  Grow the mind.  
**Tone:** Calm, technical, reassuring.  No fear‑bait.  
**Promise:** Your feeds will feel calmer, longer, and smarter within a day.  
**Visuals:** Cool palette, laminar flow lines, soft‑edged cards.  
**Do not:** Use "AI" as the hero.  The user is the hero; the tool is a calm assistant.
