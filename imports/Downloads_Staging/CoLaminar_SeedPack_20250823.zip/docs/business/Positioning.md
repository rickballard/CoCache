
# Positioning

**Category:** Attention hygiene / parental learning companion.  
**For:** Parents and learners who want a healthier, smarter feed.  
**Unlike:** Parental filters that only block harm or readers that only aggregate,  
**CoLaminar** curates **for** learning value, hides dopamine traps, and proves impact with simple grades.
