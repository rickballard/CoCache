
---
name: Bug report
about: Something broke or misbehaved
labels: bug
---

**What happened**
A clear description.

**Steps to reproduce**
1. 
2. 
3. 

**Expected**
What you expected to happen.

**Notes**
Logs, screenshots, environment.
