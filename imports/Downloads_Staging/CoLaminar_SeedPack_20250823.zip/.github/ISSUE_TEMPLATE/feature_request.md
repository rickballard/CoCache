
---
name: Feature request
about: Suggest an idea
labels: enhancement
---

**Problem to solve**
Short description.

**Proposal**
What should change and why.

**Acceptance**
Clear, testable acceptance criteria.
