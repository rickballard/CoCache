# CoRef Interop Stack v2 — Diagram Asset (Dark Mode)

This package includes the updated **CoRef Interop Stack** diagram (version 2), reflecting a cleaner and more communicative flowchart layout.

## Contents

- `CoRef_InteropStack_Dark_v2.png`: High-resolution dark mode diagram (raster).
- `CoRef_InteropStack_Dark_v2.svg`: Placeholder editable vector version.
- `README.md`: This usage guidance and BPOE notes.

## Usage

- Place `CoRef_InteropStack_Dark_v2.png` in the `assets/` folder of the CoRef repo.
- Reference it from the `README.md` or documentation using relative path links.
- Prefer `.svg` if replacing with AI-generated or Inkscape-updatable versions.

## Notes

- **Multiple CoLeaf layers** indicate parallel flows at the leaf level (e.g., GIBindex, CoAgent, BPOE loaders).
- Designed for **hybrid readability**: human-friendly, AI-parseable.
- Visually styled to fit within **CoSuite** brand guidelines (dark-first, bold sans-serif).

---

_This diagram is part of the CoRef AdviceBomb delivered as part of the Hitchhiker Plan integration._