# Next Actions

1) **Close PR #344** (title/mentions):
   - If stub job is green and others pass → it will auto-merge.
   - If it stalls: fix any remaining advisories; as last resort use `--admin` (if policy permits).

2) **Close PR #345** (CoSnap idea+prototype):
   - Land as docs/prototype; gate runtime to Windows-only for now.

3) **Close PR #346** (BPOE refresh):
   - Once merged, treat BPOE as policy source and refer to it via CoNudge heartbeat.

4) **Add `CoCheck.ps1` (pre-push)**:
   - Runs local stubs check, codespell, markdownlint, yamllint on changed files; blocks push on failure.

5) **Normalize the insight file header**:
   - Keep `# Being Noname` as canonical; ensure markdownlint line is present if needed. Document in BPOE.

6) **Consolidate CoAgent tools**:
   - Publish `tools/CoAgent/` module manifest; export `CoPong`, `CoNudge`, `CoSnap`; add README usage.
