CoWrap Pack — 2025-09-05_0134

What’s inside
-------------
1) SESSION_SUMMARY.md      — what we did, what’s in-flight, failures, learnings.
2) CI_MITIGATIONS.md       — quick fixes for common failing checks.
3) BPOE_DIFF.md            — the sections we added/changed in BPOE today.
4) NEXT_ACTIONS.md         — concrete steps to close the loop next session.
5) KNOWN_ISSUES.md         — things that tripped us, with root-cause notes.
6) CLI_SNIPPETS.ps1        — CoNudge helper, CoPong Full-Send, CoSnap prototype, verification cmds.
7) TROUBLESHOOTING_GH.md   — why GitHub content fetches returned 404 + reliable verification commands.

Tip: keep these files (or copy into your repo under /notes/cowrap/) so the assistant can re-ground quickly.
