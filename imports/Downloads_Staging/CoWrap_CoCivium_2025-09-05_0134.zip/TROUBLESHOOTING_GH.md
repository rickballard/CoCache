# Troubleshooting: “Still looks the same” & 404s

## Why the page doesn’t change
The GitHub link points to `main`. If your edits are in a PR branch, the published page won’t change until **after** merge.

## Prove the header at a given ref
```powershell
# 1) Get PR head ref
$ref = gh pr view 344 --json headRefName -q .headRefName

# 2) Verify the file header text at that ref (raw content)
$file = "insights/Insight_Story_Being_Noname_c2_20250801.md"
gh api -H "Accept: application/vnd.github.raw" "/repos/rickballard/CoCivium/contents/$($file)?ref=$ref" |
  Select-String '^(#\s*)Being\s+Noname' -SimpleMatch

# If 404 → the path likely doesn't exist at that ref; confirm with:
gh api "/repos/rickballard/CoCivium/contents/insights?ref=$ref" | ConvertFrom-Json | % { $_.name }
# Or use git plumbing:
git fetch origin $ref
git show origin/$ref:$file | Select-String '^(#\s*)Being\s+Noname' -SimpleMatch
```

## Unicode-safe search & replace
```powershell
$dash = "[\-\u2010-\u2015\u2212]"
(Get-Content $file -Raw) `
  -replace "(?m)^(#\s*)Being\s+name${dash}pending\b", '$1Being Noname' `
  -replace "(?i)\bname${dash}pending\b", 'Noname' | Set-Content $file -Encoding UTF8
```
