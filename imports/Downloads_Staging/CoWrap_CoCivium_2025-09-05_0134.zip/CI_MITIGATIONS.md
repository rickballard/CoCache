# CI: Common Failures → Quick Fixes

| Failing Check                      | Why it fails                              | Fast Fix (CLI) |
|---|---|---|
| **lock-readme/guard**             | README changed in unrelated PR            | `git checkout origin/main -- README.md && git commit -m "ci: drop README change"` |
| **name-pending-stubs-check**      | Stubs missing or links wrong              | Ensure BOTH exist & link to `insights/Insight_Story_Being_Noname_c2_20250801.md`: `stories/being-name-pending.md`, `insights/story-being-name-pending.md` |
| **codespell**                      | Domain words flagged (e.g., `Noname`)     | Add to `docs/lexicon/codespell-ignore.txt` |
| **markdownlint**                   | Long lines/inline HTML in insights        | Add `<!-- markdownlint-disable MD013 MD033 -->` near top once |
| **yamllint**                       | Tabs/CRLF/trailing spaces                 | tabs→spaces, normalize LF, trim trailing spaces |
| **PR labeler**                     | Label rule mismatch                        | `gh pr edit <N> --add-label docs` (and others as needed) |

## Deterministic stub workflow
```yaml
- name: Verify stubs exist and point to canonical
  run: |
    set -euo pipefail
    test -f stories/being-name-pending.md
    test -f insights/story-being-name-pending.md
    grep -q "insights/Insight_Story_Being_Noname_c2_20250801.md" stories/being-name-pending.md
    grep -q "insights/Insight_Story_Being_Noname_c2_20250801.md" insights/story-being-name-pending.md
    echo "name-pending stubs OK ✅"
    exit 0
```
