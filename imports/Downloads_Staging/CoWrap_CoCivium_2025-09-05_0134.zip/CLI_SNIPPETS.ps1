# CoNudge — focus chat, type ".", press Enter
function CoNudge {
  param([string]$TitleLike='ChatGPT|OpenAI|Civium|Claude|Gemini|Bard',[int]$DelayMs=250)
  Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue
  if(-not ("Native.Win32" -as [type])){
    Add-Type -Namespace Native -Name Win32 -MemberDefinition @"
[System.Runtime.InteropServices.DllImport("user32.dll")] public static extern bool SetForegroundWindow(System.IntPtr hWnd);
[System.Runtime.InteropServices.DllImport("user32.dll")] public static extern bool IsIconic(System.IntPtr hWnd);
[System.Runtime.InteropServices.DllImport("user32.dll")] public static extern bool ShowWindow(System.IntPtr hWnd, int nCmdShow);
[System.Runtime.InteropServices.DllImport("user32.dll")] public static extern System.IntPtr GetForegroundWindow();
"@ | Out-Null
  }
  $p = Get-Process chrome,msedge,firefox,brave,opera -ErrorAction SilentlyContinue |
       Where-Object { $_.MainWindowHandle -ne 0 -and $_.MainWindowTitle -match $TitleLike } |
       Select-Object -First 1
  if(-not $p){
    $hwnd = [Native.Win32]::GetForegroundWindow()
    if($hwnd -ne [IntPtr]::Zero){
      $p = Get-Process | Where-Object { $_.MainWindowHandle -eq $hwnd } | Select-Object -First 1
    }
  }
  if(-not $p){ Write-Warning "No chat window found"; return }
  if([Native.Win32]::IsIconic($p.MainWindowHandle)){ [Native.Win32]::ShowWindow($p.MainWindowHandle,9) | Out-Null }
  [Native.Win32]::SetForegroundWindow($p.MainWindowHandle) | Out-Null
  Start-Sleep -Milliseconds $DelayMs
  [System.Windows.Forms.SendKeys]::SendWait("."); Start-Sleep -Milliseconds 60
  [System.Windows.Forms.SendKeys]::SendWait("~")
}

# CoPong Full-Send — copy tail, focus, paste, send; fallback to folder open
function CoPong {
  [CmdletBinding()]
  param([int]$Lines,[switch]$CommandsOnly,[switch]$NoSend,[int]$MaxChars=12000,[string]$TitleLike='ChatGPT|OpenAI|Civium|Claude|Gemini|Bard')
  Set-StrictMode -Version Latest
  $LogRoot = Join-Path $HOME "Downloads\CoCivium-Logs"; New-Item -ItemType Directory -Force -Path $LogRoot | Out-Null
  function Ensure-Transcript {
    $v = Get-Variable -Name __CoPingLog -Scope Global -ErrorAction SilentlyContinue
    if (-not ($v -and $v.Value -and (Test-Path $v.Value))) {
      $path = Join-Path $LogRoot ("auto-{0}.ps1log" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
      Start-Transcript -Path $path -IncludeInvocationHeader | Out-Null
      $global:__CoPingLog = $path
    }
  }
  function Set-CoClipboard([string]$Text,[int]$Retries=4){
    for($i=1;$i -le $Retries;$i++){
      try{ Set-Clipboard -Value $Text }catch{}
      Start-Sleep -Milliseconds (60*$i)
      try{ $got = Get-Clipboard -Raw }catch{ $got=$null }
      if($got -and $got.Length -ge [Math]::Min($Text.Length,32)){ return $true }
    }
    return $false
  }
  function Focus-And-Paste([string]$TitleLike,[int]$DelayMs=250){
    Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue
    if(-not ("Native.Win32" -as [type])){
      Add-Type -Namespace Native -Name Win32 -MemberDefinition @"
[System.Runtime.InteropServices.DllImport("user32.dll")] public static extern bool SetForegroundWindow(System.IntPtr hWnd);
[System.Runtime.InteropServices.DllImport("user32.dll")] public static extern bool IsIconic(System.IntPtr hWnd);
[System.Runtime.InteropServices.DllImport("user32.dll")] public static extern bool ShowWindow(System.IntPtr hWnd, int nCmdShow);
"@ | Out-Null
    }
    $p = Get-Process chrome,msedge,firefox,brave,opera -ErrorAction SilentlyContinue |
         Where-Object { $_.MainWindowHandle -ne 0 -and ($_.MainWindowTitle -match $TitleLike -or $_.MainWindowTitle) } |
         Select-Object -First 1
    if(-not $p){ return $false }
    if([Native.Win32]::IsIconic($p.MainWindowHandle)){ [Native.Win32]::ShowWindow($p.MainWindowHandle,9) | Out-Null }
    [Native.Win32]::SetForegroundWindow($p.MainWindowHandle) | Out-Null
    Start-Sleep -Milliseconds $DelayMs
    [System.Windows.Forms.SendKeys]::SendWait("^(v)"); Start-Sleep -Milliseconds 80; [System.Windows.Forms.SendKeys]::SendWait("~")
    return $true
  }
  Ensure-Transcript
  $base=200;$min=120;$max=600
  $raw=@(); if($global:__CoPingLog -and (Test-Path $global:__CoPingLog)){ $raw = Get-Content -Path $global:__CoPingLog -Tail ($max*4) }
  $rxDrop='^(PowerShell transcript (start|end)|\*{10,}|^→ Transcript:|^✓ CoPong:|^Command start time:|^<<< CoPong PS|^PS CoPong >>>)\b'
  $raw = $raw | ? { $_ -notmatch $rxDrop }
  if($CommandsOnly){ $raw = $raw | ? { $_ -match '^\s*PS [^>]+>\s' -or $_ -match '^\s*>>' -or $_ -match '^\s*Line \|' -or $_ -match '^\s*At line' } }
  $bonus=0
  $lastCmd = (Get-History | Select-Object -Last 1 | % CommandLine)
  if($lastCmd -and ($lastCmd -match '(?i)\b(git|gh|pwsh|dotnet|npm|yarn|pnpm|pip|winget|choco|make)\b')){ $bonus+=80 }
  $tail120 = ($raw | Select-Object -Last 120) -join "`n"
  if($tail120 -match '(?im)(^At line|^Line \s*\||^CategoryInfo|^FullyQualifiedErrorId|(?:^|\s)(error|fatal)\b|Exception:|Traceback)'){ $bonus+=120 }
  $want = $Lines ? [math]::Min($max,[math]::Max($min,$Lines)) : [math]::Min($max,[math]::Max($min,$base+$bonus))
  try{ $hist = Get-History | Select-Object -Last $want | % CommandLine; if($hist){ $raw += $hist } }catch{}
  if(-not $raw -or ($raw -join '').Trim().Length -eq 0){ $raw=@('(CoPong: nothing to copy yet.)') }
  $text = (($raw | Select-Object -Last $want) -join "`r`n")
  if($text.Length -gt $MaxChars){ $text = "…(truncated to $MaxChars chars)…`r`n" + $text.Substring($text.Length - $MaxChars) }
  $ok = Set-CoClipboard $text
  $out = Join-Path $LogRoot ("copong_{0}.txt" -f (Get-Date -Format 'yyyyMMdd_HHmmss')); $text | Set-Content $out -Encoding UTF8
  Write-Host ("✓ CoPong: copied {0} chars; saved → {1}" -f $text.Length, $out) -ForegroundColor Green
  if(-not $NoSend){
    if(-not (Focus-And-Paste $TitleLike)){
      Write-Warning "Paste failed or no browser focused. Opening folder so you can drag-drop: $LogRoot"
      Start-Process explorer.exe $LogRoot
    }
  }
}

# CoSnap prototype (Windows)
function CoSnap {
  [CmdletBinding()] param([switch]$Paste)
  Set-StrictMode -Version Latest
  $SnapRoot = Join-Path $HOME "Downloads\CoCivium-Logs"; New-Item -ItemType Directory -Force -Path $SnapRoot | Out-Null
  if(-not ("Native.Win32" -as [type])){
    Add-Type -Namespace Native -Name Win32 -MemberDefinition @"
[System.Runtime.InteropServices.DllImport("user32.dll")] public static extern System.IntPtr GetForegroundWindow();
[System.Runtime.InteropServices.DllImport("user32.dll")] public static extern bool GetWindowRect(System.IntPtr hWnd, out RECT r);
public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }
"@ | Out-Null
  }
  Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue
  Add-Type -AssemblyName System.Drawing       -ErrorAction SilentlyContinue
  $h=[Native.Win32]::GetForegroundWindow(); if($h -eq [IntPtr]::Zero){ Write-Warning "No active window"; return }
  $r = New-Object Native.Win32+RECT; [void][Native.Win32]::GetWindowRect($h, [ref]$r)
  $rect = [System.Drawing.Rectangle]::FromLTRB($r.Left,$r.Top,$r.Right,$r.Bottom)
  $bmp = New-Object System.Drawing.Bitmap($rect.Width,$rect.Height)
  $g=[System.Drawing.Graphics]::FromImage($bmp); $g.CopyFromScreen($rect.Location,[System.Drawing.Point]::Empty,$rect.Size); $g.Dispose()
  $png = Join-Path $SnapRoot ("cosnap_{0}.png" -f (Get-Date -Format 'yyyyMMdd_HHmmss')); $bmp.Save($png,[System.Drawing.Imaging.ImageFormat]::Png); $bmp.Dispose()
  Write-Host "Saved: $png" -ForegroundColor Green
  if($Paste){ [System.Windows.Forms.Clipboard]::SetImage([System.Drawing.Image]::FromFile($png)); Start-Sleep -Milliseconds 120; [System.Windows.Forms.SendKeys]::SendWait("^(v)"); Start-Sleep -Milliseconds 60; [System.Windows.Forms.SendKeys]::SendWait("~") }
}
