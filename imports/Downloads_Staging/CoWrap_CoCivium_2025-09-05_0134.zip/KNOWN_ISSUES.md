# Known Issues & Root Causes

- **Unicode dashes in “name‑pending”**: Regex misses unless you include `[\-‐-―−]`. Fixed in our replace blocks and pre-commit guards.
- **Git commit quoting**: Fancy quotes/em‑dashes can cause pathspec confusion. Use ASCII-only commit messages.
- **GitHub Content API 404 on PR refs**: The file path may not exist at that ref. Always verify with `git show REF:path` or list the tree at that ref first.
- **PR labeler fails**: Ensure expected label names or sync the labeler config to current branch.
- **lock-readme**: Touching README in unrelated PRs triggers failure. Restore from `origin/main` on the PR branch.
- **Assistant drift (block leaks / verbosity)**: Use the `.` heartbeat via `CoNudge`; OE Status must be posted on heartbeat.
