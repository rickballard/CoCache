# BPOE Additions (today)

## CoPingPong — one way only (keep it simple)
- One command: `CoPong` (full-send). Copies tail, focuses chat, pastes, Enter.
- Sizing heuristics: base=200, min=120, max=600; +80 for big CLI; +120 on recent errors.
- Long output truncation with `MaxChars`; fallback to image via CoSnap if needed.

## OE Heartbeat
- Operator may send a single `.` heartbeat every ~20 minutes or when drift is suspected.
- Assistant must: (1) post OE Status, (2) re-affirm BPOE guardrails, (3) continue with minimal churn.

## CoSnap (screenshots, opt-in)
- `CoSnap` active-window PNG to `~/Downloads/CoCivium-Logs`; `CoSnapScroll -Pages N` stitches.
- `-Paste` copies image, focuses chat, pastes, sends.
- Privacy: opt-in only; visible console message; local-only storage.

## CI: Fail Causes → Mitigations
- Lock README, stub checks, codespell ignores, markdownlint toggle, YAML hygiene, PR labels.

## CoWrap Checklist
- Land doc-only PRs (auto-merge or admin if policy allows).
- Verify `main` reflects intended titles/redirects.
- `git grep -n -I -i -- 'name-pending' -- 'docs/**/*.md' 'insights/**/*.md'` for regressions.
- Keep BPOE as source of truth (no reliance on assistant memory).
