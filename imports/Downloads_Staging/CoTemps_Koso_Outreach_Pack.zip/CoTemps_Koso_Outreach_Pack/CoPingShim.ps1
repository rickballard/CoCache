# CoPing shim — defines CoDo to run scripts from %USERPROFILE%\CoTemps
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'

function CoDo {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$RelPath,
    [Parameter(ValueFromRemainingArguments=$true)][object[]]$Args
  )
  $base = Join-Path $HOME 'CoTemps'
  $file = Join-Path $base $RelPath
  if (-not (Test-Path $file)) { throw "CoDo: file not found: $file" }
  & pwsh -NoProfile -ExecutionPolicy Bypass -File $file @Args
}
