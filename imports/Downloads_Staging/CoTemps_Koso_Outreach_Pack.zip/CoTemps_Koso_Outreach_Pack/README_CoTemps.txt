# CoTemps — Koso Outreach Pack

## Files
- `CoPingShim.ps1` — defines a lightweight `CoDo` function if the CoPingPong module isn't available.
- `ops\koso\Do-Koso-Outreach.ps1` — idempotent: adds `START-HERE.md`, patches Koso doc, writes a breadcrumb, opens PR, tries to merge.
- `ops\koso\Do-Koso-OpenLink.ps1` — opens the Koso synergy doc on main (handy after merge).

## Quick start
1. Extract this folder into: `%USERPROFILE%\CoTemps\`  
   Final path example: `C:\Users\Chris\CoTemps\ops\koso\Do-Koso-Outreach.ps1`

2. In PowerShell 7:
   ```pwsh
   . "$HOME\CoTemps\CoPingShim.ps1"
   CoDo 'ops\koso\Do-Koso-Outreach.ps1' -AutoMerge
   ```

   or without the shim:
   ```pwsh
   pwsh -NoProfile -ExecutionPolicy Bypass -File "$HOME\CoTemps\ops\koso\Do-Koso-Outreach.ps1" -AutoMerge
   ```

3. Open the doc:
   ```pwsh
   CoDo 'ops\koso\Do-Koso-OpenLink.ps1'
   ```
