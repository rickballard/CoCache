param()
Start-Process -FilePath "https://github.com/rickballard/CoCivium/blob/main/outreach/partners/Koso-Synergy-Report.md"
