param(
  [string]$RepoPath = (Join-Path $HOME 'Documents\GitHub\CoCivium'),
  [switch]$AutoMerge
)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
if (-not (Test-Path $RepoPath)) { throw "Repo not found: $RepoPath" }

$StartHere = 'outreach/partners/START-HERE.md'
$KosoDoc   = 'outreach/partners/Koso-Synergy-Report.md'
$CrumbsDir = 'docs/status/breadcrumbs'
$CrumbFile = Join-Path $CrumbsDir (Get-Date -Format 'yyyy-MM-dd') + '_koso-outreach.md'
$Branch    = 'ops/koso-touchups-' + (Get-Date -Format 'yyyyMMdd-HHmm')

Push-Location $RepoPath
try {
  git fetch origin
  git checkout main | Out-Null
  git pull --ff-only
  git checkout -b $Branch

  # Ensure folders
  $dir = Split-Path -Parent $StartHere
  if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }

  # START-HERE
  $start = @"
# Partners — Start Here

Welcome! Quick entry points into CoCivium:

- **Root README** → [../../README.md](../../README.md)
- **Documentation index** → [../../docs/](../../docs/)
- **BPOE / Status (ops signal)** → [../../docs/status/BPOE.md](../../docs/status/BPOE.md)

If you're here for a partner proposal, see the specific doc in this folder (e.g., *Koso-Synergy-Report.md*).
"@
  if (-not (Test-Path $StartHere)) { Set-Content -Path $StartHere -Value $start -Encoding UTF8 }

  # Patch Koso doc "More to explore"
  if (-not (Test-Path $KosoDoc)) { throw ("Missing expected file: {0}" -f $KosoDoc) }
  $k = Get-Content $KosoDoc -Raw
  if ($k -notmatch 'More to explore in CoCivium') {
    $k += @"

---

### More to explore in CoCivium
- **Root README** → [../../README.md](../../README.md)
- **Documentation index** → [../../docs/](../../docs/)
- **BPOE / Status** → [../../docs/status/BPOE.md](../../docs/status/BPOE.md)
- **Partners: Start Here** → [START-HERE.md](START-HERE.md)
"
    Set-Content -Path $KosoDoc -Value $k -Encoding UTF8
  }

  # Breadcrumb
  if (-not (Test-Path $CrumbsDir)) { New-Item -ItemType Directory -Force -Path $CrumbsDir | Out-Null }
  $crumb = @"
# Breadcrumb — Koso Outreach ($(Get-Date -Format 'yyyy-MM-dd'))

**What shipped**
- `outreach/partners/Koso-Synergy-Report.md` (on main previously).
- Partners pointer page: `outreach/partners/START-HERE.md` (this pass).
- Koso doc includes a **More to explore** block → root README, docs/, BPOE status.

**Workflow notes**
- Use PowerShell 7 (`pwsh -NoProfile`) to avoid legacy profile noise.
- `gh pr create --base main --head <branch>` when auto-detection fails.
- Merge via `gh pr merge <num> --squash -d` (add `--auto` if checks block).

**Links**
- Koso doc: outreach/partners/Koso-Synergy-Report.md
- Partners Start Here: outreach/partners/START-HERE.md
"@
  $crumb | Set-Content -Path $CrumbFile -Encoding UTF8

  # Commit & push
  git add $StartHere $KosoDoc $CrumbFile
  $msg = "Partners: START-HERE + Koso links; add breadcrumb [" + (Get-Date -Format 'yyyyMMdd-HHmm') + "]"
  if (-not (git diff --cached --quiet)) { git commit -m $msg }
  git push -u origin $Branch

  # Best-effort labels + PR
  gh label create docs -c "#1E90FF" -d "Documentation" 2>$null
  gh label create outreach -c "#8A2BE2" -d "Partner & outreach docs" 2>$null
  gh label create partners -c "#2E8B57" -d "Partner-specific items" 2>$null
  gh label create bpoe -c "#444444" -d "BPOE / workflow" 2>$null

  $prUrl = gh pr create --base main --head $Branch `
    --title "Partners: START-HERE + Koso links; add breadcrumb" `
    --body "Adds **START-HERE.md**, ensures Koso doc exploration block, and records a breadcrumb in **docs/status/breadcrumbs/**." `
    --label docs,outreach,partners,bpoe

  if ($AutoMerge) {
    gh pr merge --squash -d --auto
  } else {
    gh pr merge --squash -d 2>$null
    if ($LASTEXITCODE -ne 0) { Write-Warning "PR not mergeable right now; run again with -AutoMerge or merge in UI." }
  }

  Write-Host "`nKoso outreach doc (main): https://github.com/rickballard/CoCivium/blob/main/outreach/partners/Koso-Synergy-Report.md" -ForegroundColor Green
}
finally {
  Pop-Location
}
