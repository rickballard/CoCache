# Migration Notes

- Copy `proposal/` into repo `/proposal/`
- Validate diagrams/links
- HumanGate review; squash-merge
