# Onramp: Contributor

- Pick `good-first-task` / `deliverable:ready`
- Follow BPOE (branch→PR→HumanGate→squash)
- Use CoWrap in PRs
