# Onramp: Researcher / Partner

- Contact partnerships (placeholder)
- Define pilot scope & evaluation
- Publish Records entry with measures
