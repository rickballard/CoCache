# Onramp: Explorer

- Read [Academy](../academy/genesis.md)
- Skim [Outputs](../outputs/index.md)
- Join discussions (placeholder)
- File a question/suggestion
