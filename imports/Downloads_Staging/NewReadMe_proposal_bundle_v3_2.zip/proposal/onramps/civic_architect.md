# Onramp: Civic Architect (Badged)

- Survey [Policies](../outputs/policies.md), [Standards](../outputs/standards.md)
- Propose via RFC (`/docs/rfcs/0000-template.md`)
- Facilitate CoCleanse; produce congruence summary
