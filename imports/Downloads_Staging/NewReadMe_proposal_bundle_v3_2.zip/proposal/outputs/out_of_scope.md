# Out of Scope (Non-Deliverables)

CoCivium does **not** deliver:
- Legal representation or adversarial litigation services.
- Criminal sentencing frameworks.
- Surveillance tooling beyond explicit, consented governance use-cases.
- Closed-source binaries without aligned open-core.
- Personal data repositories; persistent identity graphs without ethics approval.
- Partisan campaigning artifacts.
