param(
  [string[]]$Repos = @(
    "$env:USERPROFILE\Documents\GitHub\CoCivium",
    "$env:USERPROFILE\Documents\GitHub\Godspawn",
    "$env:USERPROFILE\Documents\GitHub\CoAgent"
  ),
  [switch]$WhatIf
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
function Info($m){ Write-Host "[INFO] $m" -ForegroundColor Cyan }
function Die($m){ Write-Error $m; exit 1 }

$UseWhatIf = $PSBoundParameters.ContainsKey('WhatIf')

# locate this pack folder (the script lives beside /pack/*)
$PSScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$pack = Join-Path $PSScriptRoot 'pack'

# copy policy/workflows into each repo and commit to main
foreach($repo in $Repos){
  if(-not (Test-Path $repo)){ Write-Warning "Skip missing repo $repo"; continue }
  Push-Location $repo
  try{
    Info "Installing BPOE policy and workflows into $repo"
    git fetch origin --prune
    git checkout main
    git pull --ff-only origin main

    $docs = Join-Path $repo 'docs\policies'
    $wf   = Join-Path $repo '.github\workflows'
    New-Item -ItemType Directory -Force -Path $docs | Out-Null
    New-Item -ItemType Directory -Force -Path $wf   | Out-Null

    Copy-Item (Join-Path $pack 'BPOE-land-on-main.md') $docs -Force
    Copy-Item (Join-Path $pack 'automerge-on-green.yml') $wf -Force
    Copy-Item (Join-Path $pack 'nudge-stale-branches.yml') $wf -Force

    git add $docs $wf
    if(git status --porcelain){
      if(-not $UseWhatIf){
        git commit -m "BPOE: policy + workflows (Land on Main)"
        git push origin HEAD:main
      } else { Write-Host "(WhatIf) would commit and push changes" -ForegroundColor Yellow }
    } else {
      Info "No changes to commit in $repo"
    }
  } finally {
    Pop-Location
  }
}

# merge branches onto main
$helper = Join-Path $PSScriptRoot 'Merge-LandOnMain-Now.ps1'
if(-not (Test-Path $helper)){ Die "Missing Merge-LandOnMain-Now.ps1" }

& $helper -Repos $Repos -UseGH -SquashIfNoFF -PruneMerged:$false -WhatIf:$UseWhatIf
Info "LandOnMain orchestration complete."
