# BPOE — Land on Main

Intent: seed repos so important content lands on `main` quickly and stays visible for sites and readers.

Rules:
- Default branch is `main`. Public sites publish from `main`.
- Docs and low-risk content may auto-merge on green.
- Branches older than 48h without explicit blockers should auto-merge on green.
- Stale branches get nudged weekly; >14 days can auto-close (label `needs-reopen`).
- Steward class may land directly to `main` with squash commits when appropriate.
- Use sidecars and CI so local tool gaps don’t block merges.
