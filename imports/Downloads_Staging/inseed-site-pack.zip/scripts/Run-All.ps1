
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
param(
  [Parameter(Mandatory=$true)][string]$RepoRoot,
  [string]$ZoneId,
  [string]$Token
)
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
# Step 1: clean stray whitepaper variants
& (Join-Path $here 'Whitepaper-Cleanup.ps1') -RepoRoot $RepoRoot
# Step 2: apply site patches + write canonical whitepaper shell
& (Join-Path $here 'Apply-InSeedChanges.ps1') -RepoRoot $RepoRoot -Commit -CommitMessage "fix(site): one TopNav + spacing; add site.js; canonical whitepaper"
# Step 3: optional CF purge
if($ZoneId -and $Token){
  & (Join-Path $here 'CF-Cache-Ops.ps1') -ZoneId $ZoneId -Token $Token -DevMode 'on' `
    -PurgeFiles @('https://inseed.com/','https://inseed.com/index.html','https://inseed.com/assets/site.css','https://inseed.com/assets/site.js','https://inseed.com/whitepaper/')
}
Write-Host "Done." -ForegroundColor Green
