
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
param(
  [Parameter(Mandatory=$true)][string]$ZoneId,
  [Parameter(Mandatory=$true)][string]$Token,
  [string[]]$PurgeFiles = @('https://inseed.com/','https://inseed.com/index.html','https://inseed.com/assets/site.css','https://inseed.com/assets/site.js','https://inseed.com/whitepaper/'),
  [ValidateSet('on','off')][string]$DevMode = ''
)
$H = @{ Authorization = "Bearer $Token"; 'Content-Type' = 'application/json' }
if($DevMode){
  $r = Invoke-RestMethod -Method Patch -Uri "https://api.cloudflare.com/client/v4/zones/$ZoneId/settings/development_mode" -Headers $H -Body (@{ value = $DevMode } | ConvertTo-Json)
  Write-Host "Dev mode => $($r.result.value)" -ForegroundColor Cyan
}
if($PurgeFiles.Count){
  $body = @{ files = $PurgeFiles } | ConvertTo-Json
  $r = Invoke-RestMethod -Method Post -Uri "https://api.cloudflare.com/client/v4/zones/$ZoneId/purge_cache" -Headers $H -Body $body
  if($r.success){ Write-Host "Purged: $($PurgeFiles -join ', ')" -ForegroundColor Green }
  else{ Write-Warning "Purge failed: $($r.errors | ConvertTo-Json -Compress)" }
}
