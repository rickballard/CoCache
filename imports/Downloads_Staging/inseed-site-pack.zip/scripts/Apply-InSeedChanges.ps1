
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'

param(
  [Parameter(Mandatory=$true)][string]$RepoRoot,
  [Parameter(Mandatory=$false)][switch]$Commit,
  [string]$CommitMessage = "chore(site): normalize TopNav, fix spacing, add site.js, content fixes",
  [string]$TopNavPath = ".\templates\topnav.html",
  [string]$SiteJsPath = ".\assets\site.js"
)

function Read-Text([string]$p){ if(!(Test-Path $p)){ throw "Missing file: $p"}; Get-Content -Raw -Path $p }
function Write-Text([string]$p,[string]$s){ $dir=Split-Path -Parent $p; if($dir -and !(Test-Path $dir)){ New-Item -ItemType Directory -Force -Path $dir | Out-Null }; Set-Content -Path $p -Value $s -Encoding UTF8 }

$TopNav = Read-Text (Join-Path $PSScriptRoot $TopNavPath)
$SiteJs = Read-Text  (Join-Path $PSScriptRoot $SiteJsPath)

$build = Get-Date -UFormat %Y%m%d%H%M%S

# 1) Ensure assets/site.js exists in repo
$repoSiteJs = Join-Path $RepoRoot "assets\site.js"
Write-Text $repoSiteJs $SiteJs

# 2) Patch assets/site.css: quick fixes (idempotent)
$cssPath = Join-Path $RepoRoot "assets\site.css"
if(Test-Path $cssPath){
  $css = Get-Content -Raw $cssPath
  if($css -notmatch 'InSeed v5 quick-fixes'){
@"
/* InSeed v5 quick-fixes */
.topnav + .topnav{ display:none }   /* if two navs slip in, hide the second one */
.hero, .hero img, .hero-blurb{ margin-bottom:8px !important }
.hero-blurb p{ margin-top:4px !important }
body > footer .container{ max-width:var(--page); margin:0 auto; padding:0 16px; }
.loose-links, footer .micro{ text-align:center }
/* end v5 */
"@ | Add-Content $cssPath
  }
}

# Helpers
function EnsureHead($s){
  if($s -notmatch '(?i)</head>'){ $s = "<!doctype html><head></head><body>$s</body>" }
  # CSS cache-bust
  if($s -notmatch '/assets/site\.css'){
    $s = [regex]::Replace($s,'</head>','<link rel="stylesheet" href="/assets/site.css?v='+$build+'">'+"`r`n</head>",1)
  } else {
    $s = [regex]::Replace($s,'/assets/site\.css(\?v=\d+)?','/assets/site.css?v='+$build,1)
  }
  # site.js include
  if($s -notmatch '/assets/site\.js'){
    $s = [regex]::Replace($s,'</head>','<script src="/assets/site.js?v='+$build+'" defer></script>'+"`r`n</head>",1)
  } else {
    $s = [regex]::Replace($s,'/assets/site\.js(\?v=\d+)?','/assets/site.js?v='+$build,1)
  }
  if($s -notmatch 'rel="icon"'){
    $s = [regex]::Replace($s,'</head>','<link rel="icon" href="/favicon.svg" type="image/svg+xml">'+"`r`n</head>",1)
  }
  return $s
}
function EnsureSingleTopNav($s){
  # remove ALL existing .topnav navs (legacy or prior runs)
  $s = [regex]::Replace($s,'(?is)<nav[^>]*class\s*=\s*["'']topnav["''][\s\S]*?</nav>','')
  # inject our single nav immediately after <body>
  if($s -match '(?is)<body[^>]*>'){
    $s = [regex]::Replace($s,'(<body[^>]*>)', { param($m) $m.Groups[1].Value+"`r`n"+$TopNav }, 1)
  } else { $s = $TopNav + "`r`n" + $s }
  # defensive de-dupe if two slipped in anyway
  $s = [regex]::Replace($s,'(?is)(<nav[^>]*class\s*=\s*["'']topnav["''][\s\S]*?</nav>)(?:\s*<nav[^>]*class\s*=\s*["'']topnav["''][\s\S]*?</nav>)+','$1')
  return $s
}
function ContentFixes($s){
  # Deduplicate repeated phrase
  $s = [regex]::Replace($s,'(?i)\b(data-?leakage or vendor lock-in)\b(?:\s*(?:,|and)?\s*\1\b)+','$1')
  # quickly\. -> quickly.
  $s = $s -replace 'quickly\\\.', 'quickly.'
  # common typos
  $s = $s.Replace('gaurdrails','guardrails').Replace('vissionary','visionary').Replace('consutant','consultant').Replace('virtical','vertical').Replace('balue','value')
  return $s
}

# 3) Patch HTML files
$patched = @()
Get-ChildItem -Path $RepoRoot -Recurse -File -Include *.html | Where-Object {
  $_.FullName -notmatch '\\deprecated\\'
} | ForEach-Object {
  $raw = Get-Content -Raw $_.FullName
  $new = ContentFixes (EnsureSingleTopNav (EnsureHead $raw))
  if($new -ne $raw){
    Set-Content -Path $_.FullName -Value $new -Encoding UTF8
    $patched += $_.FullName
  }
}

# 4) Normalize the CEO Survival block on home
$idx = Join-Path $RepoRoot 'index.html'
if(Test-Path $idx){
  $raw = Get-Content -Raw $idx
  $block = @'
<h2>CEO Survival Guide</h2>
<p class="muted">Business vision perspective in the age of AI:</p>
<ul>
  <li><a href="/whitepaper/">CEO Survival Guide (Executive Summary + Full Paper)</a></li>
</ul>
'@
  $new = [regex]::Replace($raw,'(?is)<h2[^>]*>\s*(For\s*Boards\s*and\s*CEOs|Legacy\s*CEO\s*vs\s*TOS-AI|CEO\s*Survival\s*Guide)\s*</h2>\s*<ul>.*?</ul>',$block,1)
  if($new -ne $raw){ Set-Content -Path $idx -Value $new -Encoding UTF8; $patched += $idx }
}

# 5) Write minimal whitepaper shell (non-destructive if exists)
$wpDir = Join-Path $RepoRoot 'whitepaper'
if(!(Test-Path $wpDir)){ New-Item -ItemType Directory -Force $wpDir | Out-Null }
$wpIndex = Join-Path $wpDir 'index.html'
if(!(Test-Path $wpIndex)){
@"
<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>CEO Survival Guide • InSeed</title>
<meta name="description" content="Executive summary and full whitepaper for leaders navigating AI-era operations.">
<link rel="stylesheet" href="/assets/site.css?v=$build">
<script src="/assets/site.js?v=$build" defer></script>
</head><body>
<!-- topnav inject will place here on first run -->
<main class="container" style="max-width:900px;margin:2rem auto;padding:0 1rem">
  <h1>CEO Survival Guide</h1>

  <section id="exec-summary">
    <h2>Executive Summary</h2>
    <p class="muted">A concise 2–3 minute brief for boards and CEOs.</p>
    <ol>
      <li><strong>The problem:</strong> Fragmented data, AI pilots without runway, rising risk of data-leakage or vendor lock-in.</li>
      <li><strong>The approach:</strong> TOS‑AI runway (intake → sandbox → pilot → guardrails → service) with weekly incremental outcomes.</li>
      <li><strong>What changes:</strong> Single source of governed data, minimal viable services, reversible contracts, measurable risk reduction.</li>
      <li><strong>Next steps:</strong> Start with one critical workflow; publish a one-pager; staff a cross‑functional tiger‑team.</li>
    </ol>
  </section>

  <hr>

  <section id="full-paper">
    <h2>Full Whitepaper</h2>
    <p>Use this page as the canonical home for the paper. Replace the stubs below with the final content.</p>
    <h3>1. Context</h3>
    <p>[replace me]</p>
    <h3>2. Risks &amp; Guardrails</h3>
    <p>[replace me]</p>
    <h3>3. Runway &amp; Services</h3>
    <p>[replace me]</p>
    <h3>4. Roadmap</h3>
    <p>[replace me]</p>
    <h3>Appendix</h3>
    <p>[replace me]</p>
  </section>

  <p class="micro" style="text-align:center;margin-top:2rem">This page co‑evolves via reader feedback. No personal data is collected. <a href="/contact/?topic=feedback">Share input</a>.</p>
</main>
</body></html>
"@ | Set-Content -Path $wpIndex -Encoding UTF8
  $patched += $wpIndex
}

if($Commit){
  Push-Location $RepoRoot
  git add -A
  git commit -m $CommitMessage
  Pop-Location
}

Write-Host "Patched files:" -ForegroundColor Cyan
$patched | ForEach-Object { Write-Host " - $_" }
