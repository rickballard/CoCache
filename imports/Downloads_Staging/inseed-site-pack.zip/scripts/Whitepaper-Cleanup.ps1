
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
param([Parameter(Mandatory=$true)][string]$RepoRoot)
$deprecated = Join-Path $RepoRoot 'deprecated'
if(!(Test-Path $deprecated)){ New-Item -ItemType Directory -Force -Path $deprecated | Out-Null }

Get-ChildItem -Path $RepoRoot -Recurse -File -Include *amuse*.html,*fun*.html,*playful*.html | ForEach-Object {
  $target = Join-Path $deprecated $_.Name
  Move-Item -Force $_.FullName $target
  Write-Host "Moved $_ to $target" -ForegroundColor Yellow
}
