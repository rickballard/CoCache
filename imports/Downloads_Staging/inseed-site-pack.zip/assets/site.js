
// InSeed site.js — theme, language, and privacy-first telemetry helpers
(function () {
  const themeKey = 'inseed-theme';
  const langKey  = 'inseed-lang';

  // THEME
  try {
    const saved = localStorage.getItem(themeKey);
    if (saved) document.documentElement.dataset.theme = saved;
  } catch (_) {}
  document.addEventListener('click', (e) => {
    const t = e.target.closest('#themeToggle');
    if (!t) return;
    const cur = document.documentElement.dataset.theme === 'light' ? '' : 'light';
    if (cur) localStorage.setItem(themeKey, cur); else localStorage.removeItem(themeKey);
    document.documentElement.dataset.theme = cur;
  });

  // LANGUAGE
  const langs = [
    {code:'en', label:'English', href:'/'},
    {code:'gib', label:'Gibberlink (AI)', href:'/gibberlink/'},
    {code:'de', label:'Deutsch', href:'/intl/de/'},
    {code:'fr', label:'Français', href:'/intl/fr/'},
    {code:'ja', label:'日本語', href:'/intl/ja/'},
    {code:'ko', label:'한국어', href:'/intl/ko/'},
    {code:'zh', label:'简体中文', href:'/intl/zh/'},
    {code:'et', label:'Eesti', href:'/intl/et/'},
    {code:'he', label:'עברית', href:'/intl/he/'}
  ];
  function renderLangMenu(current) {
    const wrap = document.getElementById('langChooser');
    const head = document.getElementById('langHead');
    const menu = document.getElementById('langMenu');
    if (!wrap || !head || !menu) return;
    const by = Object.fromEntries(langs.map(l => [l.code, l]));
    const here = (document.documentElement.getAttribute('lang') || 'en').toLowerCase();
    const cur = current || localStorage.getItem(langKey) || here || 'en';
    function ordered(p){
      const rest = langs.filter(l => l.code !== p && l.code !== 'gib');
      return (p==='gib') ? [by.gib, by.en, ...rest] : [by[p] || by.en, by.gib, ...rest];
    }
    const arr = ordered(cur);
    const l1 = head.querySelector('.l1'); const l2 = head.querySelector('.l2');
    if (l1) l1.textContent = arr[0].label;
    if (l2) l2.textContent = arr[1]?.label || '';
    menu.innerHTML = '';
    arr.forEach(l => {
      const b = document.createElement('button');
      b.className = 'lang-item'; b.setAttribute('role','option');
      b.setAttribute('aria-selected', l.code === cur ? 'true' : 'false');
      b.textContent = l.label;
      b.addEventListener('click', () => {
        try { localStorage.setItem(langKey, l.code); } catch(_){}
        location.href = l.href;
      });
      menu.appendChild(b);
    });
    head.addEventListener('click', () => {
      const o = wrap.classList.toggle('open');
      wrap.setAttribute('aria-expanded', o ? 'true' : 'false');
    });
    document.addEventListener('click', (e) => {
      if (!wrap.contains(e.target)) {
        wrap.classList.remove('open');
        wrap.setAttribute('aria-expanded', 'false');
      }
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        wrap.classList.remove('open');
        wrap.setAttribute('aria-expanded', 'false');
      }
    });
  }
  renderLangMenu();

  // TELEMETRY (privacy-first): only coarse org/country via Cloudflare, no PII
  function sendTelemetry(ev, k, v) {
    try {
      const img = new Image();
      img.decoding = 'async';
      const qp = new URLSearchParams({ ev:String(ev||''), k:String(k||''), v:String(v||'') });
      img.src = '/__t?' + qp.toString();
    } catch (_) {}
  }
  // Expose for inline handlers if needed
  window.InSeed = window.InSeed || {};
  window.InSeed.telemetry = sendTelemetry;

  // CHECKLIST UX binder (for pages that use [data-yes] buttons)
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-yes]');
    if (!btn) return;
    const d = e.target.closest('.q');
    const yes = btn.getAttribute('data-yes') === '1' ? '1' : '0';
    const key = d?.dataset?.id || 'q';
    sendTelemetry('chk', key, yes);
  });
})();
