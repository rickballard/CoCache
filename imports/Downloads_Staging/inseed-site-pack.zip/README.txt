
InSeed Site Pack — programmatic fixes & whitepaper consolidation
===============================================================

WHAT THIS DOES
--------------
1) Normalizes a single TopNav across pages and injects working theme/lang JS.
2) Tightens hero spacing, centers footer text, and prevents duplicate navs (CSS quick fix).
3) Adds /assets/site.js (theme toggle, language picker, telemetry helper, checklist binder).
4) Consolidates whitepaper to /whitepaper/ with Exec Summary + Full Paper (shell ready).
5) Optionally purges Cloudflare cache for key pages and turns Dev Mode on for quick verification.
6) Provides a cleanup script to move any "amusing/fun" variants into /deprecated.

FILES
-----
scripts/Apply-InSeedChanges.ps1   - Patch HTML, add site.js, CSS fixes, update home link to /whitepaper/
scripts/Whitepaper-Cleanup.ps1    - Move any playful/amusing variants to /deprecated
scripts/CF-Cache-Ops.ps1          - Turn CF dev mode on/off and purge specific files
scripts/Run-All.ps1               - Orchestrates everything (cleanup -> patch -> purge)
assets/site.js                    - Theme/lang/telemetry/checklist logic
templates/topnav.html             - Canonical navigational header
whitepaper/index.html             - Canonical whitepaper (Exec Summary + Full Paper placeholders)

HOW TO RUN
----------
1) Unzip this somewhere (e.g., Downloads\inseed-site-pack\).
2) Open a PowerShell and run:

   .\scripts\Run-All.ps1 -RepoRoot "$HOME\Documents\GitHub\InSeed" `
     -ZoneId "f78decddfecdb9880e5a1f93bf98b877" -Token "YOUR_CF_TOKEN"

   (You can omit the -ZoneId/-Token flags if you just want local file changes.)

NOTES
-----
- This bundle is idempotent. You can run it again safely.
- No PII is collected by site.js or your telemetry worker; only anonymous signals.
- Commit messages are concise for traceability.
