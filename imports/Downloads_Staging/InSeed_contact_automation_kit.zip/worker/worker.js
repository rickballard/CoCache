// worker/worker.js
// Cloudflare Worker: receive POST from contact forms, verify Turnstile (optional), validate, send via Resend
export default {
  async fetch(request, env, ctx) {
    if (request.method !== 'POST') {
      return new Response('Method Not Allowed', { status: 405 });
    }
    const origin = request.headers.get('Origin') || '';
    const allowed = (env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
    if (allowed.length && !allowed.includes(origin)) {
      return new Response('Forbidden origin', { status: 403 });
    }

    // Enforce JSON body
    let data;
    try {
      data = await request.json();
    } catch {
      return new Response('Bad Request (expected JSON)', { status: 400 });
    }

    const email = (data.email || '').trim();
    const name = (data.name || '').trim();
    const message = (data.message || '').trim();
    const token = (data['cf-turnstile-response'] || data.turnstile || '').trim();

    // Basic validation
    const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRe.test(email)) return resp(400, {ok:false,error:"invalid_email"});
    if (message.length < 10)  return resp(400, {ok:false,error:"message_too_short"});
    // crude link/throttle
    const links = (message.match(/https?:\/\//gi) || []).length;
    if (links > 3) return resp(400, {ok:false,error:"too_many_links"});

    // Optional Turnstile verify
    if (env.TURNSTILE_SECRET && token) {
      const formData = new FormData();
      formData.append('secret', env.TURNSTILE_SECRET);
      formData.append('response', token);
      formData.append('remoteip', request.headers.get('CF-Connecting-IP') || '');
      const verify = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
        method: 'POST',
        body: formData
      }).then(r => r.json()).catch(() => ({success:false}));
      if (!verify.success) return resp(400, {ok:false,error:"captcha_failed"});
    }

    // Compose email using Resend
    const to = env.TO_EMAIL || 'rballard@InSeed.com';
    const from = env.FROM_EMAIL || 'no-reply@mail.inseed.com';
    if (!env.RESEND_API_KEY) return resp(500,{ok:false,error:"missing_resend_api_key"});

    const subject = `Contact from ${name || email}`;
    const html = `
      <h3>New contact form submission</h3>
      <p><b>Name:</b> ${escapeHtml(name)}</p>
      <p><b>Email:</b> ${escapeHtml(email)}</p>
      <pre style="white-space:pre-wrap;font-family:system-ui,Segoe UI,sans-serif">${escapeHtml(message)}</pre>
      <hr>
      <small>Origin: ${escapeHtml(origin || 'unknown')}</small>
    `;

    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${env.RESEND_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        from, to, subject, html,
        reply_to: email
      })
    });
    if (!res.ok) {
      const txt = await res.text();
      return resp(502, { ok:false, error:"resend_error", detail: txt.slice(0,500) });
    }
    return resp(200, { ok:true });
  }
};

function resp(status, obj) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { 'content-type': 'application/json', 'cache-control': 'no-store' }
  });
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, m => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  }[m]));
}
