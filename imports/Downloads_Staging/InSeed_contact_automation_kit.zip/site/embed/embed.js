// site/embed/embed.js
(() => {
  const form = document.querySelector('#contact-form');
  const status = document.querySelector('#status');
  // Set this to your deployed Worker URL (no trailing slash)
  const ENDPOINT = window.CONTACT_ENDPOINT || 'https://YOUR_WORKER_SUBDOMAIN.workers.dev';

  form?.addEventListener('submit', async (e) => {
    e.preventDefault();
    status.textContent = 'Sending…';
    const fd = new FormData(form);
    // include Turnstile response if present
    const token = window.turnstile?.getResponse?.();
    if (token) fd.append('cf-turnstile-response', token);

    const payload = {};
    for (const [k,v] of fd.entries()) payload[k] = v;

    try {
      const res = await fetch(ENDPOINT, {
        method: 'POST',
        headers: {'content-type':'application/json'},
        body: JSON.stringify(payload),
      });
      const j = await res.json().catch(() => ({}));
      if (!res.ok || !j.ok) throw new Error(j.error || 'send_failed');
      status.textContent = 'Thanks! Your message has been sent.';
      form.reset();
      if (window.turnstile?.reset) window.turnstile.reset();
    } catch (err) {
      status.textContent = 'Sorry, something went wrong. Please try again.';
      console.error(err);
    }
  });
})();
