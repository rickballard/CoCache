# scripts/setup.ps1
# Programmatic setup: pushes Worker code to a new repo, sets GitHub secrets/vars, and prepares to deploy via Cloudflare Wrangler Action.
param(
  [string]$Owner = "rickballard",
  [string]$Repo  = "inseed-contact-endpoint",
  [string]$Local = "$PWD\inseed-contact-endpoint",
  [string]$AllowedOrigins = "https://inseed.com,https://groupbuild.org,https://rickballard.github.io/InSeed,https://rickballard.github.io/GroupBuild",
  [string]$ToEmail = "rballard@InSeed.com",
  [string]$FromEmail = "no-reply@mail.inseed.com"
)

$ErrorActionPreference='Stop'

# 1) Create local folder & copy worker files
New-Item -ItemType Directory -Force -Path $Local | Out-Null
Copy-Item -Recurse -Force "$PSScriptRoot\..\worker\*" $Local

# Patch wrangler.toml vars
(Get-Content "$Local\wrangler.toml") `
  -replace 'ALLOWED_ORIGINS = ".*"', ('ALLOWED_ORIGINS = "'+$AllowedOrigins+'"') `
  -replace 'TO_EMAIL = ".*"', ('TO_EMAIL = "'+$ToEmail+'"') `
  -replace 'FROM_EMAIL = ".*"', ('FROM_EMAIL = "'+$FromEmail+'"') `
  | Set-Content "$Local\wrangler.toml"

# 2) Init git & create GitHub repo (if missing)
if (-not (Test-Path (Join-Path $Local '.git'))) { git -C $Local init | Out-Null }
if (-not (Get-Command gh -ErrorAction SilentlyContinue)) { throw "gh CLI required. Install from https://cli.github.com/" }

$slug = "$Owner/$Repo"
$exists = $false; try { gh repo view $slug 1>$null 2>$null; $exists=$true } catch {}
if (-not $exists) {
  gh repo create $slug --public --source $Local --remote origin --push
} else {
  try { git -C $Local remote get-url origin 1>$null 2>$null } catch { git -C $Local remote add origin "https://github.com/$slug.git" }
  git -C $Local add -A
  if (-not (git -C $Local diff --cached --quiet)) {
    git -C $Local commit -m "feat: contact worker scaffolding"
    git -C $Local branch -M main
    git -C $Local push -u origin main
  }
}

Write-Host "`nNext steps:" -f Yellow
Write-Host "  1) Create a Cloudflare API token with Workers write (or run 'wrangler login')." -f Yellow
Write-Host "  2) Set GitHub secrets on $slug :" -f Yellow
Write-Host "     - RESEND_API_KEY (from https://resend.com/api-keys)" -f Yellow
Write-Host "     - CLOUDFLARE_API_TOKEN (if using the wrangler action)" -f Yellow
Write-Host "     - CLOUDFLARE_ACCOUNT_ID (if using the wrangler action)" -f Yellow
Write-Host "  3) Deploy locally:  npm i -g wrangler ; cd $Local ; wrangler deploy" -f Yellow
Write-Host "  4) Point your forms to the deployed URL and keep ALLOWED_ORIGINS tight." -f Yellow
