# Insight Folder

This folder contains philosophical essays, refactored from legacy codices or emergent through recursive pattern work.

These are *not* canonical like the Codex—they are explorations, arguments, and mirrors.

They are meant to evolve.