[CmdletBinding()]
param(
  [string]$Repo = "$HOME\Documents\GitHub\InSeed",
  [string]$FragmentPath,
  [switch]$Commit
)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'

$about = Join-Path $Repo 'about\index.html'
if(-not (Test-Path $about)){ throw "Missing: $about" }
if(-not (Test-Path $FragmentPath)){ throw "Missing fragment: $FragmentPath" }

$frag = Get-Content $FragmentPath -Raw
$t    = Get-Content $about -Raw

$t = [regex]::Replace($t, '(?is)\s*<!--\s*about:\s*origins-intent v1\s*-->[\s\S]*?</section>', '', 1)
$t = [regex]::Replace($t, '(?is)\s*<section[^>]*id="history"[\s\S]*?</section>', '', 1)
$t = [regex]::Replace($t, '(?is)\s*<section[^>]*id="origins"[\s\S]*?</section>', '', 1)

if($t -notmatch 'about:\s*story-v1'){
  $t = [regex]::Replace($t, '(?is)(<h1[^>]*>.*?</h1>)', { param($m) $m.Groups[1].Value + "`r`n" + $frag }, 1)
}

$build = Get-Date -UFormat %Y%m%d%H%M%S
$t = $t -replace 'href="/assets/site\.css(\?[^"]*)?"', "href=""/assets/site.css?v=$build"""
$t = $t -replace 'src="/assets/site\.js(\?[^"]*)?"',  "src=""/assets/site.js?v=$build"""

$backup = Join-Path (Split-Path $about -Parent) ("index.backup-{0}.html" -f $build)
Copy-Item $about $backup -Force
Set-Content -Encoding UTF8 $about $t

if($Commit){
  Push-Location $Repo
  try{
    git add $about
    git commit -m "about: insert story-v1 fragment; remove old history/origins; cache-bust" | Out-Null
    git push | Out-Null
    Write-Host "Committed and pushed about page changes."
  } finally { Pop-Location }
} else {
  Write-Host "Updated about page (no commit). Backup at $backup"
}
