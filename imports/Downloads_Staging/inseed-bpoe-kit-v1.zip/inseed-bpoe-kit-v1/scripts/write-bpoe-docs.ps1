[CmdletBinding()]
param(
  [string]$Repo = "$HOME\Documents\GitHub\InSeed",
  [switch]$Commit
)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'

$docs = Join-Path $Repo 'docs\bpoe'
New-Item -ItemType Directory -Force -Path $docs | Out-Null

$bluepop = @'
# Blue-Pop SVG (BPOE Pattern)

**Why**: consistent, readable diagrams in light/dark; portable (styles embedded); easy to evolve.

**Key moves**
- Embed palette + styles **inside** `<svg>` via `<style data-inseed-bluepop>…</style>`.
- Add `<defs><filter id="pop"><feDropShadow …/></filter></defs>` and apply to card nodes.
- Prefer rectangles with rx=12 for nodes, rx=16 for panels; blue stroke 1.25–1.35; soft shadow.
- Never rely on external CSS when saving to `/assets/`.

**Starter CSS** (selectors cover both attribute and class-based nodes):

```css
:root{
  /* light */
  --p75:#eaf0ff; --p300:#a5b4fc; --p400:#818cf8; --border:#b8c2ea; --ink:#1e2330; --accent:#eef2ff;
}
@media (prefers-color-scheme: dark){
  :root{
    /* dark */
    --p75:#121a33; --p300:#24367a; --p400:#2f44a3; --border:#2b3246; --ink:#e6e9f5; --accent:#141a2a;
  }
}
rect[rx="16"], .panel { fill:var(--accent); stroke:var(--border) }
rect[rx="12"], .node, .card { fill:var(--p75); stroke:var(--p300); stroke-width:1.25; filter:url(#pop) }
text { fill:var(--ink); }
line, path { stroke:var(--p400); }
marker path { fill:var(--p400); }
```
'@

$workflow = @'
# Diagram Workflow (BPOE)

1) Draft in Canvas/Figma/hand; export **SVG** (e.g., 1100×260/320). Use nodes rx=12; panel rx=16.
2) Inject Blue-Pop styles + `#pop` filter _inside_ SVG.
3) Save to `/assets/diagram-*.svg` with a descriptive name.
4) Insert with `<figure>`; write literal **alt** and interpretive **figcaption**.
5) Cache-bust the page (update `site.css?v=…` and `site.js?v=…`).
6) Keep arrows visible (prefer short segments; avoid obscured long lines).
'@

$page_surgery = @'
# Page Surgery Playbook (BPOE)

- **Nav landmark**: `<nav class="topnav" role="navigation" aria-label="Main">`
- **Skip link**: `<a id="skip-link" href="#main" class="skip-link">…</a>` + `<main id="main">`
- **Language**: current first; **Gibberlink** second; `aria-expanded`, keyboard handlers
- **Strapline**: top-level pages only; audit and remove elsewhere
- **Cache bust**: two separate `-replace` calls (CSS then JS)

**Regex tip**: When you need capture groups (`$m.Groups`), use `[regex]::Replace($text, 'pattern', { param($m) '…' }, 1)`.
'@

$cache_busting = @'
# Cache Busting (BPOE)

Use two separate `-replace` calls:

```powershell
$build = Get-Date -UFormat %Y%m%d%H%M%S
$t = $t -replace 'href="/assets/site\.css(\?[^"]*)?"', "href=""/assets/site.css?v=$build"""
$t = $t -replace 'src="/assets/site\.js(\?[^"]*)?"',  "src=""/assets/site.js?v=$build"""
```
'@

Set-Content -Encoding UTF8 (Join-Path $docs 'BPOE-BluePopSVG.md')      $bluepop
Set-Content -Encoding UTF8 (Join-Path $docs 'BPOE-Diagram-Workflow.md') $workflow
Set-Content -Encoding UTF8 (Join-Path $docs 'BPOE-Page-Surgery.md')     $page_surgery
Set-Content -Encoding UTF8 (Join-Path $docs 'BPOE-Cache-Busting.md')    $cache_busting

if($Commit){
  Push-Location $Repo
  try{
    git add docs/bpoe
    git commit -m "docs(bpoe): add Blue-Pop SVG, Diagram Workflow, Page Surgery, Cache Busting" | Out-Null
    git push | Out-Null
    Write-Host "Committed and pushed docs."
  } finally { Pop-Location }
} else {
  Write-Host "Docs written to $docs (no commit). Use -Commit to auto-commit."
}
