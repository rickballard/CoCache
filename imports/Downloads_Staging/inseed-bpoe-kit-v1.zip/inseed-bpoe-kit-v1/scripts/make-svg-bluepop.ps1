[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][string]$Path,
  [string]$Repo = "$HOME\Documents\GitHub\InSeed",
  [switch]$Commit
)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'

if(-not (Test-Path $Path)){ throw "File not found: $Path" }
$t = Get-Content $Path -Raw

if($t -notmatch 'data-inseed-bluepop'){
  $style = @'
<style data-inseed-bluepop>
  :root{
    --p75:#eaf0ff; --p300:#a5b4fc; --p400:#818cf8; --border:#b8c2ea; --ink:#1e2330; --accent:#eef2ff;
  }
  @media (prefers-color-scheme: dark){
    :root{
      --p75:#121a33; --p300:#24367a; --p400:#2f44a3; --border:#2b3246; --ink:#e6e9f5; --accent:#141a2a;
    }
  }
  rect[rx="16"], .panel { fill:var(--accent); stroke:var(--border) }
  rect[rx="12"], .node, .card { fill:var(--p75); stroke:var(--p300); stroke-width:1.25; filter:url(#pop) }
  text { fill:var(--ink); }
  line, path { stroke:var(--p400); }
  marker path { fill:var(--p400); }
</style>
'@
  $t = [regex]::Replace($t,'(<svg[^>]*>)', { param($m) $m.Groups[1].Value + "`r`n" + $style }, 1)
}

if($t -notmatch 'id="pop"'){
  $defs = '<defs><filter id="pop"><feDropShadow dx="0" dy="1" stdDeviation="1.2" flood-opacity=".25"/></filter></defs>'
  $t = [regex]::Replace($t,'(<svg[^>]*>)', { param($m) $m.Groups[1].Value + "`r`n" + $defs }, 1)
}

if($t -notmatch 'data-inseed-pop-override'){
  $override = @'
<style data-inseed-pop-override>
  rect.node, .node { stroke-width:1.35 }
</style>
'@
  $t = [regex]::Replace($t,'(<svg[^>]*>)', { param($m) $m.Groups[1].Value + "`r`n" + $override }, 1)
}

Set-Content -Encoding UTF8 $Path $t

if($Commit){
  Push-Location $Repo
  try{
    git add $Path
    git commit -m ("style(bluepop): ensure palette+shadow injected for {0}" -f (Split-Path -Leaf $Path)) | Out-Null
    git push | Out-Null
    Write-Host "Committed and pushed changes for $Path"
  } finally { Pop-Location }
} else {
  Write-Host "Updated $Path (no commit). Use -Commit to auto-commit."
}
