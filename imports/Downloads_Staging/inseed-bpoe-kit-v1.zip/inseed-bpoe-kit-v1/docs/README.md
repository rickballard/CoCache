# InSeed BPOE Kit (v1)

Created: 2025-10-03 23:33:15 UTC

This kit gives you short, reusable **PowerShell scripts** and **docs** so you can run compact DO blocks
and avoid long chat-pasted here-strings.

## Contents

- `scripts/make-svg-bluepop.ps1` — injects the Blue‑Pop palette + shadow into an SVG (idempotent).
- `scripts/write-bpoe-docs.ps1` — writes BPOE docs into `docs/bpoe/` (optionally commits).
- `scripts/inject-about-story.ps1` — inserts the new story fragment on `/about/` (backs up & optional commit).
- `templates/about-story-v1.htmlfrag` — the narrative block for the About page.
- `docs/bpoe/*.md` — BPOE guidance (Blue‑Pop, Diagram Workflow, Page Surgery, Cache Busting).

## Quick use

```powershell
cd $HOME\Downloads\inseed-bpoe-kit-v1\scripts

# 1) Write BPOE docs (and commit)
.\write-bpoe-docs.ps1 -Repo "$HOME\Documents\GitHub\InSeed" -Commit

# 2) Ensure Blue‑Pop is inside timeline SVG (and commit)
.\make-svg-bluepop.ps1 -Path "$HOME\Documents\GitHub\InSeedssets\diagram-about-timeline.svg" -Commit

# (Optional) do the same for other diagrams
# .\make-svg-bluepop.ps1 -Path "$HOME\Documents\GitHub\InSeedssets\diagram-scoreboard.svg" -Commit

# 3) Insert About story fragment (reviewed in templates/about-story-v1.htmlfrag)
.\inject-about-story.ps1 -Repo "$HOME\Documents\GitHub\InSeed" -FragmentPath "$HOME\Downloads\inseed-bpoe-kit-v1	emplatesbout-story-v1.htmlfrag" -Commit
```

## Notes
- All scripts are **idempotent**: safe to run again.
- Each script supports `-Commit` to git add/commit/push automatically.
- Edit the fragment and docs before running if you want to tweak wording.
