Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

param(
  [Parameter(Mandatory=$true)][string]$SessionUrl,
  [switch]$Run
)

function Write-Note($msg){ Write-Host ("[Fix] {0}" -f $msg) }

# 1) Locate latest CoAgent worktree
$wt = Get-ChildItem "$HOME\Documents\GitHub\CoAgent__mvp3*" -Directory |
  Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $wt) { throw "No CoAgent__mvp3* worktree found under Documents\GitHub." }
$wtDir = $wt.FullName
$orc   = Join-Path $wtDir 'tools\Start-MVP3-Orchestrator.ps1'
if (-not (Test-Path $orc)) { throw "Orchestrator not found: $orc" }

Write-Note "Worktree: $wtDir"
Write-Note "Orchestrator: $orc"

# 2) Backup
$bak = "$orc.bak_{0:yyyyMMdd-HHmmss}" -f (Get-Date)
Copy-Item $orc $bak -Force
Write-Note "Backup saved -> $bak"

# 3) Load text
[string]$code = Get-Content $orc -Raw -Encoding UTF8

# 4) Parse once to show current errors (helpful for logs)
$tokens=$null;$errors=$null
[void][System.Management.Automation.Language.Parser]::ParseInput($code,[ref]$tokens,[ref]$errors)
if ($errors -and $errors.Count -gt 0) {
  Write-Note "Parser reports $($errors.Count) issue(s) pre-patch; proceeding to repair…"
}

# 5) Targeted repairs for EmptyPipeElement variants
#    - catch { | Out-File ... }  -> catch { $_ | Out-File ... }
$code = [regex]::Replace($code, '(?ms)catch\s*\{\s*\|\s*Out-File', 'catch { $_ | Out-File')

#    - lines that begin with a bare pipe to Out-File -> prefix with $_ |
$code = [regex]::Replace($code, '(?m)^\s*\|\s*Out-File\b', '$_ | Out-File')

#    - any line that is just an empty pipe -> comment it out
$code = [regex]::Replace($code, '(?m)^\s*\|\s*$', '# [patched: removed empty pipe]')

#    - occurrences of "} | Out-File" -> replace with safer form (no pipe; preserve intent comment)
$code = [regex]::Replace($code, '(?m)\}\s*\|\s*Out-File', '} ; # [patched: removed invalid pipe before Out-File] Out-File')

# 6) Re-parse; if still failing ONLY because of EmptyPipeElement on residual '|' lines, nuke them
$tokens=$null;$errors=$null
[void][System.Management.Automation.Language.Parser]::ParseInput($code,[ref]$tokens,[ref]$errors)

if ($errors -and $errors.Count -gt 0) {
  $onlyEmptyPipe = $true
  foreach($e in $errors){
    if ($e.ErrorId -ne 'EmptyPipeElement') { $onlyEmptyPipe = $false; break }
  }
  if ($onlyEmptyPipe) {
    # remove any remaining solitary '|' at line start (belt & suspenders)
    $code = [regex]::Replace($code, '(?m)^\s*\|\s*(.*)$', '# [patched: removed residual empty/leading pipe] $1')
    $tokens=$null;$errors=$null
    [void][System.Management.Automation.Language.Parser]::ParseInput($code,[ref]$tokens,[ref]$errors)
  }
}

if ($errors -and $errors.Count -gt 0) {
  Write-Note "Parser still reports $($errors.Count) issue(s) after patch. Aborting write. Top 10:"
  $errors | Select-Object -First 10 | ForEach-Object {
    Write-Host ("  {0}: {1}" -f $_.ErrorId, $_.Message)
  }
  throw "Parser still failing; stop here."
}

# 7) Write patched orchestrator
Set-Content -Path $orc -Value $code -Encoding UTF8
Write-Note "Patched orchestrator written and parse-clean."

# 8) Optional: quiet-run with rolling logs
if ($Run) {
  $LogsRoot = Join-Path (Join-Path $HOME 'Downloads') 'CoTemp\logs'
  New-Item -ItemType Directory -Force -Path $LogsRoot | Out-Null
  $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
  $outL  = Join-Path $LogsRoot "orchestrator-$stamp.out.log"
  $errL  = Join-Path $LogsRoot "orchestrator-$stamp.err.log"
  $pwsh = (Get-Command pwsh).Path

  Start-Process -FilePath $pwsh `
    -ArgumentList @('-NoLogo','-NoProfile','-File', $orc, '-SessionUrl', $SessionUrl) `
    -RedirectStandardOutput $outL `
    -RedirectStandardError  $errL | Out-Null

  Write-Note "Launched orchestrator quietly."
  Write-Note "  Out: $outL"
  Write-Note "  Err: $errL"
}
