param(
  [Parameter(Mandatory=$true)][string]$Path,
  [string]$Repo,
  [switch]$Commit
)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
if(-not (Test-Path $Path)){ throw "SVG not found: $Path" }

$svg = Get-Content -Raw -LiteralPath $Path
# Inject Blue-Pop palette + drop shadow if missing (idempotent)
$style = @'
<style data-inseed-bluepop>
  :root{
    --p75:#eaf0ff; --p300:#a5b4fc; --p400:#818cf8; --border:#b8c2ea; --ink:#1e2330; --accent:#eef2ff;
  }
  @media (prefers-color-scheme: dark){
    :root{
      --p75:#121a33; --p300:#24367a; --p400:#2f44a3; --border:#2b3246; --ink:#e6e9f5; --accent:#141a2a;
    }
  }
  rect[rx="16"], .panel { fill:var(--accent); stroke:var(--border) }
  rect[rx="12"], .node, .card { fill:var(--p75); stroke:var(--p300); stroke-width:1.25; filter:url(#pop) }
  text { fill:var(--ink); }
  line, path { stroke:var(--p400); }
  marker path { fill:var(--p400); }
</style>
<defs data-inseed-bluepop><filter id="pop"><feDropShadow dx="0" dy="1" stdDeviation="1.2" flood-opacity=".25"/></filter></defs>
'@

if($svg -notmatch 'data-inseed-bluepop'){
  $svg = [regex]::Replace($svg,'(<svg[^>]*>)', { param($m) $m.Groups[1].Value + "`r`n" + $style }, 1)
  Set-Content -Encoding UTF8 -LiteralPath $Path -Value $svg
  Write-Host "Injected Blue-Pop into $Path"
} else {
  Write-Host "Blue-Pop already present in $Path"
}

if($Commit -and $Repo){
  Push-Location $Repo
  try {
    git add -- $Path | Out-Null
    git commit -m "style(svg): ensure Blue-Pop palette in $(Split-Path -Leaf $Path)" | Out-Null
    git push | Out-Null
    Write-Host "Committed & pushed Blue-Pop update."
  } finally { Pop-Location }
} elseif($Commit -and -not $Repo){
  Write-Warning "Commit requested but -Repo not provided; skipped git commit."
}
