param(
  [Parameter(Mandatory=$true)][string]$Repo,
  [switch]$Commit
)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
$dir = Join-Path $Repo 'docs\bpoe'
New-Item -ItemType Directory -Force -Path $dir | Out-Null

$files = @{
  'blue-pop-svg.md' = @'
# Blue-Pop SVG (BPOE Pattern)

**Goal:** readable diagrams in light/dark, consistent house style, portable when hosted from `/assets/`.

**Rules**
- Embed palette + styles **inside** `<svg>` with `<style data-inseed-bluepop>…</style>`.
- Add `<defs><filter id="pop">…</filter></defs>` for soft shadow.
- Use `rx=12` for node cards, `rx=16` for outer panels. Stroke ~1.25–1.35.
- Avoid external CSS for assets; keep the SVG self-contained.

**Selectors**
```css
rect[rx="16"], .panel { fill:var(--accent); stroke:var(--border) }
rect[rx="12"], .node, .card { fill:var(--p75); stroke:var(--p300); stroke-width:1.25; filter:url(#pop) }
text { fill:var(--ink); }
line, path { stroke:var(--p400); }
marker path { fill:var(--p400); }
```
'@;

  'diagram-workflow.md' = @'
# Diagram Workflow (BPOE)

1. Rough boxes + arrows (no title) from Chris.
2. We iterate on copy inside boxes (clarity > ornament).
3. Add context text & figure caption near placement.
4. Apply **Blue-Pop** via `scripts/make-svg-bluepop.ps1`.
5. Cache-bust the page to surface the update immediately.

**Naming:** `assets/diagram-<topic>.svg`
'@;

  'page-surgery.md' = @'
# Page Surgery (safe insertion)

- Prefer inserting after the first `<h1>` or heading anchor.
- Keep a marker comment near inserted blocks, e.g. `<!-- about: story v1 -->`.
- Idempotent: check for the marker before inserting again.
'@;

  'cache-busting.md' = @'
# Cache Busting

Add `?v=<timestamp>` to `/assets/site.css` and `/assets/site.js` on the page you changed:

```powershell
$build = Get-Date -UFormat %Y%m%d%H%M%S
$t = Get-Content $page -Raw
$t = $t -replace 'href="/assets/site\.css(\?[^"]*)?"', "href=""/assets/site.css?v=$build"""
$t = $t -replace 'src="/assets/site\.js(\?[^"]*)?"',  "src=""/assets/site.js?v=$build"""
Set-Content -Encoding UTF8 $page $t
```
'@;

  'README.md' = @'
# InSeed BPOE

- **BPOE** = *Best Pattern of Execution*: small, reusable, evolvable moves.
- This folder houses house-style patterns and the scripts that apply them.

See:
- `blue-pop-svg.md`
- `diagram-workflow.md`
- `page-surgery.md`
- `cache-busting.md`
'@
}

foreach($name in $files.Keys){
  $p = Join-Path $dir $name
  Set-Content -Encoding UTF8 -LiteralPath $p -Value $files[$name]
}
Write-Host "Wrote BPOE docs to $dir"

if($Commit){
  Push-Location $Repo
  try {
    git add docs/bpoe | Out-Null
    git commit -m "docs(bpoe): seed Blue-Pop + workflow + surgery + cache busting" | Out-Null
    git push | Out-Null
    Write-Host "Committed & pushed BPOE docs."
  } finally { Pop-Location }
}
