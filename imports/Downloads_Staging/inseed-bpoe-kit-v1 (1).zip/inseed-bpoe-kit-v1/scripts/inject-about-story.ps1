param(
  [Parameter(Mandatory=$true)][string]$Repo,
  [Parameter(Mandatory=$true)][string]$FragmentPath,
  [switch]$Commit
)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
$about = Join-Path $Repo 'about\index.html'
if(-not (Test-Path $about)){ throw "Missing: $about" }
if(-not (Test-Path $FragmentPath)){ throw "Missing fragment: $FragmentPath" }

$frag = Get-Content -Raw -LiteralPath $FragmentPath
$t = Get-Content -Raw -LiteralPath $about

# Idempotent insert after first H1
if($t -notmatch '<!-- about: story v1 -->'){
  $t = [regex]::Replace($t,'(?is)(<h1[^>]*>.*?</h1>)',('$1'+"`r`n"+$frag),1)
  # cache-bust assets on this page
  $build = (Get-Date -UFormat %Y%m%d%H%M%S)
  $t = $t -replace 'href="/assets/site\.css(\?[^"]*)?"', "href=""/assets/site.css?v=$build"""
  $t = $t -replace 'src="/assets/site\.js(\?[^"]*)?"',  "src=""/assets/site.js?v=$build"""
  Set-Content -Encoding UTF8 -LiteralPath $about -Value $t
  Write-Host "Inserted About story fragment."
} else {
  Write-Host "Story fragment already present — no change."
}

if($Commit){
  Push-Location $Repo
  try {
    git add about/index.html | Out-Null
    git commit -m "about: insert/refine narrative story (fragment v1)" | Out-Null
    git push | Out-Null
    Write-Host "Committed & pushed About story."
  } finally { Pop-Location }
}
