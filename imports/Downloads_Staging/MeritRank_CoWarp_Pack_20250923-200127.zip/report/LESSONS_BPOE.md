# BPOE — Best Practices On‑Repo Execution

## PowerShell authoring
- Prefer **single‑quoted here‑strings**: `@' ... '@` to avoid interpolation (e.g., `${{ github.* }}`).
- For captured‑group inserts, use `[regex]::Replace()` with a MatchEvaluator.
- Keep scripts idempotent; bail early when repo/branch state is already desired.

## Git/CI
- `.gitignore` generated artifacts (seeds, scores).
- Freshen with `git fetch --all --prune`; `git pull --ff-only` before advice branches.
- Use `gh run list --json status,conclusion,displayTitle,workflowName,number,url,headBranch,createdAt`.
- Run tests via `python -m pytest -q`; set `PYTHONPATH` to repo root in workflow env.

## Safety posture (language)
- Say **tamper‑evident** instead of “immutable”.
- **Optionally chain‑anchored** (unless default).
- Positive‑first: kudos & proof‑of‑impact; support dispute/opt‑out.