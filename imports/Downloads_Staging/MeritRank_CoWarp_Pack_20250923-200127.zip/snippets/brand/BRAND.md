# Digital Halo — Brand Notes

**Canonical line:**  
**Your digital halo — verifiable kudos, not callouts.**

**Why it works**
- Emphasizes *kudos / positive proof*, not allegations.
- “Tamper‑evident” is accurate; “optionally chain‑anchored” is forward‑compatible.
- Clear trust & safety stance (no smears; disputes/opt‑out encouraged).

**Alt taglines**
- *Build your digital halo.*
- *Impact receipts you can cite.*
- *Proof of contribution, not a gossip feed.*
- *A positive, tamper‑evident ledger of good work.*