## Quick smoke
Windows:
```powershell
pwsh -f .\scripts\smoke.ps1
```

macOS/Linux:
```bash
./scripts/smoke.sh
```