# Trust & Safety: "Digital Halo"

MeritRank is for **kudos and verifiable impact**, not callouts.

- **Positive-first**: attestations of contribution and proof‑of‑work.
- **No smears**: defamatory/ad‑hom content is out of scope; disputes welcome.
- **Tamper‑evident**: append‑only, audit‑friendly; **optionally anchored** to public chains.
- **User respect**: provide dispute and opt‑out channels.