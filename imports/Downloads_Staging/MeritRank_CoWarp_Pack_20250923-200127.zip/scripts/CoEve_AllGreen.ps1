param(
  [string]$RepoRoot = (Join-Path $HOME 'Documents\GitHub\MeritRank'),
  [string]$Base = 'main',
  [switch]$TriggerCI
)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
pwsh -f (Join-Path $PSScriptRoot 'CoEve_SyncMain.ps1') -RepoRoot $RepoRoot -Base $Base | Out-Host
pwsh -f (Join-Path $PSScriptRoot 'CoEve_Smoke.ps1') -RepoRoot $RepoRoot | Out-Host
try { python -m pytest -q | Out-Host } catch { Write-Host "[INFO] pytest not installed/skipped." -ForegroundColor Yellow }
if ($TriggerCI) { Push-Location $RepoRoot; gh workflow run mapper-smoke.yml --ref $Base | Out-Host; Pop-Location }