param([string]$RepoRoot = (Join-Path $HOME 'Documents\GitHub\MeritRank'))
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
Push-Location $RepoRoot
if (-not (Test-Path '.venv')) { python -m venv .venv }
$env:VIRTUAL_ENV="$RepoRoot\.venv"
$env:Path="$env:VIRTUAL_ENV\Scripts;$env:Path"
python -m pip install -U pip pytest
try { python -m pytest -q } catch { Write-Host "[INFO] pytest not installed/skipped." -ForegroundColor Yellow }
Pop-Location