param(
  [string]$RepoRoot = (Join-Path $HOME 'Documents\GitHub\MeritRank'),
  [string]$Base = 'main'
)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
function Get-RepoSlug([string]$repoPath){ Push-Location $repoPath; try{ $url=(git remote get-url origin).Trim() } finally { Pop-Location }; if (-not $url) { throw "Cannot get origin URL." }; $slug = $url -replace '.*github\.com[:/](.*?)(?:\.git)?$','$1'; if ($slug -notmatch '.+/.+') { throw "Bad origin: $url" }; return $slug }
$slug = Get-RepoSlug $RepoRoot
$ts = Get-Date -Format 'yyyyMMdd-HHmmss'
$branch = "chore/branding-digital-halo-$ts"
Push-Location $RepoRoot
git fetch --all --prune
git checkout $Base
git pull --ff-only
git checkout -b $branch
New-Item -ItemType Directory -Force -Path 'docs/brand' | Out-Null
@'
# Digital Halo — Brand Notes

**Canonical line:**  
**Your digital halo — verifiable kudos, not callouts.**
'@ | Set-Content -Encoding UTF8 'docs/brand/BRAND.md'
$tagline = '> **Your digital halo — verifiable kudos, not callouts.**'
$badges  = "[![CI](https://github.com/$slug/actions/workflows/ci.yml/badge.svg)](https://github.com/$slug/actions/workflows/ci.yml) [![mapper-smoke](https://github.com/$slug/actions/workflows/mapper-smoke.yml/badge.svg)](https://github.com/$slug/actions/workflows/mapper-smoke.yml)"
$readmePath = 'README.md'
if (-not (Test-Path $readmePath)) { "# MeritRank`r`n" | Set-Content -Encoding UTF8 $readmePath }
$readme = Get-Content -Raw -Encoding UTF8 $readmePath
$needsTagline = ($readme -notmatch [regex]::Escape($tagline))
$needsBadges  = ($readme -notmatch 'actions/workflows/ci\.yml/badge\.svg')
if ($needsTagline -or $needsBadges) {
  $toInsert = @(); if ($needsTagline) { $toInsert += $tagline }; if ($needsBadges) { $toInsert += $badges }; $insertion = ($toInsert -join "`r`n")
  $readme = [regex]::Replace($readme,'(?m)^(#\s*MeritRank.*)$',{ param($m) $m.Value + "`r`n" + $insertion })
  Set-Content -Encoding UTF8 $readmePath -Value $readme
}
git add --all
git commit -m "chore(brand): add 'digital halo' tagline, badges, and BRAND.md"
git push -u origin $branch
gh pr create -t "Brand: 'digital halo' tagline + badges + BRAND.md" -b "Adds docs/brand/BRAND.md; inserts tagline and CI/mapper-smoke badges." -B $Base -H $branch
Pop-Location