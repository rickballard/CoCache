param(
  [string]$RepoRoot,
  [string]$Repo,
  [string]$Branch = 'main',
  [string]$Workflow = 'CI',
  [switch]$Watch,
  [switch]$Open
)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
function Get-Slug([string]$Path){ Push-Location $Path; try { $u=(git remote get-url origin).Trim() } finally { Pop-Location }; if(-not $u){ throw "No origin" }; return ($u -replace '.*github\.com[:/](.*?)(?:\.git)?$','$1') }
$slug = if ($Repo) { $Repo } elseif ($RepoRoot) { Get-Slug $RepoRoot } else { throw "Provide -Repo or -RepoRoot" }
$runs = gh run list --repo $slug --branch $Branch --workflow "$Workflow" --json number,url,status,conclusion --limit 10 | ConvertFrom-Json
if (-not $runs) { throw "No runs." }
$run = $runs[0]
Write-Host ("Re-running: {0} · #{1} · {2}" -f $Workflow, $run.number, $run.url)
gh run rerun $run.number --repo $slug | Out-Null
if ($Open) { Start-Process $run.url | Out-Null }
if ($Watch) { gh run watch $run.number --repo $slug --exit-status }