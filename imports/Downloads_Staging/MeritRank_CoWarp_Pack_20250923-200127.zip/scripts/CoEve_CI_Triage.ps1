param(
  [string]$RepoRoot,
  [string]$Repo,
  [string]$Branch = 'main',
  [string]$Workflow = 'CI',
  [switch]$Open
)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
function Get-Slug([string]$Path){ Push-Location $Path; try { $u=(git remote get-url origin).Trim() } finally { Pop-Location }; if(-not $u){ throw "No origin" }; return ($u -replace '.*github\.com[:/](.*?)(?:\.git)?$','$1') }
$slug = if ($Repo) { $Repo } elseif ($RepoRoot) { Get-Slug $RepoRoot } else { throw "Provide -Repo or -RepoRoot" }
$runs = gh run list --repo $slug --branch $Branch --workflow "$Workflow" --json status,conclusion,displayTitle,workflowName,number,url,createdAt --limit 10 | ConvertFrom-Json
if (-not $runs) { throw "No runs returned." }
$run = ($runs | Where-Object { $_.status -eq 'completed' } | Select-Object -First 1) ?? $runs[0]
if ($Open) { Start-Process $run.url | Out-Null }
Write-Host ("Triage: {0} · #{1} · {2} · {3}" -f $run.workflowName, $run.number, $run.status, $run.url)
$dest = Join-Path $env:TEMP ("ci_run_{0}.log" -f $run.number)
try { gh run view $run.number --repo $slug --log > $dest; Write-Host "[LOG] Full logs -> $dest" } catch { Write-Host "[WARN] Could not fetch logs; gh version may not support --log." -ForegroundColor Yellow }