#!/usr/bin/env bash
set -euo pipefail
ALLOW="${1:-components/seeder/config/allowlist.txt}"
OUT="${2:-components/seeder/out/events.ndjson}"
SCORE="${3:-tools/score_demo/out.json}"
mkdir -p "$(dirname "$ALLOW")" "$(dirname "$OUT")" "$(dirname "$SCORE")"
if [ ! -s "$ALLOW" ]; then echo "https://example.org/" > "$ALLOW"; fi
python components/seeder/seeder.py --mapper basic --allowlist "$ALLOW" --out "$OUT"
python tools/score_demo/score.py --in "$OUT" --out "$SCORE"
cat "$SCORE"
