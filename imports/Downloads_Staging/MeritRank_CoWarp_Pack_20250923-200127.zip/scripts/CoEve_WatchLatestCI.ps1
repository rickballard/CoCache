param(
  [string]$RepoRoot,
  [string]$Repo,
  [string]$Branch = 'main',
  [string]$Workflow,
  [switch]$Open
)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
function Get-Slug([string]$Path){ Push-Location $Path; try { $u=(git remote get-url origin).Trim() } finally { Pop-Location }; if(-not $u){ throw "No origin" }; return ($u -replace '.*github\.com[:/](.*?)(?:\.git)?$','$1') }
$slug = if ($Repo) { $Repo } elseif ($RepoRoot) { Get-Slug $RepoRoot } else { throw "Provide -Repo or -RepoRoot" }
$wfArg = if ($Workflow) { "--workflow `"$Workflow`"" } else { "" }
$runs = gh run list --repo $slug --branch $Branch $wfArg --json status,conclusion,displayTitle,workflowName,number,url,headBranch,createdAt --limit 20 | ConvertFrom-Json
if (-not $runs) { throw "No runs." }
$run = $runs[0]
Write-Host ("Watching: {0} · #{1} · {2} · {3}" -f $run.workflowName, $run.number, $run.status, $run.url)
if ($Open) { Start-Process $run.url | Out-Null }
if ($run.status -ne 'in_progress' -and $run.status -ne 'queued') { Write-Host ("Run {0} ({1}) has already completed with '{2}'" -f $run.workflowName, $run.number, $run.conclusion) }