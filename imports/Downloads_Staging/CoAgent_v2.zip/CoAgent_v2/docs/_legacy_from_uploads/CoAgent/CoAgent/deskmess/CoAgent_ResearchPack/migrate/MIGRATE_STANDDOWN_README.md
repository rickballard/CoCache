# Migrate Stand Down (pre-CoAgent watcher)

**Paired with:** `co-planning`  
A centralized watcher runs; do not start a second inbox watcher here.

Focus:
- **ccts fallback** remediation
- Migration-specific repo tasks

To notify Planning, drop notes/DOs into its inbox under `Downloads/CoTemp/sessions/co-planning/inbox`.
