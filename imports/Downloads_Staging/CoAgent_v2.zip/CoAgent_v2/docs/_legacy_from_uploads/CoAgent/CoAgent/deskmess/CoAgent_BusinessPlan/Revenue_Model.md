﻿# Revenue Model

**Free Core**: Queue + Read-Only + logs — personal use forever.

**Pro (individuals/teams)**:
- Repo locks, risk linter, auto-CoPong, policy packs, rollbacks
- Monthly/annual; fair pricing; discount for civic/education

**Teams/Enterprise**:
- Shared policies, audit vault, SSO, signed updates, compliance reports
- Private generics aggregator & governance dashboards

**Principles**: No data sale. No dark patterns. Free for individuals; enterprises pay.
