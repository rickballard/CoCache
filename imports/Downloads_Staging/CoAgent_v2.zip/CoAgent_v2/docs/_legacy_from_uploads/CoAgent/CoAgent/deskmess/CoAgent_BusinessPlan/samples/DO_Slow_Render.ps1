﻿<# ---
title: "DO-slowly-rendered"
risk: { writes: false, network: false, secrets: false, destructive: false }
--- #>
# [PASTE IN POWERSHELL]
Write-Host "Hello from slowly rendered DO"
