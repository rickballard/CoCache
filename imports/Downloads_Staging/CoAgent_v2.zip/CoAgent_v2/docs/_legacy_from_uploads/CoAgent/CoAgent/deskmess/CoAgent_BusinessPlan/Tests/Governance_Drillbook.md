﻿# Governance Drillbook

## G-1: Attempted acquisition
- Mock term sheet from Vendor X → run through Consent Lock
- Require dual ≥75% votes; publish rationale

## G-2: Spec change fast-path attempt
- Propose breaking change without RFC → block; open RFC with 21d window

## G-3: Conflict of interest
- Oversight member hired by vendor → recuse; replace per charter

Record outcomes and update Governance_and_Ownership_Mandate.md if gaps found.
