﻿# Private Business Plan (keep off public origin)
- Store pricing, partner lists, unit economics here.
- This folder is ignored by .gitignore.
