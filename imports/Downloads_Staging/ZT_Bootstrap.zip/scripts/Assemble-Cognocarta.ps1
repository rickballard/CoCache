param([string]$ConfigPath)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
$cfg=Get-Content -Raw $ConfigPath | ConvertFrom-Json
$repo=$cfg.Repos.CoCivium
$parts=Join-Path $repo 'docs\cc\parts'
$outMd=Join-Path $repo 'docs\cc\scroll.md'
$outHtml=Join-Path $repo 'docs\site\index.html'
$siteDir=Join-Path $repo 'docs\site'
$css='body{font-family:system-ui,Segoe UI,Roboto,Arial;margin:0;padding:24px;background:#0b0b12;color:#e6e6f0} .halo{display:inline-block;padding:12px 20px;border-radius:999px;box-shadow:0 0 24px 8px rgba(255,255,255,.35)} .header{text-align:center;margin:24px 0} .main{max-width:980px;margin:0 auto;line-height:1.6} h1,h2,h3{color:#fff}'
if(Test-Path $parts){
  $files=Get-ChildItem $parts -File | Sort-Object Name
  $md="# Cognocarta Consenti (Auto‑Assembled)`n`n"
  foreach($f in $files){ $md += (Get-Content -Raw $f.FullName) + "`n`n" }
  New-Item -ItemType Directory -Force -Path (Split-Path $outMd -Parent) | Out-Null
  $md | Set-Content -Path $outMd -Encoding UTF8
} else {
  $md="# Cognocarta Consenti`n_Awaiting parts in docs/cc/parts_."
}
New-Item -ItemType Directory -Force -Path $siteDir | Out-Null
function Md2Html([string]$m){
  $h=$m -replace '(?m)^\#\#\# (.*)$','<h3>$1</h3>' -replace '(?m)^\#\# (.*)$','<h2>$1</h2>' -replace '(?m)^\# (.*)$','<h1>$1</h1>'
  $h=$h -replace '\*\*(.*?)\*\*','<strong>$1</strong>' -replace '\*(.*?)\*','<em>$1</em>' -replace '`([^`]+)`','<code>$1</code>'
  $h=$h -replace '(?m)^\- (.*)$','<li>$1</li>' -replace '(?s)<li>(.*?)</li>','<ul><li>$1</li></ul>'
  $h='<p>'+($h -replace '\n\n+','</p><p>')+'</p>'; return $h
}
$html='<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Cognocarta — CoCivium</title><style>'+$css+'</style></head><body><section class="header"><div class="halo">CoConstitution • Cognocarta</div></section><main class="main">'+(Md2Html $md)+'</main><footer>Auto‑assembled '+(Get-Date -Format 'yyyy-MM-dd HH:mm')+' — Source of truth: CoCivium repo</footer></body></html>'
$html | Set-Content -Path $outHtml -Encoding UTF8
if($cfg.EnableAutoCommit -and (Test-Path $repo)){
  Push-Location $repo
  git add docs\cc\scroll.md docs\site\index.html 2>$null | Out-Null
  if((git status --porcelain)){
    $branch=$cfg.DefaultBranch
    git commit -m "docs(cc): auto-assemble scroll + site halo [ZT]" 2>$null | Out-Null
    git push $cfg.GitRemote $branch 2>$null | Out-Null
  }
  Pop-Location
}
