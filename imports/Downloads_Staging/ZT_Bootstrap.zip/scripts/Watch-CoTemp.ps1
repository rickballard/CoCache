param([string]$ConfigPath)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
$cfg=Get-Content -Raw $ConfigPath | ConvertFrom-Json
$inbox=Join-Path $cfg.CoTemp 'backchatter'
$out=Join-Path $cfg.Repos.CoCache 'backchatter\inbox.jsonl'
New-Item -ItemType Directory -Force -Path (Split-Path $out -Parent) | Out-Null
New-Item -ItemType Directory -Force -Path $inbox | Out-Null
function Process-One($file){
  try{
    $txt=Get-Content -Raw $file -ErrorAction Stop
    $obj=[pscustomobject]@{ ts=(Get-Date).ToUniversalTime().ToString('o'); file=(Split-Path $file -Leaf); body=$txt }
    ($obj|ConvertTo-Json -Depth 5)+"`n" | Add-Content -Path $out -Encoding UTF8
    Remove-Item $file -Force
  } catch { Write-Warning $_ }
}
Get-ChildItem -Path $inbox -File -ErrorAction SilentlyContinue | ForEach-Object { Process-One $_.FullName }
$fsw=New-Object System.IO.FileSystemWatcher $inbox, '*.*'; $fsw.EnableRaisingEvents=$true
$onCreated=Register-ObjectEvent $fsw Created -Action { Process-One $Event.SourceEventArgs.FullPath }
while($true){ Start-Sleep -Seconds 5 }
