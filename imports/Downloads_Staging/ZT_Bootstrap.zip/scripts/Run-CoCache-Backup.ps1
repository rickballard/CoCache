param([string]$ConfigPath)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
$cfg=Get-Content -Raw $ConfigPath | ConvertFrom-Json
$srcs=@($cfg.Downloads,"$($cfg.GitRoot)\CoCivium","$($cfg.GitRoot)\CoModules","$($cfg.GitRoot)\CoAgent")
$dst=Join-Path $cfg.Repos.CoCache 'backup_mirror'
New-Item -ItemType Directory -Force -Path $dst | Out-Null
foreach($s in $srcs){
  if(Test-Path $s){
    $t=Join-Path $dst (Split-Path $s -Leaf)
    $cmd="robocopy `"$s`" `"$t`" /MIR /R:1 /W:2 /XD .git node_modules .venv __pycache__ .cache"
    cmd.exe /c $cmd | Out-Null
  }
}
$stamp=Get-Date -Format 'yyyy-MM-dd'
$snapDir=Join-Path $cfg.Repos.CoCache "backup_snapshots\$stamp"
New-Item -ItemType Directory -Force -Path $snapDir | Out-Null
$marker=Join-Path $snapDir 'DONE.txt'
if(-not (Test-Path $marker)){ "Snapshot created $(Get-Date)" | Set-Content $marker -Encoding UTF8 }
