param([string]$ConfigPath = "$PSScriptRoot\..\zt-bootstrap.config.json")
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
$cfg=Get-Content -Raw $ConfigPath | ConvertFrom-Json
$root=Split-Path -Parent $ConfigPath
$patchRoot=Join-Path $root 'repo_patch'
function Apply-OnePatch($name,$dest){
  $src=Join-Path $patchRoot $name
  if(-not (Test-Path $src)){ Write-Host "[SKIP] $name (no patch)"; return }
  if(-not (Test-Path $dest)){ Write-Warning "[MISS] $dest not found"; return }
  Write-Host "[COPY] $name -> $dest"
  Copy-Item -Path (Join-Path $src '*') -Destination $dest -Recurse -Force
  Push-Location $dest
  try{
    $branch="zt-bootstrap/{0}" -f (Get-Date -Format 'yyyyMMddHHmm')
    git checkout -b $branch 2>$null | Out-Null
    git add . 2>$null | Out-Null
    if((git status --porcelain)){
      git commit -m "chore: apply ZT bootstrap patches [auto]" 2>$null | Out-Null
      git push $cfg.GitRemote $branch 2>$null | Out-Null
      $gh=Get-Command gh -ErrorAction SilentlyContinue
      if($gh){ gh pr create --fill --base $cfg.DefaultBranch --head $branch | Out-Null } else { Write-Host "[INFO] gh not found; PR not opened." }
    } else { Write-Host "[CLEAN] No changes to commit in $name" }
  } finally { Pop-Location }
}
Apply-OnePatch -name 'CoCivium' -dest $cfg.Repos.CoCivium
Apply-OnePatch -name 'CoAgent'  -dest $cfg.Repos.CoAgent
Write-Host "[DONE] Repo patches applied."
