param(
  [string[]]$TranscriptPaths,[int]$HeavyOps=0,[int]$Errors=0,[int]$Fanout=0,[switch]$PaneDrift,[double]$Hours=$null)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
$errHits=0;$heavyHits=0;$paneBursts=0
if($TranscriptPaths){
  $errPat='(WARNING|ParserError|is not recognized|not recognized as|error:)'
  $heavyPat='(Compress-Archive|Expand-Archive|git\s+clone|git\s+fetch|Export-CSV|Import-CSV|zip)'
  $panePat='not recognized'
  foreach($p in $TranscriptPaths){ if(Test-Path $p){
    $text=Get-Content -Raw -ErrorAction SilentlyContinue $p
    $errHits+=([regex]::Matches($text,$errPat,'IgnoreCase')).Count
    $heavyHits+=([regex]::Matches($text,$heavyPat,'IgnoreCase')).Count
    $paneBursts+=([regex]::Matches($text,$panePat,'IgnoreCase')).Count -ge 3 ? 1 : 0
  }}
}
if($Errors -gt 0){$errHits+=$Errors}; if($HeavyOps -gt 0){$heavyHits+=$HeavyOps}
$pd=$PaneDrift.IsPresent -or ($paneBursts -gt 0)
if(-not $Hours){$Hours=3}
$dh=[math]::Min(1,$Hours/6.0); $ho=[math]::Min(1,$heavyHits/6.0); $er=[math]::Min(1,$errHits/10.0); $f=[math]::Min(1,$Fanout/4.0); $pdn=$pd?1:0
$slam=[math]::Round(100*(0.35*$dh+0.25*$ho+0.25*$er+0.10*$f+0.05*$pdn))
$band=if($slam -ge 70){'Red'} elseif($slam -ge 40){'Amber'} else {'Green'}
[pscustomobject]@{SLAM=$slam;Band=$band} | ConvertTo-Json -Depth 3
