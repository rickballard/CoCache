param(
  [string]$Focus="Migration",[string]$Next="",[string]$Repo="",
  [int]$IntervalSeconds=120,[string[]]$TranscriptPaths,[string]$OutFile)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
function Get-Slam(){
  try{
    $meas=Join-Path $PSScriptRoot 'Measure-SLAM.ps1'
    if(Test-Path $meas){
      $json=& pwsh $meas -TranscriptPaths ($TranscriptPaths -join ',') -Fanout 2 -Hours 3 2>$null
      if($LASTEXITCODE -eq 0 -and $json){ return ($json|ConvertFrom-Json) }
    }
  } catch { }
  return $null
}
while($true){
  $t=(Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
  $slam=Get-Slam(); $slamVal=if($slam){$slam.SLAM}else{''}
  $line="[BPOE] t={0} | focus={1} | repo={2} | SLAM={3} | next={4}" -f $t,$Focus,$Repo,$slamVal,$Next
  if($OutFile){ New-Item -ItemType Directory -Force -Path (Split-Path $OutFile -Parent) | Out-Null; $line|Set-Content -Path $OutFile -Encoding UTF8 }
  Write-Output $line
  Start-Sleep -Seconds $IntervalSeconds
}
