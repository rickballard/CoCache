param([string]$ConfigPath = "$PSScriptRoot\..\zt-bootstrap.config.json")
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
function Ensure-Task($name,$exe,$args,$work,$triggers,$desc){
  try{
    $exists=Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue
    if($exists){ Unregister-ScheduledTask -TaskName $name -Confirm:$false -ErrorAction SilentlyContinue | Out-Null }
    $a=New-ScheduledTaskAction -Execute $exe -Argument $args -WorkingDirectory $work
    Register-ScheduledTask -TaskName $name -Action $a -Trigger $triggers -Description $desc -RunLevel Highest | Out-Null
    "[OK] "+$name
  } catch { "[WARN] Failed "+$name+": "+$_ }
}
$cfg=Get-Content -Raw $ConfigPath | ConvertFrom-Json
$sr=Split-Path -Parent $ConfigPath | Join-Path -ChildPath 'scripts'
$statusOut=Join-Path $cfg.Repos.CoCache 'status\BPOE_STATUS.txt'
$sdArgs="-NoProfile -ExecutionPolicy Bypass -File `"{0}`" -Focus `"Migration`" -Repo `"CoCivium@{1}`" -Next `"Auto-assemble CC`" -TranscriptPaths `"{2}\logs\ps_transcript.log`" -OutFile `"{3}`"" -f (Join-Path $sr 'BPOE.StatusDaemon.ps1'), $cfg.DefaultBranch, $cfg.CoTemp, $statusOut
$trg1=@((New-ScheduledTaskTrigger -AtLogOn),(New-ScheduledTaskTrigger -Once (Get-Date).AddMinutes(2) -RepetitionInterval (New-TimeSpan -Seconds $cfg.StatusIntervalSeconds) -RepetitionDuration ([TimeSpan]::MaxValue)))
Ensure-Task "CoCivium-StatusDaemon" "pwsh.exe" $sdArgs $sr $trg1 "Emit BPOE status"
$trg2=@((New-ScheduledTaskTrigger -AtLogOn),(New-ScheduledTaskTrigger -Once (Get-Date).AddMinutes(3) -RepetitionInterval (New-TimeSpan -Minutes $cfg.BackupIntervalMinutes) -RepetitionDuration ([TimeSpan]::MaxValue)))
Ensure-Task "CoCache-Backup" "pwsh.exe" "-NoProfile -ExecutionPolicy Bypass -File `"$sr\Run-CoCache-Backup.ps1`" -ConfigPath `"$ConfigPath`"" $sr $trg2 "Mirror + snapshot"
$trg3=@((New-ScheduledTaskTrigger -AtLogOn))
Ensure-Task "CoTemp-Watcher" "pwsh.exe" "-NoProfile -ExecutionPolicy Bypass -File `"$sr\Watch-CoTemp.ps1`" -ConfigPath `"$ConfigPath`"" $sr $trg3 "Backchatter ingest"
$trg4=@((New-ScheduledTaskTrigger -Once (Get-Date).AddMinutes(5) -RepetitionInterval (New-TimeSpan -Minutes $cfg.AssembleIntervalMinutes) -RepetitionDuration ([TimeSpan]::MaxValue)))
Ensure-Task "CoCivium-AutoAssemble" "pwsh.exe" "-NoProfile -ExecutionPolicy Bypass -File `"$sr\Assemble-Cognocarta.ps1`" -ConfigPath `"$ConfigPath`"" $sr $trg4 "Assemble CC + push"
"Done."
