# run.ps1 (hello runnable)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$out = Join-Path $PSScriptRoot 'out.txt'
"Hello from Hello_CoAgent payload at $(Get-Date -Format o)" | Set-Content -Encoding UTF8 $out
Write-Host "Wrote $out"
