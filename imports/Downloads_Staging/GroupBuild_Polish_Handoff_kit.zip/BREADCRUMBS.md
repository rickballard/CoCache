# BREADCRUMBS (decisions & learnings)

- Local-first workflows so repos can pass CI without depending on CoCache immediately.
- Use `actions/setup-powershell@v2` to stay compatible (previous `PowerShell/PowerShell@v1` resolves poorly in GH Actions).
- Self-evolve job writes:
  - `docs/assets/manifest.json` + `manifest.md`
  - `docs/bpoe/SESSION_STATUS.md` heartbeat
- Auto-commits are gated behind repo variable `ENABLE_AUTOCOMMITS` to avoid surprise pushes.
- Next step after green: replace local workflows with CoCache reusable ones.
- Site polish kept minimal and safe: `robots.txt`, `site.webmanifest`, `404.html`. Additional SEO (OG/Twitter/JSON-LD) can be injected once the home HTML exists.