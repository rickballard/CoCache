# GroupBuild: CI bootstrap & site hygiene — handoff notes

**Timestamp:** 2025-09-15T22:57:13.362361Z

## What this kit does
- Adds three local GitHub Actions workflows:
  - `smoke` – quick repo sanity (PowerShell).
  - `safety-gate` – size guard + light secret scan.
  - `self-evolve` – generates/updates an assets manifest and a session status heartbeat; can auto-commit when `ENABLE_AUTOCOMMITS=true` (repo variable).
- Adds baseline site hygiene:
  - `robots.txt`, `site.webmanifest`, `404.html`.
- Leaves breadcrumbs in `BREADCRUMBS.md` and this advice file for the migration thread.

## How to apply
1) Clone the repo locally (if not present):
   ```powershell
   git clone https://github.com/rickballard/GroupBuild.git "C:\Users\Chris\Documents\GitHub\GroupBuild"
   ```
2) Unzip this kit and copy:
   - `WORKFLOWS/*` → `.github/workflows/` in the repo
   - `SITE/*` → repo root
3) Commit/push on a feature branch, open a PR, and (optionally) enable auto-commits:
   ```powershell
   $RepoPath = "C:\Users\Chris\Documents\GitHub\GroupBuild"
   $Branch = "polish/bootstrap-$(Get-Date -Format yyyyMMdd)"
   git -C $RepoPath checkout -B $Branch
   robocopy "$env:TEMP\GBKIT\WORKFLOWS" (Join-Path $RepoPath ".github\workflows") /E /NFL /NDL /NJH /NJS /NP
   robocopy "$env:TEMP\GBKIT\SITE" $RepoPath /E /NFL /NDL /NJH /NJS /NP
   git -C $RepoPath add -A
   git -C $RepoPath commit -m "GroupBuild: CI bootstrap + site hygiene"
   git -C $RepoPath push -u origin $Branch
   gh variable set ENABLE_AUTOCOMMITS --repo rickballard/GroupBuild --body true
   gh pr create --repo rickballard/GroupBuild --head $Branch --base main --fill --title "GroupBuild: CI bootstrap & site polish"
   ```

## Source of truth for BPOE
- Central **BPOE** workflows live in **CoCache**. Once this PR is green, you can switch from local workflows to the reusable ones with:
  ```yaml
  uses: rickballard/CoCache/.github/workflows/bpoe-smoke.yml@main
  uses: rickballard/CoCache/.github/workflows/bpoe-safety-gate.yml@main
  uses: rickballard/CoCache/.github/workflows/bpoe-self-evolve.yml@main
  ```

## Custom domain
- If `groupbuild.org` is used, add a `CNAME` file at repo root with the domain, and ensure DNS points to GitHub Pages.
  - Update `robots.txt` and meta tags to the canonical domain once active.