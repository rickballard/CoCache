# Release Checklist

- [ ] One watcher per session (no duplicates)
- [ ] DO headers validated (risk/consent present)
- [ ] Smoke tests pass (RepoScan, DO-Smoke)
- [ ] Public plan reviewed; private plan encrypted
