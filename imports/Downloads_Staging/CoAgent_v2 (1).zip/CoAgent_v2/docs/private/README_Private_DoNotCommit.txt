# Private Materials Pointer

Place private materials here (pricing, partners, GTM, secret sauce). This folder is excluded by `.gitignore`.

- Keep the **private investor brief** here (Markdown or docx).
- Use `tools/Protect-Private.ps1` to produce an encrypted `.7z` before pushing.
