# Roadmap (next sprints)

**Sprint 1:** stabilize runtime, docs, smokes, two-tab launcher  
**Sprint 2:** watcher debounce/lockfile, compact-on-exit, minimal telemetry  
**Sprint 3:** packaging (zip/winget), consent prompts, basic policy gates
