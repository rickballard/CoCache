﻿# BL-002 — Panel Registry Compaction on Exit
Status: TODO | Owner: Planning
- [ ] Hook job cleanup on launcher stop
- [ ] Remove dead PIDs + stale records
- [ ] Add Status-QuickCheck -Compact flag
