# Roadmap

## P0 (Weeks 0–2)
- CoTemp launcher (done)
- Majority vote + logs

## P1 (Weeks 3–5)
- Judge model + constraints
- Experiment harness

## P2 (Weeks 6–8)
- Debate round (N=1)
- Bandit weights (alpha)
