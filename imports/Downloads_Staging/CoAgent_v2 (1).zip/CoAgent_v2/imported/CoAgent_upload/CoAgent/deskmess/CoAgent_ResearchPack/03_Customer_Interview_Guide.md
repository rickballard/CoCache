# Customer Interview Guide (Optional)

Use later when ready. Keep it conversational; avoid pitching.

1. What work do you use AI for today? Where does it fail?
2. How do outages or policy changes impact you?
3. How do you review or trust AI outputs?
4. Would multi-model consensus help? Where?
5. What would make it a non-starter?
