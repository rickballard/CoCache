﻿- [ ] One watcher per session (Status-QuickCheck clean)
- [ ] Drop-CoDO and Send-CoNote available both panes
- [ ] Smoke DO shows \System.Collections.Hashtable.PSVersion correctly (no Hashtable… line)
- [ ] README_FIRST + Ops runbook reflect current flow
