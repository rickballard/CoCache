﻿# Private materials pointer
Primary location: \\NAS\CoAgent\BP_Private   (replace with your actual NAS path)
Contents: pricing, partners, GTM, unit economics.
