# CoTicker (Concept)

A thin, always-on-top ticker (just above the Windows taskbar) to stream
BPOE/CoAgent status with **blocks** and **thinking dots**.

- Event API: JSON files in `~/Downloads/CoTemp/coticker/inbox/*.json`
- Roadmap: hover cards, click-through, cross-platform (Electron/PWA)

See `modules/CoTicker/PLAN.md` for product plan.
