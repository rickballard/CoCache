# CoTicker — Product Plan (public)

## Problem
Agent/workflow feedback must be visible without stealing focus.

## v0 Prototype
- PS/WPF overlay, file-queue events (blocks, dots, clear)

## v1
- Click-through overlay with hover cards, CoAgent event schema, theming

## v2+
- Cross-platform (Electron/PWA), rules & alerts, opt-in telemetry
