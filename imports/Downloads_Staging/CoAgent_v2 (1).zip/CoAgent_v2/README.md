# CoAgent (proto repo)

This is a **clean proto-repo** layout for CoAgent. It separates public docs from
private/business materials and includes helper scripts to **encrypt** private content
before committing or pushing.

- Public docs: `docs/`
- Private docs (never commit plaintext): `docs/private/` (git-ignored)
- Tools (encryption, status pack): `tools/`
- Modules (product modules & seeds): `modules/`

## Quick Start

1. Put any private materials in `docs/private/` (pricing, partners, secret sauce).
2. Run `tools/Protect-Private.ps1` to create an encrypted `CoAgent_private_*.7z`.
3. Commit/push the **.7z** and **never** commit plaintext `docs/private/`.

### Create Git repo & first commit (from this folder)

```powershell
git init
# (optional) git checkout -b master
git add .
git commit -m "CoAgent proto-repo: structure, docs, tools"
```

### Push to a **new GitHub repo** named `CoAgent`

```powershell
# Create the GitHub repo first (private), then:
git remote add origin https://github.com/<your-user>/CoAgent.git
git push -u origin master
```
