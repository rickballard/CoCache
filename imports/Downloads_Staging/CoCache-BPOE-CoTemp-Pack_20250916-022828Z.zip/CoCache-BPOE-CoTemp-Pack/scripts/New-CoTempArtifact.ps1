param(
  [Parameter(Mandatory=$true)][string]$Name,
  [Parameter(Mandatory=$true)][string[]]$Paths,
  [string]$RepoPath = "",
  [string]$Session = "adhoc"
)
$ErrorActionPreference = 'Stop'

$home = [Environment]::GetFolderPath("UserProfile")
$coTempRoot = Join-Path (Join-Path $home "Documents") "CoTemp"
$sessionDir = Join-Path $coTempRoot $Session
if (!(Test-Path $sessionDir)) { New-Item -ItemType Directory -Force -Path $sessionDir | Out-Null }

$stamp = (Get-Date).ToUniversalTime().ToString("yyyyMMdd-HHmmss'Z'")
$zipName = "{0}_{1}.zip" -f $Name, $stamp
$zipPath = Join-Path $sessionDir $zipName

# Collect files
$toZip = New-Object System.Collections.Generic.List[System.String]
foreach($p in $Paths){
  $full = Resolve-Path -LiteralPath $p -ErrorAction Stop
  if (Test-Path $full -PathType Container) {
    Get-ChildItem -LiteralPath $full -Recurse -File | ForEach-Object { $toZip.Add($_.FullName) }
  } elseif (Test-Path $full -PathType Leaf) {
    $toZip.Add($full)
  }
}

if ($toZip.Count -eq 0) { throw "No files found under provided Paths." }

Add-Type -AssemblyName System.IO.Compression.FileSystem

if (Test-Path $zipPath) { Remove-Item -Force $zipPath }
$tmpDir = Join-Path $sessionDir ("tmp_" + [Guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Force -Path $tmpDir | Out-Null

try {
  foreach($f in $toZip){
    $rel = if($RepoPath -and $f.StartsWith($RepoPath, [StringComparison]::OrdinalIgnoreCase)){
      $f.Substring($RepoPath.Length).TrimStart('\','/')
    } else {
      Split-Path $f -Leaf
    }
    $dest = Join-Path $tmpDir $rel
    $destDir = Split-Path $dest -Parent
    if (!(Test-Path $destDir)) { New-Item -ItemType Directory -Force -Path $destDir | Out-Null }
    Copy-Item -LiteralPath $f -Destination $dest -Force
  }

  [System.IO.Compression.ZipFile]::CreateFromDirectory($tmpDir, $zipPath, [System.IO.Compression.CompressionLevel]::Optimal, $false)
} finally {
  if (Test-Path $tmpDir) { Remove-Item -Recurse -Force $tmpDir }
}

Write-Host "✅ Created artifact: $zipPath" -ForegroundColor Green
$zipPath
