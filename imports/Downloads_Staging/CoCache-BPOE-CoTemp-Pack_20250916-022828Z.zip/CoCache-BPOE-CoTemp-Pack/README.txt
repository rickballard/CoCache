CoCache BPOE CoTemp Pack
========================

Purpose
- Create timestamped CoTemp artifacts (zips) from one or more paths.
- File names always include seconds to avoid collisions across sessions.

Usage
1) Expand the zip somewhere (e.g., your Downloads).
2) Run New-CoTempArtifact.ps1, for example:

   pwsh -NoProfile -ExecutionPolicy Bypass -File "<DL>\CoCache-BPOE-CoTemp-Pack\scripts\New-CoTempArtifact.ps1" `
     -Name "omnibar-v2-assets" `
     -Paths "$HOME\Documents\GitHub\CoAgent\assets\ui" `
     -RepoPath "$HOME\Documents\GitHub\CoAgent" `
     -Session ($env:COAGENT_SESSION ?? 'adhoc')

Output
- Artifacts are written to: $HOME\Documents\CoTemp\<Session>\<Name>_<YYYYMMDD-HHMMSSZ>.zip
