# Pricing Scenarios (exploratory)

- **OSS core + paid cloud**: hosted CoAgent services; local is free
- **Seat-based**: per-user with token budgets
- **Usage-based**: per 1k tokens adjudicated + storage
- **Enterprise**: SSO, policy engine, audit API
