$ErrorActionPreference="Stop"; Set-StrictMode -Version Latest

# Locate repo
$repo = (git rev-parse --show-toplevel) 2>$null
if(-not $repo){
  $fallback = Join-Path $HOME "Documents\GitHub\CoCache"
  if(Test-Path $fallback){ $repo = $fallback } else { throw "CoCache repo not found." }
}
Set-Location $repo

# Determine range since last CoWrap tag
$lastWrap = (git tag --list "cowrap-*" --sort=-creatordate | Select-Object -First 1)
if($lastWrap){
  $range = "$lastWrap..HEAD"
}else{
  $first = (git rev-list --max-parents=0 HEAD | Select-Object -First 1)
  $range = "$first..HEAD"
}

# Gather stats
$shortstat = (git diff --shortstat $range)
$log      = (git log --oneline --decorate --no-merges $range)
$authors  = (git shortlog -sne $range)
$bnHook   = Test-Path ".git/hooks/pre-commit"
$ciFile   = Test-Path ".github/workflows/civium-safety.yml"

# Report path
$wrapDir  = Join-Path $repo "WRAPS"
New-Item -ItemType Directory -Force -Path $wrapDir | Out-Null
$stamp    = Get-Date -Format "yyyyMMdd_HHmm"
$wrapPath = Join-Path $wrapDir ("CoWrap_{0}.md" -f $stamp)

# Read manifest for package info
$mf = Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot "manifest.json") | ConvertFrom-Json

# Compose report
$content = @"
# CoWrap — $([DateTime]::Now.ToString('s'))

**Package:** $($mf.name) v$($mf.version)

## What shipped (since $lastWrap)
$shortstat

### Commits
$log

### Authors
$authors

## State checks
- BN pre-commit hook: $([string]::Copy($(if($bnHook){"enabled"}else{"missing"})))
- Safety workflow (.github/workflows/civium-safety.yml): $([string]::Copy($(if($ciFile){"present"}else{"missing"})))

## Next up (carry-over / follow-ups)
- [ ] Review Recovery/* and promote anything that belongs in canon.
- [ ] Expand CC megascroll sections from stubs to fully-formed text.
- [ ] Add any issues arising from today’s changes.

"@
Set-Content -LiteralPath $wrapPath -Encoding UTF8 -Value $content

# Commit the report
git add -- $wrapPath 2>$null
$hasChanges = git diff --cached --name-only
if($hasChanges){
  git commit -m ("docs(cowrap): session wrap {0}" -f $stamp)
}

# Tag + push
$tag = "cowrap-" + (Get-Date -Format "yyyyMMdd-HHmm")
git tag -a $tag -m ("CoWrap {0}" -f ([DateTime]::Now.ToString('s')))
git push origin HEAD --follow-tags

Write-Host ("CoWrap created: {0}  tag={1}" -f $wrapPath,$tag) -ForegroundColor Green
