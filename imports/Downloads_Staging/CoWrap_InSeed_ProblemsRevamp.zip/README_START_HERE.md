# CoWrap: InSeed Problems Revamp

## What we did
- Added **Legacy CEO vs CEOS** diagram to `/problems/`
- Wired in **rolling consensus dates** JS (22mo → 52mo window)
- Updated **Resources** page with LinkedIn + Substack links
- Enabled **GitHub Pages deploy via Actions**
- Created CSS polish hooks for diagram backgrounds

## Next Steps
- Apply the `diagram` class to the `<img>` so the light blue background shows
- Expand diagrams into **paired portrait (Legacy)** vs **landscape (CEOS)** flows
- Integrate explanatory text blocks, referencing change management best practices (Kotter, ADKAR, Lean Change)
- Consider adding subtle timeline visualizations (auto-updated consensus window)
- SEO polish: unify meta descriptions, fonts, spacing
