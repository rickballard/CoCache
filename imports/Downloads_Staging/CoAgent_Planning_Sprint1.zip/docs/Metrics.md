# Ops & Quality Metrics

- Launch time to smoke pass (p50/p95).
- Duplicate watcher incidents per week.
- DO header compliance rate.
- Error‑labeled logs per 10 runs.
