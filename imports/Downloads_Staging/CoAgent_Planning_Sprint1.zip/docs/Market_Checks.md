# Market Checks (No Interviews – Desk Research)

- Map adjacent tools: Git hooks, pre-commit, VSCode Tasks, GitHub Actions (gaps for local multi‑session chat control).
- Validate positioning: local-first, agent‑safe, repo‑aware.
- Seed early adopters: CoCivium/GroupBuild internal pilots.
- Define “wow” moments: one‑command relaunch, zero‑dup watchers, DO provenance.
