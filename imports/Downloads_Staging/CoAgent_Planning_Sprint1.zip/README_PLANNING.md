# CoAgent Planning – Sprint 1

Artifacts to keep this pane focused on planning:
- `docs/PRD_CoAgent_MVP.md`
- `docs/Packaging_Roadmap.md`
- `docs/Market_Checks.md`
- `docs/Metrics.md`
- `backlog/MVP_Backlog.md`

**Next action:** ensure Stabilize Pack is applied, then drive R1 packaging.
