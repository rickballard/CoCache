# MVP Backlog (trimmed)

- [ ] BL‑001 CCTS fallback remediation (owner: Migrate)
- [ ] BL‑002 Panel registry compaction on exit
- [ ] BL‑003 Watcher debounce + lockfile
- [ ] BL‑004 Packaging & Starter Kit
- [ ] BL‑005 Post‑install smoke flow
