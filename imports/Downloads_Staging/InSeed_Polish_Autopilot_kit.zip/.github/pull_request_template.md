# PR Checklist
- [ ] Hero banner wired (`<!-- HERO:BEGIN -->` block present)
- [ ] ODT text merged if applicable (`<!-- ODT:BEGIN -->` block)
- [ ] README badges present and current (`<!-- BADGES:BEGIN -->` block)
- [ ] Repo Smoke passes locally (`tools/Repo-Smoke.ps1`)
- [ ] Assets manifest updated (`docs/assets/manifest.json`)
- [ ] BPOE SESSION_STATUS updated
