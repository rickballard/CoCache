# MasterPlan: Rick Ballard

## Purpose
Unify civic tech, charity, pro-bono consulting, and personal ethos into a coherent, trustable public posture.

## Anchors
- 🐾 Dogsnhome.org.uk → Ground-level empathy work
- 🧠 CoCivium → Scalable governance frameworks
- 🛠 InSeed.com → Pro-bono civic tech deployment firm
- 📊 CoFit → First tool launched into external orgs

## Positioning Strategy
- Post-mercenary founder (no economic motive)
- Mission: create infrastructure for hybrid human/AI society
- Focus: consentual systems, ethical governance tools, identity repair

## Channels
- GitHub (all code + issue flow)
- Substack (narratives, insights, calls to co-evolve)
- Consulting/invitations by alignment, not sales

## Living This Plan
- Work only on CoModules and Civium projects
- Maintain coherence and visibility across repos
- Archive public reflections in CoCache
