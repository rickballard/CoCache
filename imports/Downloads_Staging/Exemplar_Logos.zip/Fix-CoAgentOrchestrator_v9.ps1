param(
  [string]$SessionUrl = "",
  [switch]$Run
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Note([string]$m){ Write-Host "[Fix] $m" }

$logsRoot = Join-Path (Join-Path $HOME 'Downloads') 'CoTemp\logs'
New-Item -ItemType Directory -Force -Path $logsRoot | Out-Null

# Locate latest worktree
$wt = Get-ChildItem "$HOME\Documents\GitHub\CoAgent__mvp3*" -Directory -ErrorAction SilentlyContinue |
      Sort-Object LastWriteTime -Descending | Select-Object -First 1
if(-not $wt){ throw "Worktree not found under Documents\GitHub\CoAgent__mvp3*." }
$wtDir = $wt.FullName
$orch  = Join-Path $wtDir 'tools\Start-MVP3-Orchestrator.ps1'
if(-not (Test-Path $orch)){ throw "Orchestrator not found: $orch" }

Note "Worktree: $wtDir"
Note "Orchestrator: $orch"

function Test-ParseClean([string]$path,[ref]$errsOut){
  $t=$null;$e=$null
  [void][System.Management.Automation.Language.Parser]::ParseFile($path,[ref]$t,[ref]$e)
  $errsOut.Value=$e
  return (-not $e -or $e.Count -eq 0)
}

# Show a compact snapshot of current parser state (first ~60 lines) to avoid spam
$errs=$null
if(-not (Test-ParseClean -path $orch -errsOut ([ref]$errs))){
  Note "Parser currently reports issues (showing a subset):"
  ($errs | Select-Object ErrorId,Message,Extent | Select-Object -First 60 |
     Format-Table -AutoSize | Out-String).Trim() | Write-Host
}

# Backup
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$bak = "$orch.bak_$stamp"
Copy-Item $orch $bak -Force
Note "Backup saved -> $bak"

# --- Line-by-line, context-aware patching (no giant regex over full file) ---
[string[]]$lines = Get-Content -LiteralPath $orch

for($i=0; $i -lt $lines.Count; $i++){
  $line = $lines[$i]

  # 0) Normalize any CR-only oddities (safety)
  $line = $line -replace "\r",""

  # 1) Single-line "catch { | Out-File ... }"  ->  "catch { $_ | Out-File ... }"
  if($line -match '^\s*catch\s*\{\s*\|\s*Out-File'){
    $line = $line -replace '\|\s*Out-File', '$_ | Out-File'
  }

  # 2) A bare leading pipe to Out-File on any line  ->  prefix with pipeline object
  #    e.g.,  "| Out-File ..."  ->  "$_ | Out-File ..."
  if($line -match '^\s*\|\s*Out-File'){
    $line = $line -replace '^\s*\|\s*Out-File', '$_ | Out-File'
  }

  # 3) "} | Out-File ..." is syntactically impossible; convert to safe statement + comment
  if($line -match '^\s*\}\s*\|\s*Out-File'){
    $rest = $line -replace '^\s*\}\s*\|\s*Out-File\s*',''
    $line = "} ; # FIX: removed invalid `}|` pipe. Original: Out-File $rest"
  }

  # 4) Line that is literally just a stray '|' -> comment it
  if($line -match '^\s*\|\s*$'){
    $line = '# FIX: removed stray pipe'
  }

  # 5) Two-line pattern:
  #    previous line ends with "catch {" and the *next* line begins "| Out-File ...".
  #    Replace that next line with "$_ | Out-File ..."
  if($i -gt 0){
    $prev = $lines[$i-1]
    if(($prev -match '^\s*catch\s*\{\s*$') -and ($line -match '^\s*\|\s*Out-File')){
      $line = $line -replace '^\s*\|\s*Out-File', '$_ | Out-File'
    }
  }

  # Assign back
  $lines[$i] = $line
}

# Save patched file
Set-Content -LiteralPath $orch -Value $lines -Encoding UTF8

# Re-parse and either keep or restore
$errs=$null
if(-not (Test-ParseClean -path $orch -errsOut ([ref]$errs))){
  $report = Join-Path $logsRoot ("orchestrator-parse-$stamp.txt")
  $reportLines = @()
  $reportLines += "Orchestrator parse still failing at $(Get-Date -f s)"
  $reportLines += "File: $orch"
  $reportLines += ""
  foreach($e in $errs){ $reportLines += ("  {0}: {1}" -f $e.ErrorId,$e.Message) }
  $reportLines += ""
  $reportLines += "Showing first $($errs.Count) errors."
  Set-Content -LiteralPath $report -Value $reportLines -Encoding UTF8

  Copy-Item $bak $orch -Force
  Note "Parser still failing; backup restored."
  Note "See report: $report"
  throw "Parser still failing; stop here."
}else{
  Note "Parser clean after fixes."
}

# Optional: launch orchestrator quietly (keeps output minimal)
if($Run.IsPresent){
  $env:COAGENT_INTERACTIVE = '1'
  $args = @()
  if($SessionUrl){
    $args += @('-SessionUrl', $SessionUrl)
  }else{
    Note "Warning: -Run specified without -SessionUrl (will start without chat binding)."
  }
  Note "Launching orchestrator…"
  try{
    & $orch @args
  }catch{
    Note ("Orchestrator exited with error: " + $_.Exception.Message)
  }
  Note "Done."
}
