param(
  [string]$SessionUrl = "",
  [switch]$Run
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Note([string]$m){ Write-Host "[Fix] $m" }

$logsRoot = Join-Path (Join-Path $HOME 'Downloads') 'CoTemp\logs'
New-Item -ItemType Directory -Force -Path $logsRoot | Out-Null

# Locate latest worktree
$wt = Get-ChildItem "$HOME\Documents\GitHub\CoAgent__mvp3*" -Directory -ErrorAction SilentlyContinue |
      Sort-Object LastWriteTime -Descending | Select-Object -First 1
if(-not $wt){ throw "Worktree not found under Documents\GitHub\CoAgent__mvp3*." }
$wtDir = $wt.FullName
$orch  = Join-Path $wtDir 'tools\Start-MVP3-Orchestrator.ps1'
if(-not (Test-Path $orch)){ throw "Orchestrator not found: $orch" }

Note "Worktree: $wtDir"
Note "Orchestrator: $orch"

function Test-Parse([string]$path,[ref]$tokens,[ref]$errs){
  $t=$null;$e=$null
  [void][System.Management.Automation.Language.Parser]::ParseFile($path,[ref]$t,[ref]$e)
  $tokens.Value = $t
  $errs.Value   = $e
  return (-not $e -or $e.Count -eq 0)
}

# Backup
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$bak = "$orch.bak_$stamp"
Copy-Item $orch $bak -Force
Note "Backup saved -> $bak"

# Load text as lines (preserve newlines on write back)
[string[]]$lines = Get-Content -LiteralPath $orch

function Fix-EmptyPipe([ref]$linesRef, [int]$lineIdx, [int]$colIdx){
  # lineIdx/colIdx are 0-based
  $linesArr = $linesRef.Value
  if($lineIdx -lt 0 -or $lineIdx -ge $linesArr.Count){ return $false }
  $line = $linesArr[$lineIdx]

  # Defensive: if column beyond line, ignore
  if($colIdx -lt 0 -or $colIdx -ge ($line.Length)){ return $false }

  # Sanity: expect a pipe at the reported spot
  if($line[$colIdx] -ne '|'){ 
    # Try to find nearest '|' on this line (sometimes extents are trimmed)
    $pipePos = $line.IndexOf('|')
    if($pipePos -lt 0){ return $false }
    $colIdx = $pipePos
  }

  # Grab trimmed views for context
  $left  = $line.Substring(0,[Math]::Max(0,$colIdx)).TrimEnd()
  $right = $line.Substring([Math]::Min($line.Length,$colIdx+1)).TrimStart()

  # Case A: at start-of-line or only whitespace before -> prefix pipeline obj
  if([string]::IsNullOrWhiteSpace($left)){
    # if it already targets Out-File, ensure "$_ | Out-File ..."
    if($right -match '^(Out-File\b.*)'){
      $line = '$_ | ' + $right
    } else {
      # generic: replace leading '|' with a harmless comment
      $line = '# FIX: removed stray pipe ' + $right
    }
  }
  # Case B: previous token likely 'catch {' (look at previous non-empty line)
  elseif($left -match '\}\s*$'){
    # "} | ..." is never valid: terminate prior statement and comment original
    $line = '} ; # FIX: removed invalid `}|` pipe. Original: ' + $right
  }
  elseif($lineIdx -gt 0){
    $prev = $linesArr[$lineIdx-1]
    if($prev -match '^\s*catch\s*\{\s*$' -and $right -match '^(Out-File\b.*)'){
      $line = '$_ | ' + $matches[1]
    }
    elseif($prev -match '^\s*catch\s*\{\s*$' -and [string]::IsNullOrWhiteSpace($right)){
      # 'catch {' followed by '|' and nothing -> remove the pipe
      $line = '# FIX: removed empty pipe after catch {'
    }
    elseif($right -match '^\|\s*$'){
      # '||' collapse
      $line = '# FIX: removed double pipe'
    }
    elseif($right -match '^Out-File\b'){
      $line = '$_ | ' + $right
    }
    else{
      # Fallback: comment the lone pipe to unblock parsing
      $line = $left + ' ; # FIX: removed empty pipe; original rhs: ' + $right
    }
  } else {
    # Fallback for first line case
    if($right -match '^Out-File\b'){ $line = '$_ | ' + $right }
    else { $line = '# FIX: removed stray leading pipe ' + $right }
  }

  $linesArr[$lineIdx] = $line
  $linesRef.Value = $linesArr
  return $true
}

# Iteratively fix up to N passes
$maxPasses = 8
$pass = 0
$madeAnyChange = $false

while($pass -lt $maxPasses){
  $pass++
  $t=$null;$e=$null
  $tmpPath = Join-Path $env:TEMP ("orch_fix_tmp_{0}.ps1" -f $pass)
  # write current lines to tmp, parse from disk for accurate extents
  Set-Content -LiteralPath $tmpPath -Value $lines -Encoding UTF8

  $ok = Test-Parse -path $tmpPath -tokens ([ref]$t) -errs ([ref]$e)
  if($ok){ break }

  $errsThisPass = @($e | Where-Object { $_.ErrorId -eq 'EmptyPipeElement' })
  if($errsThisPass.Count -eq 0){ break }

  # Fix each EmptyPipeElement by its reported extent (line+column)
  $fixedThisPass = $false
  foreach($err in $errsThisPass){
    $ln = $err.Extent.StartLineNumber - 1
    $col = $err.Extent.StartColumnNumber - 1
    if(Fix-EmptyPipe ([ref]$lines) $ln $col){ $fixedThisPass = $true }
  }

  if(-not $fixedThisPass){ break }
  $madeAnyChange = $true
}

# Write final result and validate on the real file
if($madeAnyChange){
  Set-Content -LiteralPath $orch -Value $lines -Encoding UTF8
}

$finalTokens=$null;$finalErrs=$null
$finalOK = Test-Parse -path $orch -tokens ([ref]$finalTokens) -errs ([ref]$finalErrs)
if(-not $finalOK){
  $report = Join-Path $logsRoot ("orchestrator-parse-$stamp.txt")
  $reportLines = @()
  $reportLines += "Orchestrator parse still failing at $(Get-Date -f s)"
  $reportLines += "File: $orch"
  $reportLines += ""
  foreach($e in $finalErrs){
    $reportLines += ("  {0} @ line {1}, col {2}: {3}" -f $e.ErrorId, $e.Extent.StartLineNumber, $e.Extent.StartColumnNumber, $e.Extent.Text)
  }
  $reportLines += ""
  $reportLines += "Passes attempted: $pass"
  Set-Content -LiteralPath $report -Value $reportLines -Encoding UTF8

  Copy-Item $bak $orch -Force
  Note "Parser still failing; backup restored."
  Note "See report: $report"
  throw "Parser still failing; stop here."
} else {
  Note "Parser clean after fixes (passes: $pass)."
}

# Optional: launch orchestrator quietly
if($Run.IsPresent){
  $env:COAGENT_INTERACTIVE = '1'
  $args = @()
  if($SessionUrl){
    $args += @('-SessionUrl', $SessionUrl)
  } else {
    Note "Warning: -Run specified without -SessionUrl."
  }
  Note "Launching orchestrator…"
  try { & $orch @args } catch { Note ("Orchestrator exited: " + $_.Exception.Message) }
  Note "Done."
}
