CoCivium Outreach Seed v0.1 — Install

1) Put these two files into your repo:
   outreach/projects/outreach-stage-seed/CoCivium_outreach_leads_seed.csv
   outreach/projects/outreach-stage-seed/README.md  (rename from outreach_project_proposal.md if you prefer)

2) ONEBLOCK (PowerShell) to stage & commit:
   ------------------------------------------------
   ''|Out-Null
   $ErrorActionPreference='Stop'; Set-StrictMode -Version Latest
   $Repo  = Join-Path $HOME 'Documents\GitHub\CoCivium'
   $Stage = Join-Path $Repo 'outreach\projects\outreach-stage-seed'
   New-Item -ItemType Directory -Force -Path $Stage | Out-Null

   Copy-Item "$HOME\Downloads\CoTemp\CoCivium_outreach_leads_seed.csv" $Stage -Force
   Copy-Item "$HOME\Downloads\CoTemp\outreach_project_proposal.md" (Join-Path $Stage 'README.md') -Force

   Set-Location $Repo
   git checkout -b 'outreach/seed-contacts-v0.1' 2>$null
   git add 'outreach/projects/outreach-stage-seed/README.md' `
           'outreach/projects/outreach-stage-seed/CoCivium_outreach_leads_seed.csv'
   git commit -m 'outreach: seed leads list + playbook (v0.1)'
   # gh pr create -t 'Outreach: seed leads + playbook (v0.1)' -b 'Adds seed contact list and outreach playbook.'
   ------------------------------------------------
