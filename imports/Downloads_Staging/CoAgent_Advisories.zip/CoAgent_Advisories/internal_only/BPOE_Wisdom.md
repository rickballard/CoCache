# BPOE Wisdom (Internal Only)

- **Lesson 1:** Zero-footprint uninstall matters. Always clean local traces.  
- **Lesson 2:** Ask unfinished-feature questions → capture user expectations.  
- **Lesson 3:** Depersonalized wisdom donation strengthens co-evolution.  
- **Lesson 4:** Transparency builds trust. Show plans, diffs, scores.  
- **Lesson 5:** Movement framing reduces competitive friction and builds adoption.  
