# Lexicon

Human-facing index for the entries under `/entries`.  Generated pages can be produced later from the YAML entries.
