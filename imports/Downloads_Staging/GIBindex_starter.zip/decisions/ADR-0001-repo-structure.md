# ADR-0001: Repo Structure

**Date:** 2025-08-09T03:59:46Z  
**Status:** Accepted

- Data under `/entries` (CC0-1.0).
- Docs under `/docs` and root (CC-BY-4.0).
- Schema in YAML for readability.
- PRs + validation required for changes.
