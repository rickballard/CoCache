## Summary
- What this PR changes

## Checklist
- [ ] Added/updated `*.gib.yaml` under `/entries/<domain>/`
- [ ] `version` and `timestamp` updated
- [ ] Relations (`supersedes`, `related`, etc.) considered
- [ ] Local validation run (scripts/validate_entries.py)

Closes #
