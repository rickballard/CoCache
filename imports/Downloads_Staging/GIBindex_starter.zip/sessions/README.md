# Sessions

Use this as a public scratchpad for intersessional notes. Keep items terse and link to entries or issues.
