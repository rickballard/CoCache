## What changed?
- 

## Why?
- 

## Checks
- [ ] UTF8 writes only
- [ ] Pages cache sanity (scripts/check-cache.ps1)
- [ ] No regressions to TOS-AI copy or links
