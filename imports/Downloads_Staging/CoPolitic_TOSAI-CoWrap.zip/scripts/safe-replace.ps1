# safe-replace.ps1 — anchored, UTF8-safe content replace
param([string]$File,[string]$Pattern,[string]$Replacement)
$txt = Get-Content -Raw -LiteralPath $File
$new = [regex]::Replace($txt,$Pattern,$Replacement)
if ($new -ne $txt) { Set-Content -LiteralPath $File -Value $new -Encoding UTF8; "Patched: $File" } else { "No change: $File" }
