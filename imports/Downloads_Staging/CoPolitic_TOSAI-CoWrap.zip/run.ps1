Write-Host 'Loaded CoWrap v2 for CoPolitic → TOS-AI' -ForegroundColor Cyan
Write-Host 'See CoWrap.md, ACTIONS.md, MANIFEST.json, snapshot/, scripts/, .github/' -ForegroundColor Cyan
