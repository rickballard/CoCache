# Action Deck

## NOW
- [ ] Fill all exemplar logos (160x160 PNG, transparent, dark on white)
- [ ] Add /roles/index.html to CoPolitic
- [ ] Run scripts/check-cache.ps1 after each deploy
- [ ] Ensure CTA issue labels exist: tos-ai, help wanted

## NEXT
- [ ] Auto-build TOS-AI one-pager PDF
- [ ] Link-checker Action with badge
- [ ] A11y pass (focus rings, color contrast)

## LATER
- [ ] Mini search for roles/docs
- [ ] i18n scaffolding
- [ ] Metrics-lite badge
