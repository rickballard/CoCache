# CoCEO (deprecated)

This label is retired.

See **[TOS-AI — Transition Office Steward (AI pivots)](./TOS-AI.md)** for the current role definition and scope.
