# Glossary

- **TOS-AI** — *Transition Office Steward – AI pivots*. Temporary executive-level steward during AI transitions.  
  _Formerly prototyped as **TOS-AI**._

