# About

**Temporary steward (unpaid):** [Rick Ballard](https://www.linkedin.com/in/richardballard/)

- Essays & context: [rickpublic.substack.com](https://rickpublic.substack.com/)
- Work with canines & community: [Dogs Needing Homes (UK)](https://dogsnhomes.org.uk/)

CoPolitic is designed to be a neutral, public-interest space. Inclusion of organizations or individuals on the site does not imply endorsement or coordination.
