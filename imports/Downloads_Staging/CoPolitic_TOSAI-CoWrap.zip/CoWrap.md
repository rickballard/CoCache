# CoWrap — CoPolitic (CoCEO → **TOS-AI**) — 2025-09-24T12:58:45.5156867-04:00

## Project Snapshot
- Repo: https://github.com/rickballard/CoPolitic.git
- Branch: main @ 764f076
- Dirty working copy: YES (see below)

### Recent commits (≤30)
764f076 2025-09-24 content: add /roles/tos-ai.html + footer Roles link  ΓÇö Rick Ball
a446962 2025-09-24 ux: add TOS-AI intake CTA + legacy /coceo redirect  ΓÇö Rick Ball
7a7f033 2025-09-24 content: TOS-AI checklist on homepage + CoCEO stub + ABOUT note  ΓÇö Rick Ball
b74a62f 2025-09-23 content: add TOS-AI explainer under hero  ΓÇö Rick Ball
ca2e4ef 2025-09-23 refactor: complete CoCEO ΓåÆ TOS-AI sweep + first-mention expansion  ΓÇö Rick Ball
c6adbb8 2025-09-23 refactor: rename CoCEO ΓåÆ TOS-AI (Transition Office Steward ΓÇô AI pivots)  ΓÇö Rick Ball
5a7834c 2025-09-23 assets: add/normalize logos for openai, skollfoundation  ΓÇö Rick Ball
2b07bfd 2025-09-23 ux: add avatar fallback badge for missing exemplar logos  ΓÇö Rick Ball
8a4d0be 2025-09-23 ux: drop legacy Exemplar Advocates bullet list (keep grid)  ΓÇö Rick Ball
71ec5e3 2025-09-23 feat: populate #exemplars grid with tiles  ΓÇö Rick Ball
55d74c5 2025-09-23 chore: bump index.html to refresh ETag  ΓÇö Rick Ball
69b7f1a 2025-09-23 chore: ensure .nojekyll present  ΓÇö Rick Ball
bb92f90 2025-09-23 chore: trigger Pages  ΓÇö Rick Ball
2ced03c 2025-09-23 hotfix: client-side strip of legacy Exemplar list (edge-cache safe)  ΓÇö Rick Ball
d6d7f75 2025-09-23 chore: trigger pages  ΓÇö Rick Ball
58e7987 2025-09-23 ux: remove legacy Exemplar Advocates bullet list above hero  ΓÇö Rick Ball
c941955 2025-09-23 chore: trigger pages  ΓÇö Rick Ball
8fbd087 2025-09-23 ux: add visible live build stamp  ΓÇö Rick Ball
63cf9e7 2025-09-23 chore: trigger Pages rebuild  ΓÇö Rick Ball
c455196 2025-09-23 ux: remove legacy list block; ensure single grid; add visible deploy marker  ΓÇö Rick Ball
010536b 2025-09-23 chore: trigger Pages rebuild  ΓÇö Rick Ball
846c7b4 2025-09-23 ux: remove legacy list block; add deployed commit marker  ΓÇö Rick Ball
26d6f4e 2025-09-23 chore: trigger GitHub Pages rebuild  ΓÇö Rick Ball
90a74d2 2025-09-23 ux: add CTAs to extended notes  ΓÇö Rick Ball
75056d8 2025-09-23 ux: add minimal footer links  ΓÇö Rick Ball
3c8e734 2025-09-23 chore: add PR & issue templates to guide contributions  ΓÇö Rick Ball
04ac4bb 2025-09-23 a11y: visible focus ring on pillar sub-nav  ΓÇö Rick Ball
902c40b 2025-09-23 ux: wire favicon link into <head>  ΓÇö Rick Ball
8d7ab37 2025-09-23 ux: add minimal SVG favicon and link  ΓÇö Rick Ball
c9d4a69 2025-09-23 ux: smooth-scroll + scroll-spy for pillar sub-nav  ΓÇö Rick Ball


### Working-copy diff summary
?? index.html.bak
?? index.html.bak2
?? live-after.html
?? live-server.html
?? live.html


---

## What’s Done ✅
- **Rename**: All occurrences of “CoCEO/Co-CEO/Co CEO” → **TOS-AI (Transition Office Steward — AI pivots)**.
- **Docs**: docs/defs/TOS-AI.md (authoritative), docs/defs/CoCEO.md (deprecation stub), docs/GLOSSARY.md.
- **Homepage**: Explainer chip, checklist card, CTA (prefilled GitHub issue), and **legacy redirect** /coceo.html.
- **Roles**: /roles/tos-ai.html + **footer** link.
- **Exemplars**: Grid section wired; JS fallback badge for missing logos; early batch of normalized logos added.
- **SEO basics**: Canonical + meta description on home.

## NOW (near-term actions) 🧭
1) **Logo completeness/quality**
   - Standardize all exemplar PNGs to 160×160 transparent squares with 12px inset.
   - Prefer **black/dark on white**. Avoid “white on black”/inverted variants.
   - Validate: missing logos degrade to SVG initials badge (already in place).

2) **Roles hub**
   - Add /roles/index.html to **this repo** (exists in MeritRank). Link from footer and hero.

3) **Cache sanity checks**
   - Use scripts\check-cache.ps1 to assert GitHub Pages edge is serving fresh (Age header, ETag churn).

4) **Issue intake**
   - Keep the TOS-AI prefilled issue; add labels 	os-ai, help wanted.

## NEXT (roadmap 1–3 weeks) 🚀
- **One-pager PDF** auto-build for TOS-AI (wkhtmltopdf or GitHub Action) from the MD card.
- **Micro-landing**: /roles/index.html with CTA and quick FAQ.
- **A11y/UX polish**: higher contrast on chips, focus rings, skip links.
- **Link integrity**: periodic external link checker (action) with report badge.

## LATER (nice-to-haves) ✨
- **Search**: client-side mini search for roles/docs.
- **Internationalization**: scaffold translation keys for glossary and roles cards.
- **Metrics**: lightweight pageview badge (privacy-respecting) to detect interest.

---

## Ideas & Improvements (Creative Pass)
- **“Steward, not savior” copy tweak**: Add one callout clarifying TOS-AI hands back control at exit criteria.
- **Timeline block**: Small horizontal timeline under the checklist: *Scope → Orchestrate → Exit*.
- **Risk register starter**: Sample table in the TOS-AI card for GRC conversations.
- **Live marker**: Tiny footer “Deployed: ISO datetime · short SHA” (we tried; can re-add once edge cache stable).
- **Role taxonomy**: Seed future roles (TOS-Sec, TOS-Data, CoPMO, CoOps) as stubs linking to #coming-soon.

---

## BPOE / Operating Norms
- Idempotent PS edits with anchored regex; **always** -Encoding UTF8.
- Pages deploy watching via gh run list --workflow="pages-build-deployment".
- Cache validation by bust querystring + Age/ETag/X-Served-By.
- Respect branch protection (MeritRank PR-only vs. CoPolitic direct push).
- **Fail-safe UX**: JS logo badge fallback; never render broken <img>.

