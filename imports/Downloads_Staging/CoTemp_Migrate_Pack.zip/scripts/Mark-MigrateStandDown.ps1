Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'

param(
  [string]$SessionId = 'co-migrate',
  [string]$PlanningId = 'co-planning'
)

# Load Join (brings in CoPanels / NoteBridge if present)
. (Join-Path $HOME 'Downloads\CoTemp\Join-CoAgent.ps1')

if (-not $env:COSESSION_ID) { $env:COSESSION_ID = $SessionId }

$root = Join-Path $HOME 'Downloads\CoTemp'
$sessionRoot = Join-Path $root ("sessions\{0}" -f $SessionId)
$inbox  = Join-Path $sessionRoot 'inbox'
$outbox = Join-Path $sessionRoot 'outbox'
$logs   = Join-Path $sessionRoot 'logs'
$null = New-Item -ItemType Directory -Force -Path $sessionRoot,$inbox,$outbox,$logs | Out-Null

# Drop a stand-down flag
$flag = Join-Path $sessionRoot 'STAND_DOWN.txt'
"Stand-down set at $(Get-Date -Format o) by $env:COMPUTERNAME. Do not start another watcher here." |
  Set-Content -LiteralPath $flag -Encoding ASCII

Write-Host ("Flagged stand-down: {0}" -f $flag) -ForegroundColor Yellow

# Notify Planning
$note = "Migrate pane has stood down from launching another watcher at $(Get-Date -Format o)."
try {
  if (Get-Command Send-CoNote -ErrorAction SilentlyContinue) {
    Send-CoNote -ToSessionId $PlanningId -Text $note
  } else {
    $planningInbox = Join-Path (Join-Path $root ("sessions\{0}" -f $PlanningId)) 'inbox'
    $null = New-Item -ItemType Directory -Force -Path $planningInbox | Out-Null
    $name = "NOTE_{0}_{1}.md" -f (Get-Date -Format 'yyyyMMdd-HHmmss'), $SessionId
    Set-Content -LiteralPath (Join-Path $planningInbox $name) -Value $note -Encoding ASCII
    Write-Host "Dropped note to Planning inbox." -ForegroundColor Green
  }
} catch {
  Write-Warning ("Could not notify Planning: {0}" -f ($_ | Out-String))
}

Write-Host "Stand-down complete." -ForegroundColor Green
