Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'

. (Join-Path $HOME 'Downloads\CoTemp\Join-CoAgent.ps1')

function _CountFiles($p,$filter){ try { (Get-ChildItem -LiteralPath $p -Filter $filter -ErrorAction SilentlyContinue).Count } catch { 0 } }

$panels = @( if (Get-Command Get-CoPanels -ErrorAction SilentlyContinue) { Get-CoPanels } else { @() } )
$root = Join-Path $HOME 'Downloads\CoTemp'

$rows = @()

foreach($sid in @('co-planning','co-migrate')){
  $sess = Join-Path $root ("sessions\{0}" -f $sid)
  $inbox  = Join-Path $sess 'inbox'
  $outbox = Join-Path $sess 'outbox'
  $logs   = Join-Path $sess 'logs'

  $rows += [pscustomobject]@{
    session    = $sid
    inbox_ps1  = _CountFiles $inbox  '*.ps1'
    outbox_ps1 = _CountFiles $outbox '*.ps1'
    last_log   = (Get-ChildItem -LiteralPath $logs -Filter '*.txt' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -desc | Select-Object -First 1).Name
  }
}

"Panels:"
if ($panels.Count -gt 0) {
  $panels | Format-Table -AutoSize name,session_id,pid
} else {
  "  (Get-CoPanels not available)"
}

"`nJobs:"
Get-Job | Where-Object { $_.Name -like 'CoQueueWatcher-*' } | Format-Table -AutoSize Name, State, HasMoreData

"`nCounts:"
$rows | Format-Table -AutoSize
