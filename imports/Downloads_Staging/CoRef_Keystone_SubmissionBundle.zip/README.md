# CoRef: Concept-Reference Protocol

Track the co-evolution of ideas, intent, and implementation across agents and time.