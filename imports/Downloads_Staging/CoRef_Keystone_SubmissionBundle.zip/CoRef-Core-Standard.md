# CoRef Standard

Defines Seed → Pod → Sprout → Stem → Leaf → Flower → Fruit lifecycle.