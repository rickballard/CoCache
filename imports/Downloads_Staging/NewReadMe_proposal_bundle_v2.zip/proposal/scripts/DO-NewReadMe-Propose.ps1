
# NOP guard
'' | Out-Null
$ErrorActionPreference = 'Stop'; Set-StrictMode -Version Latest

# === Settings (edit if needed) ===
$RepoPath   = Join-Path $HOME 'Documents\GitHub\CoCivium'   # local repo path
$StagePath  = Join-Path $HOME 'Downloads\CoTemp\NewReadMe\proposal'  # staged proposal root
$BranchName = 'docs/new-root-readme_proposal_{0}' -f (Get-Date -Format 'yyyyMMdd_HHmm')
$PrTitle    = 'Docs: New root README + Onramps/Outputs (Proposal)'
$Labels     = @('docs','proposal','bpoe','readme','academy','onramps','outputs')
$Assignees  = @()  # e.g. 'rickballard'

# === Preconditions ===
if (-not (Test-Path $RepoPath))   { throw "Repo path not found: $RepoPath" }
if (-not (Test-Path $StagePath))  { throw "Stage path not found: $StagePath" }
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { throw "git not found in PATH" }
if (-not (Get-Command gh  -ErrorAction SilentlyContinue)) { throw "gh not found in PATH" }

# === Git prep ===
Set-Location $RepoPath
git fetch --all
$current = (& git rev-parse --abbrev-ref HEAD).Trim()
if ($current -ne 'main') {
  Write-Host "Switching to main..." -ForegroundColor Yellow
  git checkout main
}
git pull --ff-only

# === Create work branch ===
git checkout -b $BranchName

# === Copy proposal into repo /proposal ===
$Dest = Join-Path $RepoPath 'proposal'
if (Test-Path $Dest) {
  Write-Host "Cleaning old /proposal ..." -ForegroundColor Yellow
  Remove-Item $Dest -Recurse -Force
}
New-Item -ItemType Directory -Force -Path $Dest | Out-Null
Copy-Item -Path (Join-Path $StagePath '*') -Destination $Dest -Recurse -Force

# === Add & commit ===
git add proposal
$wrap = @"
CoWrap — New Root README Proposal

- Adds navigational root README (proposal)
- Onramps (explorer, contributor, civic architect, researcher)
- Outputs (policies, standards incl. congruence rubric, artefacts, records incl. badge decisions)
- Academy genesis placeholder + deprecated legacy slot
- Mermaid diagrams (process_flow, stage_map)
- BPOE CoTemp guidance + proposal notice + migration notes
- RFC template; badges/status mini-spec

BPOE: Stage Locally → Propose Centrally. Squash-merge after review via HumanGate.
"@
git commit -m $PrTitle -m $wrap

# === Push & PR ===
git push -u origin $BranchName

# Build label args
$labelArgs = @()
foreach ($l in $Labels) { $labelArgs += @('--label', $l) }
$assigneeArgs = @()
foreach ($a in $Assignees) { $assigneeArgs += @('--assignee', $a) }

gh pr create --title $PrTitle `
             --body $wrap `
             --base main `
             --head $BranchName `
             @labelArgs @assigneeArgs

Write-Host "Done. Review PR, then squash-merge. HumanGate ON." -ForegroundColor Green
