# Participation Badges & Status (Mini-Spec)

**Purpose:** Recognize meaningful contributions and signal reliable stewardship domains.

## Tiers
- **Explorer** — completed Academy intro & submitted at least one useful question/issue.
- **Contributor** — ≥3 merged PRs passing HumanGate; consistent review responsiveness.
- **Maintainer** — CODEOWNER in designated domains; handles reviews & merges.
- **Civic Architect** — led at least one RFC through full cycle (proposal→review→adoption); authored policy/spec changes with congruence analysis.

## Issuance & Revocation
- Issued by Maintainers via label/role assignment; logged in Records (decision ID).
- Revocable upon process breaches or inactivity (with a restorative path).

## Signals (where shown)
- GitHub labels/tags on profile/PRs
- Discord/Community role names
- Records index linking to badge decisions

## Anti-Gaming Guardrails
- Require CoCleanse review for badge decisions.
- Use contribution quality metrics, not just counts.
- Publish decisions in Records with rationale.
