---
title: RFC: <short, imperative title>
status: draft
authors: [github-handle]
created: YYYY-MM-DD
related: [issues/links]
---

## Summary
One-paragraph explanation of the change.

## Motivation
What problem does this solve? Who benefits? Why now?

## Design / Proposal
- Proposed changes
- Alternatives considered
- Interactions with policies/standards/tools

## Risks & Mitigations
- Risks, failure modes, rollbacks
- Ethics, privacy, and bias considerations

## Congruence Analysis
- Expected effects on fairness, transparency, and communal learning
- Metrics to monitor

## Rollout Plan
- Milestones, owners, dependencies
- Success criteria

## Appendix
- Prior art
- Glossary
