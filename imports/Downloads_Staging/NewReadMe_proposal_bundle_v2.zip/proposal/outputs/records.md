# Records & Reports

---

## Participation Decisions
Badge/role issuance and revocation are recorded as decision entries with rationale, evidence, and congruence summaries. This ensures recognition is transparent and accountable.
