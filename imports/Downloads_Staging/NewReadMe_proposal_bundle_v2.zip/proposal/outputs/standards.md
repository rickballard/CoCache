# Standards & Specifications

---

## Congruence Scoring Rubric (Draft)

**Goal:** Evaluate proposals and decisions by their alignment with CoCivium principles.

| Dimension        | Guiding Question                                      | Scale (0–5) | Notes |
|------------------|--------------------------------------------------------|-------------|-------|
| Fairness         | Does it reduce unjust advantage/harm?                 |             |       |
| Transparency     | Is rationale/evidence auditable?                      |             |       |
| Remedy Orientation | Does it enable repair/restoration over punishment?  |             |       |
| Inclusivity      | Were impacted voices included?                         |             |       |
| Evidence Weight  | Is evidence weighed rigorously and reproducibly?      |             |       |
| Accountability   | Are roles/owners clear and reviewable?                |             |       |
| Iterability      | Can this be monitored and improved post-adoption?     |             |       |

**Usage:** score per dimension; include summary in Records with links to evidence. Thresholds/weights may vary by domain and maturity stage.
