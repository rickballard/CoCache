

**Automation:** Run `proposal/scripts/DO-NewReadMe-Propose.ps1` to stage → branch → push → open PR.
