# IdeaCards Summary
- **Civic-BPMN**: extension of BPMN with civic stencils.  
- **Dual-Layer Indexing**: human-facing and AI-facing indexes in sync.  
- **Academy**: founder-training first, community-onboarding next.  
- **Consultant Buzzword Map**: decode → translate → republish in civic idiom.  
