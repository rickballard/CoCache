# Guidance: Dual-Layer Indexing System

## Human Layer
- Highlights: keystone docs, scrolls, IdeaCards, AdviceBombs.  
- Purpose: fast orientation for humans joining the project.  

## AI Layer
- Graph of repo purposes, deliverables, cross-links.  
- Parsable by AI to answer holistic queries.  

## Governance Rule
Both layers must evolve **together**. Updating one without the other introduces fragmentation.  
