# Guidance: Upsweep/Downsweep Method

## Upsweep
- Scan all repos systematically.  
- Extract metadata: purpose, deliverables, structure, dependencies.  
- Store snapshots in **machine-readable (JSON/YAML)** format.  
- Summarize in **human-readable index**: keystone docs, scrolls, advisories.  

## Downsweep
- Edit repos for clarity, consistency, readability.  
- Improve linking between docs and indexes.  
- Ensure both human and AI indexes stay aligned.  

## Why Important
- Prevents silos and duplication.  
- Creates a clear map for contributors and AI agents.  
