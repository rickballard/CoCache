# Guidance: Academy Folder Series

## Each Folder Contains
1. Consultant-style advisory (dense, jargon, frameworks).  
2. Civic translation track (plain language, CoCivium metaphors).  
3. Snippets & IdeaCards.  

## Learning Rhythm
- Founder-first: accelerates Rick’s literacy.  
- Community-later: onboarding kit for regular contributors.  
