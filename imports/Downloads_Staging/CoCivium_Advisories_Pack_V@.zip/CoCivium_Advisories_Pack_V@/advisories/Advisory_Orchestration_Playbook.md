# CoCivium Orchestration Playbook

## Adopt
- End-to-end orchestration of both human and automated tasks.  
- Long-running processes with state persistence and auditability.  
- BPMN for process flows, DMN for decision rules.  
- One-model approach: design, execution, and monitoring unified.  

## Adapt
- Civic-BPMN: extend BPMN with civic stencils (Assembly, Ballot, Grant Escrow).  
- Gibberlinkish metadata for AI/agent parsing.  

## Reject
- Monolithic automation platforms.  
- Proprietary tooling that raises TCO.  

## Pilot Plan
1. Model *Grant Lifecycle* and *Policy-Vote Pipeline*.  
2. Implement with CoAgent, GitHub, Payment connectors.  
3. Monitor with heatmaps and SLA tracking.  
4. Iterate after 90 days.  
