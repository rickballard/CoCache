# Advisory: CoCivium Academy

## Goal
- Train Rick quickly with consultant frameworks.  
- Translate into civic modules for the wider community.  

## Dual-Track Design
1. **Consultant Track**: buzzword-heavy, maturity models, frameworks (raw ore).  
2. **Civic Track**: accessible translations, metaphors (music, ecosystems, rituals).  

## Folder Themes
- Foundations of Orchestration & Transformation  
- Process Standards & Languages  
- Governance & Change Management  
- AI + Civic Systems Integration  
- Open Standards vs Proprietary Platforms  
- Measurement & Maturity  

## Why It Matters
- Builds founder literacy.  
- Creates onboarding assets.  
- Defends against external consultant critique.  
