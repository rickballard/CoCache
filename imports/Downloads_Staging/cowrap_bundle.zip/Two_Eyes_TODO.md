# Crest & Two Eyes TODO

The README smoke check warns:
- “CC crest not referenced”
- “Two Eyes not referenced”

## Quick fixes
- Add a small crest image (SVG/PNG) near the top of README linking to CC Hub.
- Add a “Two Eyes” blurb or icon with a one‑liner and a link to its explainer.
