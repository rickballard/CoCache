# Loose ends

- **Place CoTip where breakages happen**: append the Ctrl+C tip at the *bottom* of blocks that risk leaving PS at `>>`/`>`.
- **README “New” autoupdate**: identify which workflow updates the top “New” list; ensure schedule + write permissions (see `UPDATE_README_TOP.md`).
- **Idea Quickstart surface**: add a bullet “✨ Easiest method: Open an Idea issue…” under README quick links and on `/site` (link points to Idea template chooser).
- **Labels**: `docs`, `diagram`, `phase:1`, `priority:high`, `nice-to-have`, `CC`, `ratification` — ensure present (script provided).
- **Pinned issues**: keep CC ratification pinned (script can rotate pins if already 3).
- **Pages**: verify build succeeds on main after merge; homepage should show clear entry points.
- **Branch protection**: keep strict checks (12 contexts). Temporary relax/restore script provided for emergencies.
