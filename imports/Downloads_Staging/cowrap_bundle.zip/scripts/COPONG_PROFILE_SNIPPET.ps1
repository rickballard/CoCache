# Add this line to $PROFILE to clearly mark restarts:
Add-Content -Path $PROFILE -Value 'Write-Host "[CoPong] PS restart: $(Get-Date -Format o) | PS $($PSVersionTable.PSVersion)" -ForegroundColor Cyan'
