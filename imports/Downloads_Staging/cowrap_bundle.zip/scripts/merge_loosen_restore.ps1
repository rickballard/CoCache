# Loosen status checks temporarily to merge PRs, then restore (preserve contexts)
param([int[]]$PrNumbers)

Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
$repo = gh repo view --json nameWithOwner -q .nameWithOwner
$bp   = gh api "repos/$repo/branches/main/protection" --jq '.required_status_checks.contexts' | ConvertFrom-Json

# Loosen only status checks
@{
  required_status_checks        = $null
  enforce_admins                = $true
  required_pull_request_reviews = @{
    dismiss_stale_reviews=$true; require_code_owner_reviews=$false; required_approving_review_count=0
  }
  restrictions=$null; allow_force_pushes=$false; allow_deletions=$true; block_creations=$false
  required_linear_history=$false; required_conversation_resolution=$true; lock_branch=$false; allow_fork_syncing=$true
} | ConvertTo-Json -Depth 6 | gh api -X PUT "repos/$repo/branches/main/protection" -H "Accept: application/vnd.github+json" --input - | Out-Null

foreach($n in $PrNumbers){ try { gh pr merge $n --squash --delete-branch } catch { Write-Host "Merge failed for PR #$n: $_" -ForegroundColor Yellow } }

# Restore
@{
  required_status_checks        = @{ strict=$true; contexts=$bp }
  enforce_admins                = $true
  required_pull_request_reviews = @{
    dismiss_stale_reviews=$true; require_code_owner_reviews=$false; required_approving_review_count=0
  }
  restrictions=$null; allow_force_pushes=$false; allow_deletions=$true; block_creations=$false
  required_linear_history=$false; required_conversation_resolution=$true; lock_branch=$false; allow_fork_syncing=$true
} | ConvertTo-Json -Depth 6 | gh api -X PUT "repos/$repo/branches/main/protection" -H "Accept: application/vnd.github+json" --input - | Out-Null

Write-Host "Restored strict status checks with original contexts." -ForegroundColor Green
