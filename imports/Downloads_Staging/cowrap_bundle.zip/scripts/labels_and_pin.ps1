# Ensure labels exist; apply to issues; optionally pin CC ratification
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
$labels = @(
  @{n='docs';          c='0366d6'; d='Documentation'},
  @{n='stubs';         c='6e7781'; d='Auto-created stub files'},
  @{n='diagram';       c='0e8a16'; d='Diagram work'},
  @{n='phase:1';       c='a2eeef'; d='Phase 1'},
  @{n='priority:high'; c='d73a4a'; d='High priority'},
  @{n='nice-to-have';  c='bfd4f2'; d='Non-blocking improvement'},
  @{n='CC';            c='5319e7'; d='Cognocarta-related'},
  @{n='ratification';  c='fbca04'; d='Review/Ratify window'}
)
foreach($L in $labels){ gh label create $L.n --color $L.c --description $L.d 2>$null | Out-Null }

# Example: apply to known issues if they exist
try { gh issue edit 320 --add-label "docs","stubs","phase:1","priority:high" } catch {}
try { gh issue edit 321 --add-label "docs","diagram","nice-to-have" } catch {}
try { gh issue edit 319 --add-label "CC","ratification","priority:high" } catch {}

# Pin #319 if possible (rotate oldest if 3 already pinned)
try { gh issue pin 319 } catch {
  $pins = gh issue list --limit 100 --json number,updatedAt,isPinned | ConvertFrom-Json | ? { $_.isPinned } | Sort-Object updatedAt
  if($pins -and ($pins.Count -ge 3) -and -not ($pins.number -contains 319)){
    gh issue unpin $($pins[0].number) | Out-Null
    gh issue pin 319 | Out-Null
  }
}
Write-Host "Labels ensured; issue labels/pin updated where applicable." -ForegroundColor Green
