# Build docs/cc/SCROLL.md from canonical parts (idempotent)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
function Write-LFAbs([string]$Rel,[string]$Text){
  $dst = [System.IO.Path]::GetFullPath((Join-Path $PWD.Path $Rel))
  $dir = [System.IO.Path]::GetDirectoryName($dst)
  if($dir -and -not (Test-Path $dir)){ New-Item -ItemType Directory -Force | Out-Null }
  $enc = New-Object System.Text.UTF8Encoding($false)
  $nl  = $Text -replace "`r`n","`n" -replace "`r","`n"
  [System.IO.File]::WriteAllText($dst,$nl,$enc)
}

$parts = @(
  "docs/cc/COGNOCARTA_CONSENTI.md",
  "docs/cc/AMENDMENTS_LOG.md",
  "docs/cc/DECISION_FLOW.md",
  "docs/cc/GLOSSARY.md",
  "docs/cc/CC_SUPPORTING_DOCS.md"
) | Where-Object { Test-Path $_ }

$stamp = Get-Date -Format 'yyyy-MM-dd HH:mm zzz'
$header = @"
# Cognocarta Consenti — Scroll

*Single continuous reading copy assembled from canonical parts.*
*Last updated: $stamp*

"@

$scroll = $header
foreach($p in $parts){
  $leaf = Split-Path $p -Leaf
  $scroll += "`n---`n`n<!-- Source: $leaf -->`n`n"
  $scroll += (Get-Content $p -Raw -Encoding UTF8)
}

Write-LFAbs 'docs/cc/SCROLL.md' $scroll
Write-Host "Wrote docs/cc/SCROLL.md from $($parts.Count) parts." -ForegroundColor Green
Write-Host "CoTip: if you get a short '>>' prompt, press Ctrl+C to return to PS …>." -ForegroundColor Yellow
