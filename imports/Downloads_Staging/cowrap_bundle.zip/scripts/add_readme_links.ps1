# Idempotently add helpful links to README
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
$rm = 'README.md'
$body = Get-Content $rm -Raw -Encoding UTF8
$append = @()
if($body -notmatch '\[docs/INDEX\.md\]'){ $append += '- **Docs Index (start here):** [docs/INDEX.md](docs/INDEX.md)' }
if($body -notmatch '\[docs/cc/SCROLL\.md\]'){ $append += '- **Read the CC (single scroll):** [docs/cc/SCROLL.md](docs/cc/SCROLL.md)' }
# Try to infer Pages URL: https://<owner>.github.io/<repo>/
$repo  = gh repo view --json nameWithOwner -q .nameWithOwner
$owner = $repo.Split('/')[0]; $name = $repo.Split('/')[1]
$site  = "https://$owner.github.io/$name/"
if($body -notmatch '\*\*Website:\*\*'){ $append += "- **Website:** $site" }

if($append.Count -gt 0){
  $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
  $body = ($body.TrimEnd() + "`n`n" + ($append -join "`n") + "`n") -replace "`r`n","`n" -replace "`r","`n"
  [System.IO.File]::WriteAllText((Join-Path $PWD.Path $rm), $body, $utf8NoBom)
  git add README.md
  git commit -m "docs(readme): surface Docs Index / CC Scroll / Website (idempotent)"
  Write-Host "README updated with: $($append -join ', ')" -ForegroundColor Green
} else {
  Write-Host "README already had all target links; no change." -ForegroundColor Cyan
}
