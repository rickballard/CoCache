# Repo‑based scheduling (no ChatGPT scheduler)

Pattern: create/keep a single **Schedule Bucket** issue (e.g., title “Schedule bucket”), and have a *weekly* GitHub Action post a comment checklist there. Humans then copy any items into real issues when appropriate.

## Enable (optional)
1. Open `.github/workflows/repo_nudge_workflow.yml` from this bundle.
2. Set `ISSUE_NUMBER` to your Schedule Bucket issue number.
3. Commit as `.github/workflows/repo_nudge.yml` in your repo.
4. Ensure the workflow has:
   - `on: schedule:` with a sensible cron.
   - `permissions: issues: write, contents: read`.

This avoids filling external schedulers and keeps history in‑repo.
