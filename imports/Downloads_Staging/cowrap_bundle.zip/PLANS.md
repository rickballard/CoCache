# Next steps (repo optics & onboarding)

**Goal:** Fast, non‑GitHub readers can *read first, act second*.

1) **Single‑scroll CC is present** (docs/cc/SCROLL.md). If missing or stale, run `scripts/assemble_cc_scroll.ps1`.
2) **Docs entry points are obvious**:
   - README has: **Docs Index**, **CC Scroll**, **Website**.
   - `/site` landing links **CC Scroll** & **Docs Index**.
3) **Easiest method (Idea Quickstart)** is one click from README & `/site`:
   - Link to `<https://github.com/<owner>/<repo>/issues/new/choose>` with “Idea” template highlighted.
   - Include the one‑pager `IDEA_QUICKSTART.md`; optionally render `idea_flow.mmd`.
4) **README “New” block**: audit workflow that maintains it; ensure it has `permissions: contents: write` and a schedule (`on: schedule:`). See `UPDATE_README_TOP.md`.
5) **Pages is enabled** and builds `/site` via Actions. Use `scripts/pages_workflow.yml` if needed.
6) **Two Eyes + crest** references: see `Two_Eyes_TODO.md`.
7) **Repo‑based nudges** (no ChatGPT scheduler): enable `scripts/repo_nudge_workflow.yml` after filling placeholders, or keep manual.

_All steps are additive and non‑destructive to existing prose._
