# Updating the "New" section at the top of README

If the “New” list feels stale:

1. Identify the workflow that writes to README (names often include `readme`, `og`, `autogen`, etc.).
   ```sh
   gh workflow list
   gh workflow view "<name or file>" --yaml
   ```
2. Ensure it has:
   - `on: schedule:` (cron) **and** `workflow_dispatch:` for manual runs.
   - `permissions: contents: write`
3. Check latest runs:
   ```sh
   gh run list --workflow "<name or file>" --limit 20
   gh run view <run-id> --log
   ```
4. If failing with “Resource not accessible by integration”, add the `permissions` block and ensure it’s running on `main` or with a token that can write.
5. As a stopgap, manually update the block in README and label the PR with `readme-ok` if your repo requires that to bypass the guard.
