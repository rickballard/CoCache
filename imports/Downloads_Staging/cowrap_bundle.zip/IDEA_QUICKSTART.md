# Idea Quickstart (plant a seed in ~1–2 minutes)

- ✨ **Easiest method:** open an **Idea** issue → describe your idea in 1–3 sentences → submit and you’re done:
  - `https://github.com/<owner>/<repo>/issues/new/choose`

## Steps
1) Open the **Idea** template: `https://github.com/<owner>/<repo>/issues/new/choose`
2) **Title:** one line. **Body:** 1–3 sentences. Optional: one link or sketch.
3) **Submit.** Others can ask questions or pick it up.

```mermaid
flowchart LR
  A[Have an idea] --> B[Open Idea template]
  B --> C[Write 1–3 sentence pitch]
  C --> D[Submit]
  D --> E{Triage}
  E -->|label/route| F[Discussion]
  E -->|ready| G[Small PRs]
  E -->|park| H[Parking Lot]
```
