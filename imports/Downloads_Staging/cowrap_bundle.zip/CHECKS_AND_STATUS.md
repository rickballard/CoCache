# Branch protection & checks (reference)

- `strict`: **true**
- Required status check contexts (12):
  - add, check, codespell, gate, guard, label, linkcheck, lint, lychee, markdownlint, spell, yamllint

## Quick verify
```sh
gh api "repos/$(gh repo view --json nameWithOwner -q .nameWithOwner)/branches/main/protection"   --jq '{strict:.required_status_checks.strict,count:(.required_status_checks.contexts|length)}'
```
Expect: `{"strict": true, "count": 12}`.
