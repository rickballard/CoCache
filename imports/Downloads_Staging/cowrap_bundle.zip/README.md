# CoWrap Bundle
_Last updated: 2025-08-28 08:36 UTC_

This bundle collects "loose ends", quick wins, and ready-to-run scripts so you can pick up the migration next session without digging through chat.

## What’s inside
- `PLANS.md` — prioritized next steps for repo optics & onboarding.
- `LOOSE_ENDS.md` — small open items with owner/action.
- `CHECKS_AND_STATUS.md` — branch protection expectations (12 checks) & tips.
- `SCHEDULE_BUCKET.md` — repo‑based nudge pattern (no ChatGPT scheduler).
- `IDEA_QUICKSTART.md` & `idea_flow.mmd` — “Easiest path” doc + diagram.
- `scripts/assemble_cc_scroll.ps1` — builds **docs/cc/SCROLL.md** from canonical parts.
- `scripts/add_readme_links.ps1` — idempotent links for README (Docs Index, CC Scroll, Website).
- `scripts/pages_workflow.yml` — GitHub Pages workflow to build `/site` (Actions).
- `scripts/repo_nudge_workflow.yml` — weekly nudge to a Schedule Bucket issue (disabled by default; edit before use).
- `scripts/labels_and_pin.ps1` — ensure helpful labels exist; (optionally) pin CC ratification.
- `scripts/merge_loosen_restore.ps1` — temporarily relax status checks to merge, then restore (preserves contexts).
- `scripts/COPONG_PROFILE_SNIPPET.ps1` — prints a clear CoPong header on PS7 restarts.
- `Two_Eyes_TODO.md` — small “crest/Two Eyes” follow‑ups.
- `UPDATE_README_TOP.md` — how to fix/update the “New” section.

See each file for precise instructions.
