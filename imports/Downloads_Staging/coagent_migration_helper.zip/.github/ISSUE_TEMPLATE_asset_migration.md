---
name: Asset Migration
about: Track copying assets into CoAgent with breadcrumbs
labels: migration, breadcrumbs
---

**Source path(s)**
- <path>

**Globs**
- <glob>

**Notes**
- Why these assets are needed
- Cleanup plan
