# Breadcrumb note (include alongside any imported file)

- ORIGIN: <full original path>
- HASH: <sha256>
- MOVED: <ISO timestamp>
- BY: <user@machine>
- NOTE: Temporary import. Remove after consolidation by Grand Migration.
