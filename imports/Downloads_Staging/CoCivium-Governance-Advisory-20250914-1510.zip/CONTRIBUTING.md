﻿# Contributing
- Open an issue for non-trivial changes.
- Keep PRs small & reversible; document *why / alternatives / consequences*.
- Update docs/ops/OPERATING_LOG.md when merging meaningful changes.
