﻿# Code of Conduct
Be civil. No harassment. Assume good faith. Document disagreements. Temporary moderation may apply; all actions are logged.
