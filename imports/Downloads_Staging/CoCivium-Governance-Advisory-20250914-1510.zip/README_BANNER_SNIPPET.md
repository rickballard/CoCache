﻿> **Stewarded, not owned.** CoCivium is a public, fork-first civic canon.  
> Stewards are temporary caretakers. See docs/governance/* for mission, principles, and process.
