﻿# CoCivium — Stewarded, not owned
CoCivium is a public, fork-first civic canon. No single human, AI, corp, or state may own or capture it.
Decisions are transparent, reversible where feasible, and congruent with *co-evolution*.

**No corruption. No coercion. No kings.**
