﻿# Threats & Countermeasures
- Platform capture → mirrors + signed releases + public fingerprints
- Maintainer capture → multi-steward rule, rotation, transparency
- Content poisoning → provenance notes, review, rollback playbook
