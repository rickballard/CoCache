﻿# Stewards (roster)
Add via PR. Include public contact and conflicts statement.

- Provisional: Rick Ballard (@rickballard) — temporary steward; mandate to decentralize.
