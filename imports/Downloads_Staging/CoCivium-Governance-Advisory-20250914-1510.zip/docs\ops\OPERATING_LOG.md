﻿# Operating Log
_A rolling breadcrumb trail. Timestamp → what/why/where._
