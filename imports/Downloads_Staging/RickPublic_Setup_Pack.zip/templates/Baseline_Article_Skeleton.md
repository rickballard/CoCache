# [Hero title with one number that matters]

![hero-infographic](hero.png "Alt: what the chart shows")  
<footnote> Sources: X, Y. Method: Z (see methods.md). </footnote>

**Lead (≤120 words).** What changed, why it matters, how we know.

## Three Signals
1) Signal #1 → CoCivium soundbite → [repo link]
2) Signal #2 → CoCivium soundbite → [repo link]
3) Signal #3 → CoCivium soundbite → [repo link]

> **Callout:** “Facts are public. Methods are the passport.”

**What you can do:** comment with sources, replicate the method, propose a fix.

---
See `methods.md` for data, model, replicability, limitations, and ethics.
