# Methods & Sources (Template)

**Data:** Describe sources, collection dates, transforms, exclusions.  
**Model:** Assumptions, parameters, uncertainty, failure modes.  
**Replicability:** Steps or code pointer; note any external dependencies.  
**Limitations:** What this analysis does **not** show; risks of misread.  
**Ethics:** Bias checks, privacy considerations, licenses.

**Citations:**  
- Source A — …  
- Source B — …  
