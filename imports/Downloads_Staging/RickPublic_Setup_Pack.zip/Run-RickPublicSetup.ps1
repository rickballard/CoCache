
<#
Run-RickPublicSetup.ps1 — PS7 ONEBLOCK
Creates an Idea Card + mapper seed + weekly scaffold in the RickPublic repo,
opens a PR, and attempts an auto-merge (squash) into main.
Prereqs: PowerShell 7+, git, gh (gh auth login), repo push rights.

USAGE:
  pwsh -File .\Run-RickPublicSetup.ps1 -Owner rickballard -Repo RickPublic
#>

[CmdletBinding()]
param(
  [string]$Owner = "rickballard",
  [string]$Repo  = "RickPublic",
  [string]$Remote = "origin",
  [string]$Main   = "main",
  [switch]$NoMerge,         # If set, do not auto-merge PR
  [switch]$NoPR,            # If set, do not open a PR (commit & push branch only)
  [string]$Workspace = "$HOME\Documents\GitHub",
  [string]$IdeaDirRel = "docs/idea_cards",
  [string]$IdeaFile   = "idea_rickpublic_cocivium_messaging_bridge.md",
  [string]$MapperDirRel = "mapper",
  [string]$MapperSeed   = "seed.json",
  [string]$ArticlesRel  = "articles"
)

$ErrorActionPreference = "Stop"; Set-StrictMode -Version Latest

function Write-Note($msg){ Write-Host "[NOTE] $msg" -ForegroundColor Cyan }
function Write-Ok($msg){ Write-Host "[OK]   $msg" -ForegroundColor Green }
function Write-Warn($msg){ Write-Warning $msg }
function New-Folder($p){ if(-not (Test-Path $p)){ New-Item -Type Directory -Force -Path $p | Out-Null } }

# Resolve paths
$repoPath = Join-Path $Workspace $Repo
New-Folder $Workspace

# Clone if needed
if (-not (Test-Path $repoPath)) {
  Write-Note "Cloning https://github.com/$Owner/$Repo.git to $repoPath"
  git clone "https://github.com/$Owner/$Repo.git" $repoPath
}
Set-Location $repoPath

# Clean state
git fetch $Remote --prune
git checkout $Main
git pull --ff-only $Remote $Main

# Create branch
$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$branch = "docs/idea-rickpublic-bridge_$stamp"
git checkout -b $branch
Write-Ok "Created branch $branch"

# Ensure folders
$ideaDir = Join-Path $repoPath $IdeaDirRel
$mapperDir = Join-Path $repoPath $MapperDirRel
$articlesDir = Join-Path $repoPath $ArticlesRel
New-Folder $ideaDir
New-Folder $mapperDir
New-Folder $articlesDir

# Determine current ISO week folder
$iso = [System.Globalization.ISOWeek]::GetWeekOfYear([datetime]::UtcNow)
$year = (Get-Date).ToString("yyyy")
$weekFolder = "{0}-{1:d2}" -f $year, $iso
$weekPath = Join-Path $articlesDir $weekFolder
New-Folder $weekPath

# Load template content from the same folder as script (zip extracted dir)
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$tplMethods = Get-Content -Raw -LiteralPath (Join-Path $scriptDir "templates\Methods_Template.md")
$tplSkeleton = Get-Content -Raw -LiteralPath (Join-Path $scriptDir "templates\Baseline_Article_Skeleton.md")
$tplMapperSeed = Get-Content -Raw -LiteralPath (Join-Path $scriptDir "mapper_seed.json")

# Write files
$ideaPath = Join-Path $ideaDir $IdeaFile
$mapperSeedPath = Join-Path $mapperDir "seed.json"
$draftPath = Join-Path $weekPath "draft.md"
$methodsPath = Join-Path $weekPath "methods.md"
$metricsPath = Join-Path $weekPath "metrics.csv"
$weekMapperPath = Join-Path $weekPath "mapper.json"

# Idea Card content
$today = Get-Date -Format "yyyy-MM-dd"
$idea = @"
# Idea Card — RickPublic ↔ CoCivium Automated Messaging Bridge
**Status:** Draft • **Owner:** Rick Ballard • **Date:** $today  
**Objective:** Convert weekly trending issues into concise, data-backed RickPublic posts that map to CoCivium soundbites + repo links.  
**Rule:** Experiments run **between separate articles only** against a fixed **Baseline** (no in-article A/B).

## Principles
- Truth brand over clout; cite sources, append Methods.
- Anti-polarization: frame mechanisms/incentives, not tribes.
- Inference-dense, quotable callouts; every post ends with Methods & Sources.

## Baseline
- 800–1100 words (+ Methods). Hero infographic → 120-word lead → 3 signals (each maps to a CoCivium soundbite + 1–2 repo links) → 1–2 meme-able callouts → Actions → Methods.
- Infographic: single clear chart, alt text, footnote with sources; avoid dual-axis unless justified in Methods.
- Link hygiene: UTM on externals; stable repo paths; pin commits for non-drifting docs.

## Message Mapper (Design)
Fields: neutral_summary, co_soundbite{id,text}, repo_links[title,path], data_sources[name,url], infographic{type,notes}, risk_flags, compliance{privacy,license_ok}.

## Weekly Pipeline
Ingest → Map → Graphic → Draft → Methods → Pre-flight (sources/licenses/bias/link lint) → Publish Friday → Archive artifacts in `/articles/YYYY-WW/`.

## Between-Article Experiments (W5+)
Run Baseline W1–W4. Then change one variable/week (framing, chart type, callout style, CTA placement, publish time, link count). Re-test winners after a washout.

## Metrics → Resonance Score
Open rate, hero dwell, deep-link CTR, read time, share rate, comment quality, sub growth, unsub/complaints. Weighted, normalized over trailing 8 weeks. Promote if ≥ +10 vs baseline twice; retire if ≤ −10 twice. Visible corrections log.

## Governance & Safety
Evidence gate; license gate; polarization gate; extra review for election/health; prominent corrections.

## Speaking Pipeline
After 10–12 issues with RS > baseline: one-pager + 90-sec reel (pinned) and outreach to civic-tech / journalism / AI-governance venues.

## Next Steps
Freeze Baseline (W1–W4) • Seed `/mapper/` with ~8 archetypes • Ship Week-1 baseline article • Plan W5–W12 experiment knobs.
"@

# Week scaffold content
if (-not (Test-Path $draftPath)) {
  Set-Content -Path $draftPath -Value $tplSkeleton -Encoding UTF8
}
if (-not (Test-Path $methodsPath)) {
  Set-Content -Path $methodsPath -Value $tplMethods -Encoding UTF8
}
if (-not (Test-Path $weekMapperPath)) {
  Set-Content -Path $weekMapperPath -Value $tplMapperSeed -Encoding UTF8
}

# Write idea card (overwrite if different)
$writeIdea = $true
if (Test-Path $ideaPath) {
  if ((Get-Content -Raw $ideaPath) -eq $idea) { $writeIdea = $false }
}
if ($writeIdea) { Set-Content -Path $ideaPath -Value $idea -Encoding UTF8 }

# Minimal metrics header (if absent)
if (-not (Test-Path $metricsPath)) {
  "week,open_rate,hero_dwell_sec,deep_link_ctr,avg_read_time_sec,share_rate,comment_quality,sub_growth,unsub_rate" | Set-Content -Path $metricsPath -Encoding UTF8
}

# Stage & commit
git add $ideaPath $mapperSeedPath $draftPath $methodsPath $metricsPath $weekMapperPath 2>$null
# Also ensure mapper seed gets written (copy into repo mapper dir)
Set-Content -Path $mapperSeedPath -Value $tplMapperSeed -Encoding UTF8
git add $mapperSeedPath

git commit -m "docs: add RickPublic↔CoCivium idea card, mapper seed, and weekly scaffold"

# Push branch
git push -u $Remote $branch

if ($NoPR) {
  Write-Note "NoPR flag set; skipping PR creation."
  exit 0
}

# Create PR
$prUrl = gh pr create --title "Idea: RickPublic↔CoCivium messaging baseline + weekly scaffold" `
                      --body  "Adds idea card, mapper seed, and articles/$weekFolder scaffold (draft.md, methods.md, mapper.json, metrics.csv)." `
                      --base $Main --head $branch

Write-Host "`nPR: $prUrl`n"

if (-not $NoMerge) {
  try {
    gh pr merge --squash --delete-branch --auto $prUrl | Out-Host
  } catch {
    Write-Warn "Auto-merge not permitted or checks pending. Merge manually: $prUrl"
  }
} else {
  Write-Note "NoMerge flag set; leaving PR open."
}

Write-Ok "Done."
