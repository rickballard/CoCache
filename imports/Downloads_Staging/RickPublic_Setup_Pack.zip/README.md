# RickPublic Setup Pack

This zip contains a **single PowerShell 7 script** that will:
- Create an Idea Card in `docs/idea_cards/`
- Seed a Message Mapper (`/mapper/seed.json`)
- Create a weekly scaffold under `/articles/2025-38/` with `draft.md`, `methods.md`, `mapper.json`, `metrics.csv`
- Push a branch, open a PR, and attempt an **auto-merge (squash)** into `main`

## Prerequisites
- PowerShell 7+ (`pwsh`)
- `git` and GitHub CLI (`gh`) installed
- `gh auth login` completed
- Push rights to the target repo

## Usage
1. Unzip somewhere convenient.
2. Open **PowerShell 7** in that folder.
3. Run:
   ```pwsh
   pwsh -File .\Run-RickPublicSetup.ps1 -Owner rickballard -Repo RickPublic
   ```
   Options:
   - `-NoPR`  → commit & push branch only (no PR)
   - `-NoMerge` → open PR but don’t auto-merge

## What it writes
- `docs/idea_cards/idea_rickpublic_cocivium_messaging_bridge.md`
- `mapper/seed.json`
- `articles/2025-38/draft.md`
- `articles/2025-38/methods.md`
- `articles/2025-38/mapper.json`
- `articles/2025-38/metrics.csv`

All content is baseline-safe and editable post‑merge.
