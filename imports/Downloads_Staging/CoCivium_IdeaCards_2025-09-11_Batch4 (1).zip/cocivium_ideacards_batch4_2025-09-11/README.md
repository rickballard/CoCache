# CoCivium IdeaCards — Batch 4 (2025-09-11)

This batch contains 4 IdeaCards (43–46). Suggested path: `docs/ideas/2025-09-11/batch-4/`.

## Cards
- 43 CoIndex Site Generator — Public Standards & Tools Portal
- 44 ProofPack — One-Click CiviProof Bundles
- 45 CoGuard Rails — Template Guardrails for Protectorates
- 46 CoDialogues — RepTag-Weighted Public Debate Arenas
