# How It Works — Content Template
1) **Publish a brief** (AI-assisted draft → human review).  
2) **Invite a cohort** (contributors join pseudonymously).  
3) **Contribute with PRs** (ScriptTags for automation; RepTags accrue).  
4) **Validate & Demo** (ephemeral links; tester flows).  
5) **Mobilize** (events/schedules/prompts; resources ensure safety & effectiveness).