# Resources — MVP Content
- **Safety Tent Setup**: sourcing list, layout, power, signage, supplies.
- **Event Types:** rallies, sit-ins, town halls, picket lines; permits & liaison tips.
- **Checklists:** pre-event, day-of, post-event debrief.
- **Templates:** posters, press release, incident log, volunteer roles.
- **Ops Guides:** comms trees, marshals, accessibility, de-escalation basics.
*(All can live as Markdown under `/resources/...` and be improved by PRs.)*