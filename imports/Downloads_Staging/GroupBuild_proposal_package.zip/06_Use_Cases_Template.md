# Use Cases — Content Template
- **Local Rally:** organizer toolkit + signup → materials checklist → day-of comms.  
- **Policy Feedback Sprint:** brief → reviewers with RepTags → weighted consensus → publish.  
- **Open-source Patchathon:** AI brief → starter issues → fast demo links → PR merge ceremony.