# Licensing & Governance
- **License:** choose permissive (MIT/Apache-2.0) for website content and code; CC BY for docs if preferred.
- **Contribution:** DCO or CLA policy; emphasize pseudonymous acceptance.
- **Moderation:** code of conduct; safety-first takedown policy for doxxing/harassment.
- **Transparency:** publish a lightweight funding ledger and roadmap cadence.