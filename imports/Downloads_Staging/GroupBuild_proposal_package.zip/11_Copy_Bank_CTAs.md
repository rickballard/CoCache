# CTA Copy Bank
- **Start an aligned build** → onboarding for organizers.
- **Join a cohort** → join contributors, earn reputation.
- **See the demo** → open the sandbox (clearly separate from front-page).
- **Get the safety kit** → resources hub link.
- **Support the mission** → donation slider (placeholder) + ledger page.
- **Contribute on GitHub** → “Fix a typo, save a life” style micro-CTA.
