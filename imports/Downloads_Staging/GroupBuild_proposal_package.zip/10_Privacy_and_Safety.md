# Privacy & Safety
- **No doxxing**: we never ask for PII; pseudonymous-first.
- **Human/bot gate**: questionnaire-style checks and trust growth via contributions.
- **Moderation policy** with clear escalation.
- **Field safety**: de-escalation basics, legal primers (jurisdiction disclaimers).