# Contribute — Content Template
- **Getting Started** (forks, PRs, coding standards).  
- **Issue Labels:** `good-first-issue`, `resources`, `copy`, `design`.  
- **Briefs Board:** open briefs seeking help.  
- **Safety & Conduct:** pseudonymity, non-doxing rules, de-escalation and care.  
- **Discord / Office Hours:** join link and schedule.