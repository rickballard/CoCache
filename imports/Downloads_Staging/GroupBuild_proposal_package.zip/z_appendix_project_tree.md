# Project ZIP Tree

```
/
2025 Project GroupBuild/
  .gitignore
  .~lock.GB_Feature_Proposal_Quiz_v1.odt#
  .~lock.GB_Feature_Req_Quiz_v3.odt#
  Advisory Board Participation Request.doc
  AI-Ethicalized Media.png
  AI_Partnership_Principles.doc
  AI_Types_Mapped_To_Projects_v3.odt
  Amplify_Your_Mission.png
  Anonymous Democracy.png
  Bussines-Politics-Infographics-Nolan-Chart.png
  Call to Shape v1.doc
  Call to Shape v1.odt
  Call to Shape v2.doc
  ChatGPT's Open Ownership Position.odt
  Civil Resilience.png
  Civium Name Proposal v1.odt
  Complete_with_Docusign_Partnership_Agreement.pdf
  Contributor ChatGPT prompt v1.odt
  desktop.ini
  Ensured Connection.png
  Feature Req  - Bluesky.doc
  Feature Req  - Bluesky.odt
  Feature Req - Moderator.doc
  Future_Of_Democracy_Is_Anonymous.png
  GB_Advisory_Board_Call_to_Shape_v2.odt
  GB_BeAxaTorch_On_Old_Glory_Blue.afdesign
  GB_BeAxaTorch_On_Old_Glory_Blue_v1.png
  GB_BeAxaTorch_On_Old_Glory_Blue_v2.png
  GB_BeAxaTorch_On_Old_Glory_Blue_v3.png
  GB_Bot_Reqs.odt
  GB_Boycott_Signup_Mockup_v1.png
  GB_Brand_Style_Guide_Brand_Messaging_Dark.png
  GB_Brand_Style_Guide_Chats_Dark.png
  GB_Brand_Style_Guide_Colors_Icons.png
  GB_Brand_Style_Guide_Dark_Light.png
  GB_Brand_Style_Guide_Event_Layout_Dark.png
  GB_Brand_Style_Guide_Instructions_v1.odt
  GB_Brand_Style_Guide_UI_Components_Dark.png
  GB_Brand_Style_Guide_WebDev_v1.odt
  GB_Brief_Social_Media_Developer.odt
  GB_CEO_Checklist_v3.odt
  GB_ChatGPT_MetaCommit_Artifact.doc
  GB_Conceptual_Architecture.png
  GB_Email_Hosting_Comparison.odt
  GB_Email_Strategy.odt
  GB_Event_Scheduler_Mockup_v1.png
  GB_Feature_Proposal_Quiz_v1.odt
  GB_Feature_Req_Quiz_v3.odt
  GB_Feature_Req_Voting_Design_v1.odt
  GB_Feature_Req_Voting_v1.odt
  GB_Group_Profile_Mockup.png
  GB_Icons.zip
  GB_Icon_Logo_BeAxaTorch.png
  GB_Integration_Req_Revolt_Matrix.odt
  GB_Landing_Graphic_Spec_v2.odt
  GB_Legal_Setup_v1.odt
  GB_Logo_Heads_Torsos.ico
  GB_Logo_Heads_Torsos.png
  GB_Marketing_CompetitiveAnalysis_v2.odt
  GB_Marketing_CompetitiveAnalysis_v3.odt
  GB_Nolan_Chart_Visual_Design_Proposal_v1.odt
  GB_OpenSource_Options.odt
  GB_Partnership_Candidates_v1.odt
  GB_Resources_Page_Mockup_v1.png
  GB_Resources_Page_MVP_Plan_v1.odt
  GB_Resources_Page_MVP_Plan_v5.odt
  GB_Suggested_MVP_APIs_v1.odt
  GB_Swarms_v4.odt
  GB_TechStack.png
  GB_UI_25-05-31.odt
  GB_UI_Design_25-05-31.odt
  GB_UserRoles_DevGuide_v2.odt
  GB_User_Roles_Dev_Guide_v1.odt
  GB_Volunteer_Onboarding_Agreement_v5.odt
  GB_Volunteer_Onboard_Agreement.odt
  GB_Volunteer_Onboard_Agreement_v2.odt
  GB_Volunteer_Onboard_Agreement_v4.odt
  GB_VPN_Popup_Mockup_v1.png
  GB_Workflow_Integrations.odt
  GroupBuild Ideation v3.odp
  GroupBuild Ideation v3.pdf
  GroupBuild Logo v1.odp
  GroupBuild Statrup Ideation v1.odp
  GroupBuild Statrup Ideation v1.pdf
  GroupBuild_Backup_20250820.zip
  GroupBuild_Effort_Log_Template_20250903.csv
  GroupBuild_FeatureRequest_Revolt_Matrix.odt
  GroupBuild_OpenSource_Research_List_WithLinks.odt
  GroupBuild_Pilot_Outreach_and_Trial_Pack_20250903.md
  GroupBuild_Pilot_Signoff_Sheet_20250903.md
  GroupBuild_Pilot_Summary_Plan_and_Deliverables_20250904_152830.md
  GroupBuild_Training_Deck_20250903.md
  Groupbuild_UI_Design_v1.odt
  GroupBuild_Video_Outreach.odt
  LICENSE
  List of Protest Mgmt Platforms v1.doc
  List of Protest Mgmt Platforms v1.odt
  Logo_GroupBuild.png
  Neural.gif
  Open Ownership Postion Paper v1.odt
  Outreach_Target_Suggestions_v1.odt
  Partnership Agreement RB+ES v1.doc
  Partnership Agreement RB+ES v1.odt
  Partnership_Agreement_RB+ES_v1.docx.pdf
  Partnership_Agreement_Summary.pdf
  README.md
  README.txt
  School Options.ods
  Thumbs.db
  Val_Prop_v1.odt
  Vision_And_Contributor_Agreement_v20250514.doc
  2025 Project GroupBuild/.git/
    config
    description
    HEAD
    2025 Project GroupBuild/.git/hooks/
      applypatch-msg.sample
      commit-msg.sample
      fsmonitor-watchman.sample
      post-update.sample
      pre-applypatch.sample
      pre-commit.sample
      pre-merge-commit.sample
      pre-push.sample
      pre-rebase.sample
      pre-receive.sample
      prepare-commit-msg.sample
      push-to-checkout.sample
      sendemail-validate.sample
      update.sample
    2025 Project GroupBuild/.git/info/
      exclude
    2025 Project GroupBuild/.git/objects/
      2025 Project GroupBuild/.git/objects/info/
      2025 Project GroupBuild/.git/objects/pack/
    2025 Project GroupBuild/.git/refs/
      2025 Project GroupBuild/.git/refs/heads/
      2025 Project GroupBuild/.git/refs/tags/
  2025 Project GroupBuild/.github/
    2025 Project GroupBuild/.github/workflows/
      docs.yml
  2025 Project GroupBuild/docs/
    INDEX.md
  2025 Project GroupBuild/GB_Capstone Package/
    GB_Capstone_Brief_v4.odt
    GB_Landing_Page_Spec.odt
    GB_Sample_Design_Work.odt
    GB_Vision_Contributor_Agreement_V4.odt
    GroupBuild_Capstone_Brief.pdf
    GroupBuild_Sample_Design_Landing_Page.pdf
    GroupBuild_Vision_Agreement.pdf
  2025 Project GroupBuild/GB_Hacker Package/
    GitHubPost.txt
    README.txt
    TargetList.txt
  2025 Project GroupBuild/GB_Icons/
    GB_Icon_Accessibility_Body.png
    GB_Icon_Archive_Document.png
    GB_Icon_Broadcast_Megaphone.png
    GB_Icon_Broadcast_MegaphoneFilled.png
    GB_Icon_Collaboration_HandShake1Collar.png
    GB_Icon_Collaboration_HandShake2Collars.png
    GB_Icon_Community_Torsos.png
    GB_Icon_Event_BeAxaHoldTorch.png
    GB_Icon_Event_Fist.png
    GB_Icon_Event_FistPump.png
    GB_Icon_Logo_BeAxaTorch.png
    GB_Icon_Message_BubbleEyeWithin.png
    GB_Icon_Nav_ArrowForward.png
    GB_Icon_Nav_ArrowUpward.png
    GB_Icon_Security_CircleLockTick.png
    GB_Icon_Security_KeyHole.png
    GB_Icon_Security_Lock.png
    GB_Icon_Security_LockTick.png
    GB_Icon_Settings_GearCog.png
    GP_Icon_Message_BubbleEyeOver.png
    Thumbs.db
  2025 Project GroupBuild/GB_vid_shorts/
    GB_We_The_People_Empowered_Cue_Sheet_v3.pdf
    GB_We_The_People_Empowered_StoryBoard.png
    GB_We_The_People_Storyboard.png
    Scene_1.mp3
    Scene_2..mp3
    Scene_3.mp3
    Scene_4.mp3
    Scene_5.mp3
    Scene_6.mp3
    Scene_7.mp3
    Scene_8.mp3
    Thumbs.db
    WeThePeople_Empowered_Runway_Cue_v1.csv
    We_The_People_Empowered_Script_v3.odt
    We_The_People_Empowered_Voice_Over_v1.mp3
    We_The_People_Empowered_Voice_Over_v2.mp3
    We_The_People_Stand_Together_Script.odt
    We_The_People_Stand_Together_Script_Updated.odt
  2025 Project GroupBuild/GB_Volunteer_Prospecting/
    GB_Capstone_Brief_v2.odt
    GB_Capstone_Brief_v3.odt
    GB_Capstone_Email_Template_V1.odt
    GB_Capstone_Outreach_Plan_v1.odt
    Thumbs.db
```

# Sample Snippets

### 2025 Project GroupBuild/desktop.ini
```
[LocalizedFileNames]
Partnership Agreement RB+ES v1.odt=@Partnership Agreement RB+ES v1.odt,0

```

### 2025 Project GroupBuild/GroupBuild_Effort_Log_Template_20250903.csv
```
Date,Event,Role,Person,Planning_Minutes,DayOf_Minutes,AfterAction_Minutes,Notes

```

### 2025 Project GroupBuild/GroupBuild_Pilot_Outreach_and_Trial_Pack_20250903.md
```
# GroupBuild — MVP Pilot Trial & Outreach Pack

**Purpose.** Win a fast, local proof of value for multi‑site actions using GroupBuild’s day‑of ops tools (shift coverage, live headcounts, broadcast with SMS fallback).  Free to the organization during the pilot and will continue free while they are trialing or requesting additional features.  

---

## 1) Why these initial targets
- **CUPE local in active action (Toronto area).** Daily/weekly pickets, multi‑site logistics, safety alerts.  
- **ACORN Canada (Toronto/Hamilton).** Frequent tenant actions, mixed connectivity, need for simple headcounts.  
- **350/Sunrise local hub.** Time‑boxed “days of action,” decentralized sites, legal/safety lanes.  

**Selection logic:** high urgency & frequency ⇒ proof in ≤4 weeks; decentralized ops ⇒ coordination pain; heterogeneous tech ⇒ offline‑tolerant QR + SMS differentiator; small enough to decide fast; non‑rip‑and‑replace (exports coexist with existing stacks).

---

## 2) Pilot objectives (customer sign‑off)
The organization selects 3–5 objectives below.  Success will be judged against the paired KPIs.

1. **Increase turnout reliability.**  
   *KPI:* Show‑up rate delta ≥ **+10–25%** (Checked‑in ÷ Committed vs baseline action).  

2. **Stabilize shift coverage across sites.**  
   *KPI:* Coverage ratio (staffed hours ÷ planned hours) ≥ **95%**; zero “dark” sites.  

3. **Speed up last‑minute change comms.**  
   *KPI:* **≥90%** of targeted volunteers receive alerts within **5 minutes**; **≥60%** acknowledgments within **10 minutes**.  

4. **Improve safety messaging discipline.**  
   *KPI:* At least **1** proactive safety broadcast per action and **100%** site leads acknowledge.  

5. **Capture reliable headcounts.**  
   *KPI:* **≥85%** of on‑site participants recorded (QR or manual), per site and per shift.  

6. **Cut organizer coordination time.**  
   *KPI:* **25–40%** reduction in organizer hours on day‑of coordination vs baseline (self‑reported).  

7. **Data portab
```

### 2025 Project GroupBuild/GroupBuild_Pilot_Signoff_Sheet_20250903.md
```
# GroupBuild Pilot — One‑Page Sign‑Off

**Org:** ________________________________    **Pilot Owner:** ________________________________  
**Phone:** ____________  **Email:** ____________________    **Target action date(s):** ______________

## Objectives (select 3–5)
1 ☐ Increase turnout reliability (+10–25% show‑up delta)  
2 ☐ Stabilize shift coverage (≥95% staffed hours; zero dark sites)  
3 ☐ Faster change comms (≥90% delivery in 5m; ≥60% acks in 10m)  
4 ☐ Safety messaging discipline (≥1 safety broadcast; 100% site‑lead acks)  
5 ☐ Reliable headcounts (≥85% recorded)  
6 ☐ Reduce organizer hours (−25–40% vs baseline)  
7 ☐ Data ownership/portability (export in T+24h; retention ≤30d)

## What we’ll provide
- Console for rosters, headcounts, and broadcasts (with SMS fallback).  
- Printable QR posters; offline cache; CSV/JSON exports.  
- Privacy controls (opt‑in, retention ≤30 days).  

## What you’ll provide
- Site list + site leads; baseline metrics; poster printing; 15‑min readiness check.  
- Day‑of: place posters, 2–4 sweeps per shift, approve/trigger broadcasts.  
- T+24–48h: 15‑min retro; optional case‑study approval.

## Terms
- **Free during pilot and while trialing/requesting features within pilot scope.**  
- **You own your data** (exports on request; default retention ≤30 days).  
- Case study only with your approval; no lock‑in.

**Signature:** _____________________________  **Date:** _____________

```

### 2025 Project GroupBuild/GroupBuild_Pilot_Summary_Plan_and_Deliverables_20250904_152830.md
```

# GroupBuild Pilot — Summary Plan, Strategy & Deliverables (Both Parties)

**Purpose.** Provide a one-page (Discord-ready) summary of the MVP pilot: strategy, scope, objectives/KPIs, timeline, and deliverables for **GroupBuild** and the **Customer**.

---

## 1) Strategy (why this pilot, why now)
- **Wedge:** Day-of operations & resilience (shift coverage, live headcounts, instant alerts with SMS fallback).  
- **Approach:** Run a **2–4 week, no-cost** pilot tied to one real action day; coexist with current stack (CSV/JSON exports).  
- **Targets:** A union local in active action (e.g., CUPE), ACORN chapter, or climate hub (350/Sunrise) to get frequent reps and fast proof.  
- **Promise:** Measurable lift in turnout reliability, coverage, and coordination efficiency without rip-and-replace.

---

## 2) Scope (what’s in / out)
**In:** Shift signup/handoff · On-site headcounts (QR + manual, offline cache) · Broadcast lanes (All-Hands, Safety/Legal, Per-Site) with SMS fallback · CSV/JSON export · Privacy/retention controls (≤30 days by default).  
**Out for now:** Long-term CRM/list mgmt, donations/petitions, deep VAN write-back, advanced rideshare (post-pilot candidates).

---

## 3) Objectives & KPIs (customer selects 3–5 to sign off)
| Objective | KPI (Target) |
|---|---|
| Increase turnout reliability | **+10–25%** show-up delta (Checked-in/Committed vs baseline) |
| Stabilize shift coverage | **≥95%** staffed hours; **0** “dark” sites |
| Faster last-minute comms | **≥90%** delivery in **5m**; **≥60%** acknowledgments in **10m** |
| Safety messaging discipline | ≥**1** safety broadcast; **100%** site-lead acknowledgments |
| Reliable headcounts | **≥85%** participants recorded (QR or manual) |
| Reduce organizer hours | **−25–40%** day-of coordination time vs baseline |
| Data ownership & portability | Export delivered **T+24h**; retention **≤30d**; **0** unresolved issues |

**Baseline:** last comparable action (or 4-week average).

---

## 4) Timeline & milesto
```

### 2025 Project GroupBuild/GroupBuild_Training_Deck_20250903.md
```
# GroupBuild Training Deck (Facilitator Notes)

> 12–15 minutes.  Keep it moving.  Volunteers only need QR + SMS basics.

---
## Slide 1 — Welcome & the 2‑minute promise
- What you’ll get today: faster turnout, safer shifts, less organizer thrash.  
- Pilot is free; you keep your data; no lock‑in.

---
## Slide 2 — Today’s pain
- Missed shifts, unknown headcounts, slow last‑minute changes.  
- Mixed devices/connectivity → need offline + SMS fallback.

---
## Slide 3 — What GroupBuild covers (pilot scope)
- Shift signup/handoff.  
- On‑site headcounts (QR + manual fallback).  
- Broadcast lanes (All‑Hands, Safety/Legal, Per‑Site) with SMS fallback.

---
## Slide 4 — Roles
- **Pilot Owner:** approves messages, watches dashboard, 10–20 min day‑of.  
- **Site Leads:** place posters; 2–4 sweeps/shift; acknowledge broadcasts.  
- **Volunteers:** scan once; opt‑in to SMS (optional).

---
## Slide 5 — Poster + QR flow
- Place at entrance/gather points.  
- Volunteers scan; offline cache works if data is weak.  
- Manual check‑in if needed.

---
## Slide 6 — Broadcast lanes
- **All‑Hands:** schedule, general updates.  
- **Safety/Legal:** route/weather/legal—acks required.  
- **Per‑Site:** fill gaps, shift handoffs.

---
## Slide 7 — Offline + SMS fallback
- Check‑ins cache and sync later.  
- Broadcasts fall back to SMS (opt‑in).

---
## Slide 8 — Privacy & retention
- Minimal data.  Opt‑in.  Export on request.  Auto‑purge ≤30 days.

---
## Slide 9 — Day‑of checklist
- T‑60m test ping; posters up; first sweep T‑15m.  
- Watch coverage alerts; trigger safety lane if needed.

---
## Slide 10 — After‑action & metrics
- Export CSV/JSON; 15‑min retro.  
- KPIs: show‑up delta, coverage, acks, headcount completeness, organizer hours.

**Q&A (10 minutes).**

```

### 2025 Project GroupBuild/README.md
```
﻿# 2025-Project-GroupBuild

Short description here. Goals, audience, quickstart.

## Quickstart
\\\ash
git clone <this-repo>
\\\

## Documentation
- See [/docs](./docs) for guides and references.

---
Canonicality: Working Draft (0.6)
Last-Reviewed-UTC: 2025-09-11T05:19:17Z
Notes: This doc may change; PRs welcome.
```

### 2025 Project GroupBuild/README.txt
```

# GroupBuild Icon Bundle

This bundle contains 20 finalized red-shield, blue-symbol icons for use as bullet-style content markers across the GroupBuild website.

## Contents
- 20 PNG icon files (transparent backgrounds, enhanced contrast, black outlines)
- CSS snippets for hover effects
- README documentation (this file)

## Usage Instructions
1. Place icons in a web-accessible folder (e.g., `/assets/icons/`).
2. Reference each image in your HTML using <img> tags or as CSS backgrounds.
3. Include the sample CSS to create visual hover effects.

## Example HTML Usage
```html
<img class="gb-icon gb-icon-empowerment" src="/assets/icons/GB_Icon_Empowerment_Fist.png" alt="Empowerment">
```

## Example CSS Snippets
```css
.gb-icon {
  width: 48px;
  height: 48px;
  transition: transform 0.2s ease-in-out, box-shadow 0.2s;
}

.gb-icon:hover {
  transform: scale(1.1);
  box-shadow: 0 0 12px rgba(255, 50, 50, 0.7);
}

.gb-icon-empowerment:hover {
  animation: pulse 1s infinite alternate;
}

@keyframes pulse {
  from { transform: scale(1); }
  to { transform: scale(1.2); }
}
```

## Tips for Developers
- Adjust `transform` or `filter` to suit dark/light themes.
- Embed additional effects using SVG versions if needed.
- Maintain filename consistency for reuse in content databases.

---

Created by ChatGPT in collaboration with RickBall.

```

### 2025 Project GroupBuild/.github/workflows/docs.yml
```
﻿name: docs-ci
on:
  push: { paths: ['**.md'] }
  pull_request: { paths: ['**.md'] }
jobs:
  linkcheck:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Basic link check
        run: |
          grep -RhoE '\(https?://[^ )]+?\)' --include='*.md' || true
          echo 'OK'
```

### 2025 Project GroupBuild/docs/INDEX.md
```
﻿# Docs INDEX

---
Canonicality: Working Draft (0.6)
Last-Reviewed-UTC: 2025-09-11T05:19:17Z
Notes: This doc may change; PRs welcome.
```

### 2025 Project GroupBuild/GB_Hacker Package/GitHubPost.txt
```
GitHubPost.txt — Public Call for Contributors to GroupBuild

Title: Build Democracy’s Immune System: Join GroupBuild

---

We're building GroupBuild — a decentralized, open-source platform to help communities self-organize in defence of Democracy, dignity, and digital privacy.

Think of it as a secure civic stack for protests, petitions, whistleblower protection, and cooperative governance. Anonymous but accountable. Designed for resilience. Built by and for people who still give a damn.

We need your help if you care about:
- Building tech that can’t be hijacked by billionaires or regimes
- Enabling secure protest coordination outside mainstream platforms
- Designing tools that actually protect user anonymity while enabling trust
- Resisting mass manipulation and preserving democratic agency

GroupBuild is open-source, non-commercial, and mission-aligned. No VC. No extraction. Just tools that fight for the people who use them.

We're calling developers, designers, and privacy-aware engineers who want to work on something meaningful. Whether you're a civic hacker, system architect, or crypto-anarchist tinkerer—we want you.

🔒 Join pseudonymously. Contribute how you like. All skill levels welcome.

📎 See full technical overview and contribution paths in README.txt.

Questions? Want to lurk first? Email us: rick@groupbuild.org

Together, let’s give the next generation tools to fight back.

---
```

### 2025 Project GroupBuild/GB_Hacker Package/README.txt
```
README.txt — Technical Overview for GroupBuild Contributors

---

Welcome to the GroupBuild project.

This is a civic tech platform designed to help communities self-organize, resist manipulation, and coordinate public action securely.

🔧 Tech Goals
- Accountable anonymity (via pseudonymous IDs + trust tagging)
- Encrypted group coordination (e.g. event planning, voting)
- Ethical AI moderation (BeAxa stack: flagging, context scoring)
- Decentralized and federated design (resilience first)
- Interoperable with Matrix, ActivityPub, and privacy-first tools

🧱 Stack (MVP phase)
- Frontend: React / TypeScript (Alt: Svelte welcome)
- Backend: Node.js or Rust (open to Go)
- Auth: Temporary IDs, optional zk-SNARKs for pseudonym proofs
- Storage: IPFS, Postgres, or hybrid (negotiable)
- AI moderation: OpenAI APIs + shadow-model cross-checking
- Deployment: Docker / DigitalOcean / Self-hosted

📌 Contributions Wanted
- UI/UX engineers for protest/event builder and anonymous chat
- Backend devs for pseudonymous identity and voting system
- Security experts for trust scoring, zero-knowledge proofs
- Ethical AI engineers for moderation logic and fallback alerts
- DevOps for lightweight hosting, network self-replication

🚩 How to Join
1. Fork this repo and clone it locally.
2. Check out issues/ for "good first task" labels.
3. Join our secure Matrix or Signal group (invite on request).
4. Use a pseudonym or handle if preferred. We respect privacy.

📬 Contact
- Rick (Co-Founder, Ops/Marketing) — email at rick@groupbuild.org
- Elias (Co-Founder, Dev Coordinator) — [contact info pending secure contact setup]

We’re here to build something bigger than an app. This is infrastructure for the people.

---
```

### 2025 Project GroupBuild/GB_Hacker Package/TargetList.txt
```
TargetList.txt — Tag and Contact Targets for GroupBuild Dev Recruitment

---

🌐 Fediverse / Mastodon
- @democracylab@mastodon.social
- @fosstodon.org (tag #opensource, #privacy, #activism)
- @privacyguides@fosstodon.org
- @radicalxchange@social.coop

🧵 Reddit
- r/privacy
- r/opensource
- r/civictech
- r/anarchism
- r/foss

🗳️ Democracy + Civic Tech Orgs
- DemocracyLab (GitHub and website contact)
- Code for America (GitHub and Slack/Brigade leaders)
- Open Source Design (opensourcedesign.net)
- RadicalxChange Foundation (info@radicalxchange.org)

💬 Matrix / Chatrooms
- #privacy:matrix.org
- #civictech:matrix.org
- @privacyguides:matrix.org
- #fediverse-dev:matrix.org

🔐 Individual Contacts
- Maintainers at Open Source Design
- Hosts of “Tech Won’t Save Us” and “RadicalxChange” podcasts
- Past collaborators from CivicTech Toronto, NYC, or Vancouver
- Known devs or security folks from IFF, CCA, or TAILS OS contributors (via secure DM)

🔁 Crossposts / Channels
- Lemmy: c/digitaldemocracy, c/opensource, c/privacy
- Gitcoin “Public Goods” channel
- Open Source Collective Discord
- Twitter/X fallback (only as redirect to Mastodon or GitHub)

---

Please use discretion and adapt tone per community culture.
Avoid spam. Focus on shared values and invite participation, not just labor.
```

### 2025 Project GroupBuild/GB_vid_shorts/WeThePeople_Empowered_Runway_Cue_v1.csv
```
Scene,Timestamp Start,Timestamp End,Script Line,Emotion,Prompt
1,00:00,00:07,"People disappear in broad daylight. As we watch on our screens. And do, nothing.",Uneasy / Dread,"Urban protest scene with riot police dragging a person across a broken protest sign. Onlookers frozen, filming with phones, children's faces in shock. Moody lighting, gritty realism."
2,00:07,00:14,"We call ourselves free. We teach children to be kind. Yet we scroll past in silence. And pretend, it's normal.",Guilt / Numb,"Montage of news clips and social media feeds showing civil unrest, an angry child with a protest sign, fading into a man scrolling emotionlessly on his phone. Muted color palette, newsprint overlay style."
3,00:14,00:23,"Democracies fade away in silence. One right, one freedom at a time. Until all that remains is fear.  Regret.  Shame.",Grave / Reflective,Flickering candlelight fading into darkening courtroom and voting booth. Silhouettes watching in silence. Visual decay effect to black and white across frames.
4,00:23,00:30,But. We The People.  We are many. They are few. And Democracy. It isn't what we watch. It's what we build.,Hopeful / Empowered,"Rising shot of citizens gathering in sunny public town center, overlay of a digital map glowing with pins, close-up of hands creating protest signs, young people painting murals of people."
5,00:30,00:31,GroupBuild doesn't serve the system. It rewrites it. ,Resolved / Strategic,"Stylized overlay of the GroupBuild UI showing pins dropping on a map, chat interface opening, and event scheduling. Futuristic tech overlays with activist energy."
6,00:31,00:45,Find your people. Feel their power. Feel yours. Map. Meet. Move.  ,Warm / Mobilizing,"Faces light up as people find nearby supporters on screen, hug in person, march together in unity. Emotive camera pans, diverse ages and backgrounds."
7,00:45,00:54,No kings. No scapegoats. Just us.,Determined / Unifying,"Montage of grassroots organizations, no single leader. Groups forming cir
```
