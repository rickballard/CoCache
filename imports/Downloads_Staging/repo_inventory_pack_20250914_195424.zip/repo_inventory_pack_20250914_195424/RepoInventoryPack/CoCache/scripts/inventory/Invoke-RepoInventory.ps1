<#
.SYNOPSIS
  Scans repos under $Root for scripts and doc assets. Emits per-repo manifests and a CoCache master rollup.
  Safe for unattended runs; commits only changed files (unless -NoGit).

.PARAMETER Root
  Parent folder containing your GitHub repos (default: "$HOME\Documents\GitHub").

.PARAMETER NoGit
  If set, do not commit/push changes.

.PARAMETER Repos
  Optional list of repo names to restrict the scan.

.NOTES
  Spec: cocivium.ai/repo-inventory/v1
#>
[CmdletBinding()]
param(
  [string]$Root = (Join-Path $HOME 'Documents\GitHub'),
  [switch]$NoGit,
  [string[]]$Repos
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ===== Helpers =====
function New-Utf8File([string]$Path,[string]$Text){
  [IO.Directory]::CreateDirectory( (Split-Path $Path -Parent) ) | Out-Null
  $utf8 = [Text.UTF8Encoding]::new($false)
  [IO.File]::WriteAllText($Path,$Text,$utf8)
}
function Get-RepoList([string]$Root,[string[]]$Only){
  $dirs = Get-ChildItem $Root -Directory -ErrorAction SilentlyContinue
  if($Only -and $Only.Count){ $dirs = $dirs | Where-Object { $Only -contains $_.Name } }
  return $dirs | Sort-Object Name
}
function Is-TextFile([IO.FileInfo]$f){
  $ext = [IO.Path]::GetExtension($f.FullName).ToLowerInvariant()
  if ($ext -in ('.png','.jpg','.jpeg','.gif','.pdf','.ico','.zip','.7z','.rar','.gz','.bz2','.xz','.exe','.dll','.pdb','.ttf','.woff','.woff2','.mp4','.mov','.mp3','.wav','.ogg','.webm')) { return $false }
  return $true
}
function Find-References([string]$repoPath,[IO.FileInfo]$file){
  # Heuristic: search for filename (with extension) across text files in repo.
  $name = $file.Name
  $hits = 0
  $textFiles = Get-ChildItem $repoPath -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.FullName -ne $file.FullName -and (Is-TextFile $_) }
  foreach($tf in $textFiles){
    try{
      if( Select-String -Path $tf.FullName -SimpleMatch -Quiet -Pattern $name ){ $hits++; if($hits -gt 3){ break } }
    }catch{}
  }
  return $hits
}

# ===== Classifiers =====
$ScriptExts = @('.ps1','.psm1','.psd1','.ps1xml','.bat','.cmd','.sh','.bash','.zsh','.py','.js','.mjs','.ts','.rb','.go','.sql','.psql','.kql','.lua','.pl','.r','.ps','.yml','.yaml','.json')
$DocExts    = @('.md','.mdx','.markdown','.txt','.mmd','.mermaid','.plantuml','.csv','.yml','.yaml','.json')

$nowZ = (Get-Date).ToUniversalTime().ToString("yyyy-MM-dd'T'HH:mm:ss'Z'")
$coCache = Join-Path $Root 'CoCache'
$rollupDir = Join-Path $coCache 'ai\inventory'
[IO.Directory]::CreateDirectory($rollupDir) | Out-Null

$repos = Get-RepoList -Root $Root -Only $Repos

$roll = @()
foreach($d in $repos){
  $repoName = $d.Name
  $repoPath = $d.FullName
  $hasGit   = Test-Path (Join-Path $repoPath '.git')

  $files = Get-ChildItem $repoPath -Recurse -File -ErrorAction SilentlyContinue

  $scripts = @()
  $assets  = @()
  foreach($f in $files){
    $ext = [IO.Path]::GetExtension($f.FullName).ToLowerInvariant()
    $rel = $f.FullName.Substring($repoPath.Length).TrimStart('\')
    $isDeprecated = $f.FullName -match '(\\|/)(deprecated|DEPRECATED|obsolete)(\\|/)'
    $text = $null
    $flags = @{ deprecated=$isDeprecated; todo=$false; fixme=$false; wip=$false; orphanedCandidate=$false }
    $size = $f.Length
    $updated = $f.LastWriteTimeUtc.ToString("yyyy-MM-dd'T'HH:mm:ss'Z'")

    if ($ext -in $ScriptExts){
      # light content scan for TODO/FIXME/WIP
      try{
        $text = Get-Content $f.FullName -Raw -ErrorAction Stop
        if($text -match '(?i)\bTODO\b'){ $flags.todo = $true }
        if($text -match '(?i)\bFIXME\b'){ $flags.fixme = $true }
        if($text -match '(?i)\bWIP\b'){ $flags.wip = $true }
      }catch{}
      # orphaned heuristic: not referenced elsewhere by name
      $refs = Find-References -repoPath $repoPath -file $f
      if($refs -eq 0){ $flags.orphanedCandidate = $true }
      $scripts += [pscustomobject]@{ path=$rel; size=$size; updated=$updated; flags=$flags }
    }
    elseif ($ext -in $DocExts){
      if(-not $text){
        try{ $text = Get-Content $f.FullName -Raw -ErrorAction Stop }catch{}
      }
      $todo = $false
      $wip  = $false
      if($text){
        if($text -match '(?i)\bTODO\b'){ $todo=$true }
        if($text -match '(?i)\bWIP\b'){ $wip=$true }
      }
      $assets += [pscustomobject]@{ path=$rel; size=$size; updated=$updated; flags=@{ deprecated=$isDeprecated; todo=$todo; wip=$wip } }
    }
  }

  $manifest = [ordered]@{
    spec    = 'cocivium.ai/repo-inventory/v1'
    scanned = $nowZ
    repo    = $repoName
    root    = $repoPath
    counts  = @{
      scripts = $scripts.Count
      assets  = $assets.Count
      suspect = @{
        orphanedCandidates = (@($scripts | Where-Object { $_.flags.orphanedCandidate })).Count
        deprecated         = (@($scripts + $assets | Where-Object { $_.flags.deprecated })).Count
        todos              = (@($scripts + $assets | Where-Object { $_.flags.todo })).Count
        wips               = (@($scripts + $assets | Where-Object { $_.flags.wip })).Count
      }
    }
    scripts = $scripts
    assets  = $assets
  }

  # Write per-repo outputs
  $invDir = Join-Path $repoPath 'ai\inventory'
  $humDir = Join-Path $repoPath 'docs\status'
  [IO.Directory]::CreateDirectory($invDir) | Out-Null
  [IO.Directory]::CreateDirectory($humDir) | Out-Null
  New-Utf8File (Join-Path $invDir 'INVENTORY.json') (($manifest | ConvertTo-Json -Depth 6))
  # Human summary
  $md = @()
  $md += "# Repo Inventory — $repoName"
  $md += ""
  $md += "_Scanned $nowZ_"
  $md += ""
  $md += "- Scripts: **$($scripts.Count)**  · Assets: **$($assets.Count)**"
  $md += "- Suspect — Orphaned: **$($manifest.counts.suspect.orphanedCandidates)** · Deprecated flags: **$($manifest.counts.suspect.deprecated)** · TODOs: **$($manifest.counts.suspect.todos)** · WIPs: **$($manifest.counts.suspect.wips)**"
  $md += ""
  if($scripts.Count){
    $md += "## Scripts (top 20 by recency)"
    $md += ""
    $md += "| Path | Updated (UTC) | Flags |"
    $md += "|---|---|---|"
    foreach($s in ($scripts | Sort-Object updated -Descending | Select-Object -First 20)){
      $flagStr = @()
      foreach($k in $s.flags.Keys){ if($s.flags[$k]){ $flagStr += $k } }
      $md += ("| `{0}` | {1} | {2} |" -f $s.path,$s.updated,($(if($flagStr){ $flagStr -join ',' } else { '' })))
    }
    $md += ""
  }
  if($assets.Count){
    $md += "## Assets (top 20 by recency)"
    $md += ""
    $md += "| Path | Updated (UTC) | Flags |"
    $md += "|---|---|---|"
    foreach($a in ($assets | Sort-Object updated -Descending | Select-Object -First 20)){
      $flagStr = @()
      foreach($k in $a.flags.Keys){ if($a.flags[$k]){ $flagStr += $k } }
      $md += ("| `{0}` | {1} | {2} |" -f $a.path,$a.updated,($(if($flagStr){ $flagStr -join ',' } else { '' })))
    }
    $md += ""
  }
  New-Utf8File (Join-Path $humDir 'INVENTORY.md') (($md -join "`n") + "`n")

  # Optional commit per repo
  if(-not $NoGit -and $hasGit){
    Push-Location $repoPath
    try{
      git add ai/inventory/INVENTORY.json docs/status/INVENTORY.md *> $null
      $dirty = (git status --porcelain) 2>$null
      if($dirty){
        git commit -m "ai(inventory): refresh repo inventory (auto)" *> $null
        git push *> $null
      }
    } catch {} finally {
      Pop-Location
    }
  }

  # Capture summary for rollup
  $roll += [pscustomobject]@{
    repo=$repoName; scripts=$scripts.Count; assets=$assets.Count;
    orphaned=$manifest.counts.suspect.orphanedCandidates; deprecated=$manifest.counts.suspect.deprecated;
    todos=$manifest.counts.suspect.todos; wips=$manifest.counts.suspect.wips
  }

  # Also mirror machine json into CoCache rollup for one-stop scrape
  New-Utf8File (Join-Path $rollupDir ("{0}.json" -f $repoName)) (($manifest | ConvertTo-Json -Depth 6))
}

# Write rollup files in CoCache
$rollup = [ordered]@{ spec='cocivium.ai/repo-inventory-rollup/v1'; scanned=$nowZ; repos=$roll | Sort-Object repo }
New-Utf8File (Join-Path $rollupDir 'ROLLUP.json') (($rollup | ConvertTo-Json -Depth 6))

$md2 = @()
$md2 += "# CoCache — Repo Inventory Rollup"
$md2 += ""
$md2 += "_Scanned $nowZ_"
$md2 += ""
$md2 += "| Repo | Scripts | Assets | Orphaned? | Deprecated? | TODOs | WIPs |"
$md2 += "|---|---:|---:|---:|---:|---:|---:|"
foreach($r in ($roll | Sort-Object repo)){
  $md2 += ("| {0} | {1} | {2} | {3} | {4} | {5} | {6} |" -f $r.repo,$r.scripts,$r.assets,$r.orphaned,$r.deprecated,$r.todos,$r.wips)
}
New-Utf8File (Join-Path $coCache 'docs\status\REPO-INVENTORY.md') (($md2 -join "`n") + "`n")

# Commit rollup in CoCache
if(-not $NoGit -and (Test-Path (Join-Path $coCache '.git'))){
  Push-Location $coCache
  try{
    git add ai/inventory/*.json docs/status/REPO-INVENTORY.md *> $null
    $dirty = (git status --porcelain) 2>$null
    if($dirty){
      git commit -m "ai(inventory): refresh master rollup (auto)" *> $null
      git push *> $null
    }
  } catch {} finally {
    Pop-Location
  }
}

Write-Host "✅ Repo inventory complete. Per-repo: ai/inventory/INVENTORY.json · docs/status/INVENTORY.md. Rollup: CoCache/ai/inventory/ROLLUP.json"
