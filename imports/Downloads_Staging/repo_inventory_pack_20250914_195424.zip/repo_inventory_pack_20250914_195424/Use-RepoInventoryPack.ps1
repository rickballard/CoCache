# Use-RepoInventoryPack.ps1 — installs/updates CoCache crawlers, runs a first scan, and schedules refreshes.
param(
  [string]$Root = (Join-Path $HOME 'Documents\GitHub'),
  [switch]$NoGit
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# 0) Locate CoCache + latest pack zip (or current folder if unpacked)
$coCache   = Join-Path $Root 'CoCache'
$downloads = Join-Path $HOME 'Downloads'
$latestZip = Get-ChildItem $downloads -Filter 'repo_inventory_pack_*.zip' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Desc | Select-Object -First 1
if(-not $latestZip){
  # also check Downloads\CoTemp\Drops
  $drops = Join-Path (Join-Path $HOME 'Downloads\CoTemp') 'Drops'
  $latestZip = Get-ChildItem $drops -Filter 'repo_inventory_pack_*.zip' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Desc | Select-Object -First 1
}
if(-not $latestZip){ throw "RepoInventory pack zip not found in Downloads or CoTemp\Drops." }

# 1) Expand to temp and copy into CoCache/scripts
$stage = Join-Path $env:TEMP ("RepoInventory_" + (Get-Date -Format 'yyyyMMdd_HHmmss'))
Expand-Archive -Path $latestZip.FullName -DestinationPath $stage -Force
$src = Join-Path $stage 'RepoInventoryPack\CoCache\scripts\inventory'
$dst = Join-Path $coCache 'scripts\inventory'
[IO.Directory]::CreateDirectory($dst) | Out-Null
Copy-Item (Join-Path $src '*') $dst -Recurse -Force

# 2) Run first scan now
$inv = Join-Path $dst 'Invoke-RepoInventory.ps1'
Write-Host "▶ Running initial inventory..." -ForegroundColor Cyan
& pwsh -NoProfile -ExecutionPolicy Bypass -File $inv -Root $Root @($NoGit ? @('-NoGit') : @())

# 3) Schedule periodic refresh (every 3 hours) + at startup
try{
  Import-Module ScheduledTasks -ErrorAction Stop
  $pwsh = (Get-Command pwsh).Source
  $action = New-ScheduledTaskAction -Execute $pwsh -Argument ('-NoLogo -NoProfile -ExecutionPolicy Bypass -File "' + $inv + '" -Root "'+$Root+'"')
  $t1 = New-ScheduledTaskTrigger -AtStartup
  $t2 = New-ScheduledTaskTrigger -Once (Get-Date).AddMinutes(10) -RepetitionInterval (New-TimeSpan -Hours 3) -RepetitionDuration ([TimeSpan]::FromDays(3650))
  Register-ScheduledTask -TaskName 'CoRepoInventory' -Action $action -Trigger @($t1,$t2) -Force | Out-Null
  Write-Host "🕑 Scheduled task 'CoRepoInventory' (startup + every 3h)." -ForegroundColor Green
}catch{
  Write-Warning "Could not register scheduled task (permissions?). You can run: pwsh -NoProfile -ExecutionPolicy Bypass -File `"$inv`""
}

# 4) Commit the scripts themselves to CoCache (optional)
if(-not $NoGit -and (Test-Path (Join-Path $coCache '.git'))){
  Push-Location $coCache
  try{
    git add scripts/inventory/Invoke-RepoInventory.ps1 *> $null
    $dirty = (git status --porcelain) 2>$null
    if($dirty){ git commit -m "ops(inventory): add/update repo inventory crawler" *> $null; git push *> $null }
  } catch {} finally { Pop-Location }
}

Write-Host "✅ RepoInventory pack installed. Scripts at: $dst"
