# UX Flow (First-Time User)

1. **Landing:** “Map your world” CTA. Short explainer.
2. **Editor:** Sliders per metric; live radar updates (smooth animation).
3. **Compare:** Toggle overlays: CoCivium Ideal, Federation, Empire, Nordics, USA.
4. **Explain:** Hover a vertex to read metric definition and “how to improve” tips.
5. **Export/Share:** PNG, JSON, Embed. Auto-watermark + link-back.
6. **(Optional) Publish:** Post to gallery; receive a shareable link + RepTag hook.
