# Roadmap Notes

- **Sprint 1**: Implement editor + radar render + export (PNG/JSON/embed).
- **Sprint 2**: Templates + comparisons; watermarking; basic docs.
- **Sprint 3**: PWA packaging; optional lightweight backend; public demo.
- **Phase 2**: Gallery, AI suggestions, leaderboards, RepTag integration.
