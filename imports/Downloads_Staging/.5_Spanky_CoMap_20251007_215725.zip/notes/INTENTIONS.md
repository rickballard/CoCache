# Intentions

- Build **CoMap** MVP (editor, sliders, overlays, export). *(Unfinished)*
- Draft **metrics schema** and **methodology**; align to CoCore/CoNeura. *(In progress)*
- Prepare **templates** for fictional + real-world models. *(In progress)*
- Implement **gallery** + **AI suggest** features. *(Unfinished)*
- Package as **downloadable app** with simple backend. *(Unfinished)*
- Stage as **CoModule**; evaluate promotion to standalone repo post-MVP. *(Unfinished)*
