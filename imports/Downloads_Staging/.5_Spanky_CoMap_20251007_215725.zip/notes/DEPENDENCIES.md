# Dependencies

- CoCore / CoNeura vocab for domain alignment.
- CoCache / CoWrap processes for memory + provenance.
- Optional: RepTag/MeritRank for gallery identity hooks (future).
