# Glossary

- **CoMap:** Top-level governance radar map product.
- **CoModule:** Pluggable module staged within CoCivium before standalone.
- **CoCore/CoNeura:** Core model repositories and domain taxonomy.
- **CoWrap:** Zipped session deliverable with manifest + out.txt + provenance.
