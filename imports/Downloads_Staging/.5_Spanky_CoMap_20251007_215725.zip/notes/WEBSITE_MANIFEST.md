# Website Manifest (This Session)

This session did **not** produce live website assets; intent concerns a product plan and repo scaffolding. 
If integrating with CoCivium.org later, ensure:
- Landing page hero CTA (“Map your world”).
- Embedded widget demo with **CoMap**.
- Docs links to methodology and sources.
