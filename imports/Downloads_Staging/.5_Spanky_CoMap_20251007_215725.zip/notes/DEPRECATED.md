# Deprecated / Parked

- None explicitly deprecated; “gallery” and “AI copilot” features deferred to post‑MVP.
