# Risks

- **Metric bias** or perceived coercion → Mitigate via transparency, sources, rebuttals.
- **Data freshness** for real-world models → add timestamps and citations workflow.
- **Scope creep** (gallery, AI) → Tame with staged roadmap and feature flags.
