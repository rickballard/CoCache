Write-Host 'Loaded CoWrap v3.1 for CoPolitic → TOS-AI' -ForegroundColor Cyan
Write-Host 'See CoWrap.md, ACTIONS.md, MANIFEST.json, snapshot/, logos/, scripts/, .github/' -ForegroundColor Cyan
