# CoAgent Advice: Graphics Tooling Fallbacks

- Do not prompt users to install inkscape automatically.
- Prefer CI renders (see `.github/workflows/render-assets.yml`).
- Local pre-commit renders are non-blocking and only run when inkscape exists.
- Provide `tools/SafeInstall-Inkscape.ps1` for voluntary install, and `-Uninstall` to remove.
- Respect `CORENDER_STRICT=1` when a developer wants enforcement locally.
