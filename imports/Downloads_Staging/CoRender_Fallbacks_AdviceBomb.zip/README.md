# Graphics Tooling Fallbacks — Advice Bomb (CoRender)

Purpose: Make SVG/PNG asset workflows safe for users without Inkscape.
- Source of truth is SVG.
- Local renders are optional and non-blocking.
- CI (GitHub Actions) performs authoritative PNG exports with Inkscape.
- Shared pre-commit hook skips renders if tools are missing.
- Optional one-shot installers are provided but never auto-run.

Repos: CoAgent (advice + tooling), CoCivium (CI + hooks), others can adopt.
