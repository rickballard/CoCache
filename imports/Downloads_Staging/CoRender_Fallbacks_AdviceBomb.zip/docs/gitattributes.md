Add to the repo root as .gitattributes:

* text=auto
*.ps1 text eol=lf
*.md  text eol=lf
*.svg text eol=lf
*.png binary
*.jpg binary
