# README_FOR_AI.md

This repo is used by humans and GPT‑5 together.  

Follow `/admin/Intersessional_Profile.md` for rules, filenames, and session rituals.  

At session start, paste `/admin/Session_Starter_Prompt.md` into GPT‑5.  
At session end, update `/admin/Last_Session_Context.md` using `/admin/End_of_Session_Template.md`.  

If a file seems duplicated, prefer the **better** version over the **newer** one.  
Preserve good content; don’t silently delete.  
