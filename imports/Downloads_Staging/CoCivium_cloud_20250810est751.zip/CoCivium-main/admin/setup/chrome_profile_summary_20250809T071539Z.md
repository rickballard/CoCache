﻿# Chrome Profile Summary (20250809T071539Z)

## Core

* Profile: **Default**
* Homepage: **** (is_newtab=)
* Restore on startup: ****
* Bookmark bar visible: **True**
* Search provider: **** - 

## Flags
_None_

## Extensions (enabled state)

| Name | Version | Enabled | ID | Store |
|------|---------|---------|----|-------|
