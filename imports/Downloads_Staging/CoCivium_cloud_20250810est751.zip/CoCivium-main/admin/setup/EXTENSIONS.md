# Enabled Chrome extensions (Default)

- Chrome PDF Viewer — `mhjfbmdgcfjbbpaeojofohoefgiehjai`
- Google Hangouts — `nkeimhogjdpnpccoofpliimaahmaaome`
- Google Network Speech — `neajdppkdcdipfabeoofebfddakdcjhd`
- Web Store — `ahfgeienlihckogmohjhadlkjgocpleb`
