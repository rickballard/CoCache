# CoAgent — TRAINING (Elias Onboarding)

Run:

```powershell
pwsh -File tools\Run-Training.ps1
```
