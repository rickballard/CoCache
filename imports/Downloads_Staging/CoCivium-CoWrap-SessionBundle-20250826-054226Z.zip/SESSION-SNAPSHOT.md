# Session Snapshot (errors & open items)

## Notable errors we saw
- **Invalid Base64** when trying to write a bootstrap script: likely caused by invisible line breaks / wrapped text.
- **PowerShell continuation prompt `>>`** after pasting multi-line blocks that PowerShell thought were incomplete.
- **Markdown/YAML pasted into the shell**: e.g., badges/issue templates caused `ParserError` (“Missing type name after '['”, `name:` not recognized).
- **.gitattributes error**: `text*.md is not a valid attribute name: .gitattributes:13` (a malformed line like `text*.md ...`).

## Open items
- Ensure `.gitattributes` is clean and normalized (LF).
- Make IssueOps buttons available in the GitHub UI (not in the shell).
- Optionally open a docs PR from the branch `docs/repo-map-workflows-250826-0025Z`.

See `NEXT-STEPS.md` for the safe sequence.
