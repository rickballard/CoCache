# Next Steps (safe, minimal)

1. **Unzip this bundle at your repo root** (it creates `.github/`, `docs/`, `tools/` etc.).
2. **Commit & push** the added files:
   ```powershell
   git add .
   git commit -m "chore: add IssueOps + CoWrap capsule + LF rules"
   git push
   ```
3. In GitHub UI, open **docs/ISSUEOPS.md** and click the badge:
   - _Run safe bootstrap_ → ensures QUICK-NAV + docs placeholders and opens a PR via automation.
   - _Fix .gitattributes (LF)_ → corrects malformed rules and normalizes endings.
4. Review the PR, squash & merge, delete the branch when merged.

From now on, prefer these **buttons** or the reusable **tools/safe-bootstrap.ps1** over pasting large shell snippets.
