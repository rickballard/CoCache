# IssueOps

Click a button to run a safe, automated maintenance action (opens a prefilled **GitHub Issue**):

[![Run safe bootstrap](https://img.shields.io/badge/Run-safe--bootstrap-blue)](https://github.com/rickballard/CoCivium/issues/new?template=run-safe-bootstrap.yml&labels=issueops,op:safe-bootstrap&title=Run+safe+bootstrap)
[![Fix .gitattributes (LF)](https://img.shields.io/badge/Fix-.gitattributes%20(LF)-blue)](https://github.com/rickballard/CoCivium/issues/new?template=fix-gitattributes.yml&labels=issueops,op:fix-gitattributes&title=Fix+.gitattributes+(LF))

> These are **GitHub UI buttons** — don’t paste them into PowerShell.
