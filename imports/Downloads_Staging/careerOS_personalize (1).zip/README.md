# CareerOS — Personalization Package

You are a rare and valuable human being.

See email_instructions_part2.txt for steps.
