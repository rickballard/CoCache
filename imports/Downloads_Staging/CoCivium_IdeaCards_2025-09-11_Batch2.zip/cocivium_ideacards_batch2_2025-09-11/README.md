# CoCivium IdeaCards — Batch 2 (2025-09-11)

This batch contains 4 IdeaCards (35–38). Suggested path: `docs/ideas/2025-09-11/batch-2/`.

## Cards
- 35 CiviDiff — Canonical A/B Doc Comparator
- 36 WaitGate — Browser Heartbeat & Patience Policy
- 37 BPOE Microtext — Self-Audit Footer & Drift Checks
- 38 CivIndex — Standards & Toolshop Registry UI
