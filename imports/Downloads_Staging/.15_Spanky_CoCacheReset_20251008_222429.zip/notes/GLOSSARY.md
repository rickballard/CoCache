# Glossary
- Human-Touch Assets: Polished narrative pieces to preserve.
- Secret-Sauce: Competitive methods/details, stored in passworded zips.
- Twin Indexing: Human vs AI-parsable indexes for the suite.
- CoKey: Temporary high-privilege control path (to be retired).
