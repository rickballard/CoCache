# Decisions
- Advisory zip is directional, not executable.
- Human-touch assets protected from AI-style flattening.
- Civium repo to be made Private once fully migrated.
