# BPOE Notes
- Sidecar storage via CoCache/CoCacheGlobal.
- Append-style edits for human-touch assets.
- Checkpoints + rollback at every phase.
- CoAgent orchestration with watchers/dashboards.