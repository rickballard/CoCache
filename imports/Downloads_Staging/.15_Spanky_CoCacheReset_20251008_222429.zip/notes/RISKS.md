# Risks
- Overwriting polished human content.
- Secrets exposure if processes misconfigured.
- Session/token limits without sidecar.
- Complex rollback without checkpoints.
