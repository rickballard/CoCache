# Browser Setup & Launcher (live)

## Goal
One-click opens CoCivium Chrome profile with pinned tabs + two Git Bash tabs.

## Pinned tabs (confirm)
- CoCivium (Code / PRs / Actions)
- GIBindex (Code / PRs / Actions)
- GIBindex/sessions/LOG.md
- ChatGPT (paste CIVPACK)
- GitHub Notifications

## Next session
- Generate CoCivium-Workbench.bat
- Add Windows Terminal profile (2 Git Bash tabs)
- Optional Task Scheduler (Toronto time)
