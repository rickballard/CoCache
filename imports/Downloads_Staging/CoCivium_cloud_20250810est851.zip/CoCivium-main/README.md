# CoCivium
Civic protocols and founding scrolls for CoCivium: aligning biological and synthetic minds via recursive ethical co-evolution.

---
**License:** This project is licensed under the Creative Commons Attribution–ShareAlike 4.0 International License. See the [LICENSE](LICENSE) file for details.

---
**License:** This work is licensed under a [Creative Commons Attribution-ShareAlike 4.0 International License](https://creativecommons.org/licenses/by-sa/4.0/).
