InSeed Telemetry Pack (Cloudflare Workers)

What you get
------------
- worker/src/index.mjs    : privacy-first telemetry with Durable Object day buckets
- worker/wrangler.toml    : worker config (crons + vars), routes optional
- scripts/Install-Telemetry.ps1 : patches config and deploys (optionally adds routes)
- scripts/Patch-Checklist-Beacon.ps1 : enables the anonymous checklist beacon
- docs/README.txt

Deploy (OAuth login recommended)
--------------------------------
1) npm i -g wrangler
2) wrangler login
3) PowerShell:

Expand-Archive -Path "$HOME\Downloads\inseed-telemetry-pack.zip" -DestinationPath "$HOME\Downloads\inseed-telemetry-pack" -Force
powershell -ExecutionPolicy Bypass -File "$HOME\Downloads\inseed-telemetry-pack\scripts\Install-Telemetry.ps1" -Domain "inseed.com" -MailTo "rballard@inseed.com" -MailFrom "noreply@inseed.com"

(Optional) add routes automatically by also passing -ZoneId and -Token.

Verify
------
- https://inseed.com/__t/health → 'ok'
- https://inseed.com/admin/?code=PRINTED_PASSCODE → HTML dashboard

Enable checklist beacons
------------------------
powershell -ExecutionPolicy Bypass -File "$HOME\Downloads\inseed-telemetry-pack\scripts\Patch-Checklist-Beacon.ps1" -Repo "$HOME\Documents\GitHub\InSeed"
git -C "$HOME\Documents\GitHub\InSeed" commit -am "telemetry: enable anonymous checklist beacons" && git -C "$HOME\Documents\GitHub\InSeed" push
