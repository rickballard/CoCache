// InSeed Telemetry Worker (privacy-first)
export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;

    // Basic CORS & cache headers
    const nocache = {
      "Cache-Control": "no-store, max-age=0",
      "Pragma": "no-cache",
      "Expires": "0",
      "Access-Control-Allow-Origin": "*",
    };

    // Health check
    if (path === "/__t/health") {
      return new Response("ok", { headers: { ...nocache, "content-type":"text/plain" } });
    }

    // Admin dashboard
    if (path.startsWith("/admin")) {
      const code = url.searchParams.get("code") || "";
      if (!env.ADMIN_PASSCODE || code !== env.ADMIN_PASSCODE) {
        return new Response("Forbidden", { status: 403, headers: nocache });
      }
      const days = Number(url.searchParams.get("days") || "30");
      const data = await readRange(env, days);
      const html = renderAdminHTML(data, days);
      return new Response(html, { headers: { ...nocache, "content-type": "text/html; charset=utf-8" } });
    }

    // Pixel endpoint (anonymous): GET /__t?ev=...&p=...&q=...&a=...
    if (path === "/__t") {
      if (request.method !== "GET") return new Response("", { status: 405, headers: nocache });
      const ev = (url.searchParams.get("ev") || "").slice(0, 24);
      const p  = (url.searchParams.get("p")  || "").slice(0, 128);
      const q  = (url.searchParams.get("q")  || "").slice(0, 64);
      const a  = (url.searchParams.get("a")  || "").slice(0, 16);
      if (!ev) return new Response("", { status: 204, headers: nocache });

      const day = dayKey(new Date());
      const id = env.BUCKET.idFromName(day);
      const stub = env.BUCKET.get(id);
      const key = compactKey({ev,p,q,a});
      // fire and forget
      ctx.waitUntil(stub.fetch("https://do/incr", { method:"POST", body: JSON.stringify({ key }) }));
      return new Response("", { status: 204, headers: nocache });
    }

    return new Response("Not Found", { status: 404, headers: nocache });
  },

  // Cron: daily and monthly emails
  async scheduled(controller, env, ctx) {
    const spec = controller.cron; // e.g., "0 8 * * *" or "10 8 1 * *"
    let days = 1;
    let subject = "InSeed daily signals (last 24h)";
    if (spec === "10 8 1 * *") {
      days = 30;
      subject = "InSeed monthly signals (last 30d)";
    }

    const data = await readRange(env, days);
    const text = renderEmailText(data, days);
    if (env.MAIL_TO && env.MAIL_FROM) {
      await sendMail(env, {to: env.MAIL_TO, from: env.MAIL_FROM, subject, text});
    }
  },
};

export class BucketDO {
  constructor(state, env) {
    this.state = state;
    this.env = env;
  }

  async fetch(request) {
    const url = new URL(request.url);
    if (url.pathname === "/incr" && request.method === "POST") {
      const { key } = await request.json();
      const curr = (await this.state.storage.get(key)) || 0;
      const next = (curr|0) + 1;
      await this.state.storage.put(key, next);
      return new Response("ok");
    }

    // dump all for this DO
    if (url.pathname === "/dump") {
      const list = await this.state.storage.list();
      const obj = {};
      for (const [k,v] of list) obj[k] = v;
      return new Response(JSON.stringify(obj), { headers: {"content-type":"application/json"} });
    }

    return new Response("ok");
  }
}

// Helpers
function dayKey(d) {
  const yyyy = d.getUTCFullYear();
  const mm = String(d.getUTCMonth()+1).padStart(2,"0");
  const dd = String(d.getUTCDate()).padStart(2,"0");
  return `${yyyy}${mm}${dd}`;
}

function compactKey({ev,p,q,a}){
  // keep it small and structured for counting
  return `ev:${ev}|p:${p}|q:${q}|a:${a}`;
}

async function readRange(env, days) {
  const now = new Date();
  const results = {};
  for (let i=0;i<days;i++){
    const d = new Date(now.getTime() - i*86400000);
    const day = dayKey(d);
    const id = env.BUCKET.idFromName(day);
    const stub = env.BUCKET.get(id);
    const r = await stub.fetch("https://do/dump");
    if (r.ok) {
      const obj = await r.json();
      results[day] = obj;
    } else {
      results[day] = {};
    }
  }
  return results;
}

function aggregate(results){
  const total = new Map();
  for (const day of Object.keys(results)){
    const obj = results[day] || {};
    for (const k of Object.keys(obj)){
      total.set(k, (total.get(k)||0) + (obj[k]|0));
    }
  }
  const arr = [...total.entries()].sort((a,b)=>b[1]-a[1]);
  return arr;
}

function renderAdminHTML(results, days){
  const agg = aggregate(results);
  const rows = agg.slice(0,200).map(([k,v])=>{
    const parts = Object.fromEntries(k.split("|").map(s=>s.split(":")));
    return `<tr><td>${esc(parts.ev||"")}</td><td>${esc(parts.p||"")}</td><td>${esc(parts.q||"")}</td><td>${esc(parts.a||"")}</td><td style="text-align:right">${v}</td></tr>`;
  }).join("");
  return `<!doctype html><meta charset="utf-8"><title>InSeed Signals (${days}d)</title>
  <style>
  body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,'Helvetica Neue',Arial,sans-serif;margin:20px}
  table{border-collapse:collapse;width:100%}th,td{border:1px solid #ddd;padding:6px}th{background:#f5f5f5;text-align:left}
  </style>
  <h1>InSeed Signals (${days} days)</h1>
  <p>This dashboard shows anonymous counts. No PII is collected.</p>
  <table><thead><tr><th>Event</th><th>Page</th><th>Key</th><th>Ans</th><th>Count</th></tr></thead>
  <tbody>${rows||"<tr><td colspan=5>(no data)</td></tr>"}</tbody></table>`;
}

function renderEmailText(results, days){
  const agg = aggregate(results);
  const lines = agg.slice(0,50).map(([k,v])=>{
    const parts = Object.fromEntries(k.split("|").map(s=>s.split(":")));
    return `${v} × ev=${parts.ev||""} p=${parts.p||""} q=${parts.q||""} a=${parts.a||""}`;
  });
  return `InSeed signals (last ${days} day${days>1?"s":""})\n\n` + (lines.join("\n") || "(no activity)");
}

async function sendMail(env, {to, from, subject, text}){
  const body = {
    personalizations: [{ to: [{ email: to }] }],
    from: { email: from, name: "InSeed Telemetry" },
    subject,
    content: [{ type: "text/plain; charset=utf-8", value: text }],
  };
  await fetch("https://api.mailchannels.net/tx/v1/send", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
}

// tiny escape for HTML
function esc(s){ return String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])); }
