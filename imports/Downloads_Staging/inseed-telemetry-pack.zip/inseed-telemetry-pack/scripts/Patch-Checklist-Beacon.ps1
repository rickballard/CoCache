param(
  [Parameter(Mandatory=$true)][string]$Repo
)
$path = Join-Path $Repo "checklist\index.html"
if(!(Test-Path $path)){ throw "File not found: $path" }
$raw = Get-Content $path -Raw

# Enable the beacon (swap commented line to live line)
$raw = $raw -replace "(?ms)//\s*new Image\(\)\.src='\/__t\?ev=chk[^']*';", "new Image().src='/__t?ev=chk&p='+encodeURIComponent(location.pathname)+'&q='+encodeURIComponent(d.dataset.id)+'&a='+val;"

Set-Content $path -Value $raw -Encoding UTF8
Write-Host "Checklist beacon enabled in $path"
