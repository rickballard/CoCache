param(
  [Parameter(Mandatory=$true)][string]$Domain,
  [Parameter(Mandatory=$true)][string]$MailTo,
  [Parameter(Mandatory=$true)][string]$MailFrom,
  [string]$ZoneId,     # optional: if provided we'll add routes
  [string]$Token       # optional: API token to fetch ZoneId from Domain if ZoneId not specified
)

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$worker = Join-Path (Split-Path -Parent $here) "worker"
$toml = Join-Path $worker "wrangler.toml"

if(-not (Test-Path $toml)){ throw "wrangler.toml not found at $toml" }

# Random passcode
$chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
$rand = -join ((1..24) | ForEach-Object { $chars[(Get-Random -Min 0 -Max $chars.Length)] })

# Patch vars in wrangler.toml
$raw = Get-Content $toml -Raw
$raw = $raw -replace 'MAIL_TO\s*=\s*".*?"',       ('MAIL_TO = "'+$MailTo+'"')
$raw = $raw -replace 'MAIL_FROM\s*=\s*".*?"',     ('MAIL_FROM = "'+$MailFrom+'"')
$raw = $raw -replace 'ADMIN_PASSCODE\s*=\s*".*?"',('ADMIN_PASSCODE = "'+$rand+'"' )
Set-Content $toml -Value $raw -Encoding UTF8

Write-Host "Admin passcode: $rand"

# Optionally inject routes with ZoneId
if(-not $ZoneId -and $Token){
  try{
    $resp = Invoke-RestMethod -Method Get -Uri ("https://api.cloudflare.com/client/v4/zones?name="+$Domain) -Headers @{ Authorization = "Bearer $Token" }
    $ZoneId = $resp.result[0].id
  } catch { Write-Warning "Could not resolve ZoneId via API token."; }
}

if($ZoneId){
  # add routes array (or replace if present)
  $routes = @"
routes = [
  {{ pattern = "$Domain/__t*",   zone_id = "$ZoneId" }},
  {{ pattern = "$Domain/admin*", zone_id = "$ZoneId" }}
]
"@

  $raw = Get-Content $toml -Raw
  if($raw -match "(?ms)^routes\s*=\s*\[.*?\]"){
    $raw = [Regex]::Replace($raw, "(?ms)^routes\s*=\s*\[.*?\]", $routes)
  } else {
    $raw = $raw.TrimEnd() + "`r`n`r`n" + $routes + "`r`n"
  }
  Set-Content $toml -Value $raw -Encoding UTF8
  Write-Host "Routes added for $Domain (ZoneId=$ZoneId)"
} else {
  Write-Warning "No ZoneId provided. The worker will deploy to workers.dev; add routes later or rerun with -ZoneId."
}

Push-Location $worker
try{
  wrangler deploy
} finally {
  Pop-Location
}

Write-Host ""
Write-Host "If routes were added, verify:"
Write-Host "  https://$Domain/__t/health   (should return 'ok')"
Write-Host "  https://$Domain/admin/?code=$rand"
