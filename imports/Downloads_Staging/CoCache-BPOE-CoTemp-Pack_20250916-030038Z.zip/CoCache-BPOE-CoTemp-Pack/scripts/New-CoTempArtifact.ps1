[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][string]$Name,
  [Parameter(Mandatory=$true)][string[]]$Paths,
  [Parameter(Mandatory=$true)][string]$RepoPath,
  [string]$Session = "adhoc"
)
$ErrorActionPreference = 'Stop'
function Ensure-Dir([string]$p){ if(!(Test-Path $p)){ New-Item -ItemType Directory -Force -Path $p | Out-Null } }

$base = Join-Path $env:USERPROFILE "Documents\CoTemp"
$sessionDir = Join-Path $base $Session
Ensure-Dir $sessionDir

$stamp = (Get-Date).ToUniversalTime().ToString("yyyyMMdd-HHmmssZ")
$sanName = ($Name -replace '[^\w\-]+','-').Trim('-')
if([string]::IsNullOrWhiteSpace($sanName)){ $sanName = "artifact" }
$zipPath = Join-Path $sessionDir ("{0}_{1}.zip" -f $sanName, $stamp)

$staging = Join-Path ([System.IO.Path]::GetTempPath()) ("CoTempStage_{0}" -f ([guid]::NewGuid().ToString("N")))
Ensure-Dir $staging

foreach($p in $Paths){
  $src = if([System.IO.Path]::IsPathRooted($p)) { $p } else { Join-Path $RepoPath $p }
  if(!(Test-Path $src)){ Write-Warning "Path not found: $src"; continue }
  $dest = Join-Path $staging (Split-Path $src -Leaf)
  Copy-Item -Recurse -Force -Path $src -Destination $dest
}

$manifest = @{
  name     = $Name; repo=$RepoPath; created=(Get-Date).ToUniversalTime().ToString("o"); session=$Session; paths=$Paths
}
$manifest | ConvertTo-Json -Depth 5 | Set-Content -Encoding UTF8 (Join-Path $staging "manifest.json")

if(Test-Path $zipPath){ Remove-Item -Force $zipPath }
Compress-Archive -Path (Join-Path $staging "*") -DestinationPath $zipPath -Force
Remove-Item -Recurse -Force $staging

Write-Host "✅ Wrote CoTemp artifact:" -ForegroundColor Green
Write-Host "   $zipPath"
