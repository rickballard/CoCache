# Red team questions

These questions are meant to break the proposal so it can be improved.

1. Does neighbor status for synthetic minds collapse human specialness.
   - Response: it expands duty rather than shrinking dignity. Humans keep full standing while sharing it with others who carry moral load.

2. Does consent gradient language undermine clear rules.
   - Response: a gradient does not erase thresholds. It allows re checking when stakes change so rules match reality.

3. Does sidecar indexing smuggle doctrine.
   - Response: indexing is a pointer system. It does not add claims. It makes claims legible to tools and reviewers.

4. What stops a group from using public funds to enforce private doctrine.
   - Response: the guardrail that public funds require public reasons. Courts can test this.

5. What if a tradition forbids recognition of non human persons.
   - Response: worship remains free. Public services still run on shared evidence and neighbor care.
