# IdeaCards — Batch 5 (47–50)

This batch contains four IdeaCards intended for intake under `docs/ideas/2025-09-11/batch-5/`.

- 47 CoPath — Safe Shared Planning with Pseudonymous Accounts
- 48 Civium Labs — Sandboxed Field Trials & A/B Guarded Rollouts
- 49 CoBounty — Open Bounty Market for Civic Tasks
- 50 CiviGuard — Red-Team Drills & Incident Snapshots

**Notes**
- Sensitivity: public unless flagged later.
- See `manifest.json` for file list.
