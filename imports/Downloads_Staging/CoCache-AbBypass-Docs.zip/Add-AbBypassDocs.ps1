Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'

# Find repo root
$root = (git rev-parse --show-toplevel) 2>$null
if (-not $root) { throw "Not inside a git repo. Open a terminal in your repo and run this again." }
Set-Location $root.Trim()

$readme = 'README.md'
if (-not (Test-Path -LiteralPath $readme)) {
  $repoName = Split-Path -Leaf $root
  Set-Content -LiteralPath $readme -Encoding UTF8 -Value ("# {0}`r`n" -f $repoName)
}

$marker = '### AB-bypass (air-bag branches)'
$blurb = @'
### AB-bypass (air-bag branches)
Branches starting with `ab/` or `ab-` can skip pre-push checks to let WIP land quickly.  
The pre-push hook begins with:

```powershell
# --- AB bypass (must be first) ---
$branch = (git rev-parse --abbrev-ref HEAD).Trim()
if ($branch -match '^(ab/|ab-)') { if ($PSCommandPath) { exit 0 } else { return } }
# --- end AB bypass ---
```

All other branches run the full hook.
'@

$changed = $false
if (-not (Select-String -Path $readme -SimpleMatch -Pattern $marker -Quiet)) {
  Add-Content -LiteralPath $readme -Encoding UTF8 -Value "`r`n$blurb`r`n"
  $changed = $true
}

if ($changed) {
  git add -- $readme | Out-Null
  git commit -m "docs: document AB-bypass (air-bag branches) in README" | Out-Null
  try { git push --no-verify | Out-Null } catch { Write-Warning "Push failed (possibly no upstream). Commit is local."; }
  Write-Host "✓ AB-bypass docs appended to README.md"
} else {
  Write-Host "• README already contains AB-bypass section; nothing to do."
}
