CoCache AB-bypass README injector

What it does
------------
Appends a documented snippet to README.md explaining the AB-bypass ("air-bag")
pre-push behavior. It commits (and attempts to push) the change.

Usage
-----
1) Open a terminal *inside your target repo*.
2) Run the one-liner from the chat that expands this zip from your Downloads
   folder and executes Add-AbBypassDocs.ps1.
3) If push fails (no upstream), push manually later.

Safe re-run:
- If the section is already present, it exits without changes.
