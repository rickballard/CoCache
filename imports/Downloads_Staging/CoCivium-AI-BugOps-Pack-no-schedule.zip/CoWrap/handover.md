# CoWrap Handover (Start Fresh in New Chat)
Paste this to a new chat to brief it, **without** asking it to schedule anything:

---
**Context:** We're working on AI BugOps. Use the repo pack I provide. Avoid any ChatGPT scheduling.

**What to do now:**
1) Keep using GitHub Actions **workflow_dispatch** or the **/ai-dump** comment trigger.
2) When bugs occur, create an **AI bug report** and attach HAR / x-request-id.
3) Use local scripts:
   - `tools/New-AIReproCapsule.ps1`
   - `tools/Export-AIIncidentForOpenAI.ps1 -Kind <product|api|...> -HarPath <file> -RequestId <id>`
4) Generate an on-demand support packet via Actions when needed.
---
