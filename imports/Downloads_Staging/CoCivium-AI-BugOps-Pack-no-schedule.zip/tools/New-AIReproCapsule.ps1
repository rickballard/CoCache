\
[CmdletBinding()]
param(
  [string]$OutDir = ".reports"
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$ts = Get-Date -Format 'yyyyMMdd-HHmmss'
$path = Join-Path $OutDir ("ai-repro-$ts.txt")

Write-Host "Creating repro capsule at $path ..."

$summary = Read-Host "One-line summary"
$steps = Read-Host "Repro steps (paste numbered list)"
$notes = Read-Host "Any extra notes (optional)"

$env = @"
OS: $([System.Environment]::OSVersion.VersionString)
PowerShell: $($PSVersionTable.PSVersion)
UserName: $env:USERNAME
Host: $env:COMPUTERNAME
"@

@"
=== AI REPRO CAPSULE ===
Timestamp: $(Get-Date -Format u)

Summary:
$summary

Steps to reproduce:
$steps

Notes:
$notes

Environment:
$env
"@ | Set-Content -Encoding UTF8 $path

Write-Host "Saved: $path"
