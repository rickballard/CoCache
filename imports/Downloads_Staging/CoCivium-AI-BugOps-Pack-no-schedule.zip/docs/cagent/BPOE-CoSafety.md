# BPOE Guardrails (CoSafety)
- **Paste-shield:** avoid running lines that begin with `PS C:\...>`
- **Idempotence lock:** `Use-CoLock` pattern to prevent double-run
- **Repo preflight:** `Require-CoRepoState` (branch, origin, clean tree, no rebase)
- **Human-in-the-loop:** `Confirm-Co "Type YES to continue"` for risky steps
- **Protections:** backup/relax/restore branch protections explicitly when needed

> Principle: make destructive ops explicit, reversible, and logged.
