# AI Ops (No-ChatGPT-Scheduling)
This repo uses **no ChatGPT scheduling**. Everything is either:
- Run **manually** (via a button in GitHub Actions or a local script), or
- Triggered by a **comment** (`/ai-dump`) on any issue.

## Quick start
1. File an AI bug using **Issues → New → AI bug report** (requests HAR/x-request-id).
2. Capture a repro capsule locally:
   ```powershell
   tools/New-AIReproCapsule.ps1
   tools/Export-AIIncidentForOpenAI.ps1 -Kind product -HarPath path\to\bug.har -RequestId abcd-1234
   ```
3. To generate a support packet **on demand**:
   - In **Actions → ai-ops-export-pack → Run workflow** (no schedule), or
   - Comment **/ai-dump** on any issue.

The run uploads an artifact named **ai-ops-export** with a sanitized markdown report.
