# CoTemp Queue Kit (global inbox watcher)

This tiny kit gives you a **reliable, no-frills watcher** that:
- Monitors `~/Downloads/CoTemp/inbox/*.ps1`
- Executes each file with `_shared/Run-DO.ps1`
- Moves it to `inbox/processed/` (or `processed/FAIL_*.ps1` on error)
- Writes logs via your current session’s `Run-DO.ps1` rules

> Why global? It’s the simplest “back channel” that works across panes without duplicating work, and it avoids the earlier job-name drift.

## Install
1. Unzip the contents into `~/Downloads/CoTemp/` so you have:
   - `~/Downloads/CoTemp/scripts/Watch-GlobalInbox.ps1`
   - `~/Downloads/CoTemp/scripts/Start-CoWatchers.ps1`

2. In each pane you want a watcher:
   ```powershell
   Set-ExecutionPolicy -Scope Process Bypass -Force
   . "$HOME\Downloads\CoTemp\Join-CoAgent.ps1"   # if you use it
   & "$HOME\Downloads\CoTemp\scripts\Start-CoWatchers.ps1"
   ```

3. Verify:
   ```powershell
   Get-Job | ? Name -eq 'CoInboxWatcher' | ft Id,Name,State
   ```

## Use
Drop a DO into the inbox (from either pane):
```powershell
'inbox ping from ' + $env:COTEMP_SID | Set-Clipboard
& "$HOME\Downloads\CoTemp\_shared\Send-DOFromClipboard.ps1" -Name 'ping' -Tag 'gmig' -LF
```

Tail the most recent log:
```powershell
Get-ChildItem "$HOME\Downloads\CoTemp\logs" -File |
  Sort LastWriteTime -desc | Select -First 1 | % { Get-Content $_.FullName -Tail 50 }
```

Stop/restart the watcher:
```powershell
Get-Job -Name CoInboxWatcher | Stop-Job -Force
& "$HOME\Downloads\CoTemp\scripts\Start-CoWatchers.ps1" -Restart
```
