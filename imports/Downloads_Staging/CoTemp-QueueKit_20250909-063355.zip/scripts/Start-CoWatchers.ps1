param(
  [switch]$Restart
)
$root   = Join-Path $HOME 'Downloads\CoTemp'
$scripts= Join-Path $root 'scripts'
$watch  = Join-Path $scripts 'Watch-GlobalInbox.ps1'

if (-not (Test-Path $watch)) {
  throw "Missing watcher script at $watch. Unzip the kit to $root first."
}

$existing = Get-Job | Where-Object { $_.Name -eq 'CoInboxWatcher' }
if ($existing -and -not $Restart) {
  Write-Host "Watcher already running:"
  $existing | Format-Table Id,Name,State -AutoSize
  return
}
if ($existing) { $existing | Stop-Job -Force | Out-Null }

Write-Host "Starting CoInboxWatcher (global inbox) ..."
Start-Job -Name 'CoInboxWatcher' -ScriptBlock {
  param($pth)
  try { Unblock-File -Path $pth } catch {}
  & $pth
} -ArgumentList $watch | Out-Null

Start-Sleep -Milliseconds 300
Get-Job -Name 'CoInboxWatcher' | Format-Table Id,Name,State -AutoSize