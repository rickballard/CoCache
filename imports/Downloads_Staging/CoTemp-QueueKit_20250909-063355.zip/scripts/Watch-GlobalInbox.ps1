param(
  [int]$IntervalMs = 800
)
$ErrorActionPreference = 'Stop'
$root      = Join-Path $HOME 'Downloads\CoTemp'
$inbox     = Join-Path $root 'inbox'
$processed = Join-Path $inbox 'processed'
$shared    = Join-Path $root '_shared'
$run       = Join-Path $shared 'Run-DO.ps1'

New-Item -ItemType Directory -Force -Path $inbox,$processed | Out-Null

Write-Host "[Watcher] Global inbox => $inbox (logging via Run-DO.ps1)"

while ($true) {
  try {
    $files = Get-ChildItem -LiteralPath $inbox -Filter '*.ps1' -File -ErrorAction SilentlyContinue |
             Sort-Object LastWriteTime
    foreach ($f in $files) {
      $start = Get-Date
      $label = "[Watcher] running: $($f.Name)"
      Write-Host "$label"
      try {
        & $run -Path $f.FullName | Out-Null
        $dest = Join-Path $processed $f.Name
        Move-Item -LiteralPath $f.FullName -Destination $dest -Force
        Write-Host "[Watcher] ok -> $dest  ($( (Get-Date) - $start ))"
      } catch {
        $dest = Join-Path $processed ("FAIL_" + $f.Name)
        try { Move-Item -LiteralPath $f.FullName -Destination $dest -Force } catch {}
        Write-Warning "[Watcher] FAIL  -> $dest  : $($_.Exception.Message)"
      }
    }
  } catch {
    Write-Warning "[Watcher] loop error: $($_.Exception.Message)"
  }
  Start-Sleep -Milliseconds $IntervalMs
}