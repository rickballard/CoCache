# History Hygiene

- Create `docs/history/INDEX.md` and `docs/history/<YEAR>.md` (YYYY).  
- `.github/ISSUE_TEMPLATE/history_year.yml` that pings in December to roll to next year.  
- Backfill notable tags/releases and link to PRs.  
- Encourage squads to add 1–2 bullets per month (what changed; why it matters).
