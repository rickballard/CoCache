# Open Questions
- When (if ever) should a sentinel hard‑fail by default?  
- Which protected‑docs flows merit plaintext‑leak CI lint?  
- Weekly gardening vs monthly path‑pruning cadence?  
- CoAgent packaging track (GPT extension / middleware / OSS+SaaS)?
