## Checklist
- [ ] No `<placeholders>` in runnable lines
- [ ] No `exit 0` in docs/examples
- [ ] AB-bypass only in `.githooks/pre-push.ps1`
- [ ] BPOE Sanity passes

## Summary
