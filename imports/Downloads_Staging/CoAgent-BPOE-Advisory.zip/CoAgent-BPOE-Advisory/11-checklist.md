# Checklist (Productization)

- [ ] CoAgent owns BPOE bookends (pre/post).
- [ ] Minimal GH workflow present; logs minimized.
- [ ] Branch protection requires BPOE Sanity on default branch.
- [ ] Templates present (.gitattributes, .editorconfig, PR template).
- [ ] ADR‑0003 referenced in NOTICE.
- [ ] Retention policy for CI logs short.
