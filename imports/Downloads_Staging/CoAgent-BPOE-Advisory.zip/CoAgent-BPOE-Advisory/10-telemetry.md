# Telemetry

- Local only by default; opt-in upload for team dashboards.
- Metrics: failures per run, time-to-green, categories (placeholders, bypass leak, exit-0).
- No code content, no prompts, no PII.
