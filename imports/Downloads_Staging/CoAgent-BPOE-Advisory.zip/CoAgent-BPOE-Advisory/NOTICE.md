See ADR‑0003: Externalized Memory Discipline — all canonical state lives outside vendor memory.
BPOE logic runs inside CoAgent; CI is enforcement‑only.
