# NOP (paste-guard)
'' | Out-Null
Set-StrictMode -Version Latest; $ErrorActionPreference = 'Stop'

# --- Settings ---
$RepoPath = Join-Path $HOME 'Documents\GitHub\CoCivium'
$RelDest  = 'outreach\partners\Koso-Synergy-Report.md'
$Source   = Join-Path $PSScriptRoot 'outreach\partners\Koso-Synergy-Report.md'

if (-not (Test-Path $RepoPath)) { throw "Repo not found at $RepoPath" }
if (-not (Test-Path $Source))   { throw "Source file not found at $Source" }

Push-Location $RepoPath
try {
  # Ensure clean working tree
  $status = git status --porcelain
  if ($LASTEXITCODE -ne 0) { throw "git status failed" }

  # Pull latest main
  git checkout main | Out-Null
  git pull --ff-only

  # New branch
  $stamp = Get-Date -Format 'yyyyMMdd-HHmm'
  $branch = "outreach/koso-synergy-$stamp"
  git checkout -b $branch

  # Ensure destination folder exists
  $destDir = Split-Path -Parent $RelDest
  if (-not (Test-Path $destDir)) { New-Item -ItemType Directory -Force -Path $destDir | Out-Null }

  # Copy file
  Copy-Item -Force -Path $Source -Destination $RelDest

  # Stage / commit
  git add $RelDest
  git commit -m "Add Koso synergy outreach doc (informal partnership) [$stamp]"

  # Push and open PR
  git push -u origin $branch
  gh pr create `
    --title "Add Koso synergy outreach doc (informal partnership)" `
    --body "Adds `outreach/partners/Koso-Synergy-Report.md` with a link to the root README for repo exploration. Safe, informal invite for collaboration/pilot." `
    --label docs,outreach

  Write-Host "`nPR created. Review and merge when ready." -ForegroundColor Green
}
finally {
  Pop-Location
}
