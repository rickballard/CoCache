# Faiths Hero Placeholder
- Subtle, non-ranking token field around a centered CoCivium mark.
- Greyscale tokens; rainbow is low-opacity field to signal inclusivity without picking winners.
- No symbols near exact N/E/S/W; jitter avoids cardinal emphasis.
