
# Grand Migration — Thin-Shim Autopilot
Generated: 2025-09-15 21:14:58

This kit applies the **three thin-shim workflows** to multiple repos under a root folder, opens a branch, commits, pushes, optionally sets `ENABLE_AUTOCOMMITS`, and can dispatch `smoke`/`self-evolve` runs against the feature branch.

- Central SoT: `rickballard/CoCache` (root) with reusable workflows.
- Local shims: `.github/workflows/smoke.yml`, `safety-gate.yml`, `self-evolve.yml`

Edit `CONFIG.json` then run `Autopilot.ps1` **once**. It is idempotent.
