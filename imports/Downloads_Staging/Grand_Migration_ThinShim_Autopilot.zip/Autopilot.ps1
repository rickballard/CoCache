
#requires -Version 7.0
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'

# --- Load config ---
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$config = Get-Content -Raw -Encoding UTF8 -Path (Join-Path $Here 'CONFIG.json') | ConvertFrom-Json
$root   = $config.Root
$repos  = @($config.Repos)
$ownerRepoCentral = $config.OwnerRepoCentral
$prefix = $config.FeatureBranchPrefix
$enableAC = [bool]$config.EnableAutoCommits
$dispatch = [bool]$config.DispatchWorkflows
$today  = Get-Date -Format 'yyyyMMdd'

function Ensure-Dir($p) { New-Item -ItemType Directory -Force -Path $p | Out-Null }

# --- For each repo ---
foreach ($name in $repos) {
  $repoPath = Join-Path $root $name
  if (-not (Test-Path $repoPath)) { Write-Warning "Skip: repo path not found $repoPath"; continue }

  $wfDir = Join-Path $repoPath '.github\workflows'
  Ensure-Dir $wfDir

  # Write stubs from templates, substituting $OwnerRepoCentral
  $tmplDir = Join-Path $Here 'thin_shim_templates'
  foreach ($f in @('smoke.yml','safety-gate.yml','self-evolve.yml')) {
    $templ = Get-Content -Raw -Encoding UTF8 -Path (Join-Path $tmplDir $f)
    $templ = $templ.Replace('$OwnerRepoCentral', $ownerRepoCentral)
    Set-Content -Path (Join-Path $wfDir $f) -Value $templ -Encoding UTF8
  }

  # Feature branch
  if (-not (Test-Path (Join-Path $repoPath '.git'))) { git -C $repoPath init | Out-Null }
  $branch = '{0}{1}' -f $prefix, $today
  git -C $repoPath checkout -B $branch
  git -C $repoPath add -A

  if (git -C $repoPath diff --cached --quiet) {
    Write-Host ">> [$name] No shim changes (idempotent)."
  } else {
    git -C $repoPath commit -m "chore(bpoe): switch to central reusable workflows"
    $remote = (git -C $repoPath remote) | Select-Object -First 1
    if ($remote) { git -C $repoPath push -u $remote $branch }
  }

  # Optional: set ENABLE_AUTOCOMMITS
  if ($enableAC -and (Get-Command gh -ErrorAction SilentlyContinue)) {
    try { gh variable set ENABLE_AUTOCOMMITS --repo "rickballard/$name" --body true | Out-Null } catch {}
  }

  # Optional: dispatch smoke & self-evolve again the branch
  if ($dispatch -and (Get-Command gh -ErrorAction SilentlyContinue)) {
    try {
      gh workflow run smoke.yml             --repo "rickballard/$name" --ref $branch | Out-Null
    } catch { Write-Warning "[$name] smoke dispatch: $($_.Exception.Message)" }
    try {
      # Use explicit path name; some GH instances require full path for non-default branches
      gh workflow run ".github/workflows/self-evolve.yml" --repo "rickballard/$name" --ref $branch | Out-Null
    } catch { Write-Warning "[$name] self-evolve dispatch: $($_.Exception.Message)" }
  }

  Write-Host ">> [$name] Thin shim ready on $branch"
}

Write-Host "`n[OE:✔] Autopilot complete."
