# Breadcrumbs (Where to look)
- System of Truth: **CoCache**
  - `.github/workflows/bpoe-*.yml`
  - `module/BPOE.Autopilot/*`
- Per repo:
  - `docs/bpoe/SESSION_STATUS.md` (self-evolve output)
  - README badges between `<!-- BPOE:STATUS-BADGES BEGIN/END -->`
