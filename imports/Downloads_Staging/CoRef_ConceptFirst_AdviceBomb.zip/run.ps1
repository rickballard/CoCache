Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Push-Location $here
"CoCivium CoRef Advice Bomb"
"Time: $(Get-Date -Format o)"
"Files:"
Get-ChildItem -Recurse | ForEach-Object { $_.FullName }
$out = @()
$out += "[STATUS] CoRef bundle OK"
$out += "Generated: $(Get-Date -Format o)"
$out | Set-Content -Path (Join-Path $here 'out.txt') -Encoding UTF8
Pop-Location
