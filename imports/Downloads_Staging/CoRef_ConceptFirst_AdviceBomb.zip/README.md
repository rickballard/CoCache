# CoRef Concept-First Indexing — Advice Bomb

This bundle seeds a bottom-up tagging system (CoRef) that meets the top-down indexing of the Hitchhiker Plan (HH).
It is concept-first, edit-robust, and kept out of the reading flow.

Includes:
- Standards for filenames and metadata
- Concept Registry schema (`CR:*`) and CoRef sidecars
- Tools to generate CoRef maps from Markdown
- HH alignment guidance and GIBindex integration plan
- Examples on the “Faiths in Dialogue” draft

Execution: `run.ps1` prints a status and checks files. No side effects.
