---
Term: CoID
Category: CoAgency
Status: Draft
---
Cryptographic identity, signatures, and key management enabling authenticated CoCivium actions.
