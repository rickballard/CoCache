---
Term: ActuatorNet
Category: CoAgency
Status: Draft
---
Integration layer for commits, merges, publishing, notifications.
