---
Term: Ledger of Acts
Category: CoAgency
Status: Draft
---
Append-only record of decisions, signatures, and outcomes.
