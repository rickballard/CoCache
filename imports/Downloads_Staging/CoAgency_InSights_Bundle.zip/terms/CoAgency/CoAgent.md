---
Term: CoAgent
Category: CoAgency
Status: Draft
---
Operational execution engine that performs actions under policy and logging.
