---
Term: CoPersona
Category: CoAgency
Status: Draft
---
Role profiles CoCivium can assume for clarity and accountability.
