---
Term: TrustFlag
Category: CoAgency
Status: Draft
---
Public authenticity/trust dashboard summarizing identity proofs and risk posture.
