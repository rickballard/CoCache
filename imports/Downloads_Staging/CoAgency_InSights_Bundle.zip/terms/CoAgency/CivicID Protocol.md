---
Term: CivicID Protocol
Category: CoAgency
Status: Draft
---
External handshake for institutions/AI systems to recognize CoCivium.
