---
Term: CoStd
Category: CoAgency
Status: Draft
---
Standards for how CoCivium behaves in transactions and representations.
