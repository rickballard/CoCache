---
Term: CoCache
Category: CoAgency
Status: Draft
---
Continuity store for signed logs, manifests, and state handoff.
