---
Term: RepTag
Category: CoAgency
Status: Draft
---
Counterparty- and context-scoped reputation tagging for interactions and outcomes.
