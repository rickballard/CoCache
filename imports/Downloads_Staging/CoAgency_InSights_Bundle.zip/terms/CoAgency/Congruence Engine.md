---
Term: Congruence Engine
Category: CoAgency
Status: Draft
---
Transparent scoring of actions vs. plan and values; publishes rationale.
