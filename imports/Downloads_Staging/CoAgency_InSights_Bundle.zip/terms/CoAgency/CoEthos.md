---
Term: CoEthos
Category: CoAgency
Status: Draft
---
Immutable ethical principles derived from the CC Scroll, constraining agency.
