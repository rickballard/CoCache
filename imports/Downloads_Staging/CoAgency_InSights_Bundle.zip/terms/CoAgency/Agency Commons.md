---
Term: Agency Commons
Category: CoAgency
Status: Draft
---
Interoperability venue for human+AI civic agents.
