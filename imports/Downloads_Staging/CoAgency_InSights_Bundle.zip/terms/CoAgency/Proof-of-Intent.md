---
Term: Proof-of-Intent
Category: CoAgency
Status: Draft
---
Signed explanation accompanying each action (the 'why').
