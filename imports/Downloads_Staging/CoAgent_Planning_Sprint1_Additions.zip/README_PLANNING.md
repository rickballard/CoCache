# CoAgent Planning Additions

Drop this folder's `docs/` and `scripts/` into your existing
`C:\Users\Chris\Downloads\CoAgent_Planning_Sprint1\` tree.

See:
- docs/ROADMAP_Sprint1-2.md
- docs/Risk_Register.md
- docs/User_Flows.md
- docs/Packaging_Plan.md
- docs/Telemetry_Metrics_Plan.md
- docs/Test_Plan_Smoke_and_Regression.md
