# Annex E — Repo & IdeaCard Harvester

Collect idea cards, import CoAgent ops hurdles, map to schemas, open PRs.
