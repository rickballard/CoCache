# Annex D — GitHub Wiring

CODEOWNERS, branch protections, labels, actions stubs, PR/Issue templates.
