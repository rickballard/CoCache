# Annex B — CanonScore & Mistake‑Welcoming Protection

Tiers 0–4. CanonScore governs escalation. RFC if score drop ≥5.
