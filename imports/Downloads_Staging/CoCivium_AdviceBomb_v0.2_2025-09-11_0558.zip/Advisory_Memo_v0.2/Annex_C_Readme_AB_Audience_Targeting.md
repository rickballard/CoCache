# Annex C — README A/B/C

README.default/exec/dev + switcher options; keep deltas small; limit variants.
