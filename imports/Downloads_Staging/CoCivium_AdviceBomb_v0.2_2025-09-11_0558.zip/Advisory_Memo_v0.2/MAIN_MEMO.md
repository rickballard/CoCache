# CoCivium Advisory Memorandum — v0.2 (2025-09-11_0558)
**Mode:** CoCache payload (advice bomb). **Do not trigger** until *Grand Migration → Final Polish*.
## What Changed Since v0.1
- Modular annexes; mistake‑welcoming protection; grooming charter; README A/B/C; staged metrics; CoAgent hooks; schemas; Actions stubs.
## Trigger Window
- Post‑merge convergence; pre‑canonicalization freeze; dashboard able to ingest CanonScore/ReproRate.
## Immediate Actions On Trigger
1) Apply protection schema per Annex B. 2) Enable workflows. 3) Dashboard MVP. 4) Promote Canon candidates. 5) README A/B/C switch.
## Notes on Repo Scans
No private repo scan included. Run Annex E harvester when access is granted.
