# Annex F — Automated Grooming Charter & Anti‑Capture

Allowed vs escalated vs forbidden bot edits; provenance; watchdog.
