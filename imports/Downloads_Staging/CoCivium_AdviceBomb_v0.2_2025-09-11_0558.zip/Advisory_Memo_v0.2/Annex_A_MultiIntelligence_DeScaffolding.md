# Annex A — Multi‑Intelligence & De‑Scaffolding

Ladders by domain; activation via PR with cooling‑off sim and rollback.
