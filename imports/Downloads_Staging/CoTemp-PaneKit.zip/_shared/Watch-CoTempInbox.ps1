param([switch]$Dots)

$root   = Join-Path $HOME 'Downloads/CoTemp'
$inbox  = Join-Path $root 'inbox'
$runner = Join-Path (Join-Path $root '_shared') 'Run-DO.ps1'
New-Item -ItemType Directory -Force -Path $inbox | Out-Null

$fsw = New-Object IO.FileSystemWatcher $inbox, '*.ps1'
$fsw.IncludeSubdirectories = $false
$fsw.EnableRaisingEvents   = $true

$action = {
  param($fullPath)
  # Wait briefly for file to finish writing
  for($i=0;$i -lt 30;$i++){
    try { $s = (Get-Item $fullPath).Length } catch { $s = -1 }
    if ($s -gt 0) { break }
    Start-Sleep -Milliseconds 100
  }
  if (Test-Path $fullPath) { & $using:runner -Path $fullPath -Dots:$using:Dots }
}

foreach($ev in 'Created','Changed'){
  Register-ObjectEvent -InputObject $fsw -EventName $ev -Action {
    Start-Job -ScriptBlock $using:action -ArgumentList $Event.SourceEventArgs.FullPath | Out-Null
  } | Out-Null
}

Write-Host "Watching inbox: $inbox"
Write-Host "Drop .ps1 files there (e.g. via Send-DOFromClipboard.ps1)."
Write-Host "Press Ctrl+C to stop."
while($true){ Start-Sleep -Seconds 3600 }
