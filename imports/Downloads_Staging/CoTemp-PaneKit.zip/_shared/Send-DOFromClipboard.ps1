param([string]$Name='', [string]$Tag='work', [switch]$LF)

# Ensure helpers
$util = Join-Path (Join-Path $HOME 'Downloads/CoTemp') '_shared/ctts-utils.ps1'
if (Test-Path $util) { . $util }

$root  = Join-Path $HOME 'Downloads/CoTemp'
$inbox = Join-Path $root 'inbox'
New-Item -ItemType Directory -Force -Path $inbox | Out-Null

$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$slug  = ($Name ? $Name : 'do'); $slug = ($slug -replace '[^\w\-]+','-').Trim('-')
$fname = "{0}-{1}-{2}.ps1" -f $stamp,$Tag,$slug
$path  = Join-Path $inbox $fname

$text  = if (Get-Command ctts -ErrorAction SilentlyContinue) { ctts -FromClipboard } else { (Get-Clipboard -Raw) }
if ($LF) { $text = $text -replace "`r?`n","`n" }
Set-Content -LiteralPath $path -Value $text -Encoding utf8NoBOM
Write-Host "Dropped DO to inbox: $path"
$path
