param([Parameter(Mandatory)][string]$Path,[switch]$Dots)

$Path = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($Path)

# Ensure logs location
$logs = $env:COTEMP_LOG
if (-not $logs) {
  $logs = Join-Path (Join-Path $HOME 'Downloads/CoTemp') 'logs'
  New-Item -ItemType Directory -Force -Path $logs | Out-Null
}

$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$leaf  = Split-Path $Path -Leaf
$log   = Join-Path $logs "$stamp-$leaf.log"

# Execute and tee to log, synchronously (robust)
& $Path *>&1 | Tee-Object -FilePath $log | Out-Null
Write-Host "Log: $log"
