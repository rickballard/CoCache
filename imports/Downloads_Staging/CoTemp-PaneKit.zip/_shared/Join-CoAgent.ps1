# Drag/run this in the other pane to join the shared CoTemp setup
Set-ExecutionPolicy -Scope Process Bypass -Force
$boot = Join-Path (Join-Path $HOME 'Downloads/CoTemp') 'CoTemp.Bootstrap.ps1'
if (Test-Path $boot) { Unblock-File $boot; . $boot -Tag 'coagent' -AddSharedToPath -AddBinToPath }
if (Get-Command Install-CoTempShims -ErrorAction SilentlyContinue) { Install-CoTempShims }
Write-Host "CoAgent pane ready. Use: Watch-CoTempInbox.ps1 to auto-run dropped DO files."
