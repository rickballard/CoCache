CoTemp Pane Kit (two-pane DO flow)
==================================

1) Extract this zip to:  %USERPROFILE%\Downloads\CoTemp
   You should end up with:
     Downloads\CoTemp\CoTemp.Bootstrap.ps1
     Downloads\CoTemp\_shared\*.ps1

2) In your WORKING pane (grand migration):
   - Allow scripts for just this shell:
       Set-ExecutionPolicy -Scope Process Bypass -Force
   - Bootstrap and add PATH entries:
       . "$HOME\Downloads\CoTemp\CoTemp.Bootstrap.ps1" -Tag "gmig" -AddSharedToPath -AddBinToPath
       Install-CoTempShims

   - Test sending a DO to the inbox:
       'Write-Host "Inbox hello"' | Set-Clipboard
       Send-DOFromClipboard.ps1 -Name "hello" -Tag "gmig"

3) In the OTHER pane (CoAgent planning):
   - Start the watcher (auto-runs anything dropped into CoTemp\inbox):
       Set-ExecutionPolicy -Scope Process Bypass -Force
       . "$HOME\Downloads\CoTemp\CoTemp.Bootstrap.ps1" -Tag "plan" -AddSharedToPath -AddBinToPath
       Install-CoTempShims
       pwsh -NoLogo -NoProfile -ExecutionPolicy Bypass -File "$HOME\Downloads\CoTemp\_shared\Watch-CoTempInbox.ps1"

   - Or just run:
       "$HOME\Downloads\CoTemp\_shared\Join-CoAgent.ps1"

Notes
-----
- ctts-utils.ps1 includes a SAFE fallback for Convert-TranscriptToScript, so Save/Send scripts work
  even if you don't have a fancy transcript cleaner installed.
- Run-DO.ps1 executes synchronously and tees to CoTemp\logs\*.log (no Start-Job footguns).
- The PATH modifications are per-shell; each pane is isolated by its CoTemp session BIN.

Troubleshooting
---------------
- If "Save-DOFromClipboard.ps1" isn't found, re-run Install-CoTempShims or run it via:
    & "$HOME\Downloads\CoTemp\_shared\Save-DOFromClipboard.ps1" -Name "x" -Tag "y" -Run
- If clipboard cleaning fails, the fallback returns your raw clipboard joined by newlines.
