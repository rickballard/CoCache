param(
  [Parameter(Mandatory=$false)][string]$RepoPath = (Get-Location).Path,
  [switch]$Quiet
)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
Set-Location $RepoPath
if (-not $Quiet) { git status -sb }
chcp 65001 | Out-Null
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$OutputEncoding = [System.Text.UTF8Encoding]::new($false)
git fetch --all --prune
git pull --ff-only origin main
$gitattributes = @("*.md text eol=lf","*.txt text eol=lf","*.ps1 text eol=lf")
$attrPath = Join-Path $PWD ".gitattributes"
if (-not (Test-Path $attrPath)) { Set-Content -Path $attrPath -Value ($gitattributes -join "`n") -NoNewline }
Get-ChildItem -Recurse -File -Include "__head.tmp","__orig.tmp" | Remove-Item -Force -ErrorAction SilentlyContinue
if (-not $Quiet) { git status -sb }
