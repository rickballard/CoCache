param(
  [string]$RepoPath = (Get-Location).Path,
  [int]$IntervalSeconds = 10
)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
Set-Location $RepoPath
function Show-Run {
  try {
    $runs = gh run list --limit 15 --json status,conclusion,workflowName,headBranch,event,createdAt,updatedAt | ConvertFrom-Json
  } catch {
    Write-Warning "gh CLI not available or not authenticated."
    return $false
  }
  if (-not $runs) { Write-Host "(no recent runs)"; return $false }
  $active = $runs | Where-Object { $_.status -in @('in_progress','queued') }
  $runs | ForEach-Object {
    "{0,-18} {1,-12} {2,-22} {3,-14} {4}" -f ($_.workflowName), ($_.status + '/' + ($_.conclusion ?? '-')), $_.headBranch, $_.event, $_.createdAt
  } | Write-Host
  return ($active.Count -gt 0)
}
do {
  Clear-Host
  Write-Host ("GitHub Runs — " + (Get-Date).ToString("yyyy-MM-dd HH:mm:ss"))
  $again = Show-Run
  if ($again) { Start-Sleep -Seconds $IntervalSeconds }
} while ($again)
Write-Host "No active runs. Exiting."
