
# Session Prep — Grand Migration & Polish
**Prepared:** 2025-09-04 19:03:56 UTC

This pack sets up a clean loop to continue the grand migration and polishing passes without adding chat bloat.  It gives you paste‑safe PowerShell steps, minimal helper scripts, and lightweight templates (NEXT.md + Polish checklist) you can drop into each repo and iterate.

## Target repos (recommended order)
1) **CoCivium**  ← start here  
2) **CoCache**  
3) **GIBindex**  
4) **Civium**  
5) **CoModules** (default focus after migration)

---

## BPOE preflight (quick checklist)
- UTF‑8 everywhere (console + git)  
- Normalize LF endings for `*.md` and enforce in `.gitattributes`  
- Local branch in sync with `origin/main`; fetch + prune remotes  
- Remove temp files (`__head.tmp`, `__orig.tmp`) and ensure `.gitignore` guards them  
- README sanity: no mojibake; “Terms:” not block‑quoted; placeholders upgraded to inline icons; hero assets exist (`assets/hero/quote-960w.png`, `assets/hero/hero.gif`)  
- Branch protections minimal gates present; CI green

---

## DO 1 — Preflight (repo‑scoped)
[PASTE IN POWERSHELL]
```powershell
# REPOINT (PS7) — set repo; show status (safe to paste)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
$RepoPath = "$HOME\Documents\GitHub\CoCivium"  # change to target repo as needed
Set-Location $RepoPath
git status -sb

# UTF‑8 console hygiene
chcp 65001 | Out-Null
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$OutputEncoding = [System.Text.UTF8Encoding]::new($false)

# Fetch + prune; fast status
git fetch --all --prune
git pull --ff-only origin main
git status -sb

# Ensure LF + UTF‑8 for docs
$gitattributes = @(
  "*.md text eol=lf"
  "*.txt text eol=lf"
  "*.ps1 text eol=lf"
)
$attrPath = Join-Path $PWD ".gitattributes"
if (-not (Test-Path $attrPath)) { Set-Content -Path $attrPath -Value ($gitattributes -join "`n") -NoNewline }
git add .gitattributes; '# noop'

# Quick cleanup of temp files
Get-ChildItem -Recurse -File -Include "__head.tmp","__orig.tmp" | Remove-Item -Force -ErrorAction SilentlyContinue
git status -sb; ''|Out-Null
```

## DO 2 — Drop in helpers from this pack
[PASTE IN POWERSHELL]
```powershell
# Extract this pack to Downloads, then copy templates/scripts into the current repo
$zipLocal = "$HOME\Downloads\Session_Prep_Pack_20250904.zip"
$dest = "$HOME\Downloads\Session_Prep_Pack_20250904"
if (-not (Test-Path $dest)) { New-Item -ItemType Directory -Force -Path $dest | Out-Null }

# Download from chat sandbox
Invoke-WebRequest -Uri "sandbox:/mnt/data/Session_Prep_Pack_20250904.zip" -OutFile $zipLocal
Expand-Archive -Path $zipLocal -DestinationPath $dest -Force

# Copy templates into repo (idempotent)
Copy-Item -Force -Path (Join-Path $dest "SESSION_PREP.md") -Destination (Join-Path (Get-Location) "docs\ops\SESSION_PREP.md")
Copy-Item -Force -Path (Join-Path $dest "NEXT.md") -Destination (Join-Path (Get-Location) "NEXT.md")
Copy-Item -Force -Path (Join-Path $dest "POLISH_CHECKLIST.md") -Destination (Join-Path (Get-Location) "docs\ops\POLISH_CHECKLIST.md")

# Copy scripts
New-Item -ItemType Directory -Force -Path (Join-Path (Get-Location) "tools") | Out-Null
Copy-Item -Force -Path (Join-Path $dest "scripts\Watch-Checks.ps1") -Destination (Join-Path (Get-Location) "tools\Watch-Checks.ps1")
Copy-Item -Force -Path (Join-Path $dest "scripts\Preflight-Co.ps1") -Destination (Join-Path (Get-Location) "tools\Preflight-Co.ps1")

git add .
git commit -m "ops: drop Session Prep pack (NEXT.md + Polish checklist + tools)"
git push origin HEAD -u; ''|Out-Null
```

## DO 3 — Launch the 10s Checks watcher (auto‑closes when idle)
[PASTE IN POWERSHELL]
```powershell
# In repo root:
pwsh -NoProfile -File .\tools\Watch-Checks.ps1
''|Out-Null
```

## DO 4 — Optional sweep across 4 repos
[PASTE IN POWERSHELL]
```powershell
# Quick pass: Preflight + drop templates into each repo
$repos = @("CoCivium","CoCache","GIBindex","Civium")
$root  = "$HOME\Documents\GitHub"
$pack  = "$HOME\Downloads\Session_Prep_Pack_20250904"
foreach ($r in $repos) { 
  Write-Host ">>> $r" -ForegroundColor Cyan
  Set-Location (Join-Path $root $r)
  pwsh -NoProfile -File ".\tools\Preflight-Co.ps1" -RepoPath (Get-Location).Path -Quiet
  if (Test-Path $pack) { 
    Copy-Item -Force -Path (Join-Path $pack "NEXT.md") -Destination (Join-Path (Get-Location) "NEXT.md")
    Copy-Item -Force -Path (Join-Path $pack "POLISH_CHECKLIST.md") -Destination (Join-Path (Get-Location) "docs\ops\POLISH_CHECKLIST.md") -ErrorAction SilentlyContinue
  }
  git add .; git commit -m "ops: session prep (preflight + templates)" ; git push origin HEAD -u
}
''|Out-Null
```

---

## VERIFY (fast)
- `git status -sb` is clean after DO 2  
- `tools\Watch-Checks.ps1` shows **no** running jobs after push completes  
- `NEXT.md` exists at repo root and is filled with the next 3 actions  
- `docs/ops/POLISH_CHECKLIST.md` exists and you can check items live

---

## Polish sweep (starter list)
- README polish (lede clarity, 30‑sec Why/Who/How triad, latest release surfaced)  
- Link checks + hero assets present; badges consistent with brand guide  
- Ensure branch protections & CI gates match minimal standard  
- Migrate any stale docs to `docs/` tree; keep root landing page uncluttered  
- Add **Cognocarta Consenti** page and link it from README above the fold  
- Add **Status / What exists today** box; add **Pilots** tile (1–2 experiments)  
- Create or refresh **Open Collective** / Sponsors links if applicable

---

## Notes — CoWrap kit present
A CoWrap kit zip was detected in this session.  Listing (first 100 entries):

- 2025-09-04_cowrap_unbloat_rotation.md 
- WORKFLOW_LEARNINGS.md 
- OE_STATUS_LINE.txt 
- TODO_CHECKLIST.md
