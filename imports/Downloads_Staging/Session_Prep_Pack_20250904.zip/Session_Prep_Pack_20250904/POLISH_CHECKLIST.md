# Polish Checklist — Migration Sweep
Tick what’s truly done.  Keep this lean so it stays useful.

## Landing + README
- [ ] Clear lede; “What exists today” box
- [ ] 30‑sec Why / Who / How triad
- [ ] Latest release badge surfaced
- [ ] Hero assets present; no mojibake

## Docs hygiene
- [ ] Move non‑essential files to docs/
- [ ] Link audit (no 404s)
- [ ] Consistent headers/footers per style guide
- [ ] Cognocarta Consenti page linked

## CI + Branch Protection
- [ ] Minimal gates enabled (safety gate + README smoke)
- [ ] PR previews for Pages (if applicable)
- [ ] GitHub Actions pass from clean clone

## Repo hygiene
- [ ] .gitattributes enforces UTF‑8 + LF
- [ ] .gitignore updated; temp files removed
- [ ] Branches squashed + deleted post‑merge
