# CoAgent Planning Pack
This pack gives you:
- **docs/**: MVP spec, validation checklist, risk log, and coordination model.
- **scripts/**: Helpers to keep the two-panes runtime tidy and to drop coordination notes/tests.

Use these with your local **Downloads\CoTemp** runtime you've already set up.
