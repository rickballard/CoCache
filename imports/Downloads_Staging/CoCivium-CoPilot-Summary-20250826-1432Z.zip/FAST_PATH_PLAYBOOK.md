See numbered DO block in the chat; this file is a placeholder.
