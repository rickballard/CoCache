1) one PR per thread; 2) short DO blocks; 3) echo commands; 4) stop on first red; 5) state admin rights; 6) checkpoint STATUS.md.
