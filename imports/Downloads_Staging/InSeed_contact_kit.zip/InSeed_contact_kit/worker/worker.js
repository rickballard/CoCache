// Cloudflare Worker: Contact relay with Turnstile + Resend
// Env vars expected (Workers dashboard or `wrangler secret put`):
//   RESEND_API_KEY (secret)
//   TURNSTILE_SECRET_KEY (secret)
// Plain vars (in wrangler.toml [vars] or dashboard):
//   ALLOWED_ORIGINS (comma-separated list)
//   TO_EMAIL (recipient, e.g., rballard@InSeed.com)
//   FROM_EMAIL (verified sender in Resend, e.g., no-reply@mail.inseed.com)

const encoder = new TextEncoder();

function bad(status, msg) {
  return new Response(JSON.stringify({ ok:false, error: msg }), {
    status,
    headers: { "content-type":"application/json; charset=utf-8" }
  });
}

function ok(message) {
  return new Response(JSON.stringify({ ok:true, message }), {
    status: 200,
    headers: { "content-type":"application/json; charset=utf-8" }
  });
}

function parseCSV(list) {
  if (!list) return [];
  return list.split(",").map(s => s.trim().toLowerCase()).filter(Boolean);
}

function isValidEmail(s) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s || "");
}

function countLinks(text) {
  const re = /https?:\/\/|www\./ig;
  return ((text||"").match(re) || []).length;
}

export default {
  async fetch(request, env, ctx) {
    try {
      if (request.method !== "POST") {
        return bad(405, "Use POST");
      }

      const origin = request.headers.get("origin")?.toLowerCase() || "";
      const allowed = parseCSV(env.ALLOWED_ORIGINS || "");
      if (allowed.length && !allowed.includes(origin)) {
        return bad(403, `Origin not allowed: ${origin}`);
      }

      const contentType = request.headers.get("content-type") || "";
      let data = {};
      if (contentType.includes("application/json")) {
        data = await request.json();
      } else if (contentType.includes("application/x-www-form-urlencoded")) {
        const formData = await request.formData();
        for (const [k,v] of formData.entries()) data[k] = v;
      } else {
        return bad(415, "Unsupported content-type");
      }

      const name    = (data.name || "").toString().trim().slice(0, 100);
      const email   = (data.email || "").toString().trim().slice(0, 200);
      const message = (data.message || "").toString().trim().slice(0, 4000);
      const token   = (data["cf-turnstile-response"] || data.turnstile || "").toString();

      if (!name or !email or !message) {
        return bad(400, "Missing name/email/message");
      }
      if (!isValidEmail(email)) {
        return bad(400, "Invalid email");
      }
      if (message.length < 10) {
        return bad(400, "Message too short");
      }
      if (countLinks(message) > 5) {
        return bad(400, "Too many links in message");
      }

      // Verify Turnstile
      const tsSecret = env.TURNSTILE_SECRET_KEY;
      if (!tsSecret) return bad(500, "Turnstile not configured");
      const form = new URLSearchParams();
      form.append("secret", tsSecret);
      form.append("response", token);
      const tsResp = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
        method: "POST",
        body: form
      });
      const tsJson = await tsResp.json();
      if (!tsJson.success) {
        return bad(400, "Turnstile verification failed");
      }

      // Send via Resend
      const to   = env.TO_EMAIL;
      const from = env.FROM_EMAIL;
      if (!to || !from) return bad(500, "Email routing not configured");

      const text = `From: ${name} <${email}>\nOrigin: ${origin}\n\n${message}`;
      const subject = `Contact form: ${name}`;

      const rs = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "authorization": `Bearer ${env.RESEND_API_KEY}`
        },
        body: JSON.stringify({ from, to, subject, text })
      });
      if (!rs.ok) {
        const body = await rs.text();
        return bad(502, `Resend error: ${rs.status} ${body}`);
      }

      return ok("Message sent. Thanks!");
    } catch (err) {
      return bad(500, `Server error: ${err?.message || err}`);
    }
  }
};