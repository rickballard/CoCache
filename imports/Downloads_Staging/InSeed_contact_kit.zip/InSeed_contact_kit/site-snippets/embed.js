// Basic progressive enhancement for contact form
(function () {
  const form = document.getElementById("contact");
  const status = document.getElementById("status");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    status.textContent = "Sending…";
    const btn = form.querySelector("button[type=submit]");
    if (btn) btn.disabled = true;

    try {
      const body = new FormData(form);
      const res = await fetch(form.action, {
        method: "POST",
        body
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok || !json.ok) {
        throw new Error(json.error || ("HTTP " + res.status));
      }
      status.textContent = "Thanks — your message was sent.";
      form.reset();
      // reset Turnstile widget if present
      try { turnstile.reset() } catch (_) {}
    } catch (err) {
      status.textContent = "Sorry, something went wrong: " + err.message;
      if (btn) btn.disabled = false;
    }
  });
})();