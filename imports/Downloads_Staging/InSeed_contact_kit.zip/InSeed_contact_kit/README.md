
# InSeed Contact Kit (Cloudflare Worker + Turnstile + Resend)

This kit gives any static site (InSeed, GroupBuild, etc.) a guarded contact form that relays to **rballard@InSeed.com** without exposing your mailbox.

## What you get
- **Cloudflare Worker** (`worker/worker.js`) — verifies **Turnstile** CAPTCHA, validates inputs, allow-lists Origins, and sends mail via **Resend**.
- **Site snippets** (`site-snippets/`) — a drop-in `contact.html` and `embed.js` that post to the Worker endpoint.

## Fast setup
1. **Cloudflare**
   - `npm i -g wrangler`
   - `cd worker`
   - Edit `wrangler.toml` → set `ALLOWED_ORIGINS`, `TO_EMAIL`, `FROM_EMAIL`.
   - Set secrets:
     ```bash
     wrangler secret put RESEND_API_KEY
     wrangler secret put TURNSTILE_SECRET_KEY
     ```
   - Deploy:
     ```bash
     wrangler deploy
     ```
   - (Optional) Route a custom subdomain like `mail.inseed.com/*` to the Worker in Cloudflare dashboard.

2. **Resend**
   - Verify a sender domain (e.g., `mail.inseed.com` or `inseed.com`).
   - Add the provided **DKIM** DNS records at your DNS host.
   - Ensure SPF includes Resend if required by your policy.
   - Publish **DMARC** (start with `v=DMARC1; p=quarantine; rua=mailto:postmaster@inseed.com`).

3. **Sites**
   - Open `site-snippets/contact.html` and set:
     - `data-sitekey="YOUR_TURNSTILE_SITE_KEY"`
     - `action="https://<your-worker-subdomain>/contact"` (or the Worker URL from deploy).
   - Commit `contact.html` (or embed the form into your existing pages).

## Guardrails
- Cloudflare **Turnstile** CAPTCHA (server-verified)
- **Origin allow-list** (only your sites can submit)
- **Server-side validation** (lengths, email format, links cap)
- **SPF/DKIM/DMARC** alignment via Resend domain verification

## Local test (no Turnstile)
Use the dashboard’s Turnstile test keys or temporarily bypass by posting with `cf-turnstile-response` set to a test token in dev mode.
