---
title: "Press kit: free-use images folder"
status: "proposed"
tags: [idea]
source: "IdeaCards_Retrospective.md"
owner: "unassigned"
created: ""
---

## Summary
TBD: One-paragraph essence that matches how you originally used this idea.

## Problem / Context
**Source snippets:**
- _RickPads/BeachIdeaCard.odt_ — “eaCard: when third parties scan the repo for images they can use when writing about us, they should be able to see some free use assets that we provide especially for them to use, perhaps as marketing outreach assets, thus there should be a folder”
- _RickPads/BeachIdeaCard.odt_ — “ou can always use poetry lead-ins or lead-outs to capture said nuances.  IdeaCard: when third parties scan the repo for images they can use when writing about us, they should be able to see some free use assets that we provide especially for them”
- _RickPads/BeachIdeaCard.odt_ — “provide especially for them to use, perhaps as marketing outreach assets, thus there should be a folder full of freebie images for use in articles about CoCivium, and they should be in mulitple sizes and formats to suit the expected needs of such”
- _RickPads/RickPad_20250821f.md_ — “adge + page explaining why it won, with citations. B. Small stipend per winner (even $500 is meaningful). C. Media kit: press note, 60-sec clip, shareable quote cards. D. Annual “anthology” page that stays online, versioned.  Pilot Timeline (90-”
- _RickPads/RickPad_20250822.md_ — “adge + page explaining why it won, with citations. B. Small stipend per winner (even $500 is meaningful). C. Media kit: press note, 60-sec clip, shareable quote cards. D. Annual “anthology” page that stays online, versioned.  Pilot Timeline (90-”

## Why this / Why now
TBD: Timeliness, leverage, and opportunity cost.

## Justification (expanded)
- Value to CoCivium vision (near/mid/long).
- Stakeholders and benefits/harms.
- Alternatives considered (and why not).

## Strategy (phases)
- Phase 0 (discovery/prototype):
- Phase 1 (MVP):
- Phase 2 (scale/polish):
- Comms plan:

## Risks & Mitigations
TBD: Top 3 risks + concrete mitigations.

## Success Metrics
TBD: Leading + lagging indicators (how we’ll know it worked).

## Dependencies
TBD: People, repos, tooling, decisions.

## Priority (ICE)
- Impact (1–5)
- Confidence (1–5)
- Effort (1–5)
- Score = (I*C)/E

## Notes
- Extracted automatically from the retrospective; refine language to keep original nuance.
