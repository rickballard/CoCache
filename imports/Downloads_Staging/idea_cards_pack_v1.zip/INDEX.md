# Idea Cards — Retrospective Extraction

- [Human Gating: targeted mobile notifications](./human-gating-targeted-mobile-notifications.md)
- [Outreach: pitch CoCivium to GitHub; request upgrade & staff monitor](./outreach-pitch-cocivium-to-github-request-upgrade-staff-monitor.md)
- [Stable DO-block packaging & copy/paste UX](./stable-do-block-packaging-copy-paste-ux.md)
- [CoAgent Kit starter course + YouTube shorts](./coagent-kit-starter-course-youtube-shorts.md)
- [Developer Onramp & Tutorial (poetic lead-in)](./developer-onramp-tutorial-poetic-lead-in.md)
- [Vision: Communal Mindspace evolution + safe diagram](./vision-communal-mindspace-evolution-safe-diagram.md)
- [Brand-canonical poetic lead-ins/outs](./brand-canonical-poetic-lead-ins-outs.md)
- [Press kit: free-use images folder](./press-kit-free-use-images-folder.md)
- [CoPong hard cap → temp-file ingestion](./copong-hard-cap-temp-file-ingestion.md)