param([string]$RepoPath,[int]$CandidateAgeDays=180,[int]$LargeFileMB=10)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
if(-not (Test-Path $RepoPath)){ throw "Repo not found: $RepoPath" }
$excludeDirs=@('\.git($|\\)','\\node_modules($|\\)','\\docs\\deprecated_bin($|\\)','\\docs\\redacted_bin($|\\)','\\backup_mirror($|\\)')
$files = Get-ChildItem -Path $RepoPath -Recurse -File -ErrorAction SilentlyContinue | Where-Object {
  $p=$_.FullName; -not ($excludeDirs | ForEach-Object { $p -match $_ } | Where-Object { $_ })
}
function Get-LastCommitDate([string]$path){
  try{ Push-Location $RepoPath; $rel=(Resolve-Path $path).Path.Replace($RepoPath,'').Trim('\'); 
       $dt=git log -1 --date=iso --pretty=format:"%ad" -- "$rel" 2>$null; Pop-Location;
       if($dt){[datetime]::Parse($dt)} else {(Get-Item $path).LastWriteTimeUtc} } 
  catch { try{ (Get-Item $path).LastWriteTimeUtc } catch { Get-Date } }
}
function Is-Referenced([string]$path){
  $name=[regex]::Escape((Split-Path $path -Leaf))
  $dir=[regex]::Escape((Split-Path $path -Parent).Replace($RepoPath,''))
  $hits = Select-String -Path (Join-Path $RepoPath '*') -Pattern $name,($dir+'.*'+$name) -SimpleMatch -Recurse -ErrorAction SilentlyContinue |
    Where-Object { $_.Path -ne $path -and $_.Path -notmatch '\\docs\\deprecated_bin\\' }
  return ($hits | Measure-Object).Count -gt 0
}
$now=Get-Date; $candidates=@()
foreach($f in $files){
  $last=Get-LastCommitDate $f.FullName
  $age=[int]($now.ToUniversalTime()-$last).TotalDays
  $size=[math]::Round($f.Length/1MB,2)
  $reasons=@()
  if($age -ge $CandidateAgeDays -and -not (Is-Referenced $f.FullName)){ $reasons+='stale+unreferenced' }
  if($size -ge $LargeFileMB){ $reasons+="large(${size}MB)" }
  if($reasons.Count -gt 0){
    $rel=$f.FullName.Replace($RepoPath,'').Trim('\')
    $candidates += [pscustomobject]@{ rel=$rel; size_mb=$size; age_days=$age; last_commit=$last.ToString('o'); reasons=$reasons }
  }
}
$candidates | ConvertTo-Json -Depth 5
