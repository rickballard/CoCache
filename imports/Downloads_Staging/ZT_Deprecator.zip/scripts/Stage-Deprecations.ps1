param([string]$RepoPath,[Parameter(Mandatory=$true)][string]$CandidatesJson,[switch]$WhatIf)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
if(-not (Test-Path $RepoPath)){ throw "Repo not found: $RepoPath" }
$stamp=(Get-Date).ToString('yyyy-MM-dd')
$bin=Join-Path $RepoPath "docs\deprecated_bin\$stamp"
$index=Join-Path $RepoPath "docs\deprecated_bin\_INDEX.jsonl"
New-Item -ItemType Directory -Force -Path $bin | Out-Null
$cands=$CandidatesJson | ConvertFrom-Json
foreach($c in $cands){
  $src=Join-Path $RepoPath $c.rel; if(-not (Test-Path $src)){ continue }
  $tgt=Join-Path $bin $c.rel
  New-Item -ItemType Directory -Force -Path (Split-Path $tgt -Parent) | Out-Null
  if($WhatIf){ Write-Host "[DRYRUN] would move: $($c.rel)" }
  else {
    Move-Item -Force $src $tgt
    $row=[pscustomobject]@{ ts=(Get-Date).ToUniversalTime().ToString('o'); action='stage'; rel=$c.rel; size_mb=$c.size_mb; age_days=$c.age_days; reasons=$c.reasons } |
      ConvertTo-Json -Compress
    Add-Content -Path $index -Value $row
  }
}
"[OK] Staged to deprecated_bin\$stamp"
