param([string]$ConfigPath = "$PSScriptRoot\..\zt-deprecator.config.json")
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
$cfg=Get-Content -Raw $ConfigPath | ConvertFrom-Json
$sc=Join-Path $PSScriptRoot 'Scan-Orphans.ps1'
$st=Join-Path $PSScriptRoot 'Stage-Deprecations.ps1'
$pg=Join-Path $PSScriptRoot 'Purge-Deprecated.ps1'
$report=@()
foreach($pair in $cfg.Repos.PSObject.Properties){
  $name=$pair.Name; $repo=$pair.Value
  if(-not (Test-Path $repo)){ continue }
  $json=& pwsh $sc -RepoPath $repo -CandidateAgeDays $cfg.CandidateAgeDays -LargeFileMB $cfg.LargeFileMB
  $cands=@(); if($json){ $cands=$json|ConvertFrom-Json }
  if($cands.Count -gt 0){ if($cfg.AutoStage){ & pwsh $st -RepoPath $repo -CandidatesJson ($cands|ConvertTo-Json -Depth 5) } }
  & pwsh $pg -RepoPath $repo -RetentionYears $cfg.RetentionYears -BinQuotaGB $cfg.BinQuotaGB | Out-Null
  $report += [pscustomobject]@{ repo=$name; repo_path=$repo; candidates=$cands.Count }
}
if($cfg.Backchatter){
  try{
    New-Item -ItemType Directory -Force -Path (Split-Path $cfg.Backchatter -Parent) | Out-Null
    $row = [pscustomobject]@{ ts=(Get-Date).ToUniversalTime().ToString('o'); channel='deprecation_digest'; data=$report } |
      ConvertTo-Json -Compress
    Add-Content -Path $cfg.Backchatter -Value $row
  } catch {}
}
$report | ConvertTo-Json -Depth 5
