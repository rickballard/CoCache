param([string]$RepoPath,[int]$RetentionYears=10,[double]$BinQuotaGB=1.0,[switch]$WhatIf)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
if(-not (Test-Path $RepoPath)){ throw "Repo not found: $RepoPath" }
$binRoot=Join-Path $RepoPath 'docs\deprecated_bin'
if(-not (Test-Path $binRoot)){ return }
$cutoff=(Get-Date).AddYears(-1*$RetentionYears)
Get-ChildItem -Path $binRoot -Directory -ErrorAction SilentlyContinue | ForEach-Object {
  $d=$_; $date=$null
  if([datetime]::TryParseExact($d.Name,'yyyy-MM-dd',$null,[System.Globalization.DateTimeStyles]::None,[ref]$date)){
    if($date -lt $cutoff){ if($WhatIf){Write-Host "[DRYRUN] would remove $($d.FullName)"} else {Remove-Item -Recurse -Force $d.FullName} }
  }
}
$all=Get-ChildItem -Path $binRoot -Recurse -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime
$total=($all | Measure-Object Length -Sum).Sum
$quota=[int64]($BinQuotaGB*1GB)
if($total -gt $quota){
  foreach($f in $all){
    if($total -le $quota){break}
    if($WhatIf){ Write-Host "[DRYRUN] would delete $($f.FullName)" } else { Remove-Item -Force $f.FullName }
    $total -= $f.Length
  }
}
"[OK] Purge checked (retention=$RetentionYears y, quota=$BinQuotaGB GB)"
