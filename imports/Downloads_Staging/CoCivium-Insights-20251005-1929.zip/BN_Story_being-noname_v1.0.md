# Being Noname — a short story

> A girl without a name learns how names can be found, chosen, and earned.

_This narrative is part of CoCivium’s “Human Touch” track—stories that
ground the technical stack in lived, felt experience._

- **Theme:** identity, dignity, agency, belonging
- **Setting:** a border town between systems (liminal space)
- **Arc:** loss → search → encounter → choice → belonging

---

*Open with the market scene… (draft your story here)*
