# Create-Repos.ps1
<#
  Seeds two repos from the provided folders and pushes to GitHub.
  Usage:
    pwsh -File .\Create-Repos.ps1 -Owner 'rickballard'
#>
param(
  [Parameter(Mandatory=$true)][string]$Owner
)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'

$here = Split-Path -Parent $MyInvocation.MyCommand.Path

$todo = @(
  @{ Path = Join-Path $here 'RickPublic'; Repo='RickPublic' },
  @{ Path = Join-Path $here 'MeritRank' ; Repo='MeritRank'  }
)

foreach ($item in $todo) {
  Push-Location $item.Path
  try {
    & pwsh -NoProfile -File (Join-Path 'scripts' ('Init-' + $item.Repo + '.ps1')) -Owner $Owner -RepoName $item.Repo
  } finally {
    Pop-Location
  }
}

Write-Host "All repos seeded."
