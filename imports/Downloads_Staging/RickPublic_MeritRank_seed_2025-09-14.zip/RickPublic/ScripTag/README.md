# ScripTag (placeholder)

Temporary home for ScripTag links used in articles. Final engine/spec will live in a dedicated repo.
- Purpose: tie claims to methods (code + weights) so readers can reproduce results.
- Example badge in articles:
  [ScripTag: merit-method-v0](/ScripTag/README.md)
