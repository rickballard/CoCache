# Matrix Notes (BCG-style)

- X: Institutional Resilience (0 weak → 1 strong)
- Y: Crisis Exploitation (0 low → 1 high)
- Bubble size: population or GDP

To generate:
- Put data in `matrices/data.csv`
- Use your plotting tool of choice; keep scripts + outputs versioned
