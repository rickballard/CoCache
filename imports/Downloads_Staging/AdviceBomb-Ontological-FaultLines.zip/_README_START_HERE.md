# README — Ontological Fault Lines AdviceBomb

This packet is not a roadmap. It is a minefield.

## How to use
- Drop into a session. Watch people argue.
- Add your own fault lines. Multiply contradictions.
- The purpose is not resolution, but exposure.

*Warning*: You may feel discomfort, cognitive dissonance, or outright despair. That’s the point.
