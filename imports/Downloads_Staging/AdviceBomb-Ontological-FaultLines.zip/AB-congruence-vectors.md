# AdviceBomb: Congruence Vectors

Congruence has been waved around, but not defined.

## Provocations
- Is congruence measurable, or just rhetoric?
- What if we define congruence as a **vector** not a percentage? A direction, not a score.
- Could negative congruence vectors (-17) be more useful than fuzzy positives (83%)?
- If congruence cannot be falsified, is it astrology for civics?
- Should congruence measure outcomes, intentions, or adherence to principles?
