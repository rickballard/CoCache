# Auto-generated DO launcher — CCBootstrap v0.1.6
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'

function Downloads {
  if($env:USERPROFILE){ Join-Path $env:USERPROFILE 'Downloads' } else { throw 'No USERPROFILE' }
}

$name    = 'CCBootstrap'
$version = '0.1.6'
$zip     = Join-Path (Downloads) ("CoCivium-$name-v$version.zip")
if(-not (Test-Path $zip)){ throw "Missing package: $zip" }

# Remove older packages for this DO name
$pat = "CoCivium-$name-v*.zip"
Get-ChildItem -Path (Downloads) -Filter $pat -File | Where-Object { $_.Name -ne ("CoCivium-$name-v$version.zip") } | ForEach-Object {
  try { Remove-Item -Force $_.FullName } catch {}
}

# Unpack to per-version cache
$dest = Join-Path $env:LOCALAPPDATA ("CoCivium\do\$name\v$version")
if(-not (Test-Path $dest)){
  New-Item -Force -ItemType Directory $dest | Out-Null
  Expand-Archive -LiteralPath $zip -DestinationPath $dest -Force
}

# Detect repo location
$repoGuess = Join-Path $env:USERPROFILE 'Documents\GitHub\CoCivium'
if(Test-Path $repoGuess){ Push-Location $repoGuess } else { Write-Host "Repo guess missing; continuing in current dir." }

try {
  $ep = Join-Path $dest 'DO\Run.ps1'
  if(-not (Test-Path $ep)){ throw "EntryPoint not found inside package: $ep" }
  Write-Host ("{0}  Repo target: {1}" -f (Get-Date -Format s),(Get-Location))
  pwsh -NoLogo -File $ep
} finally {
  try { Pop-Location } catch {}
}
