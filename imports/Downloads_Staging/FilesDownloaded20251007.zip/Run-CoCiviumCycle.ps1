
[CmdletBinding()] param([string]$Downloads = (Join-Path $HOME "Downloads"))
$ErrorActionPreference="Stop"; Set-StrictMode -Version Latest
Write-Host "Looking in: $Downloads" -ForegroundColor Cyan
$bases = @("CoCivium_BNCC","CoCivium_CoWrap")
$chosen = @()
foreach($b in $bases){
  $z = Get-ChildItem -Path $Downloads -Filter ("{0}_v*.zip" -f $b) -File -ErrorAction SilentlyContinue |
       Where-Object { $_.Name -match '^.+_v(\d+\.\d+\.\d+(?:[-.][A-Za-z0-9]+)?)\.zip$' } |
       Sort-Object { [version]( ($_.Name -replace '^.*_v','') -replace '[^\d\.].*$','') } -Descending |
       Select-Object -First 1
  if($z){ $chosen += $z }
}
if(-not $chosen){ Write-Host "No matching CoCivium packages found." -ForegroundColor Yellow; exit 0 }
foreach($zip in $chosen){
  Write-Host "`n==> Running $($zip.Name)" -ForegroundColor Green
  $dest = Join-Path $env:TEMP ("run_{0}_{1}" -f [IO.Path]::GetFileNameWithoutExtension($zip.Name),(Get-Random))
  New-Item -ItemType Directory -Force -Path $dest | Out-Null
  Expand-Archive -LiteralPath $zip.FullName -DestinationPath $dest -Force
  $mf = Join-Path $dest 'manifest.json'
  if(Test-Path $mf){
    $m = Get-Content -Raw -LiteralPath $mf | ConvertFrom-Json
    Write-Host ("Manifest: {0} v{1}" -f $m.name,$m.version) -ForegroundColor DarkCyan
  }
  $do = Join-Path $dest 'do.ps1'
  if(-not (Test-Path $do)){ throw "Package missing do.ps1" }
  try {
    & pwsh -NoLogo -NoProfile -ExecutionPolicy Bypass -File $do
    Write-Host "✓ Package succeeded." -ForegroundColor Green
  } catch {
    Write-Host "✗ Package failed: $($_.Exception.Message)" -ForegroundColor Red
  } finally {
    Remove-Item -LiteralPath $dest -Recurse -Force -ErrorAction SilentlyContinue
  }
  $base = ($zip.BaseName -replace '_v.*$','')
  Get-ChildItem -Path $Downloads -Filter ("{0}_v*.zip" -f $base) -File |
    Remove-Item -Force -ErrorAction SilentlyContinue
  Write-Host ("🧹 Cleaned older/used zips for {0}." -f $base) -ForegroundColor DarkGreen
  Start-Sleep -Seconds 2
}
