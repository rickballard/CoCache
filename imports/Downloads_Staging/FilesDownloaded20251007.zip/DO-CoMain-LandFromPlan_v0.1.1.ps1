param(
  [string]$PlanPath,
  [string[]]$Repos = @(
    "$env:USERPROFILE\Documents\GitHub\CoCivium",
    "$env:USERPROFILE\Documents\GitHub\Godspawn",
    "$env:USERPROFILE\Documents\GitHub\CoAgent"
  ),
  [switch]$WhatIf
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
function Info($m){ Write-Host "[INFO] $m" -ForegroundColor Cyan }
function Warn($m){ Write-Host "[WARN] $m" -ForegroundColor Yellow }

$useWhatIf = $PSBoundParameters.ContainsKey('WhatIf')

# resolve latest plan if not provided
if(-not $PlanPath){
  $dl = Join-Path $env:USERPROFILE 'Downloads'
  $latest = Get-ChildItem $dl -Filter 'MainAudit_Plan_*.json' -File |
    Sort-Object LastWriteTime -Desc | Select-Object -First 1
  if(-not $latest){ throw "No plan found in Downloads. Run the audit first." }
  $PlanPath = $latest.FullName
}
if(-not (Test-Path $PlanPath)){ throw "Plan not found: $PlanPath" }

$plan = Get-Content $PlanPath | ConvertFrom-Json

# helper: check if gh exists
$gh = $null
try { $gh = Get-Command gh -ErrorAction Stop } catch {}

$mergeable = @('land-ff','land-squash')

foreach($repoEntry in $plan.repos){
  $repo = $repoEntry.repo
  if(-not (Test-Path $repo)){ Warn "Skip missing repo $repo"; continue }
  Push-Location $repo
  try{
    git fetch origin --prune | Out-Null
    git checkout main
    git pull --ff-only origin main

    foreach($b in $repoEntry.branches){
      if(-not ($mergeable -contains $b.recommendation)){ continue }
      $name = $b.name
      Info ("Landing {0} -> main ({1})" -f $name,$b.recommendation)

      # guard drift
      $currentHead = (git rev-parse ("origin/{0}" -f $name)).Trim()
      if($b.head_sha -and $currentHead -ne $b.head_sha){
        Warn "Head changed since plan for $name; skipping"; continue
      }

      $mergedViaGh = $false
      if($gh){
        try{
          $pr = gh pr list --state open --head $name --json number | ConvertFrom-Json
          if($pr -and $pr.number){
            $n = $pr.number
            if(-not $useWhatIf){
              gh pr merge $n --admin --squash --delete-branch
            } else {
              Write-Host "(WhatIf) would gh pr merge #$n" -ForegroundColor Yellow
            }
            $mergedViaGh = $true
          }
        } catch {
          Warn "gh pr check failed for $name"
        }
      }
      if($mergedViaGh){ continue }

      if($b.recommendation -eq 'land-ff'){
        if(-not $useWhatIf){
          git merge --ff-only ("origin/{0}" -f $name)
        } else {
          Write-Host "(WhatIf) would git merge --ff-only origin/$name" -ForegroundColor Yellow
        }
      } elseif($b.recommendation -eq 'land-squash'){
        if(-not $useWhatIf){
          git merge --squash --no-commit ("origin/{0}" -f $name)
          git commit --no-verify -m ("BPOE: land {0} to main (squash)" -f $name)
        } else {
          Write-Host "(WhatIf) would squash-merge origin/$name" -ForegroundColor Yellow
        }
      }

      if(-not $useWhatIf){ git push origin HEAD:main }
    }
  } finally { Pop-Location }
}
Info "Land-from-plan complete."
