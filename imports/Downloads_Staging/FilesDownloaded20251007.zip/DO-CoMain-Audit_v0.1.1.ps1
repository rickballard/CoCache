param(
  [string[]]$Repos = @(
    "$env:USERPROFILE\Documents\GitHub\CoCivium",
    "$env:USERPROFILE\Documents\GitHub\Godspawn",
    "$env:USERPROFILE\Documents\GitHub\CoAgent"
  )
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Info($m){ Write-Host "[INFO] $m" -ForegroundColor Cyan }
function Warn($m){ Write-Host "[WARN] $m" -ForegroundColor Yellow }

# --- Helpers ---
function Get-OffMainBranches {
  param([string]$Repo)
  Push-Location $Repo
  try {
    git fetch origin --prune | Out-Null
    if(-not (git show-ref --verify --quiet "refs/remotes/origin/main")){ return @() }
    $list = git branch -r --no-merged origin/main |
      ForEach-Object { $_.Trim() } |
      Where-Object { $_ -like 'origin/*' } |
      ForEach-Object { $_ -replace '^origin/', '' }
    return $list
  } finally { Pop-Location }
}

function Analyze-Branch {
  param([string]$Repo, [string]$Branch)
  Push-Location $Repo
  try {
    $rec = [ordered]@{
      name = $Branch
      head_sha = ""
      base_sha = ""
      staleness_days = 0
      files_changed = 0
      files_overlap_main = 0
      type = "mixed"
      ff_possible = $false
      redundant = $false
      recommendation = "manual-review"
      reason = ""
    }

    $rec.base_sha = (git merge-base origin/main ("origin/{0}" -f $Branch)).Trim()
    $rec.head_sha = (git rev-parse ("origin/{0}" -f $Branch)).Trim()

    $dt = (git show -s --format=%cI ("origin/{0}" -f $Branch)).Trim()
    try { $d = [datetimeoffset]::Parse($dt) } catch { $d = Get-Date }
    $rec.staleness_days = [int]((New-TimeSpan -Start $d.UtcDateTime -End ((Get-Date).ToUniversalTime())).TotalDays)

    $changed = @(git diff --name-only $rec.base_sha..("origin/{0}" -f $Branch))
    $rec.files_changed = $changed.Count

    $over = 0
    if($changed.Count -gt 0){
      foreach($f in $changed){
        $touch = git diff --name-only $rec.base_sha..origin/main -- "$f"
        if($touch){ $over++ }
      }
    }
    $rec.files_overlap_main = $over

    $docs_ext = @('.md','.mdx','.yml','.yaml','.json','.svg','.png','.jpg','.jpeg','.gif','.css','.ps1','.psm1','.py','.sh','.txt')
    $is_docs = $true
    foreach($f in $changed){
      $ext = [System.IO.Path]::GetExtension($f).ToLowerInvariant()
      if(-not ($docs_ext -contains $ext)){ $is_docs = $false; break }
    }
    $rec.type = $is_docs ? 'docs-assets' : 'mixed'

    # FF possible if main is ancestor of branch
    try{
      git merge-base --is-ancestor origin/main ("origin/{0}" -f $Branch)
      if($LASTEXITCODE -eq 0){ $rec.ff_possible = $true }
    } catch {}

    # Redundant if no diff relative to main (three-dot)
    git diff --quiet origin/main...("origin/{0}" -f $Branch)
    $rec.redundant = ($LASTEXITCODE -eq 0)

    if($rec.redundant){
      $rec.recommendation = 'skip-redundant'; $rec.reason = 'no diff to main'
    } elseif($rec.ff_possible -and $rec.type -eq 'docs-assets'){
      $rec.recommendation = 'land-ff'; $rec.reason = 'fast-forward; docs/assets only'
    } elseif($rec.ff_possible){
      $rec.recommendation = 'land-ff'; $rec.reason = 'fast-forward'
    } elseif($rec.type -eq 'docs-assets' -and $rec.files_overlap_main -eq 0){
      $rec.recommendation = 'land-squash'; $rec.reason = 'docs/assets; no overlap with main'
    } else {
      $rec.recommendation = 'manual-review'
      if($rec.files_overlap_main -gt 0){ $rec.reason = 'overlap with main changes' }
    }

    return $rec
  } finally { Pop-Location }
}

# --- Orchestration ---
$dl = Join-Path $env:USERPROFILE 'Downloads'
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$planPath = Join-Path $dl ("MainAudit_Plan_{0}.json" -f $stamp)
$reportPath = Join-Path $dl ("MainAudit_Report_{0}.md" -f $stamp)

$plan = @{ generated=$stamp; repos=@() }
$md = @("# Main Audit report ($stamp)"; "")

foreach($repo in $Repos){
  if(-not (Test-Path $repo)){ Warn "Skip missing repo $repo"; continue }
  Info "Analyzing $repo"
  $entry = [ordered]@{ repo=$repo; branches=@() }
  $branches = Get-OffMainBranches -Repo $repo | Where-Object { $_ -notmatch '^test/' -and $_ -notmatch '^draft/' }
  foreach($b in $branches){
    $entry.branches += (Analyze-Branch -Repo $repo -Branch $b)
  }
  $plan.repos += $entry

  $md += "## $repo"
  if(-not $entry.branches -or $entry.branches.Count -eq 0){
    $md += "_Nothing off main_"; $md += ""; continue
  }
  $md += "| branch | rec | stale(d) | files | overlap | type | ff | redundant | reason |"
  $md += "|---|---|---:|---:|---:|---|---|---|---|"
  foreach($b in $entry.branches){
    $md += ("| {0} | {1} | {2} | {3} | {4} | {5} | {6} | {7} | {8} |" -f `
      $b.name,$b.recommendation,$b.staleness_days,$b.files_changed, `
      $b.files_overlap_main,$b.type,$b.ff_possible,$b.redundant,$b.reason)
  }
  $md += ""
}

$plan | ConvertTo-Json -Depth 6 | Out-File -FilePath $planPath -Encoding utf8
$md -join "`r`n" | Out-File -FilePath $reportPath -Encoding utf8

Info "Wrote plan: $planPath"
Info "Wrote report: $reportPath"
Write-Host $planPath
Write-Host $reportPath
