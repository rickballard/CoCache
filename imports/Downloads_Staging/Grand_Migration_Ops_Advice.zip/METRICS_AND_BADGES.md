
# Metrics & Badges (lightweight)

- Add simple status badges to README if you want at-a-glance health:
  - CoCache smoke: `![smoke](https://github.com/<owner>/<repo>/actions/workflows/smoke.yml/badge.svg)`
  - Safety gate:   `![safety](https://github.com/<owner>/<repo>/actions/workflows/safety-gate.yml/badge.svg)`
  - Self-evolve:   `![evolve](https://github.com/<owner>/<repo>/actions/workflows/self-evolve.yml/badge.svg)`
