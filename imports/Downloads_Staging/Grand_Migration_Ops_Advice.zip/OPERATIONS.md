
# Daily Ops

## Trigger workflows on a non-default branch (very important)
The shim workflows live on your feature branch until merged. Use `--ref`:

```pwsh
# InSeed examples
gh workflow run smoke.yml       --repo rickballard/InSeed --ref polish/bpoe-centralize-20250915
gh workflow run self-evolve.yml --repo rickballard/InSeed --ref polish/bpoe-centralize-20250915
# Inspect recent runs for that branch
gh run list --repo rickballard/InSeed --limit 10 --branch polish/bpoe-centralize-20250915
gh run view <RUN_ID> --repo rickballard/InSeed -v
```

## Enable/disable nightly auto-commits per repo
```pwsh
gh variable set ENABLE_AUTOCOMMITS --repo <owner/repo> --body true   # enable
gh variable set ENABLE_AUTOCOMMITS --repo <owner/repo> --body false  # disable
```

## Roll out to another repo quickly (thin shim)
Add three files that delegate to CoCache (examples point at `@main`):

- `.github/workflows/smoke.yml`
- `.github/workflows/safety-gate.yml`
- `.github/workflows/self-evolve.yml`

If you need to pin to a specific CoCache commit, replace `@main` with `@<sha>`.
