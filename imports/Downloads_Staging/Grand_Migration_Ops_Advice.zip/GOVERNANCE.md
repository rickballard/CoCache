
# Governance / Source of Truth

- Canonical BPOE module + reusable workflows live in **rickballard/CoCache**.
- All repos are **thin shims**; they must not duplicate central logic.
- CoAgent / CoCacheGlobal may vendor copies for product packaging, but updates flow from CoCache.
