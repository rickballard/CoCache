
# Grand Migration — Ops Advice
Generated: 2025-09-15 21:10:29

Drop this folder into your Grand Migration tab. It contains concrete, terse guidance to operate and verify the new **CoCache**-centric BPOE setup.

**Source of Truth:** `rickballard/CoCache` (root). Repos thin-shim via `.github/workflows/*` that `uses:` CoCache reusable workflows.
