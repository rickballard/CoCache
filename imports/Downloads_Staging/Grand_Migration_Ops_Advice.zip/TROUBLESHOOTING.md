
# Troubleshooting

## `gh workflow run` returns 422 "Workflow does not have 'workflow_dispatch' trigger"
Cause: You're invoking the workflow on the default branch where the shim wasn't merged yet.
Fix: Add `--ref <feature-branch>` to target the branch that contains the shim.

## "could not find any workflows named self-evolve"
Same root cause; add `--ref <feature-branch>`, or use the workflow **filename**:
`gh workflow run self-evolve.yml --repo <owner/repo> --ref <branch>`

## Central workflow changes not picked up
Reusable workflows are referenced with `@main`. Ensure `rickballard/CoCache` has the new commit on `main`.
Check: `gh run list --repo rickballard/CoCache` or browse Actions.

## Self-evolve not committing
Ensure repo variable `ENABLE_AUTOCOMMITS=true`. The job prints the value at runtime.

## Image/link smoke fails on missing local assets
Either fix paths or remove the broken references. The smoke is conservative and only checks existence for local links by default.
