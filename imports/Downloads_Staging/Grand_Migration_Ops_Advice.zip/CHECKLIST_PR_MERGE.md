
# PR Merge Checklist (thin shim branches)

- [ ] CI green for `smoke` and `safety-gate` on the feature branch.
- [ ] `self-evolve` scheduled or manual run verifies it writes to `docs/bpoe/SESSION_STATUS.md` (if present).
- [ ] `ENABLE_AUTOCOMMITS` set as desired for this repo.
- [ ] Squash-merge feature branches; keep history tidy.
