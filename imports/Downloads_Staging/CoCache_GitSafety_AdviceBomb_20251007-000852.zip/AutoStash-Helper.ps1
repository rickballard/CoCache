
# PowerShell Script: AutoStash-Helper.ps1
$branch = git branch --show-current
Write-Host "Safely stashing all changes on branch: $branch"
git stash push -m "Auto-stash before risky action on $branch"
