
# PowerShell Script: Recover-Git-Safety.ps1
Write-Host "Reverting all uncommitted changes..."
git reset
git restore .
