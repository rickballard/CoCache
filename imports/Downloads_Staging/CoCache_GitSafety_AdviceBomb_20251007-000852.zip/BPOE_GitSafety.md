
# BPOE Wisdom: Git Safety in CoSuite Repos

## Principle: Always assume you will forget what was mid-flight.

**Mandate:**
Before running advice bombs or switching branches, always:

- `git status` and review untracked files
- `git stash push -m "Descriptive message"` if unsure
- Keep temp stash logs with timestamped notes
- Use unique filenames with YYYYMMDD-HHMMSS patterns

## Rationale:
- Prevents corruption of uncommitted work
- Eases recovery after accidental multi-session interference
