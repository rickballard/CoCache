# CoPong — Payload result
zip:   C:\Users\Chris\Downloads\YourTask__FROM_YourSession__.zip
time:  2025-09-21T23:02:39Z
exit:  0

## Log tail
Hello from sample at 2025-09-21T23:02:39Z
=== EXIT:   0
