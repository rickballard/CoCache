# Future Vision
- Visual cords (drag‑to‑pair) after Pair button MVP.
- Job library (parameterized recipes).
- Multi‑user panels (later).
- Connectors (Git/cloud/issue trackers).
