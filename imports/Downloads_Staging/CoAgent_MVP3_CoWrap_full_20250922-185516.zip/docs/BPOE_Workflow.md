# BPOE / Workflow

- Small, explicit, reversible payloads.
- Write `payload.log.txt`, `out.txt`, and human artifacts (e.g., `*.md`).
- Use `Set-StrictMode -Version Latest` and `$ErrorActionPreference='Stop'`.
