Set-Content -Encoding UTF8 out.txt 'CoWrap opened. See docs/'
