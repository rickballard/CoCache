# Handoff STATUS (MVP2 ➜ MVP3)

**Works now (MVP2)**: PS7 runner watches Downloads, runs ZIPs with `run.ps1`, CoPongs a summary; supports `_copayload.meta.json` and filename `__FROM_<session>__` hints.

**Next (MVP3)**: internal Download Manager + Runner, embedded AI/PS7 panes, Pair button, policy/consent UX, first‑run wizard + Intro Handshake.

**Risks**: terminal stability, long‑run streaming, consent UX, vendor login choices.
