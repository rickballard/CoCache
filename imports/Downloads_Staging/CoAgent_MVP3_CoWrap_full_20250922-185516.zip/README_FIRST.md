# CoAgent MVP3 CoWrap (handoff bundle)

**Purpose:** Drag‑into‑session bundle with everything to understand/continue CoAgent MVP3.

**Use**
1) MVP2 watcher: drop this ZIP in Downloads → `run.ps1` emits CoPong with pointers.
2) MVP3 container: open `docs/CoAgent_MVP3_Product_Description.md` and `docs/User_Guide.md`.
3) For copy/paste: `handoff/Intro_Handshake_Message.txt`.

**Non-destructive** — docs + samples only.
