# Placeholder for modules/CoFit/FUNDER_BRIEF.md

[Generated 2025-08-27T19:49:43.195833]