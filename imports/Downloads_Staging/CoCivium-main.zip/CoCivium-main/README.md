# CoCivium
Civic protocols and founding scrolls for CoCivium: aligning biological and synthetic minds via recursive ethical co-evolution.
