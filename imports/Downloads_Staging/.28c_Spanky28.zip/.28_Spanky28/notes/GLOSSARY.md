# Glossary
- CoWrap: compact, date-stamped handoff log.
- BPOE: Best Practically Obtainable Evidence.
- CoCache: central index of repos + CoWraps.
- Orchestrator: pairing/run harness `tools/Start-MVP3-Orchestrator.ps1`.
