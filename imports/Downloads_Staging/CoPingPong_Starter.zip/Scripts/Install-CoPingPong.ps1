# Install-CoPingPong.ps1
$docs = [Environment]::GetFolderPath('MyDocuments')
$modRoot = Join-Path $docs 'PowerShell\Modules'
$modDir  = Join-Path $modRoot 'CoPingPong'
New-Item -ItemType Directory -Force -Path $modDir | Out-Null
Copy-Item -Path (Join-Path $PSScriptRoot '..\Modules\CoPingPong\CoPingPong.psm1') -Destination $modDir -Force
$prof = $PROFILE
New-Item -ItemType Directory -Force -Path (Split-Path $prof) | Out-Null
if (Test-Path $prof) { Copy-Item $prof "$prof.bak_$(Get-Date -Format yyyyMMdd_HHmmss)" }
'Import-Module CoPingPong; Start-CoSession' | Add-Content -Path $prof
