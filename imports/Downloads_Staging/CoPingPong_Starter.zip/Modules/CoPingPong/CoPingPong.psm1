Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'
$global:CoTemp = Join-Path $HOME "Downloads/CoTemp"
New-Item -ItemType Directory -Force -Path $global:CoTemp | Out-Null

function Start-CoSession {
  param([string]$Name = (Get-Date -Format "yyyyMMdd_HHmmss"))
  $script:CoTranscript = Join-Path $global:CoTemp "CoSession_$Name.log"
  try { Stop-Transcript | Out-Null } catch {}
  Start-Transcript -Path $script:CoTranscript -Append | Out-Null
}

function Save-CoPong { param([int]$Tail = 150)
  $out = Join-Path $global:CoTemp ("CoPong_{0:yyyyMMdd_HHmmss}.md" -f (Get-Date))
  Get-Content $script:CoTranscript -Tail $Tail | Set-Content -Encoding UTF8 -Path $out
  Set-Clipboard -Value $out
}

function Save-CoPing {
  $clip = Get-Clipboard -Raw
  $out = Join-Path $global:CoTemp ("CoPing_{0:yyyyMMdd_HHmmss}.md" -f (Get-Date))
  $clip | Set-Content -Encoding UTF8 -Path $out
  Set-Clipboard -Value $out
}

if (Get-Module -ListAvailable PSReadLine | Out-Null) {
  Import-Module PSReadLine -ErrorAction SilentlyContinue
  Set-PSReadLineKeyHandler -Chord F6 -BriefDescription 'CoPong 150' -ScriptBlock {
    Save-CoPong -Tail 150; [Microsoft.PowerShell.PSConsoleReadLine]::AcceptLine()
  }
  Set-PSReadLineKeyHandler -Chord F7 -BriefDescription 'CoPing clipboard' -ScriptBlock {
    Save-CoPing; [Microsoft.PowerShell.PSConsoleReadLine]::AcceptLine()
  }
  Set-PSReadLineKeyHandler -Chord F8 -BriefDescription 'Insert BPOE template' -ScriptBlock {
    [Microsoft.PowerShell.PSConsoleReadLine]::Insert("Invoke-CoSafe ...")
  }
}
Export-ModuleMember -Function *
