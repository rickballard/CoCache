# CoPingPong Quickstart

This package sets up hotkeys to move text between PowerShell and ChatGPT.

## Keys
- F6 = CoPong (last 150 lines → file)
- F7 = CoPing (clipboard text → file)
- F8 = Insert BPOE template

Optional AHK v2 bridge:
- Ctrl+Alt+O → paste last CoPong (no Enter)
- Ctrl+Alt+Shift+O → paste + Enter
