# ISSUEOPS: CoPingPong Workflow

## PowerShell bindings
- F6 = CoPong 150
- F7 = CoPing clipboard
- F8 = Insert BPOE template

## AHK bridge
- Ctrl+Alt+O → paste CoPong
- Ctrl+Alt+Shift+O → paste + Enter
