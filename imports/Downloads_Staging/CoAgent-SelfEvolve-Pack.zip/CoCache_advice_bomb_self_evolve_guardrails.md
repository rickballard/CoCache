# Advice Bomb: Self‑Evolve guardrails & email hub

- Centralize SMTP/IMAP + digest in CoCache.
- Aggregate weekly reports across repos.
- Optional IMAP 'OK' detection; write back to issues.
- Enforce incapacity policy after 1y+1d.
