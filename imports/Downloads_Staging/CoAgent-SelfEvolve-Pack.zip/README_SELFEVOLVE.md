# CoAgent Self‑Evolve Pack

Generated: 2025-09-15 22:49:12

See scripts/Install-SelfEvolve.ps1.
