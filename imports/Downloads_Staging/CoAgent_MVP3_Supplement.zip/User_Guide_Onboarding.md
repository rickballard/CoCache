## User Guide — Onboarding
When installed, CoAgent shows the Intro Handshake message. Pair AI and PS7 panels manually.
