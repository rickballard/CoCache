## CoAgent MVP3 Product Description
A desktop container for AI+PS7 orchestration with Intro Handshake onboarding.
