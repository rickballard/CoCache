## Successor Session Pointers
Future sessions should:
- Harden security.
- Expand UX beyond single AI-human pair.
