## BPOE Learnings
- Autostart runner optional.
- Payloads require run.ps1.
- CoPong returns summaries.
