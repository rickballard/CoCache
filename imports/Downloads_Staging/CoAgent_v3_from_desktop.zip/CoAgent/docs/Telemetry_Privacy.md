# Telemetry & Privacy (MVP)
- Default: **off** (no network). Local-only metrics to CSV/MD.
- Opt‑in: aggregate metrics (TTFD, success rates). No code/PII.
- Clear controls; easy off switch.
