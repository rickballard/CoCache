# Runtime Placeholder

This folder optionally carries your local CoTemp runtime (e.g., `Join-CoAgent.ps1`, `CoAgentLauncher.ps1`, `common`, `scripts`).

- Copied any available runtime artifacts from uploads: **yes**.
- If "no", copy your existing files from `Downloads\CoTemp` after unzipping.
