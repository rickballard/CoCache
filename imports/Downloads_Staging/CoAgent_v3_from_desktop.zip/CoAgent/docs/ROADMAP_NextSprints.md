# Roadmap (Next Sprints)

**S1 (now)**: stabilize runtime, docs, smokes, two-tab launcher  
**S2**: watcher debounce/lockfile, compact-on-exit, minimal telemetry  
**S3**: packaging (zip/winget), consent prompts, basic policy gates  
