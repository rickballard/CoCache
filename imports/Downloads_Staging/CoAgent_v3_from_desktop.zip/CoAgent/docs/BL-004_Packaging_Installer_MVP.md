﻿# BL-004 — Packaging & Installer (MVP)
Status: TODO | Owner: Planning
- [ ] Produce signed ZIP with runtime/
- [ ] README_FIRST sanity checklist
- [ ] Post-install smoke DO
