﻿# BL-003 — Debounce & Lockfile for Watchers
Status: TODO | Owner: Planning
- [ ] Introduce per-session lockfile
- [ ] Backoff on flapping files
- [ ] Telemetry: dropped/merged events
