# Roadmap

**Sprint 1 (now)**: stabilize runtime, docs, smokes, two-tab launcher  
**Sprint 2**: watcher debounce/lockfile, compact-on-exit, minimal telemetry  
**Sprint 3**: packaging prototype (zip/winget), consent prompts, basic policy gates
