﻿# CoAgent (skeleton)

This is a local skeleton to start shaping the repo before publishing.

- scripts/ contains the CoTemp runtime and utilities.
- docs/ holds RFCs, runbooks, PRDs.
