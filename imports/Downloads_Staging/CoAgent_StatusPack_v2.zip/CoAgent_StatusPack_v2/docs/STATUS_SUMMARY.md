# STATUS_SUMMARY (Sprint‑1)

- One watcher per session enforced (Planning/Migrate).
- DO/Note bridge working (`Drop-CoDO`, `Send-CoNote`).
- Smoke DO prints timestamp and `$PSVersionTable.PSVersion`.
- RepoScan (read‑only) fixed generator; outputs UTF‑8 clean list.
- Launcher opens two Chat tabs; greetings present.

Use `scripts/Capture-StatusSnapshot.ps1` to generate a machine snapshot folder on Desktop.
