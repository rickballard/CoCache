# Decision Log (Template)

- **ID:** DEC-YYYYMMDD-###
- **Title:** 
- **Owner:** 
- **Stakeholders:** 
- **Context:** 
- **Options Considered:** 
- **Decision:** 
- **Risks & Mitigations:** 
- **Dissent / Appeal Path:** 
- **Review Date:** 
- **Links / Evidence:** 

> Store each decision as a standalone markdown file under `decisions/` and add to an index.
