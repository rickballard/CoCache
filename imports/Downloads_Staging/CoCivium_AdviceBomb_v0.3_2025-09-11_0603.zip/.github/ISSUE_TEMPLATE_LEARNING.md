
## Learning Log Entry
**Area:** BP / Workflow / Grooming / Dashboard / Other  
**Mistake:**  
**Impact:**  
**Fix / Mitigation:**  
**Evidence / Links:**  
**Follow-up Tasks:**  
