
# Ethical Futures Sandbox — Hooks
Use standardized sim bundles to model short/mid/long outcomes by stakeholder.  
Attach result packets to policy PRs before merge.

**Bundle Fields (min):**
- assumptions.md, scenarios.json, models.meta.json, thresholds.json, results.json, risk_register.md
