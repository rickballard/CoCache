
# Dashboard Staging Playbook
**Seed:** Repro Rate, Attribution Integrity, Appeal Latency.  
**Growth:** CanonScore, Forecast Skill, Drift Alerts, Incident MTTR.  
**Canon:** Parity Progress, Fork Health, Treaty Surfaces.

Roll out metrics by maturity; avoid vanity dashboards at seed stage.
