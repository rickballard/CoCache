
# README Multiplexing
Maintain small deltas across: default (vision), exec (KPI/ROI), dev (schemas/CLI), edu (civics).  
Use repo var or build step to select `README.current.md` → symlink to `README.md`.
