# MIGRATION ACTIONS

- Place `MYTHOS_Hybridity_Gate.md` in `docs/pillars/` or equivalent.
- Place `ONE_PATH_GUIDE.md` in `docs/ops/` and link it from CONTRIBUTING.md.
- Use `AGENT_AUTH_PRESET.schema.json` in future CoAgent onboarding kits.
- Consider `README_INSERT_HybridGateway.md` as an optional top-level readme inclusion.
