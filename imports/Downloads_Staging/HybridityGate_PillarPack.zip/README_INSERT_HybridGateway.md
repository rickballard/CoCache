## Hybrid Gateway Protocol (HGP) — “The One Path”

CoCivium assumes users enter via Human+AI pairing. This path enables simplified onboarding, congruent input packaging, and faster co-evolution.
