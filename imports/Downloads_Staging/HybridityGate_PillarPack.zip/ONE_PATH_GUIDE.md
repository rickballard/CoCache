# ONE_PATH_GUIDE.md

## Summary

This document describes the default onboarding strategy into CoCivium via a hybrid AI+Human protocol known as the "One Path". It defines the expectations and behavior of AI agents assisting human contributors...
