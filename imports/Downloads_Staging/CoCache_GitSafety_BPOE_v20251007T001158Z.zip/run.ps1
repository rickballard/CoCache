# DO — Apply Git safety reset (CoCache BPOE v20251007T001158Z)
Set-Location "$env:USERPROFILE\Documents\GitHub\CoCache"

Write-Host "⚠️ Stashing skipped: File conflict likely in BN_Canonical_Pull.ps1 or related."
Write-Host "✔️ Resetting index and working tree..."
git reset

Write-Host "✔️ Restoring all files to HEAD state..."
git restore .

Write-Host "✅ Git safety recovery complete."
