# IdeaCards — Batch 6 (51–54)

**Theme:** Government recovery & reform using CoCivium primitives.

- 51 CiviReform Kit — staged, auditable reboot for captured/hollowed agencies
- 52 Public Service Ledger — skills/roles map with merit rails
- 53 Crisis Registry & Auto‑Sunset — emergency powers audit
- 54 CiviContracts — policy‑as‑code with civic tests

Imported from the ongoing CoCivium Idea Scratchpad session.
