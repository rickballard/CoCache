# Advice Bombs (CoCivium linkage)

- Keep CoCivium.org restructure out of this session; leave hooks only.
- Pages: surface links “Contribute to CoCivium” (opens training-first guide).
- When CoCivium site migrates, update one variable: `COCIVIUM_BASE`.
