# CoAgent · Help (MVP)
Open CoAgent and it will start in **Training Mode** with three tabs:
1) Welcome (brand + what CoAgent does)
2) Guided Training (click-to-advance steps)
3) Status (self-check + “What just happened?”)

Troubleshooting is plain-English; no scripts exposed to end users.
