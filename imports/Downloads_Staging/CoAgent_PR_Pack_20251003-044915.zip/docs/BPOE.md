# BPOE · FAQ (public)
- What is BPOE? “Best Path of Execution” — the quickest happy path.
- Privacy: metrics are opt-in and redact PII; you can delete at any time.
