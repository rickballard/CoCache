# Training · Walkthrough (for maintainers)
End-users never see scripts; this is for repo owners validating the flow.
- Double-click **Run-CoAgent.cmd** in the product build.
- Complete on-screen training; the status tray shows each step.
