This pack adds product stubs, plans, and a minimal launcher.
Use tools/CoWrap.ps1 to open a branch and draft PR.
