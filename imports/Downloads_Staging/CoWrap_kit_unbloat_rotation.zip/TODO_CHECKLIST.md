# Next-Session Checklist (250904a)

- [ ] Append rotation rule to `docs/bpoe/PREFERENCES.md` and merge via PR.
- [ ] (Optional) Extend `scripts/oe_status.ps1` with recent commit churn (files changed / lines added for last N commits).
- [ ] Normalize any fresh intake into `intake/*/session_250904a`.
- [ ] Continue polishing migration artifacts; keep CoWraps concise.
- [ ] Re-run trust & OE workflows; ensure one-liner appears in PR thread.
