---
session: "Grand Migration Cleanup — rotation & bloat guard"
date: 2025-09-04
summary: "Dialogue spill observed and not captured by OE metrics. Propose rotation rule + OE refinement. Repo status steady; continuing migration/polish in new session 250904a."
outcomes:
  - "Added CI: oe-status (20m), trust_scan, triage-guard, intake-validate."
  - "BPOE prefs: 20-line scrollable DO/CoPong blocks; demarc lines inside DO; prompt reset before '# END DO'; forbid chat schedulers."
  - "OE one-liner + Trust flag integrated; repo-level snapshots only."
  - "Docs: Remote AI Guide, Trust Protocol, Prompt Templates, ISSUEOPS quick sheet."
  - "Master Plan v0 committed; streams scaffolded; IdeaCards triage/stream keys added."
observations:
  - "Spill occurred in dialogue; OE did not flag because it only measures repo artifacts."
  - "Need convention-based rotation and external (assistant-side) spill sensing without repo persistence."
decisions:
  - "Rotate to new session suffix when ≥4 DO blocks in a run OR OE SessionBloat ≥ 60% OR on operator command."
  - "Keep responses ≤ ~12 lines unless code; always close DO with Set-Location $HOME."
next_session_hint: "Normalize new artifacts into intake/*/session_250904a; keep DOs tight; rely on OE_STATUS.md + TRUST_STATUS.md; rotate per rule."
---

# Session Rotation & Bloat Guard

**OE snapshot:** `OE Status: Efficiency~56% SessionBloat~44% ErrorCount~0 FilesAccessed~11 FilesIC~9 FilesCW~2 Stage~0.17MB Map~OK Trust~OK`

## What we did (highlights)
- CI + BPOE scaffolding landed (trust/OE/triage/map).
- Scrollable DO/CoPong blocks with copy button.
- Repo-only status policy (no per-user persistence).
- Master Plan v0 and stream scaffolding; IdeaCards annotated.

## Why OE missed the spill
OE currently tracks repo-side metrics only: total normalized MD files/lines, staging size, map presence, and BPOE errors. Chat verbosity is intentionally excluded to avoid per-user persistence. Result: dialogue spill doesn’t change OE.

## Proposed refinements
1. **Rotation rule (convention):** rotate when ≥4 DOs, or `SessionBloat ≥ 60%`, or on demand.
2. **Assistant-side (ephemeral) spill sensing:** user AIs enforce a soft cap on visible prose per message (e.g., ~12 lines) and suggest rotation when exceeded. No repo writes.
3. **Repo-side proxy signal (optional):** extend `oe_status.ps1` to include “recent commit churn” (files/lines touched last N commits) to approximate activity heat, while keeping chat out of repo.

## Next actions (short list)
- Add rotation rule to `docs/bpoe/PREFERENCES.md` (see snippet below).
- Consider OE extension to include recent commit churn (optional).
- Continue migration/polish under session `250904a`.

## Snippets

### Preferences patch (append)
```
- Rotate sessions when any holds:
  - ≥4 DO blocks since last rotation, or
  - OE SessionBloat ≥ 60%, or
  - operator requests rotate.
- Response discipline: keep non-code replies ≲ 12 lines.
```

### One-off rotation DO (copy/paste into shell)
```powershell
# Title: Rotate session (convention-only)
$CoCache = "$HOME\Documents\GitHub\CoCache"
$base = Get-Date -Format 'yyMMdd'; $sfx='a'
while (Test-Path (Join-Path $CoCache ("intake\cowraps\session_01" -f $base,$sfx))) { $sfx = [char]([byte][char]$sfx + 1) }
Write-Host ("Next session: 250904a")  # change if you need a different suffix
```

