# Workflow Learnings (not all codified yet)

- Prefer **single-quoted here-strings** in CI YAML from PowerShell to avoid accidental `$` expansion.
- Keep demarc lines **inside** DO blocks only if your shell UI needs them; otherwise rely on numbered/timestamped DO headers.
- Always restore prompt to a safe location (`Set-Location $HOME`) before `# END DO`.
- Remote AIs should show `index/OE_STATUS.md` verbatim and interrupt only on: SessionBloat ≥ 60%, ErrorCount > 0, or Trust != OK.
- Trust scanning is policy-driven (`docs/bpoe/trust/{allow,warn/deny}.txt`) and repo-level; user-specific scans remain ephemeral.
