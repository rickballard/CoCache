Place final curated logos in /assets/img/exemplars/<slug>.png (160x160 transparent). Use scripts\prep-logo.ps1 to normalize. See audit.csv and staged/ for candidates found in your Downloads.
