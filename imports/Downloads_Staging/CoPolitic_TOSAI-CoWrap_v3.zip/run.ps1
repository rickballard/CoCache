Write-Host 'Loaded CoWrap v3 for CoPolitic → TOS-AI' -ForegroundColor Cyan
Write-Host 'See CoWrap.md, ACTIONS.md, MANIFEST.json, snapshot/, logos/, scripts/, .github/' -ForegroundColor Cyan
