## What changed?
-

## Why?
-

## Checks
- [ ] UTF-8 writes only
- [ ] Pages cache sanity (scripts/check-cache.ps1)
- [ ] No regressions to TOS-AI copy or links
