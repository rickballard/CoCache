# Normalize staged candidates into repo assets and commit (optional)
param([switch]$Push=$true)
$repo = (Resolve-Path "$PSScriptRoot\..\snapshot\..").Path  # parent of snapshot = wrap root; NOT your live repo
# We will try to detect your live repo by walking up from the current location if it is a git repo
try { $top = (git rev-parse --show-toplevel) } catch { throw "Run this from your live repo root to apply logos." }
$dest = Join-Path $top "assets\img\exemplars"; New-Item -ItemType Directory -Force $dest | Out-Null
$staged = Join-Path (Split-Path -Parent $PSScriptRoot) "logos\staged"
Get-ChildItem $staged -File | ForEach-Object {
  $name = $_.BaseName -replace '-candidate$',''
  $out  = Join-Path $dest ($name + ".png")
  & "$PSScriptRoot\prep-logo.ps1" -Src $_.FullName -Out $out
}
git add $dest
git commit -m "assets: normalize exemplar logos from CoWrap v3"
if($Push){ git push }
Write-Host "Applied and (optionally) pushed normalized logos."
