# Re-run the audit against Downloads and refresh logos\audit.csv and logos\staged\
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$wrap = Split-Path -Parent $root
$logos = Join-Path $wrap "logos"; $staged = Join-Path $logos "staged"
New-Item -ItemType Directory -Force $logos | Out-Null
Remove-Item $staged -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force $staged | Out-Null
# (lightweight re-implementation: looks for *-candidate files and refreshes CSV)
$download = "$HOME\Downloads"
$cands = Get-ChildItem $download -Recurse -File -Include *.png,*.jpg,*.jpeg,*.svg -ErrorAction SilentlyContinue
$slugs = @('openai','arc','chai','anthropic','redwoodresearch','github','sff','inseed','foresightinstitute','macarthurfoundation','skollfoundation','osf','govai','rand','nist','oecdai','carnegieendowment','maxbarry','bretvictor','chrislehane','gatesfoundation','emersoncollective','mitmedialab')
$rows = @()
foreach($s in $slugs){
  $hit = $cands | Where-Object { $_.Name -like "*$s*" } | Select-Object -First 1
  if($hit){ Copy-Item $hit.FullName (Join-Path $staged ($s + '-candidate' + $hit.Extension.ToLower())) -Force }
  $rows += [pscustomobject]@{ slug=$s; candidate=$hit?.FullName; ext=$hit?.Extension.TrimStart('.'); note= (if($hit){'candidate staged'}else{'no candidate'}) }
}
$rows | Export-Csv (Join-Path $logos 'audit.csv') -NoTypeInformation -Encoding UTF8
Write-Host "Refreshed logos audit."
