# CoWrap — CoPolitic (CoCEO → **TOS-AI**) — 2025-09-25T11:13:27.6521962-04:00

## Snapshot
- Repo: 
- Branch:  @ 
- Dirty working copy: no

### Recent commits (≤30)


### Working-copy diff summary


---

## Done ✅
- Rename: CoCEO → **TOS-AI (Transition Office Steward — AI pivots)**.
- Docs: docs/defs/TOS-AI.md, docs/defs/CoCEO.md (stub), docs/GLOSSARY.md.
- Homepage: explainer chip, checklist card, CTA (prefilled issue), legacy /coceo.html redirect.
- Roles: /roles/tos-ai.html + footer link.
- Exemplars: grid wired; JS **initials-badge fallback** for missing logos; some logos normalized.
- SEO basics: canonical + meta description.

## NOW 🧭
1) **Logo completion** — see logos/audit.csv and logos/staged/. Normalize to 160×160 transparent PNG (dark-on-white).
2) **Roles hub** — add /roles/index.html to this repo (optional script in this bundle).
3) **Cache sanity** — run scripts/check-cache.ps1 after deploy.

## NEXT 🚀
- Auto-build TOS-AI one-pager PDF from MD (GitHub Action or local).
- Link-checker Action + badge.
- A11y polish (focus rings, contrast).

## LATER ✨
- Mini search for roles/docs.
- i18n scaffolding.
- Metrics-lite badge.

## Ideas
- “Steward, not savior” callout; small **timeline** under checklist; **risk register** starter in TOS-AI card.
- Role taxonomy stubs (TOS-Sec, TOS-Data, CoPMO, CoOps).

## BPOE
- Idempotent PS edits; always UTF-8.
- Pages deploy watch via gh run list --workflow="pages-build-deployment".
- Cache validation by Age/ETag/X-Served-By.
- Respect branch protection (MeritRank PR-only vs CoPolitic direct push).
