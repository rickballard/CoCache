## CoAgent (product)
- Roadmap → _local repo_: **CoAgent/docs/roadmap/ROADMAP.md**
- Index → _local repo_: **CoAgent/docs/index/COAGENT-INDEX.md**
