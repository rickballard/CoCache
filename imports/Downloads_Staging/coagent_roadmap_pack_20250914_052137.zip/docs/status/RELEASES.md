# CoAgent — Release Notes
- v0.1.0 (TBD): Local runner, trace log, FS/HTTP adapters.
- v0.2.0 (TBD): Policy engine, roles, secrets vault, observability.
