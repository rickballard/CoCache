# CoAgent — One-Pager
**Tagline:** Accountable, policy-aware automation for hybrid society.
**Users:** ops, policy/compliance, researchers, integrators.
**Why now:** safe automation requires provenance and consent.
**What:** local runner → policy runtime → multi-agent supervisor → signed modules.
