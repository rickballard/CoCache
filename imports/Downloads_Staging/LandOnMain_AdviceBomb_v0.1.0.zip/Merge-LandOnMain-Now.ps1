param(
  [string[]]$Repos = @(
    "$env:USERPROFILE\Documents\GitHub\CoCivium",
    "$env:USERPROFILE\Documents\GitHub\Godspawn",
    "$env:USERPROFILE\Documents\GitHub\CoAgent"
  ),
  [switch]$UseGH,
  [switch]$SquashIfNoFF,
  [switch]$PruneMerged,
  [switch]$WhatIf
)

function Info($m){ Write-Host "[INFO] $m" -ForegroundColor Cyan }
function Warn($m){ Write-Host "[WARN] $m" -ForegroundColor Yellow }

$IncludePatterns = @(
  '^feature/faiths-',
  '^feature/congruence-',
  '^feature/faiths-hero-',
  '^feature/coref-indexing-setup$',
  '^feature/godspawn-p3-advice-',
  '^feature/corender-ci-fallbacks$',
  '^chore/cowrap-',
  '^chore/remove-stubs-'
)
$ExcludePatterns = @('^test/','^draft/')

foreach($repo in $Repos){
  if(-not (Test-Path $repo)){ Warn "Skip missing repo $repo"; continue }
  Push-Location $repo
  try{
    Info "Repo: $repo"
    git fetch origin --prune
    git checkout main
    git pull --ff-only origin main

    $branches = git branch -r --no-merged origin/main | ForEach-Object { $_.Trim() } |
      Where-Object { $_ -like 'origin/*' } |
      ForEach-Object { $_ -replace '^origin/','' }

    $targets = @()
    foreach($b in $branches){
      if($ExcludePatterns | Where-Object { $b -match $_ }){ continue }
      if($IncludePatterns | Where-Object { $b -match $_ }){ $targets += $b }
    }

    if(-not $targets){ Info "No matching branches to land"; continue }

    foreach($b in $targets){
      Info "Landing $b -> main"

      if($UseGH){
        try{
          $pr = gh pr list --state open --head $b --json number | ConvertFrom-Json
          if($pr -and $pr.number){
            $n = $pr.number
            Info "Merging PR #$n via gh (squash, delete branch)"
            if(-not $WhatIf){ gh pr merge $n --admin --squash --delete-branch }
            continue
          }
        } catch { Warn "gh pr lookup failed for $b; using git merge." }
      }

      $ffok = $false
      try{
        if(-not $WhatIf){ git merge --ff-only "origin/$b" }
        $ffok = $true
        Info "Fast-forward merge applied from origin/$b"
      } catch {
        Warn "Fast-forward not possible for $b"
      }

      if(-not $ffok){
        if($SquashIfNoFF){
          Info "Attempt squash merge for $b"
          if(-not $WhatIf){
            git merge --squash --no-commit "origin/$b"
            git commit -m ("BPOE: land {0} to main (squash)" -f $b)
          }
        } else {
          Warn "Skipping $b (no FF and squash disabled)"
          continue
        }
      }

      if(-not $WhatIf){ git push origin HEAD:main }

      if($PruneMerged){
        try{
          $isMerged = (git branch -r --merged origin/main | Select-String -SimpleMatch "origin/$b")
          if($isMerged){
            Info "Deleting remote branch $b"
            if(-not $WhatIf){ git push origin --delete $b }
          }
        } catch {
          Warn "Could not delete $b: $($_.Exception.Message)"
        }
      }
    }
  } finally { Pop-Location }
}
