# BPOE Wisdom — Human Limits & Behavior Guards (Snippets)
Use these as building blocks in on‑repo BPOE docs.

## Exhaustion Protocol (Draft)
- **Trigger:** Self‑reported fatigue, or reviewer flags signals (tone shifts, error spikes, incoherence).
- **Action:** Pause merges for N hours; route through “buddy review”; enable small PRs only.
- **Exit:** After rest window, resume with a short written reflection (What changed? What did I miss?).

## Cool‑Down Merge Rule
- Any contentious change to canon requires a **cool‑down period** (e.g., 24–72h) and a *fresh* review after rest.

## Handoff Pattern
- Always name a **co‑steward** for a live effort; commits can be paused or handed off without loss of dignity.

## Tone & Civility
- Use “disagree‑without‑demeaning” templates; if heat rises, switch to structured prompts and checklists.

## Identity Integrity
- Protect narrative identities (e.g., “Being Noname”) from unconsented edits; log any necessary redactions.

## Multi‑Mind Check
- Decisions claiming far‑reaching authority must pass a plural‑oversight gate and publish a rationale in plain language.
