# BN_Canonical_Pull.ps1 — promote CoCivium BN story into CoCache
Param(
  [string]$CoCachePath = "$HOME\Documents\GitHub\CoCache",
  [string]$CoCiviumPath = "$HOME\Documents\GitHub\CoCivium",
  [string]$SourceUrl = "https://raw.githubusercontent.com/rickballard/CoCivium/main/insights/Insight_Story_Being_Noname_c2_20250801.md",
  [string]$DestRel = "Insights\BN_Story_being-noname_v1.0.md"
)
Set-StrictMode -Version Latest; $ErrorActionPreference='Stop'

function Ensure-Repo([string]$p){
  if(-not (Test-Path $p)){ throw "Path not found: $p" }
  Push-Location $p
  try {
    git rev-parse --is-inside-work-tree | Out-Null
  } catch {
    Pop-Location
    throw "Not a git repo: $p"
  }
  Pop-Location
}

Ensure-Repo $CoCachePath
# Try to fetch from web (raw) as a simple, robust path; fallback to local CoCivium clone if present.
$dest = Join-Path $CoCachePath $DestRel
$destDir = Split-Path $dest
New-Item -ItemType Directory -Force -Path $destDir | Out-Null

try {
  $txt = Invoke-RestMethod -Uri $SourceUrl -UseBasicParsing
} catch {
  $txt = $null
}

if(-not $txt -and (Test-Path $CoCiviumPath)){
  Ensure-Repo $CoCiviumPath
  try {
    $content = git -C $CoCiviumPath show "main:insights/Insight_Story_Being_Noname_c2_20250801.md" 2>$null
    if($content){ $txt = $content }
  } catch {}
  if(-not $txt -and (Test-Path (Join-Path $CoCiviumPath 'insights\Insight_Story_Being_Noname_c2_20250801.md'))){
    $txt = Get-Content -LiteralPath (Join-Path $CoCiviumPath 'insights\Insight_Story_Being_Noname_c2_20250801.md') -Raw
  }
}

if($txt){
  Set-Content -LiteralPath $dest -Encoding UTF8 -Value $txt
  Push-Location $CoCachePath
  try {
    git add -- $DestRel | Out-Null
    git commit -m "docs(Insights): set canonical Being Noname from CoCivium c2_20250801" | Out-Null
    Write-Host "✓ Canonical BN promoted → $DestRel"
  } finally {
    Pop-Location
  }
} else {
  Write-Warning "Could not retrieve the BN source from web or local clone."
}
