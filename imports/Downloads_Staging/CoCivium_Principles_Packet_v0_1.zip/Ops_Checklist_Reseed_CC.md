# Ops Checklist — Reseed CC into CoCivium
**Objective:** Reseed the CC principles and Megascroll seed into the CoCivium repo, minimally and reversibly.

## 0. Preflight
- Ensure you are **inside the repo** before running scripts:
  - Windows PowerShell: `Set-Location 'C:\Users\Chris\Documents\GitHub\CoCache'`
  - Check: `git rev-parse --show-toplevel` (should print the repo path)

## 1. Bring over the seed files
- Copy the following into the CoCivium repo (or subfolder):
  - `.canon.CoCivium_Principles_v0.1.md`
  - `.cc.CC_Megascroll_Seed_v0.1.md`
  - `_Filename_Conventions.md`
  - `BPOE_Wisdom_Snippets.md`

## 2. Wire the builder
- Add a simple assembler or build step that pulls “core” sections into the Megascroll.
- Keep sources listed in an appendix.

## 3. Guardrails
- Add pre‑commit checks for canonical names (see example hook in prior messages).
- Require 2+ reviewers for any change to `.canon.*` files; queue changes during cooldowns.

## 4. Announce
- Open a PR titled: **“Reseed: CC principles + megascroll seed (v0.1)”** with a short rationale and how to review.

Everything should be reversible in one PR.
