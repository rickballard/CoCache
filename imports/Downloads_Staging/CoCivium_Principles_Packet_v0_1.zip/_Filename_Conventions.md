# File Naming Conventions (Draft)
Goal: communicate role and immutability at a glance, while staying **Windows‑safe**.

## Prefixes
- `.canon.` — **Canon** material (C5/C4). Examples:
  - `.canon.CoCivium_Principles_v0.1.md`
- `.cc.` — **CC component** included in Megascroll builds.
  - `.cc.CC_Megascroll_Seed_v0.1.md`
- `_` — **Highlighted readable** (front‑facing/marketing/outreach).
  - `_Welcome_to_CoCivium.md`

> Note: Avoid filenames beginning with two literal dots `..` since `..` is a path token on many systems.

## Suffixes
- `_vX.Y` for authored versioning; rely on Git for history.
- Use `-core` when an excerpt is the authoritative *core* used by assemblers.

## Labels in Front‑Matter (optional)
```yaml
role: canon|cc|highlight
canon_level: C5|C4|C3|C2|C1|C0
```
