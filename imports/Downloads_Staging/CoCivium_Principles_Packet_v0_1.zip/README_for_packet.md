# CoCivium Principles Packet (v0.1)
Generated: 2025-10-06 17:40 UTC

This packet includes:
- `_APOLOGY_PACKET.md` — pasteable message for parallel sessions.
- `.canon.CoCivium_Principles_v0.1.md` — initial principles list with immutability grades.
- `.cc.CC_Megascroll_Seed_v0.1.md` — scaffolding/seed for the CC Megascroll.
- `_Filename_Conventions.md` — proposed file naming scheme (safe on Windows).
- `Ops_Checklist_Reseed_CC.md` — steps to reseed CC content back into the CoCivium repo.
- `BPOE_Wisdom_Snippets.md` — human limits, rest, and behavior-guard snippets for BPOE.
- `BN_Canonical_Pull.ps1` — pulls the CoCivium Being Noname story into CoCache (canonical path).

All files are drafts meant for immediate collaboration and evolution.
